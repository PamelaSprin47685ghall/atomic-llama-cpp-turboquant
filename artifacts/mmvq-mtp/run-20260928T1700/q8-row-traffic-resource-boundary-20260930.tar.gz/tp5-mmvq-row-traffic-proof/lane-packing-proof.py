import json

results = []
for rows in (4, 8):
    tasks = [(t // 40, t % 40, t % 64, t // 64) for t in range(rows * 40)]
    assert sorted((r, s) for r, s, lane, iteration in tasks) == [
        (r, s) for r in range(rows) for s in range(40)
    ]
    assert all(0 <= lane < 64 and 0 <= s * 8 <= 312 for r, s, lane, iteration in tasks)
    for row in range(rows):
        restored = {
            (lane - (row * 40) % 64) % 64: s
            for r, s, lane, iteration in tasks if r == row
        }
        assert restored == {s: s for s in range(40)}
    results.append({
        "rows": rows,
        "valid_slices": rows * 40,
        "packed_passes": (rows * 40 + 63) // 64,
        "original_B_preload_passes": 1,
        "requirement": "Inverse per-row lane rotation and additional B caching or reloads",
    })
print(json.dumps(results, indent=2))
