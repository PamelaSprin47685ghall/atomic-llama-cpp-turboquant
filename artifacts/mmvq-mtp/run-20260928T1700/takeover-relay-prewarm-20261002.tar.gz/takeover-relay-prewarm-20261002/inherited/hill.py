#!/usr/bin/env python3
import argparse
import collections
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import re
import signal
import statistics
import subprocess
import time
import urllib.error
import urllib.request

BIN = Path('/var/tmp/tp5-final-build/bin/llama-server')
TARGET = '/home/kunweiz/models/Qwen3.8-Flash-Next-APEX-I-Compact/Qwen3.8-Flash-Next-APEX-I-Compact-00001-of-00006.gguf'
DRAFT = '/home/kunweiz/models/Qwen3.8-Flash-Next-MTP/mtp-Qwen3.8-Flash-Next-Q4_K_M.gguf'
ROOT = Path('/var/tmp/tp5-mmvq-hill')
PORT = 8175
NP = 128
PROMPTS = [
    '请用八句话简要介绍健康减重原则、每周运动安排、饮食建议和睡眠误区。',
    'Explain how a hash table handles collisions and resizing. Compare separate chaining with open addressing, including deletion and load factor. Give a concise worked example.',
]
REGION = re.compile(r'\[vulkan-region-policy\] backend=(\S+) family=(\S+) fused=1 mmvq_mask=(\d+) shared_q8_1=(\d+)')
POLICY = re.compile(r'\[vulkan-mmvq-policy\] backend=(\S+) mode=(\S+)')
SERVER = None


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def config(policy='auto', depth=1, knobs=None, sampling=True, pmin=0.0):
    return dict(policy=policy, depth=depth, knobs=knobs or {}, sampling=sampling, pmin=pmin)


def http(path, payload=None, timeout=180):
    data = None if payload is None else json.dumps(payload, ensure_ascii=False).encode()
    req = urllib.request.Request(f'http://127.0.0.1:{PORT}{path}', data=data,
                                 headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=timeout) as response:
        return json.load(response)


def stop_server():
    global SERVER
    if SERVER is None:
        return
    process, log = SERVER
    if process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=10)
    log.close()
    SERVER = None


def interrupted(signum, frame):
    stop_server()
    raise SystemExit(128 + signum)


def trial(label, cfg, diagnostic=False, repeats=2):
    global SERVER
    directory = ROOT / label
    directory.mkdir(parents=True, exist_ok=False)
    env = dict(PATH='/usr/bin:/bin', HOME=os.environ.get('HOME', '/home/kunweiz'),
               LD_LIBRARY_PATH=str(BIN.parent), RADV_DEBUG='nobolist',
               GGML_VK_FORCE_MMVQ='1' if cfg['policy'] == 'forced' else '0',
               GGML_VK_DISABLE_MMVQ='1' if cfg['policy'] == 'disabled' else '0',
               GGML_VK_SMALL_Q8_COLUMNS='1', GGML_MTP_KV_ONLY='1',
               GGML_TP5_MTP_DRAFT_SINGLE_GPU='1', GGML_TP5_QSA_HEADMAP='1',
               GGML_TP5_GDN_HEADMAP='1', GGML_TP5_REPLICATE_ATTN='0')
    env.update(cfg['knobs'])
    if diagnostic:
        env['GGML_TP5_RELAY_DEBUG'] = '1'
    cmd = [str(BIN), '-dev', 'Vulkan0,Vulkan1,Vulkan2,Vulkan3,Vulkan4',
           '--split-mode', 'tensor', '--fit', 'off', '-ngl', '999', '-c', '768',
           '-b', '32', '-ub', '32', '--no-mmap', '--no-host', '-np', '1',
           '--host', '127.0.0.1', '--port', str(PORT), '--model', TARGET,
           '--tp5', 'qwen4exp-af', '--tp5-latebind', 'off']
    if cfg['depth']:
        cmd += ['-md', DRAFT, '--spec-type', 'draft-mtp', '--spec-draft-n-max', str(cfg['depth']),
                '--spec-draft-p-min', str(cfg['pmin']),
                '--spec-draft-backend-sampling' if cfg['sampling'] else '--no-spec-draft-backend-sampling']
    save(directory / 'manifest.json', dict(config=cfg, command=cmd, environment=env,
         diagnostic_only=diagnostic, prediction_tokens=NP, start_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())))
    # Never terminate unrelated services or globally pkill llama-server.
    try:
        http('/health', timeout=1)
    except (urllib.error.URLError, TimeoutError, OSError):
        pass
    else:
        raise RuntimeError('Benchmark port already occupied')
    log = (directory / 'server.log').open('wb')
    process = subprocess.Popen(cmd, env=env, stdout=log, stderr=subprocess.STDOUT,
                               pass_fds=(GPU_LOCK.fileno(),))
    SERVER = (process, log)
    try:
        deadline = time.monotonic() + 300
        while True:
            if process.poll() is not None:
                raise RuntimeError(f'{label}: server exited {process.returncode}')
            try:
                if http('/health', timeout=2).get('status') == 'ok':
                    break
            except (urllib.error.URLError, TimeoutError, OSError):
                pass
            if time.monotonic() >= deadline:
                raise RuntimeError(f'{label}: readiness deadline exceeded')
            time.sleep(0.5)
        rows = []
        schedule = [(True, 0)] if diagnostic else [(True, i) for i in range(len(PROMPTS))]
        schedule += [(False, i) for _ in range(1 if diagnostic else repeats) for i in range(1 if diagnostic else len(PROMPTS))]
        for number, (warmup, prompt_index) in enumerate(schedule):
            before = (directory / 'server.log').stat().st_size
            payload = dict(prompt=PROMPTS[prompt_index], n_predict=NP, temperature=0,
                           seed=42, stream=False, ignore_eos=True, cache_prompt=False)
            start = time.monotonic()
            reply = http('/completion', payload)
            wall_ms = (time.monotonic() - start) * 1000
            save(directory / f'request-{number}.json', reply)
            timings = reply.get('timings', {})
            n = timings.get('predicted_n', 0)
            ms = timings.get('predicted_ms', 0)
            if n != NP or not math.isfinite(ms) or ms <= 0:
                raise RuntimeError(f'{label}: invalid fixed-token completion {n=}, {ms=}')
            if cfg['depth'] and timings.get('draft_n', 0) <= 0:
                raise RuntimeError(f'{label}: MTP requested but no drafts observed')
            data = (directory / 'server.log').read_bytes()[before:]
            row = dict(index=number, prompt=prompt_index, warmup=warmup, wall_ms=wall_ms,
                       predicted_n=n, predicted_ms=ms, ms_per_token=ms/n, tok_s=n*1000/ms,
                       draft_n=timings.get('draft_n', 0), accepted=timings.get('draft_n_accepted', 0),
                       output_sha256=hashlib.sha256(reply.get('content', '').encode()).hexdigest(),
                       fallback_count=data.count(b'CRITICAL-FALLBACK'),
                       log_begin=before, log_end=before+len(data))
            rows.append(row)
            save(directory / 'requests.json', rows)
        text = (directory / 'server.log').read_text(errors='replace')
        modes = collections.defaultdict(set)
        for backend, mode in POLICY.findall(text):
            modes[backend].add(mode)
        if set(modes) != {f'Vulkan{i}' for i in range(5)} or any(v != {cfg['policy']} for v in modes.values()):
            raise RuntimeError(f'{label}: actual backend modes disagree: {dict(modes)}')
        regions = [dict(backend=b, family=f, mask=int(m), shared_q8_1=int(q)) for b,f,m,q in REGION.findall(text)]
        if diagnostic:
            masks = {'disabled': {'gdn-projections': 0, 'qsa-projections': 0},
                     'auto': {'gdn-projections': 3, 'qsa-projections': 1},
                     'forced': {'gdn-projections': 7, 'qsa-projections': 5}}[cfg['policy']]
            for backend in modes:
                for family, expected in masks.items():
                    if not any(r['backend'] == backend and r['family'] == family and r['mask'] == expected for r in regions):
                        raise RuntimeError(f'{label}: missing actual dispatch mask {backend}/{family}/{expected}')
        measured = [r for r in rows if not r['warmup']]
        score = math.exp(statistics.mean(math.log(statistics.median(r['tok_s'] for r in measured if r['prompt'] == p))
                                          for p in sorted({r['prompt'] for r in measured})))
        result = dict(label=label, config=cfg, diagnostic_only=diagnostic, modes={k:sorted(v) for k,v in modes.items()},
                      actual_region_records=regions, score_tps=score, rows=rows,
                      total_fallbacks=text.count('CRITICAL-FALLBACK'), returncode=None)
        save(directory / 'result.json', result)
        print(json.dumps(dict(label=label, config=cfg, diagnostic_only=diagnostic,
             score_tps=score, measured_fallbacks=sum(r['fallback_count'] for r in measured),
             region_masks=sorted({(r['family'],r['mask']) for r in regions})), ensure_ascii=False), flush=True)
        return result
    finally:
        stop_server()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('phase', choices=['probe', 'screen', 'confirm'])
    parser.add_argument('--candidate', type=Path)
    args = parser.parse_args()
    ROOT.mkdir(parents=True, exist_ok=True)
    for signum in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        signal.signal(signum, interrupted)
    global GPU_LOCK
    GPU_LOCK = open('/var/tmp/tp5-gpu.lock', 'a+')
    fcntl.flock(GPU_LOCK, fcntl.LOCK_EX)
    health = subprocess.run(['systemctl', 'is-active', 'eagle-gpu-watchdog'], capture_output=True, text=True)
    if health.returncode or health.stdout.strip() != 'active':
        raise RuntimeError('Eagle watchdog is not active; refusing GPU experiment')
    if args.phase == 'probe':
        for policy in ('disabled', 'auto', 'forced'):
            trial('probe-'+policy, config(policy), diagnostic=True)
    elif args.phase == 'screen':
        results = []
        incumbent = config('auto', 1)
        results.append(trial('screen-anchor-start', incumbent))
        # Joint-factor ablations; no-MTP keeps the same target head maps and placement.
        for label, cfg in [('default-d1', config('disabled',1)), ('forced-d1', config('forced',1)),
                           ('disabled-no-mtp', config('disabled',0)), ('forced-no-mtp', config('forced',0)),
                           ('auto-d2', config('auto',2)), ('auto-d3', config('auto',3)), ('auto-d4', config('auto',4))]:
            results.append(trial('screen-'+label, cfg))
        candidates = [r for r in results if r['config']['depth'] and r['config']['policy'] != 'disabled']
        winner = max(candidates, key=lambda r:r['score_tps'])
        incumbent = winner['config']
        # Check policy interaction at the best observed draft depth.
        other = 'forced' if incumbent['policy'] == 'auto' else 'auto'
        rival = trial('screen-policy-neighbor', {**incumbent, 'policy':other})
        results.append(rival)
        if rival['score_tps'] > winner['score_tps'] * 1.02:
            winner = rival
            incumbent = winner['config']
        # Strictly improving one-factor moves; preserve results for every state.
        # A fixed 24-trial cap bounds exploration without optional CI stopping.
        key = lambda cfg: json.dumps(cfg, sort_keys=True)
        seen = {key(r['config']): r for r in results}
        walk = []
        step = 0
        stop_reason = 'no neighbor exceeds the 2% screening threshold'
        while True:
            base = winner['config']
            neighbors = []
            for depth in (base['depth'] - 1, base['depth'] + 1):
                if 1 <= depth <= 4:
                    neighbors.append(('depth-'+str(depth), {**base, 'depth':depth}))
            neighbors.append(('policy', {**base, 'policy':'forced' if base['policy'] == 'auto' else 'auto'}))
            for label, knob in (('columns', 'GGML_VK_SMALL_Q8_COLUMNS'), ('kv', 'GGML_MTP_KV_ONLY')):
                knobs = dict(base['knobs'])
                if knobs.get(knob, '1') == '1':
                    knobs[knob] = '0'
                else:
                    knobs.pop(knob)
                neighbors.append((label, {**base, 'knobs':knobs}))
            knobs = dict(base['knobs'])
            if 'GGML_VK_DISABLE_GDN_CACHED_SEGMENT' in knobs:
                knobs.pop('GGML_VK_DISABLE_GDN_CACHED_SEGMENT')
            else:
                knobs['GGML_VK_DISABLE_GDN_CACHED_SEGMENT'] = '1'
            neighbors.append(('gdn-cache', {**base, 'knobs':knobs}))
            neighbors.append(('sampling', {**base, 'sampling':not base['sampling']}))
            evaluated = []
            complete_neighborhood = True
            for label, current in neighbors:
                identity = key(current)
                if identity not in seen:
                    if len(results) >= 24:
                        complete_neighborhood = False
                        stop_reason = 'fixed 24-trial exploration cap reached; not a local-optimum proof'
                        break
                    result = trial(f'screen-step{step}-{label}', current)
                    results.append(result)
                    seen[identity] = result
                    save(ROOT / 'screen-progress.json', results)
                evaluated.append(seen[identity])
            best = max([winner] + evaluated, key=lambda r:r['score_tps'])
            walk.append(dict(step=step, incumbent=base, incumbent_tps=winner['score_tps'],
                             neighbors=[dict(config=r['config'], score_tps=r['score_tps']) for r in evaluated],
                             complete_neighborhood=complete_neighborhood))
            if not complete_neighborhood or best['score_tps'] <= winner['score_tps'] * 1.02:
                break
            winner = best
            step += 1
        save(ROOT / 'walk.json', dict(steps=walk, stop_reason=stop_reason))
        results.append(trial('screen-anchor-end', config('auto',1)))
        save(ROOT / 'screen.json', results)
        save(ROOT / 'candidate.json', winner['config'])
        print('SCREEN_COMPLETE '+json.dumps(winner['config']), flush=True)
    else:
        candidate = json.loads((args.candidate or ROOT/'candidate.json').read_text())
        reference = config('disabled', 1)
        results = []
        for block, order in enumerate((('R','C'),('C','R'),('R','C'),('C','R')), 1):
            for arm in order:
                cfg = reference if arm == 'R' else candidate
                results.append(trial(f'confirm-{block}-{arm}', cfg, repeats=3))
        save(ROOT / 'confirmation.json', results)
        print('CONFIRMATION_COMPLETE', flush=True)


if __name__ == '__main__':
    main()
