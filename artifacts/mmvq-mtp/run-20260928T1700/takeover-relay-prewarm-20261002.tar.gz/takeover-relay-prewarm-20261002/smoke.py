#!/usr/bin/env python3
import argparse
import datetime
import fcntl
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/var/tmp/tp5-takeover-20261002')
BIN = Path('/var/tmp/tp5-takeover-build/bin')
SCENARIOS = {
    'cpu': [
        ('capacity', ['test-predefined-capacity']),
        ('coverage', ['test-predefined-coverage']),
        ('row-program', ['test-tp5-row-program']),
        ('meta-boundaries', ['test-meta-reduce-boundary']),
        ('tp5-plans', ['test-tp5-plan']),
        ('restored-todo', ['test-rerot-todo']),
        ('restored-thinking', ['test-rerot-thinking']),
    ],
    'gpu': [
        ('command-replay', ['test-vulkan-command-replay']),
        ('scratch-reuse', ['test-vulkan-command-replay', '--scratch-reuse-only']),
        ('attention-mmvq-auto', ['test-vulkan-command-replay', '--attention-mmvq-only']),
    ],
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('phase', choices=SCENARIOS)
    args = parser.parse_args()
    directory = ROOT / ('smoke-' + args.phase)
    directory.mkdir(exist_ok=False)
    results = []
    environment = dict(PATH='/usr/bin:/bin', HOME='/home/kunweiz', RADV_DEBUG='nobolist')
    with open('/var/tmp/tp5-gpu.lock', 'a+') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        for name, command in SCENARIOS[args.phase]:
            executable = BIN / command[0]
            start = datetime.datetime.now(datetime.timezone.utc)
            result = subprocess.run([str(executable), *command[1:]], env=environment,
                                    cwd='/home/kunweiz/atomic-llama-cpp-turboquant',
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                    text=True, timeout=600)
            finish = datetime.datetime.now(datetime.timezone.utc)
            (directory / (name + '.log')).write_text(result.stdout)
            record = dict(name=name, command=[str(executable), *command[1:]],
                          executable_sha256=hashlib.sha256(executable.read_bytes()).hexdigest(),
                          start_utc=start.isoformat(), end_utc=finish.isoformat(),
                          returncode=result.returncode)
            results.append(record)
            (directory / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
            print(json.dumps(record), flush=True)
            print(result.stdout, flush=True)
            if result.returncode:
                raise RuntimeError(f'{name} failed; no following scenario executed')
    print('Completed current-source ' + args.phase + ' checks; no five-rank decode/performance qualification implied', flush=True)


if __name__ == '__main__':
    main()
