#include "server-context.h"
#include "../../wanxiangqi/server/integration.h"
#include "repetition-guard.h"
#include "server-chat.h"
#include "server-common.h"
#include "server-http.h"
#include "server-rerot.h"
#include "server-task.h"
#include "chat.h"
#include "server-queue.h"
#include "server-schema.h"
#include "server-stream.h"

#include "build-info.h"
#include "common.h"
#include "fit.h"
#include "llama.h"
#include "log.h"
#include "sampling.h"
#include "speculative.h"
#include "mtmd.h"
#include "mtmd-helper.h"

#include "../../src/llama-ext.h" // staging API: llama_get_ctx_other (used by mmproj draft mirroring)
#include "../../src/llama-rerot-profile.h"

#include <algorithm>
#include <chrono>
#include <cstddef>
#include <cinttypes>
#include <exception>
#include <memory>
#include <filesystem>
#include <utility>
#include <unordered_map>
#include <fstream>

// fix problem with std::min and std::max
#if defined(_WIN32)
#define WIN32_LEAN_AND_MEAN
#ifndef NOMINMAX
#   define NOMINMAX
#endif
#include <windows.h>
#endif

using json = nlohmann::ordered_json;

constexpr int HTTP_POLLING_SECONDS = 1;

static inline llama_state_seq_flags get_spec_checkpoint_flags(const llama_context * ctx) {
    llama_state_seq_flags flags = LLAMA_STATE_SEQ_FLAGS_PARTIAL_ONLY;
    if (ctx != nullptr) {
        const llama_model * model = llama_get_model(ctx);
        if (model != nullptr && (llama_model_is_recurrent(model) || llama_model_is_hybrid(model))) {
            // In addition to model recurrence, verify the backend actually supports device memory cloning
            // (i.e. Vulkan/CUDA/Metal or TensorParallel meta backend with cpy_tensor)
            flags |= LLAMA_STATE_SEQ_FLAGS_ON_DEVICE;
        }
    }
    return flags;
}

struct server_token_hack::impl {
    llama_context * ctx;
    wanxiangqi_repetition_guard repetition_guard;

    explicit impl(llama_context * ctx)
        : ctx(ctx) {
    }
};

server_token_hack::server_token_hack(llama_context * ctx, config cfg)
    : cfg(std::move(cfg)), pimpl(std::make_unique<impl>(ctx)) {
    progress_tokens = common_tokenize(ctx, this->cfg.progress_text, false, false);
    reset();
}

server_token_hack::~server_token_hack() = default;

void server_token_hack::reset() {
    n_confirmed = 0;
    n_injected = 0;
    pimpl->repetition_guard.reset();
}

llama_tokens server_token_hack::after_block(const llama_tokens & confirmed_block) {
    n_confirmed += (int64_t) confirmed_block.size();

    if (confirmed_block.empty() || progress_tokens.empty() || n_injected >= cfg.max_injections) {
        return {};
    }

    std::string confirmed_text;
    for (llama_token token : confirmed_block) {
        confirmed_text += common_token_to_piece(pimpl->ctx, token, true);
    }

    const auto anomaly = pimpl->repetition_guard.observe(confirmed_text);
    if (anomaly == wanxiangqi_repetition_state::normal) {
        return {};
    }

    ++n_injected;
    pimpl->repetition_guard.reset();

    SRV_INF("token hack anomaly injection: anomaly=%s block=%zu confirmed=%" PRId64 " injection=%d/%d text='%s'\n",
            wanxiangqi_repetition_state_name(anomaly), confirmed_block.size(), n_confirmed,
            n_injected, cfg.max_injections, cfg.progress_text.c_str());

    return progress_tokens;
}

static uint32_t server_n_outputs_max(const common_params & params) {
    const uint32_t n_batch = params.n_batch;
    const uint32_t n_active_seq = std::max(
        1,
        params.rerot_enabled && params.rerot_pen_max != 0
            ? static_cast<int>(params.rerot_pen_max)
            : params.n_parallel);

    if (params.embedding ||
            (params.pooling_type != LLAMA_POOLING_TYPE_UNSPECIFIED && params.pooling_type != LLAMA_POOLING_TYPE_NONE)) {
        return std::max(n_batch, n_active_seq);
    }

    const uint32_t n_outputs_per_seq = 1 + common_speculative_n_max(&params.speculative);
    const uint64_t n_outputs = (uint64_t) n_active_seq * n_outputs_per_seq;

    return std::max<uint32_t>(n_active_seq, std::min<uint64_t>(n_batch, n_outputs));
}

// state diagram: https://github.com/ggml-org/llama.cpp/pull/9283
enum slot_state {
    SLOT_STATE_IDLE,
    SLOT_STATE_WAIT_OTHER, // after assigning a task, but waiting for parent slot to process prompt
    SLOT_STATE_STARTED,    // after assigning a task and about to process prompt
    SLOT_STATE_PROCESSING_PROMPT,
    SLOT_STATE_DONE_PROMPT,
    SLOT_STATE_GENERATING,
};

enum server_inference_mode {
    SERVER_INFERENCE_MODE_DECODE,
    SERVER_INFERENCE_MODE_PREFILL,
};

enum class server_rerot_injection_kind : uint8_t {
    none = 0,
    planner,
    planner_open,
    child_open,
    heading,
    refresh,
    worker,
    serial_resume,
    dag_frame,
    probe,
    plan_prefix,
};


// Preserve the shipped JSON probe's short-plan limit. Mindmap probes use the
// episode's context-sized token budget instead of a fixed planning quota.
static constexpr uint64_t SERVER_REROT_PROBE_MAX_TOKENS = 512;

static constexpr size_t SERVER_REROT_PRIVATE_BATCH = 32;

static bool server_rerot_private_microbatch(server_rerot_injection_kind injection) {
    return injection == server_rerot_injection_kind::planner ||
           injection == server_rerot_injection_kind::refresh ||
           injection == server_rerot_injection_kind::child_open ||
           injection == server_rerot_injection_kind::worker ||
           injection == server_rerot_injection_kind::serial_resume ||
           injection == server_rerot_injection_kind::dag_frame ||
           injection == server_rerot_injection_kind::probe;
}

static bool server_rerot_public_microbatch(server_rerot_injection_kind injection) {
    return injection == server_rerot_injection_kind::plan_prefix;
}

struct server_slot; // forward declaration

struct server_batch {
    llama_batch batch;
    bool batch_rendered = false;

    struct token {
        int32_t id_slot;
        llama_token token;
        llama_pos pos;
        bool output;
    };
    std::vector<token> tokens;
    int32_t n_tokens_alloc = 0;
    int32_t n_embd = 0;

    // track if given slot can be batched with slots already in the batch
    server_slot * slot_batched = nullptr;

    // in embd mode, we temporarily swap out the tokens arr and restore it on clear()
    bool has_embd = false;
    llama_token * tokens_ptr = nullptr;
    std::vector<float> embd;

    float  alora_scale       = -1.0f;
    size_t alora_disabled_id = 0;

    // FlashPrefill V2 routing sidecar (ServerRouting ownership).
    // Parallel to tokens[]: fp_rows[i] describes tokens[i] with a frozen
    // llama_flashprefill_row (role + seq/reader identity + logical pos +
    // frozen prefill interval). Same clear() lifetime as tokens, same off
    // slicing as get_view(). OFF (default): stays empty forever — no
    // allocation, no split/sync change. Context-internal source-row mapping
    // (BatchIdentity) is not needed here; the server slices by off only and
    // the context validates n_rows == batch.n_tokens on its copy.
    std::vector<llama_flashprefill_row> fp_rows;

    server_batch() {
        batch.pos = nullptr; // sentinel: uninitialized batch
    }

    ~server_batch() {
        if (batch.pos != nullptr) {
            clear();
            llama_batch_free(batch);
        }
    }

    void init(int32_t n_tokens_alloc, int32_t n_embd) {
        this->n_tokens_alloc = n_tokens_alloc;
        this->n_embd = n_embd;
        batch = llama_batch_init(n_tokens_alloc, 0, 1);
        tokens_ptr = batch.token;
        tokens.reserve(n_tokens_alloc);
    }

    bool add(int32_t id_slot, llama_token token, llama_pos pos, bool output) {
        GGML_ASSERT(!has_embd); // cannot mix tokens + embd in same batch
        GGML_ASSERT(batch.pos != nullptr);
        if ((int32_t)tokens.size() >= n_tokens_alloc) {
            return false;
        }
        tokens.push_back({ id_slot, token, pos, output });
        return true;
    }

    bool add(int32_t id_slot, const std::vector<float> & embd_in, llama_pos pos, bool output) {
        GGML_ASSERT(batch.pos != nullptr);
        if ((int32_t)tokens.size() >= n_tokens_alloc) {
            return false;
        }
        tokens.push_back({ id_slot, LLAMA_TOKEN_NULL, pos, output });
        has_embd = true;
        embd.insert(embd.end(), embd_in.begin(), embd_in.end());
        return true;
    }

    void clear() {
        tokens.clear();
        embd.clear();
        fp_rows.clear();
        // OFF: fp_rows never reserved; enabled path reserves at most
        // n_tokens_alloc once per iteration (no per-row growth).
        common_batch_clear(batch);
        slot_batched      = nullptr;
        alora_scale       = -1.0f;
        alora_disabled_id = 0;
        batch_rendered    = false;
        has_embd          = false;
        if (batch.token == nullptr) {
            batch.token = tokens_ptr;
            batch.embd  = nullptr;
        }
    }

    int32_t size() const {
        return (int32_t)tokens.size();
    }

    void set_output(int32_t idx, bool output) {
        GGML_ASSERT(idx >= 0 && idx < (int32_t)tokens.size());
        tokens[idx].output = output;
    }

    // Push one frozen row parallel to the last add()ed token. Caller (impl)
    // gates on fp_enabled, so OFF never allocates here. Must be called
    // exactly once per successful add() while enabled to keep row identity.
    void fp_push_row(const llama_flashprefill_row & row) {
        fp_rows.push_back(row);
    }

    void render() {
        GGML_ASSERT(!batch_rendered);
        GGML_ASSERT(batch.pos != nullptr);
        // Row identity: enabled => exactly one row per token; OFF => no rows.
        GGML_ASSERT(fp_rows.empty() || fp_rows.size() == tokens.size());
        common_batch_clear(batch);
        for (int32_t i = 0; i < size(); i++) {
            const auto & t = tokens[i];
            common_batch_add(batch, t.token, t.pos, { t.id_slot }, t.output);
        }
        if (has_embd) {
            batch.token = nullptr; // will be restored on clear()
            batch.embd  = embd.data();
        }
        batch_rendered = true;
    }

    llama_batch get_view(int32_t off, int32_t n_tokens) const {
        GGML_ASSERT(batch.pos != nullptr);
        GGML_ASSERT(batch_rendered);
        GGML_ASSERT(off >= 0 && off < size());
        GGML_ASSERT(n_tokens > 0 && off + n_tokens <= size());

        auto * token = batch.token ? batch.token + off          : nullptr;
        auto * embd  = batch.embd  ? batch.embd  + off * n_embd : nullptr;

        llama_batch view = {
            n_tokens,
            token,
            embd,
            batch.pos      + off,
            batch.n_seq_id + off,
            batch.seq_id   + off,
            batch.logits   + off,
        };

        return view;
    }

    // Borrowed versioned execution view sliced by the same off/n as get_view().
    // Lifetime: valid until the next clear()/render(), exactly like the batch
    // view (the callee must copy before async submit; the context does).
    // OFF: returns an empty view (n_rows==0, rows==NULL) — the decode path
    // then takes the ordinary llama_decode() dense route with zero new work.
    llama_flashprefill_exec fp_exec_view(int32_t off, int32_t n_tokens) const {
        llama_flashprefill_exec exec = {};
        exec.version = LLAMA_FLASHPREFILL_EXEC_VERSION;
        exec.struct_size = (uint32_t) sizeof(llama_flashprefill_exec);
        if (fp_rows.empty()) {
            exec.n_rows = 0;
            exec.reserved0 = 0;
            exec.rows = nullptr;
            return exec;
        }
        GGML_ASSERT(batch_rendered);
        GGML_ASSERT(off >= 0 && off + n_tokens <= (int32_t) fp_rows.size());
        GGML_ASSERT(n_tokens > 0);
        exec.n_rows = (uint32_t) n_tokens;
        exec.reserved0 = 0;
        exec.rows = fp_rows.data() + off;
        return exec;
    }
};

struct server_slot {
    int id;

    llama_context * ctx_tgt = nullptr;
    llama_context * ctx_dft = nullptr;

    common_memory mem;

    // multimodal
    mtmd_context * mctx = nullptr;
    mtmd::batch_ptr mbatch = nullptr;

    // speculative decoding
    common_speculative * spec;

    llama_tokens spec_draft;
    llama_tokens spec_prompt;
    std::vector<int32_t> spec_i_batch;
    common_prompt_checkpoint spec_ckpt;
    bool spec_is_replay = false;

    // RERoT thin glue (§18.2): a physical slot is never a logical Lane id.
    // These fields only tag which episode/node (if any) currently borrows
    // this slot as its execution handle; the tree/queue/frontier truth lives
    // in server_rerot_runtime. OFF: all remain at their sentinels.
    bool rerot_internal = false;
    uint64_t rerot_episode_id = 0;
    // Planning wire of the episode this slot is driving: "dag" (shipped
    // strategy JSON) or "mindmap" (MM-R1 research line). Empty until a routing
    // probe commits. Recorded here so the transition, the audit trace and the
    // experiment harness all name the same plan kind instead of re-deriving it
    // from a payload.
    std::string rerot_plan_kind;
    uint32_t rerot_node_id = UINT32_MAX;
    llama_seq_id rerot_exec_seq = -1;
    // MTP draft binding stamp (§A.6) captured when this slot started drafting
    // under a RERoT view; checked for staleness before accept.
    struct llama_rerot_view_stamp rerot_draft_stamp = {0, 0, 0};
    bool rerot_has_draft_stamp = false;

    // Each sampled/public Lane contributes one token per frontier. Contiguous
    // PRIVATE control spans may use multiple causal rows in the same decode;
    // they are invisible to peers and commit only after the last row succeeds.
    server_rerot_injection_kind rerot_injection = server_rerot_injection_kind::none;
    llama_tokens rerot_injection_tokens;
    size_t rerot_injection_cursor = 0;
    std::optional<server_rerot_token_plan> rerot_inflight_plan;
    std::string rerot_inflight_bytes;
    std::vector<server_rerot_token_plan> rerot_inflight_extra_plans;
    std::vector<std::string> rerot_inflight_extra_bytes;
    bool rerot_inflight_forced = false;
    bool rerot_serial_tail = false;

    // RERoT C0 plain-continuation decision, pre-saved in post_decode while C0
    // logits are still valid. The sampler clone preserves RNG, penalty,
    // budget, and grammar evolution exactly as the ordinary path would; the
    // output/usage cursors snapshot the pristine post-prefill state so probe
    // generation leaves no residue. Consumed once by simple continuation.
    common_sampler_ptr rerot_c0_smpl;
    llama_token rerot_c0_token = LLAMA_TOKEN_NULL;
    completion_token_output rerot_c0_output;
    bool rerot_c0_ready = false;
    int32_t rerot_c0_n_decoded = 0;
    int32_t rerot_c0_n_decoded_start = 0;
    std::string rerot_c0_generated_text;
    llama_tokens rerot_c0_generated_tokens;
    std::vector<completion_token_output> rerot_c0_generated_token_probs;
    size_t rerot_c0_n_sent_text = 0;
    int64_t rerot_c0_t_start_generation = 0;
    bool rerot_c0_has_next_token = true;
    stop_type rerot_c0_stop = STOP_TYPE_NONE;
    std::string rerot_c0_stopping_word;

    // TODO: move members that belong to the task (such as `generated_text`, `has_new_line`) to task_results_state
    //       see https://github.com/ggml-org/llama.cpp/pull/18283#issuecomment-3710175837
    std::unique_ptr<const server_task> task;
    std::unique_ptr<const server_task> task_prev; // used for debugging

    // used to determine the slot that has been used the longest
    int64_t t_last_used = -1;

    // generation props
    int32_t n_ctx       = 0;  // context size per slot
    int32_t n_keep      = 0;
    int32_t n_decoded   = 0;
    int32_t n_decoded_start = 0;
    int32_t n_remaining = -1;
    int32_t i_batch     = -1;

    int32_t n_prompt_tokens_original          = 0;
    int32_t n_prompt_tokens_cache             = 0;
    int32_t n_prompt_tokens_cache_response    = 0;
    int32_t n_prompt_tokens_processed         = 0;
    int32_t n_prompt_tokens_processed_accum   = 0;

    size_t last_nl_pos = 0;

    std::string  generated_text;
    std::string  debug_generated_text;
    llama_tokens generated_tokens;

    std::vector<completion_token_output> generated_token_probs;

    bool has_next_token = true;
    bool has_new_line   = false;
    bool truncated      = false;

    stop_type stop;

    std::string stopping_word;

    // state
    slot_state state = SLOT_STATE_IDLE;
    bool triattention_compressed = false;

    server_prompt prompt;
    server_tokens response_prompt;

    bool prompt_save(server_prompt_cache & prompt_cache) const {
        if (prompt.tokens.size() == 0) {
            return false;
        }

        const size_t cur_size_tgt =           llama_state_seq_get_size_ext(ctx_tgt, id, LLAMA_STATE_SEQ_FLAGS_NONE);
        const size_t cur_size_dft = ctx_dft ? llama_state_seq_get_size_ext(ctx_dft, id, LLAMA_STATE_SEQ_FLAGS_NONE) : 0;
        std::vector<uint8_t> state_spec;
        common_speculative_get_state(spec, id, state_spec);

        const size_t cur_size = cur_size_tgt + cur_size_dft + state_spec.size();

        SRV_TRC(" - saving prompt with length %d, total state size = %.3f MiB (draft: %.3f MiB)\n",
                (int) prompt.tokens.size(), cur_size / (1024.0 * 1024.0), cur_size_dft / (1024.0 * 1024.0));

        auto * cur = prompt_cache.alloc(prompt, cur_size_tgt, cur_size_dft, state_spec.size());
        if (cur == nullptr) {
            return false;
        }

        llama_state_seq_get_data_ext(ctx_tgt, cur->data.main.data(), cur_size_tgt, id, LLAMA_STATE_SEQ_FLAGS_NONE);
        if (ctx_dft) {
            llama_state_seq_get_data_ext(ctx_dft, cur->data.drft.data(), cur_size_dft, id, LLAMA_STATE_SEQ_FLAGS_NONE);
        }
        if (!state_spec.empty()) {
            std::memcpy(cur->data.spec.data(), state_spec.data(), state_spec.size());
        }

        return true;
    }

    bool prompt_load(server_prompt_cache & prompt_cache, const server_tokens & tokens) {
        std::vector<uint8_t> state_spec;
        bool loaded_state = false;
        bool res = prompt_cache.load(prompt, tokens, ctx_tgt, ctx_dft, id, &state_spec, &loaded_state);
        if (res && loaded_state) {
            common_speculative_set_state(spec, id, state_spec);
        }
        if (res) {
            triattention_compressed = loaded_state &&
                llama_memory_seq_get_kv_used(llama_get_memory(ctx_tgt), id) < prompt.tokens.size();
        }
        if (!res) {
            SLT_WRN(*this, "%s", "failed to load prompt from cache\n");
        }

        return res;
    }

    void prompt_clear() {
        SLT_TRC(*this, "clearing prompt with %zu tokens\n", prompt.tokens.size());

        mem.seq_rm(id, -1, -1);
        common_speculative_set_paused(spec, id, false);
        common_speculative_set_state(spec, id, {});

        prompt.clear();
        triattention_compressed = false;
    }

    std::vector<common_adapter_lora_info> lora;
    int32_t alora_invocation_start = -1;

    // sampling
    json json_schema;

    common_sampler_ptr smpl;

    std::unique_ptr<server_token_hack> token_hack;
    llama_token token_append_anchor = LLAMA_TOKEN_NULL;
    llama_tokens token_append_chunk;

    llama_token sampled; // in speculative mode, this is the last accepted token

    // for TTS models, this is the embd generated from prev step, decode this to generate next hidden state
    // corresponding to one token position (size = n_embd)
    std::vector<float> inp_embd;

    // stats
    size_t n_sent_text = 0; // number of sent text character

    // TODO @ngxson : move all metrics to a sub-struct for clarity
    int64_t t_start_process_prompt;
    int64_t t_start_generation;
    int64_t t_print_last = 0;
    int32_t n_decoded_last = 0;

    double t_prompt_processing = 0.0; // ms
    double t_prompt_processing_accum = 0.0;
    double t_token_generation = 0.0;  // ms

    std::function<void(int /* id_slot */)> callback_on_release;

    // Speculative decoding stats
    int32_t n_draft_total = 0;      // Total draft tokens generated
    int32_t n_draft_accepted = 0;   // Draft tokens actually accepted
    int32_t n_draft_verif_steps = 0; // Total draft token verification steps by the target model
    std::vector<int32_t> n_accepted_per_pos; // Accepted tokens per draft position

    // FlashPrefill V2 per-slot routing state (ServerRouting ownership).
    // fp_boundary: frozen ordinary logical-prefill suffix, set once after the
    //   prefix-cache final n_past decision (STARTED path) and persisted across
    //   ubatches until reset/release. New requests must not inherit it.
    // fp_eligible_rows / fp_dense_by_reason: per-request (slot-lifetime)
    //   successful-only distribution, indexed by fp_dense_reason_index().
    //   Incremented exclusively from the post_decode success path; retry,
    //   fatal-error, and cancel paths never touch them. OFF: boundary stays
    //   unknown and all counters stay zero (no allocation beyond these inline
    //   fields, no behavior change).
    server_flashprefill_routing::fp_slot_boundary fp_boundary;
    uint64_t fp_eligible_rows = 0;
    uint64_t fp_dense_by_reason[7] = {};

    void reset() {
        SLT_DBG(*this, "%s", "\n");

        spec_is_replay = false;

        n_decoded_start                  = 0;
        n_prompt_tokens_original         = 0;
        n_prompt_tokens_cache            = 0;
        n_prompt_tokens_cache_response   = 0;
        n_prompt_tokens_processed_accum  = 0;
        response_prompt.clear();

        last_nl_pos    = 0;
        generated_text = "";
        has_new_line   = false;
        truncated      = false;
        stop           = STOP_TYPE_NONE;
        stopping_word  = "";
        n_sent_text    = 0;
        t_prompt_processing_accum = 0.0;

        if (spec) {
            spec_draft.clear();
            spec_i_batch.clear();
            spec_ckpt.clear();
        }
        generated_tokens.clear();
        generated_token_probs.clear();
        token_append_anchor = LLAMA_TOKEN_NULL;
        token_append_chunk.clear();
        if (token_hack) {
            token_hack->reset();
        }
        json_schema = json();

        // clear speculative decoding stats
        n_draft_total = 0;
        n_draft_accepted = 0;
        n_draft_verif_steps = 0;
        n_accepted_per_pos.clear();

        task_prev = std::move(task);
        task.reset();

        llama_set_sampler(ctx_tgt, id, nullptr);

        // clear alora start
        alora_invocation_start = -1;

        // clear multimodal state
        mbatch.reset();

        // RERoT: physical slot released, logical Lane mapping (if any) is
        // owned by the runtime (detach/erase); just drop the local tags.
        // OFF: sentinels already, no behavior change.
        rerot_internal = false;
        rerot_episode_id = 0;
        rerot_plan_kind.clear();
        rerot_node_id = UINT32_MAX;
        rerot_exec_seq = -1;
        rerot_draft_stamp = {0, 0, 0};
        rerot_has_draft_stamp = false;
        rerot_injection = server_rerot_injection_kind::none;
        rerot_injection_tokens.clear();
        rerot_injection_cursor = 0;
        rerot_inflight_plan.reset();
        rerot_inflight_bytes.clear();
        rerot_inflight_extra_plans.clear();
        rerot_inflight_extra_bytes.clear();
        rerot_inflight_forced = false;
        rerot_serial_tail = false;
        rerot_c0_smpl.reset();
        rerot_c0_token = LLAMA_TOKEN_NULL;
        rerot_c0_output = completion_token_output();
        rerot_c0_ready = false;
        rerot_c0_n_decoded = 0;
        rerot_c0_n_decoded_start = 0;
        rerot_c0_generated_text.clear();
        rerot_c0_generated_tokens.clear();
        rerot_c0_generated_token_probs.clear();
        rerot_c0_n_sent_text = 0;
        rerot_c0_t_start_generation = 0;
        rerot_c0_has_next_token = true;
        rerot_c0_stop = STOP_TYPE_NONE;
        rerot_c0_stopping_word.clear();

        // FlashPrefill: new requests must not inherit the previous request's
        // frozen interval or its successful-only distribution.
        fp_boundary = server_flashprefill_routing::fp_slot_boundary();
        fp_eligible_rows = 0;
        for (int i = 0; i < 7; ++i) {
            fp_dense_by_reason[i] = 0;
        }
    }

    void init_sampler() const {
        common_sampler_reset(smpl.get());

        if (!task->need_sampling()) {
            return;
        }

        const int64_t t_start = ggml_time_us();

        int n_text = 0;

        for (int i = 0; i < (int) prompt.tokens.size(); i++) {
            const llama_token id = prompt.tokens[i];

            if (id != LLAMA_TOKEN_NULL) {
                common_sampler_accept(smpl.get(), id, false);
                n_text++;
            }
        }

        SLT_TRC(*this, "init sampler, took %0.2f ms, tokens: text = %d, total = %d\n",
                (ggml_time_us() - t_start) / 1000.0, n_text, (int) prompt.tokens.size());
    }

    bool need_embd() const {
        GGML_ASSERT(task);
        return task->need_embd() || (spec && common_speculative_need_embd(spec));
    }

    bool need_embd_nextn() const {
        GGML_ASSERT(task);
        return spec && common_speculative_need_embd_nextn(spec);
    }

    // if the context does not have a memory module then all embeddings have to be computed within a single ubatch
    // also we cannot split if the pooling would require any past tokens
    // (MTP supports splitting — uses task->need_embd() not need_embd())
    bool can_split() const {
        GGML_ASSERT(task);

        return
            !task->need_embd() ||
            (llama_get_memory(ctx_tgt) && llama_pooling_type(ctx_tgt) == LLAMA_POOLING_TYPE_LAST);
    }

    bool can_batch_with(server_slot & other_slot) const {
        GGML_ASSERT(task);

        return task->type == other_slot.task->type
            && rerot_internal == other_slot.rerot_internal
            && inp_embd.size() == other_slot.inp_embd.size()
            && are_lora_equal(lora, other_slot.lora);
    }

    bool has_budget(const common_params & global_params) {
        GGML_ASSERT(task);

        if (task->params.n_predict == -1 && global_params.n_predict == -1) {
            return true; // limitless
        }

        n_remaining = -1;

        if (task->params.n_predict != -1) {
            n_remaining = task->params.n_predict - n_decoded;
        } else if (global_params.n_predict != -1) {
            n_remaining = global_params.n_predict - n_decoded;
        }

        return n_remaining > 0; // no budget
    }

    bool is_processing() const {
        return state != SLOT_STATE_IDLE;
    }

    bool can_speculate() const {
        return !!spec && token_append_chunk.empty();
    }

    void add_token(const completion_token_output & token) {
        if (!is_processing()) {
            SLT_WRN(*this, "%s", "slot is not processing\n");
            return;
        }

        generated_token_probs.push_back(token);
    }

    int get_n_draft_max() const {
        GGML_ASSERT(task);

        if (!can_speculate()) {
            return 0;
        }

        // determine the max draft that fits the current slot state
        // note: slot.prompt is not yet expanded with the `id` token sampled above
        //       also, need to leave space for 1 extra token to allow context shifts
        int n_draft_max = n_ctx - prompt.n_tokens() - 2;

        if (n_remaining > 0) {
            n_draft_max = std::min(n_draft_max, n_remaining - 1);
        }

        SLT_DBG(*this, "max possible draft: %d\n", n_draft_max);

        return n_draft_max;
    }

    // add sampled token of this slot to the batch, optionally add the speculative draft tokens if any
    // fp_enabled gates the FlashPrefill sidecar: OFF leaves batch.fp_rows empty
    // (no allocation, no split/sync change). When enabled, exactly one frozen
    // row is pushed per successful add() to keep row identity. All decode rows
    // below are conservative dense (never sparse): ordinary decode, MTP/target
    // verification, and speculative replay all keep the pre-existing attention
    // path, and the existing active-lane MTP pause is untouched (this function
    // never drafts for rerot_internal slots; those go through
    // rerot_append_planned_token).
    void handle_last_sampled_token(server_batch & batch, bool fp_enabled) {
        namespace fp = server_flashprefill_routing;
        // Dense row template for decode-phase rows: unknown boundary forbids
        // any logical-prompt tail guessing; decode position is irrelevant to
        // routing so logical_pos stays UNKNOWN.
        const fp::fp_slot_boundary fp_unknown;
        auto fp_decode_row = [&](int32_t role) {
            return fp::make_row(role, id, LLAMA_FLASHPREFILL_READER_NONE,
                LLAMA_FLASHPREFILL_POS_UNKNOWN, fp_unknown);
        };
        bool add_ok = true;
        bool handled_append_chunk = false;
        if (!token_append_chunk.empty()) {
            GGML_ASSERT(spec_draft.empty());
            GGML_ASSERT(token_append_anchor != LLAMA_TOKEN_NULL);
            GGML_ASSERT((int32_t) token_append_chunk.size() + 1 <= batch.n_tokens_alloc - batch.size());
            handled_append_chunk = true;

            auto pos0 = prompt.tokens.pos_next();
            const int32_t batch0 = batch.size();

            add_ok &= batch.add(id, token_append_anchor, pos0++, false);
            if (fp_enabled && add_ok) {
                batch.fp_push_row(fp_decode_row(LLAMA_FLASHPREFILL_ROLE_DECODE));
            }
            for (size_t i = 0; i < token_append_chunk.size(); ++i) {
                const bool ok = batch.add(id, token_append_chunk[i], pos0++, i + 1 == token_append_chunk.size());
                add_ok &= ok;
                if (fp_enabled && ok) {
                    batch.fp_push_row(fp_decode_row(LLAMA_FLASHPREFILL_ROLE_DECODE));
                }
            }

            i_batch = batch0 + (int32_t) token_append_chunk.size();

            prompt.tokens.push_back(token_append_anchor);
            prompt.tokens.insert(token_append_chunk);
            sampled = token_append_chunk.back();
            token_append_anchor = LLAMA_TOKEN_NULL;
            token_append_chunk.clear();
        } else if (spec_draft.empty()) {
            // no speculative decoding
            i_batch = batch.size();

            if (!inp_embd.empty()) {
                add_ok &= batch.add(id, inp_embd, prompt.tokens.pos_next(), true);
            } else {
                add_ok &= batch.add(id, sampled, prompt.tokens.pos_next(), true);
            }
            if (fp_enabled && add_ok) {
                batch.fp_push_row(fp_decode_row(LLAMA_FLASHPREFILL_ROLE_DECODE));
            }

            SLT_DBG(*this, "slot decode token, id=%d, n_ctx = %d, n_tokens = %d, truncated = %d\n",
                    sampled, n_ctx, prompt.n_tokens(), truncated);
        } else {
            SLT_DBG(*this, "generate_draft: id=%d, #tokens=%zu, #draft=%zu, pos_next=%d\n",
                    sampled, prompt.tokens.size(), spec_draft.size(), prompt.tokens.pos_next());

            GGML_ASSERT(spec_i_batch.empty());

            spec_i_batch.push_back(batch.size());
            for (size_t i = 0; i < spec_draft.size(); i++) {
                spec_i_batch.push_back(batch.size() + i + 1);
            }

            auto pos0 = prompt.tokens.pos_next();

            // Target-verification batch (sampled + drafts): must never route
            // sparse. Replay-after-restore uses SPECULATIVE_REPLAY, all other
            // verification batches use MTP_VERIFY (covers MTP draft/target
            // verification; external-draft verification is equally dense and
            // shares the same DENSE_ROLE server reason).
            const int32_t verify_role = spec_is_replay
                ? LLAMA_FLASHPREFILL_ROLE_SPECULATIVE_REPLAY
                : LLAMA_FLASHPREFILL_ROLE_MTP_VERIFY;
            const bool ok_sampled = batch.add(id, sampled, pos0++, true);
            add_ok &= ok_sampled;
            if (fp_enabled && ok_sampled) {
                batch.fp_push_row(fp_decode_row(verify_role));
            }
            for (auto token : spec_draft) {
                const bool ok = batch.add(this->id, token, pos0++, true);
                add_ok &= ok;
                if (fp_enabled && ok) {
                    batch.fp_push_row(fp_decode_row(verify_role));
                }
            }
        }

        GGML_ASSERT(add_ok && "batch must be large enough to hold the sampled and draft tokens");

        if (!handled_append_chunk) {
            prompt.tokens.push_back(sampled);
            prompt.tokens.insert(spec_draft);
        }
    }

    void release(bool schedule_deferred = true) {
        if (is_processing()) {
            GGML_ASSERT(task);

            SLT_INF(*this, "stop processing: n_tokens = %d, truncated = %d\n", prompt.n_tokens(), truncated);

            t_last_used        =  ggml_time_us();
            t_token_generation = (ggml_time_us() - t_start_generation) / 1e3;

            state = SLOT_STATE_IDLE;

            // do not keep context of the child slots - the parent's context is enough
            if (task->is_child()) {
                prompt_clear();
            }

            reset();

            if (schedule_deferred) {
                callback_on_release(id);
            }
        }
    }

    int32_t n_prompt_tokens_processed_total() const {
        return n_prompt_tokens_processed_accum + n_prompt_tokens_processed;
    }

    result_timings get_timings() const {
        result_timings timings;
        timings.cache_n = n_prompt_tokens_cache_response;

        const int32_t n_prompt_total = n_prompt_tokens_processed_total();
        timings.prompt_n  = n_prompt_total;
        timings.prompt_ms = t_prompt_processing;
        if (n_prompt_total > 0 && t_prompt_processing > 0.0) {
            timings.prompt_per_token_ms = t_prompt_processing / n_prompt_total;
            timings.prompt_per_second   = 1e3 / t_prompt_processing * n_prompt_total;
        }

        timings.predicted_n            = n_decoded;
        timings.predicted_ms           = t_token_generation;
        timings.predicted_per_token_ms = t_token_generation / n_decoded;
        timings.predicted_per_second   = 1e3 / t_token_generation * n_decoded;

        // Add speculative metrics
        if (n_draft_total > 0) {
            timings.draft_n          = n_draft_total;
            timings.draft_n_accepted = n_draft_accepted;
        }

        return timings;
    }

    size_t find_stopping_strings(const std::string & text, const size_t last_token_size, bool is_full_stop) {
        GGML_ASSERT(task);

        size_t stop_pos = std::string::npos;

        for (const std::string & word : task->params.antiprompt) {
            size_t pos;

            if (is_full_stop) {
                const size_t tmp      = word.size() + last_token_size;
                const size_t from_pos = text.size() > tmp ? text.size() - tmp : 0;

                pos = text.find(word, from_pos);
            } else {
                // otherwise, partial stop
                pos = string_find_partial_stop(text, word);
            }

            if (pos != std::string::npos && (stop_pos == std::string::npos || pos < stop_pos)) {
                if (is_full_stop) {
                    stop           = STOP_TYPE_WORD;
                    stopping_word  = word;
                    has_next_token = false;
                }
                stop_pos = pos;
            }
        }

        return stop_pos;
    }

    void print_timings_tg() {
        if (n_decoded < 100) {
            return;
        }

        const int64_t t_now = ggml_time_us();

        if (t_now - t_print_last < 3*1000*1000) {
            return;
        }

        const double n_gen_second     = 1e3 / (t_token_generation)   * (n_decoded);
        const double n_gen_second_win = 1e6 / (t_now - t_print_last) * (n_decoded - n_decoded_last);

        t_print_last = t_now;
        n_decoded_last = n_decoded;

        SLT_INF(*this, "n_decoded = %6d, tg = %6.2f t/s, tg_3s = %6.2f t/s\n", n_decoded, n_gen_second, n_gen_second_win);
    }

    void print_timings_pp() const {
        const double n_prompt_second = 1e3 / t_prompt_processing * n_prompt_tokens_processed;
        const double f_progress = (float) prompt.n_tokens() / task->n_tokens();

        if (t_prompt_processing < 3000.0) {
            return;
        }

        SLT_INF(*this, "prompt processing, n_tokens = %6d, progress = %.2f, t = %6.2f s / %.2f tokens per second\n",
                n_prompt_tokens_processed, f_progress, t_prompt_processing / 1e3, n_prompt_second);
    }

    void print_timings() const {
        const int32_t n_prompt_total = n_prompt_tokens_processed_total();
        const double t_prompt        = n_prompt_total > 0 ? t_prompt_processing / n_prompt_total : 0.0;
        const double n_prompt_second = t_prompt_processing > 0.0 ? 1e3 / t_prompt_processing * n_prompt_total : 0.0;

        const double t_gen        =       t_token_generation / n_decoded;
        const double n_gen_second = 1e3 / t_token_generation * n_decoded;

        SLT_INF(*this,
                "prompt eval time = %10.2f ms / %5d tokens (%8.2f ms per token, %8.2f tokens per second)\n",
                t_prompt_processing, n_prompt_total, t_prompt, n_prompt_second);

        SLT_INF(*this,
                "       eval time = %10.2f ms / %5d tokens (%8.2f ms per token, %8.2f tokens per second)\n",
                t_token_generation, n_decoded, t_gen, n_gen_second);

        SLT_INF(*this,
                "      total time = %10.2f ms / %5d tokens\n",
                t_prompt_processing + t_token_generation, n_prompt_total + n_decoded);

        SLT_INF(*this,
                "   graphs reused = %10d\n",
                llama_perf_context(ctx_tgt).n_reused);

        if (n_draft_total > 0) {
            const float  draft_ratio  = (float) n_draft_accepted / n_draft_total;
            const double mean_acc_len = n_draft_verif_steps > 0 ? 1.0 + (double) n_draft_accepted / (double) n_draft_verif_steps : 1.0;

            std::string acceptance_rates_per_pos;
            if (n_draft_verif_steps > 0) {
                for (size_t i = 0; i < n_accepted_per_pos.size(); ++i) {
                    if (i > 0) {
                        acceptance_rates_per_pos += ", ";
                    }
                    acceptance_rates_per_pos += string_format("%.3f", (double) n_accepted_per_pos[i] / (double) n_draft_verif_steps);
                }
            }

            SLT_INF(*this,
                    "draft acceptance = %0.5f (%5d accepted / %5d generated), mean len = %5.2f\n",
                    draft_ratio, n_draft_accepted, n_draft_total, mean_acc_len);
            SLT_TRC(*this,
                    "     acc per pos = (%s)\n", acceptance_rates_per_pos.c_str());
        }

        common_speculative_print_stats(spec);
    }

    json to_json(bool only_metrics = false) const {
        json res;

        res = {
            {"id",            id},
            {"n_ctx",         n_ctx},
            {"speculative",   can_speculate()},
            {"is_processing", is_processing()},
        };

        const auto & ptask = task ? task : task_prev;

        if (ptask) {
            res["id_task"] = ptask->id;
            res["n_prompt_tokens"]           = (int32_t) prompt.tokens.size();
            res["n_prompt_tokens_processed"] = n_prompt_tokens_processed;
            res["n_prompt_tokens_cache"]     = n_prompt_tokens_cache;
            res["params"] = ptask->params.to_json(only_metrics);
            res["next_token"] = {
                {
                    {"has_next_token", has_next_token},
                    {"has_new_line",   has_new_line},
                    {"n_remain",       n_remaining},
                    {"n_decoded",      n_decoded},
                }
            };

            if (!only_metrics) {
                res["prompt"] = ptask->tokens.detokenize(ctx_tgt, true);
                res["generated"] = generated_text.empty() ? debug_generated_text : generated_text;
            }
        }

        return res;
    }

    void copy_state_to(server_slot & other) const {
        GGML_ASSERT(state == SLOT_STATE_DONE_PROMPT);

        mem.seq_rm(other.id,     -1, -1);
        mem.seq_cp(id, other.id, -1, -1);

        other.n_decoded   = n_decoded;
        other.n_remaining = n_remaining;
        other.i_batch     = i_batch;

        other.t_start_process_prompt          = t_start_process_prompt;
        other.t_prompt_processing             = t_prompt_processing;
        other.t_prompt_processing_accum       = t_prompt_processing_accum;
        other.n_prompt_tokens_cache           = n_prompt_tokens_cache;
        other.n_prompt_tokens_cache_response  = n_prompt_tokens_cache_response;
        other.n_prompt_tokens_processed       = n_prompt_tokens_processed;
        other.n_prompt_tokens_processed_accum = n_prompt_tokens_processed_accum;
        other.truncated                       = truncated;

        std::vector<uint8_t> state_spec;
        common_speculative_get_state(spec, id, state_spec);
        common_speculative_set_state(spec, other.id, state_spec);

        other.prompt = prompt.clone();
        other.init_sampler();
    }

    // returns 0 on success
    // caller need to update prompt.tokens after a successful call to keep track of the processing progress
    int process_mtmd_chunk(size_t idx, size_t & n_tokens_out) {
        GGML_ASSERT(mctx);
        const auto & input_tokens = task->tokens;
        const auto & chunk = input_tokens.find_chunk(idx);
        int32_t res = 0;

        auto try_decode = [&]() -> int32_t {
            if (mbatch) {
                float * embd = mtmd_batch_get_output_embd(mbatch.get(), chunk.get());
                if (embd) {
                    void * cb_data = spec;
                    static auto cb = [](llama_batch batch, void * user_data) {
                        common_speculative * spec = static_cast<common_speculative *>(user_data);
                        if (!common_speculative_process(spec, batch)) {
                            return 1;
                        }
                        return 0;
                    };

                    llama_pos new_n_past; // unused for now
                    res = mtmd_helper_decode_image_chunk(
                        mctx,
                        ctx_tgt,
                        chunk.get(),
                        embd,
                        prompt.tokens.pos_next(),
                        id,
                        llama_n_batch(ctx_tgt),
                        &new_n_past,
                        cb,
                        cb_data
                    );
                    if (res != 0) {
                        SLT_ERR(*this, "failed to decode mtmd chunk, idx = %zu, res = %d\n", idx, res);
                        return -1;
                    }
                    n_tokens_out = mtmd_input_chunk_get_n_tokens(chunk.get());
                    return 0; // success
                }
            }
            return 1; // (non-error) need to create & encode batch
        };

        // if the batch is already exist, try searching & encode
        res = try_decode();
        if (res == 0) {
            return 0;
        }
        if (res < 0) {
            // fatal error
            return res;
        }

        // otherwise, the batch is either uninitialized or is used up
        // we need to create & encode a new batch
        mbatch.reset(mtmd_batch_init(mctx));
        res = mtmd_batch_add_chunk(mbatch.get(), chunk.get());
        GGML_ASSERT(res == 0); // we should never have an empty batch

        // try batching as much as possible
        int n_added = 1;
        size_t idx_cur = idx;
        while (res == 0) {
            auto [next_chunk, next_idx] = input_tokens.find_next_media_chunk(idx_cur);
            if (next_chunk == nullptr) {
                break;
            }
            res = mtmd_batch_add_chunk(mbatch.get(), next_chunk->get());
            n_added += (res == 0 ? 1 : 0);
            idx_cur = next_idx;
            SLT_DBG(*this, "try adding media chunk idx = %zu to batch, res = %d\n", next_idx, res);
            // if res != 0, batch is full or chunk is not compatible -> this loop breaks
        }

        // TODO @ngxson : move this log line to debug when it become more stable
        SLT_TRC(*this, "encoding mtmd batch from idx = %zu, n_chunks = %d\n", idx, n_added);

        res = mtmd_batch_encode(mbatch.get());
        if (res != 0) {
            SLT_ERR(*this, "failed to encode mtmd batch for chunk idx = %zu, res = %d\n", idx, res);
            return -1;
        }

        return try_decode();
    }
};

// Saturating once-per-successful-slice merge of one context drain delta
// (MetricsIntegration owner; declared in server-context.h). Gauges:
// scratch_live overwrites (buffers reused), scratch_peak maxes, layout time
// sums measured slices only (unmeasured slices contribute nothing).
void server_flashprefill_routing::fp_gpu_merge_slice(
        fp_gpu_deltas & acc, const struct llama_flashprefill_metrics_slice & d) {
    const auto sat_add = [](uint64_t a, uint64_t b) {
        return a > UINT64_MAX - b ? UINT64_MAX : a + b;
    };
    acc.sparse_rows     = sat_add(acc.sparse_rows, d.sparse_rows);
    acc.dense_packed    = sat_add(acc.dense_packed, d.dense_packed);
    acc.selected_blocks = sat_add(acc.selected_blocks, d.selected_blocks);
    acc.corrected_blocks = sat_add(acc.corrected_blocks, d.corrected_blocks);
    acc.visible_tokens  = sat_add(acc.visible_tokens, d.visible_tokens);
    acc.exact_tokens    = sat_add(acc.exact_tokens, d.exact_tokens);
    for (int i = 0; i < 10; ++i) {
        acc.dense_rows[i] = sat_add(acc.dense_rows[i], d.dense_rows[i]);
    }
    for (int i = 0; i < 2; ++i) {
        acc.pool_rebuild[i] = sat_add(acc.pool_rebuild[i], d.pool_rebuild[i]);
    }
    for (int i = 0; i < 3; ++i) {
        acc.plan_invalidations[i] = sat_add(acc.plan_invalidations[i], d.plan_invalidations[i]);
    }
    acc.scratch_live_bytes = d.scratch_live_bytes;
    if (d.scratch_peak_bytes > acc.scratch_peak_bytes) {
        acc.scratch_peak_bytes = d.scratch_peak_bytes;
    }
    if (d.has_layout_us) {
        acc.layout_us_total = sat_add(acc.layout_us_total, d.layout_us);
        acc.layout_slices_measured += 1;
    }
    if (d.has_gpu_us) {
        acc.gpu_pool_us_total   = sat_add(acc.gpu_pool_us_total, d.gpu_pool_us);
        acc.gpu_select_us_total = sat_add(acc.gpu_select_us_total, d.gpu_select_us);
        acc.gpu_attn_us_total   = sat_add(acc.gpu_attn_us_total, d.gpu_attn_us);
        acc.gpu_slices_measured += 1;
    }
}


//
// server_metrics
//

struct server_metrics {
    int64_t t_start = 0;

    uint64_t n_prompt_tokens_processed_total = 0;
    uint64_t t_prompt_processing_total       = 0;
    uint64_t n_tokens_predicted_total        = 0;
    uint64_t t_tokens_generation_total       = 0;

    uint64_t n_tokens_max = 0;

    uint64_t n_prompt_tokens_processed = 0;
    uint64_t t_prompt_processing       = 0;

    uint64_t n_tokens_predicted  = 0;
    uint64_t t_tokens_generation = 0;

    uint64_t n_decode_total     = 0;
    uint64_t n_busy_slots_total = 0;

    // FlashPrefill V2 metrics accumulator contract (ServerRouting ownership).
    // Successful-only, cumulative for the process lifetime, all zero while OFF
    // (no series emitted, no GPU work counted):
    //   fp_eligible_rows: rows constructed with a sparse-eligible role
    //     (PREFILL or REROT_TEACHER_FORCED) and a known frozen boundary,
    //     counted once per successful decode slice covering the row.
    //   fp_dense_by_reason[7]: server-attributable dense rows by bounded
    //     DENSE_* route label, indexed by fp_dense_reason_index()
    //     (DENSE_OFF..DENSE_CAPACITY). Today the server fills DENSE_ROLE
    //     (decode / MTP verify / replay / frontier / embedding / rerank /
    //     multimodal) and DENSE_UNKNOWN_BOUNDARY (eligible role but no known
    //     interval); SHORT/T tail/UNSUPPORTED/CAPACITY refinements arrive via
    //     the pending GPU aggregate hook (never faked here).
    //   fp_policy_fingerprint / fp_has_policy: policy identity for state and
    //     cache isolation (llama_flashprefill_fingerprint over config +
    //     model/adapter ids). OFF (default): fp_has_policy==false, omitted.
    // GPU-determined totals (MetricsIntegration owner): sparse/dense-packed
    // plan counts, granular dense buckets, selected/corrected blocks,
    // visible/exact tokens, pool/plan bounded reasons, scratch live/peak,
    // host layout time. Producer: the context drain
    // (llama_flashprefill_metrics_drain) merged in fp_merge_gpu_slice() on
    // the post_decode success path with the same once-per-slice discipline
    // as fp_count_slice_success (saturating addition; see fp_gpu_deltas in
    // server-context.h). All zero while OFF (serializer emits zeros then at
    // no counting cost, per the matrix off_baseline contract); GPU work is
    // counted only after successful graph completion, never from theoretical
    // eligibility.
    uint64_t fp_eligible_rows = 0;
    uint64_t fp_dense_by_reason[7] = {};
    uint64_t fp_policy_fingerprint = 0;
    bool     fp_has_policy = false;
    server_flashprefill_routing::fp_gpu_deltas fp_gpu;

    void init() {
        t_start = ggml_time_us();
    }

    void on_prompt_eval(const server_slot & slot) {
        const double t_prompt_attempt = std::max(0.0, slot.t_prompt_processing - slot.t_prompt_processing_accum);
        n_prompt_tokens_processed_total += slot.n_prompt_tokens_processed;
        n_prompt_tokens_processed       += slot.n_prompt_tokens_processed;
        t_prompt_processing             += t_prompt_attempt;
        t_prompt_processing_total       += t_prompt_attempt;

        n_tokens_max = std::max(n_tokens_max, (uint64_t) slot.prompt.n_tokens());
    }

    void on_prediction(const server_slot & slot) {
        n_tokens_predicted_total   += slot.n_decoded;
        n_tokens_predicted         += slot.n_decoded;
        t_tokens_generation        += slot.t_token_generation;
        t_tokens_generation_total  += slot.t_token_generation;
    }

    void on_decoded(const std::vector<server_slot> & slots) {
        n_decode_total++;
        for (const auto & slot : slots) {
            if (slot.is_processing()) {
                n_busy_slots_total++;
            }
            n_tokens_max = std::max(n_tokens_max, (uint64_t) slot.prompt.n_tokens());
        }
    }

    void reset_bucket() {
        n_prompt_tokens_processed = 0;
        t_prompt_processing       = 0;
        n_tokens_predicted        = 0;
        t_tokens_generation       = 0;
    }
};


//
// server_context_impl (private implementation)
//

struct server_context_impl {
    friend struct server_context;

public:
    // only use these pointers outside of this class:
    //  - when not in sleeping state
    //  - and, with thread-safe APIs (e.g., tokenizer calls)
    llama_model * model_tgt = nullptr;

    mtmd_context * mctx = nullptr;
    const llama_vocab * vocab = nullptr;

    server_queue    queue_tasks;
    server_response queue_results;

    void dump_request_tokens(
            const std::vector<llama_token> & tokens,
            server_token_dump_kind kind) const {
        request_token_dump.append(tokens, kind);
    }

    // note: chat_params must not be refreshed upon existing sleeping state
    server_chat_params chat_params;

    server_state_callback_t callback_state = [](server_state, json) -> void {};
    server_token_hack_factory_t token_hack_factory;

    server_context_impl() {
        mtmd_helper_log_set(common_log_default_callback, nullptr);
    }

    ~server_context_impl() {
        if (!sleeping) {
            // destroy() is already called when entering sleeping state
            // we don't call it again here to avoid double free
            destroy();
        }
    }

private:
    // note: accessing these fields outside of this class is not thread-safe
    // use server_context methods instead

    common_params params_base;

    // note: keep these alive - they determine the lifetime of the model, context, etc.
    common_init_result_ptr llama_init;

    llama_context * ctx_tgt = nullptr;

    server_batch batch;

    llama_model   * model_dft = nullptr;
    llama_context * ctx_dft   = nullptr;

    common_speculative_init_result_ptr spec_init;

    common_context_seq_rm_type ctx_tgt_seq_rm_type = COMMON_CONTEXT_SEQ_RM_TYPE_NO;
    common_context_seq_rm_type ctx_dft_seq_rm_type = COMMON_CONTEXT_SEQ_RM_TYPE_NO;

    common_speculative_ptr spec;
    int64_t t_tgt_verify_start = 0;

    bool add_bos_token = true;

    int32_t n_ctx; // total context for all clients / slots

    // set to llama_model_n_swa(model)
    // if swa_full is enabled, this is set to 0 to simulate a non-SWA model
    int32_t n_swa;

    struct server_retry_state {
        int32_t n_decoded = 0;
        int32_t n_prompt_tokens_original = 0;
        int32_t n_prompt_tokens_cache_response = 0;
        int32_t n_prompt_tokens_processed = 0;
        server_tokens response_prompt;
        size_t last_nl_pos = 0;
        std::string generated_text;
        llama_tokens generated_tokens;
        std::vector<completion_token_output> generated_token_probs;
        size_t n_sent_text = 0;
        bool has_new_line = false;
        bool truncated = false;
        int64_t t_start_generation = 0;
        double t_prompt_processing = 0.0;
    };

    // slots / clients
    std::vector<server_slot> slots;
    std::unordered_map<std::string, int> cache_key_slots;
    std::unordered_map<int, server_retry_state> retry_states;

    int trace = 0;
    int slots_debug = 0;
    int n_empty_consecutive = 0;

    server_inference_mode inference_mode = SERVER_INFERENCE_MODE_DECODE;
    int32_t id_slot_prefill = -1;

    // FlashPrefill V2 server policy (ServerRouting ownership).
    // Default is always OFF (llama_flashprefill_default_config): fp_enabled
    // false, sidecar never allocated, scheduling byte-identical to baseline.
    // Remaining dependencies (not guessed here): ConfigIntegration declares
    // llama_context_params.flashprefill + llama_decode_with_flashprefill in
    // llama.h and the CLI plumbing; ContextIntegration implements the decode
    // copy semantics + llama_flashprefill_policy_fingerprint getter and the
    // per-ubatch GPU-delta producer. Until those land, the impl builds and
    // validates the borrowed exec view per slice but keeps calling the
    // ordinary llama_decode() dense route (see decode()).
    llama_flashprefill_config fp_config = llama_flashprefill_default_config();
    bool fp_enabled = false;

    // Store identity for isolation (StatePolicy core key, not just diagnostics).
    // fp_current_fingerprint/fp_has_policy are stamped at load_model from the
    // live context (llama_flashprefill_policy_fingerprint) and never change
    // afterwards: the policy is immutable for the context lifetime. They feed
    // metrics/diagnostics only.
    // fp_current_state_key/fp_has_state_key are the store identity, refreshed
    // from llama_flashprefill_state_cache_key() every iteration (not just at
    // load): policy fingerprint + context serial + adapter generation. Any
    // effective LoRA/cvec mutation retires the key, so the RAM cache can never
    // silently reuse KV produced under older adapters. Durable authority on
    // every restore is the 64-byte core envelope inside the state bytes (the
    // key itself is an in-memory fast-path stamp, never serialized); the RAM
    // stamp below is keyed on this same value. 0 == no isolation identity
    // (OFF: legacy path).
    // fp_cache_key/fp_cache_key_stamped record which identity the RAM prompt
    // cache contents were produced under; fp_guard_prompt_cache() drops the
    // whole cache when the stamp disagrees, so sparse-prefill KV can never be
    // consumed as dense-prefill KV (or across any adapter/policy change).
    uint64_t fp_current_fingerprint = 0;
    bool     fp_has_policy = false;
    uint64_t fp_current_state_key = 0;
    bool     fp_has_state_key = false;
    uint64_t fp_cache_key = 0;
    bool     fp_cache_key_stamped = false;

    // Drop RAM prompt-cache contents produced under a different store identity.
    // Cheap (one compare) and OFF-safe: OFF has no state key, so this keeps
    // exact old behavior and never spurious-clears. Must run before any decode
    // or cache use in the iteration; called at the top of update_slots(). The
    // cache is process-lifetime with a single policy today, so this only fires
    // on a genuine identity disagreement (policy change, adapter mutation, or
    // context replacement) — which is exactly when reuse would silently mix
    // approximate and exact KV lineages.
    void fp_guard_prompt_cache() {
        if (!prompt_cache) {
            return;
        }
        // Refresh the live store identity every iteration (not just at load):
        // LoRA apply/cvec on the live context (per-batch slot LoRA, POST
        // /lora-adapters) retires the StatePolicy core key via the context
        // adapter generation, and the guard must observe that retirement here
        // or stale RAM entries would survive an adapter switch. Cheap single
        // key recompute per iteration; OFF stays 0 (legacy behavior, never
        // spurious-clears). Slot sidecar writes later in this same iteration
        // therefore also stamp the current identity.
        if (ctx_tgt != nullptr) {
            fp_current_state_key = llama_flashprefill_state_cache_key(ctx_tgt);
            fp_has_state_key = (fp_current_state_key != 0);
        }
        if (!fp_has_state_key) {
            // No identity to enforce by (pre-load, OFF, or key unavailable):
            // keep exact old behavior, never spurious-clear.
            return;
        }
        namespace fp = server_flashprefill_routing;
        if (!fp_cache_key_stamped) {
            fp_cache_key = fp_current_state_key;
            fp_cache_key_stamped = true;
            return;
        }
        if (fp::fp_isolate_store(fp_cache_key, true, fp_current_state_key, true)
                != fp::FP_STORE_USABLE) {
            SRV_WRN("flashprefill store identity changed (cache %016llx vs current %016llx): dropping %zu prompt-cache states\n",
                (unsigned long long) fp_cache_key,
                (unsigned long long) fp_current_state_key,
                prompt_cache->states.size());
            prompt_cache->states.clear();
            fp_cache_key = fp_current_state_key;
        }
    }

    // Manual slot files carry NO companion sidecar: the single authority for
    // store isolation is the 64-byte StatePolicy core envelope inside the
    // state bytes themselves (policy fingerprint + process nonce + context
    // serial + adapter generation, validated before any KV is consumed on
    // load). No v1/v2 ".flashprefill" scheme is written or read — a redundant
    // file sidecar would be a second source of truth that can disagree with
    // the envelope. Restores under a mismatched identity fail at load
    // (nread == 0 below) with a re-prefill error; OFF restores keep exact old
    // behavior (no envelope in either direction).

    // True for the two sparse-eligible roles with a known frozen boundary.
    // Everything else is a server-attributable dense row (DENSE_ROLE, or
    // DENSE_UNKNOWN_BOUNDARY when an eligible role lacks its interval).
    bool fp_row_is_eligible(const llama_flashprefill_row & row) const {
        if (!server_flashprefill_routing::role_is_sparse_eligible(row.role)) {
            return false;
        }
        return row.prefill_known;
    }

    int32_t fp_server_dense_reason(const llama_flashprefill_row & row) const {
        if (server_flashprefill_routing::role_is_sparse_eligible(row.role) && !row.prefill_known) {
            return LLAMA_FLASHPREFILL_ROUTE_DENSE_UNKNOWN_BOUNDARY;
        }
        return LLAMA_FLASHPREFILL_ROUTE_DENSE_ROLE;
    }

    // Successful-only accounting for one slice [off, off+n). Called at the top
    // of post_decode (which runs only after its decode returned 0), so each
    // row is counted exactly once; retries, throws, and cancels never arrive
    // here. Attributes rows to slots via batch.tokens (row identity intact).
    void fp_count_slice_success(int32_t off, int32_t n) {
        if (!fp_enabled || batch.fp_rows.empty()) {
            return;
        }
        GGML_ASSERT(off >= 0 && off + n <= (int32_t) batch.fp_rows.size());
        GGML_ASSERT(off >= 0 && off + n <= (int32_t) batch.tokens.size());
        for (int32_t i = 0; i < n; ++i) {
            const int32_t idx = off + i;
            const auto & row = batch.fp_rows[idx];
            const int32_t id_slot = batch.tokens[idx].id_slot;
            server_slot * slot = get_slot_by_id(id_slot);
            if (fp_row_is_eligible(row)) {
                metrics.fp_eligible_rows += 1;
                if (slot != nullptr) {
                    slot->fp_eligible_rows += 1;
                }
            } else {
                const int32_t reason = fp_server_dense_reason(row);
                const int32_t ridx = server_flashprefill_routing::fp_dense_reason_index(reason);
                GGML_ASSERT(ridx >= 0);
                metrics.fp_dense_by_reason[ridx] += 1;
                if (slot != nullptr) {
                    slot->fp_dense_by_reason[ridx] += 1;
                }
            }
        }
    }

    // GPU-determined merge for one successful slice (MetricsIntegration
    // owner; called in post_decode right after fp_count_slice_success, so the
    // same once-per-slice discipline covers both). Drains the target-context
    // ledger (transactional: failed/retried calls never commit context-side,
    // and the drain is consume-once, so narrowed-batch retries cannot double
    // count). The speculative draft context (ctx_dft) is deliberately not
    // drained: its re-eval traffic stays uncounted rather than risk double
    // attribution against the target ledger. OFF or empty drain merges
    // nothing. The drain's eligible_rows field is deliberately ignored here
    // (server-side fp_eligible_rows above stays canonical; merging both
    // would double count the same rows).
    void fp_merge_gpu_slice() {
        if (!fp_enabled || ctx_tgt == nullptr) {
            return;
        }
        llama_flashprefill_metrics_slice d = {};
        const int32_t rc = llama_flashprefill_metrics_drain(ctx_tgt, &d);
        if (rc != 0) {
            return; // 1: empty/OFF (zeroed); -1 impossible with non-null args
        }
        server_flashprefill_routing::fp_gpu_merge_slice(metrics.fp_gpu, d);
    }

    std::unique_ptr<server_prompt_cache> prompt_cache;

    // RERoT thin glue (Stage 7 + compat core, §§18-21,A.11): the logical
    // episode/tree/queue/frontier truth lives in server_rerot_runtime (already
    // implemented in server-rerot.*). This context only holds the runtime and
    // calls it from four gated hook points below. OFF: rerot stays null and
    // every hook returns immediately, so scheduling stays byte-identical.
    std::unique_ptr<server_rerot_runtime> rerot;
    uint64_t rerot_episode_id = 0;
    uint64_t rerot_task_episode_id_next = 1;
    uint64_t rerot_task_generation_next = 1;

    struct rerot_transport_state {
        server_task response_task;
        std::vector<common_adapter_lora_info> lora;
        std::unordered_map<llama_rerot_node_id, server_tokens> lineage_tokens;
        std::unordered_map<llama_rerot_run_id, std::string> run_bytes;
        std::unordered_map<llama_rerot_run_id, std::string> run_public_prefixes;
        server_rerot_line_mux line_mux;
        std::string streamed_reasoning;
        size_t final_content_offset = 0;
        uint64_t streamed_lines = 0;
        uint64_t sampled_tokens = 0;
        uint32_t root_seed = LLAMA_DEFAULT_SEED;
        int32_t prompt_tokens_processed = 0;
        int32_t prompt_tokens_processed_accum = 0;
        int32_t prompt_tokens_cache_response = 0;
        double prompt_processing_ms = 0.0;
        bool segmented_active = false;
        bool triattention_compressed = false;
        uint64_t triattention_synced_public_tokens = 0;
        uint64_t model_tokens = 0;
        uint64_t parallel_model_tokens = 0;
        int64_t started_us = 0;
        int64_t parallel_started_us = 0;
        uint64_t parallel_elapsed_us = 0;
        bool parallel_finished = false;
        uint64_t parallel_peak_lanes = 0;
        common_grammar saved_user_grammar;
        common_sampler_ptr c0_sampler;
        std::unordered_map<llama_rerot_node_id, common_sampler_ptr> lane_samplers;
        // Passivated mid-frame forward state per node. A STARTING worker
        // yielded mid-F_i already wrote the frame prefix into KV and tape;
        // resuming must continue from the saved cursor, never re-inject the
        // full frame. Saved/restored alongside lineage+sampler on park.
        struct rerot_parked_injection {
            server_rerot_injection_kind kind = server_rerot_injection_kind::none;
            llama_tokens tokens;
            size_t cursor = 0;
        };
        std::unordered_map<llama_rerot_node_id, rerot_parked_injection> parked_injections;
        // Pending next-source-token decision per node, captured from a valid
        // row before any yield and fed once through the ordinary next-input
        // path on resume. Consumed (erased) on restore; fail closed if absent.
        std::unordered_map<llama_rerot_node_id, llama_token> pending_tokens;
        // Exact committed native-end token sequences per node, in commit
        // order. A multi-token native end commits its earlier candidate rows
        // as BODY/PENDING and only the closing row as SOURCE_END, so the
        // candidate span is staged per row (while the exit parser holds a
        // candidate across the committed row) and moved into evidence on
        // close; a released (dead) candidate is dropped. Lazy-grammar
        // activation at phase handoffs replays these exact ids — no
        // re-tokenization, which would risk boundary mismatches.
        std::unordered_map<llama_rerot_node_id, llama_tokens> source_end_token_ids;
        std::unordered_map<llama_rerot_node_id, llama_tokens> source_end_candidate_stage;
        int64_t t_probe_start_us = 0;
        double probe_seconds = 0.0;
        double prefix_rebuild_seconds = 0.0;
        uint64_t ordinary_prompt_tokens = 0;
        uint64_t dag_lcp_tokens = 0;
        uint64_t replay_from_tokens = 0;
        uint64_t actual_replayed_tokens = 0;
        double fixed_entry_seconds = 0.0;
        double synthesis_switch_seconds = 0.0;

        explicit rerot_transport_state(server_task && task)
            : response_task(std::move(task)) {
        }
    };

    std::unordered_map<uint64_t, std::unique_ptr<rerot_transport_state>> rerot_transport;

    bool rerot_active(uint64_t episode_id = 0) const {
        if (!rerot) {
            return false;
        }
        if (episode_id != 0) {
            return rerot->episode(episode_id) != nullptr;
        }
        return !rerot_transport.empty() || (rerot_episode_id != 0 && rerot->episode(rerot_episode_id) != nullptr);
    }

    const server_rerot_episode * rerot_active_episode(uint64_t episode_id = 0) const {
        if (!rerot) {
            return nullptr;
        }
        if (episode_id != 0) {
            return rerot->episode(episode_id);
        }
        if (rerot_episode_id != 0 && rerot->episode(rerot_episode_id)) {
            return rerot->episode(rerot_episode_id);
        }
        if (!rerot_transport.empty()) {
            return rerot->episode(rerot_transport.begin()->first);
        }
        return nullptr;
    }

    size_t rerot_private_batch_size(const server_slot & slot) const {
        if (!ctx_tgt ||
            (!server_rerot_private_microbatch(slot.rerot_injection) &&
             !server_rerot_public_microbatch(slot.rerot_injection)) ||
            slot.rerot_injection_cursor >= slot.rerot_injection_tokens.size()) {
            return 1;
        }
        const size_t fair_batch_capacity = std::max<size_t>(
            1, llama_n_batch(ctx_tgt) / std::max<size_t>(1, slots.size()));
        return std::min({
            slot.rerot_injection_tokens.size() - slot.rerot_injection_cursor,
            SERVER_REROT_PRIVATE_BATCH,
            fair_batch_capacity,
        });
    }

    void rerot_emit_reasoning_lines(
            uint64_t episode_id,
            rerot_transport_state & transport,
            server_rerot_stream_lines && ready) {
        if (!ready.ok) {
            if (rerot && episode_id != 0) {
                rerot->hard_abort(
                    episode_id,
                    "rerot_stream_error: " + ready.error);
            }
            return;
        }
        if (!transport.response_task.params.stream) {
            return;
        }

        for (auto & line : ready.lines) {
            auto res = std::make_unique<server_task_result_cmpl_partial>();
            res->id = transport.response_task.id;
            res->index = transport.response_task.index;
            res->content = line;
            res->is_rerot_reasoning = true;
            res->n_decoded = static_cast<int32_t>(std::min<uint64_t>(
                transport.sampled_tokens,
                std::numeric_limits<int32_t>::max()));
            res->n_prompt_tokens = transport.response_task.n_tokens();
            res->n_prompt_tokens_cache = transport.prompt_tokens_cache_response;
            res->post_sampling_probs = transport.response_task.params.post_sampling_probs;
            res->verbose = transport.response_task.params.verbose;
            res->res_type = transport.response_task.params.res_type;
            res->oaicompat_model = transport.response_task.params.oaicompat_model;
            res->oaicompat_cmpl_id = transport.response_task.params.oaicompat_cmpl_id;
            queue_results.send(std::move(res));

            transport.streamed_reasoning += line;
            ++transport.streamed_lines;
        }
    }

    bool rerot_stream_commit(
            uint64_t episode_id,
            llama_rerot_node_id node_id,
            llama_rerot_run_id run_id,
            std::string_view bytes,
            size_t public_prefix_bytes) {
        auto transport_it = rerot_transport.find(episode_id);
        auto * episode = rerot ? rerot->episode(episode_id) : nullptr;
        if (transport_it == rerot_transport.end() || !episode) {
            return false;
        }
        auto & transport = *transport_it->second;
        if (!transport.response_task.params.stream) {
            return true;
        }

        auto ready = transport.line_mux.append(
            node_id, run_id, bytes, episode->document, public_prefix_bytes);
        const bool ok = ready.ok;
        rerot_emit_reasoning_lines(episode_id, transport, std::move(ready));
        return ok;
    }

    bool rerot_stream_visibility_changed(
            uint64_t episode_id,
            llama_rerot_node_id node_id) {
        auto transport_it = rerot_transport.find(episode_id);
        auto * episode = rerot ? rerot->episode(episode_id) : nullptr;
        if (transport_it == rerot_transport.end() || !episode) {
            return false;
        }
        auto & transport = *transport_it->second;
        if (!transport.response_task.params.stream) {
            return true;
        }

        auto ready = transport.line_mux.drain(node_id, episode->document);
        const bool ok = ready.ok;
        rerot_emit_reasoning_lines(episode_id, transport, std::move(ready));
        return ok;
    }

    bool rerot_stream_finish_lane(
            uint64_t episode_id,
            llama_rerot_node_id node_id) {
        auto transport_it = rerot_transport.find(episode_id);
        auto * episode = rerot ? rerot->episode(episode_id) : nullptr;
        if (transport_it == rerot_transport.end() || !episode) {
            return false;
        }
        auto & transport = *transport_it->second;
        if (!transport.response_task.params.stream) {
            return true;
        }

        auto ready = transport.line_mux.finish(node_id, episode->document);
        const bool ok = ready.ok;
        rerot_emit_reasoning_lines(episode_id, transport, std::move(ready));
        return ok;
    }

    void rerot_note_parallel_start(uint64_t episode_id) {
        auto transport_it = rerot_transport.find(episode_id);
        if (transport_it == rerot_transport.end() ||
            transport_it->second->parallel_started_us != 0 ||
            transport_it->second->parallel_finished) {
            return;
        }
        transport_it->second->parallel_started_us = ggml_time_us();
    }

    // C02: capture the episode's peak concurrent Lane count (logical lanes).
    // Called every frontier admission; idempotent max across the episode.
    void rerot_note_lane_count(uint64_t episode_id, uint64_t live_lanes) {
        auto transport_it = rerot_transport.find(episode_id);
        if (transport_it == rerot_transport.end()) {
            return;
        }
        if (live_lanes > transport_it->second->parallel_peak_lanes) {
            transport_it->second->parallel_peak_lanes = live_lanes;
        }
    }

    void rerot_note_parallel_end(uint64_t episode_id, int64_t now_us) {
        auto transport_it = rerot_transport.find(episode_id);
        if (transport_it == rerot_transport.end() ||
            transport_it->second->parallel_started_us == 0 ||
            transport_it->second->parallel_finished) {
            return;
        }
        transport_it->second->parallel_elapsed_us =
            static_cast<uint64_t>(std::max<int64_t>(
                0, now_us - transport_it->second->parallel_started_us));
        transport_it->second->parallel_finished = true;
    }

    void rerot_record_completed_episode(uint64_t episode_id) {
        auto transport_it = rerot_transport.find(episode_id);
        if (transport_it == rerot_transport.end()) {
            return;
        }

        const int64_t now_us = ggml_time_us();
        rerot_note_parallel_end(episode_id, now_us);
        const auto & transport = *transport_it->second;
        const double episode_seconds = static_cast<double>(
            std::max<int64_t>(0, now_us - transport.started_us)) / 1.0e6;
        const double parallel_seconds =
            static_cast<double>(transport.parallel_elapsed_us) / 1.0e6;

        ++rerot_metrics.completed_episodes;
        rerot_metrics.completed_model_tokens += transport.model_tokens;
        rerot_metrics.parallel_model_tokens += transport.parallel_model_tokens;
        rerot_metrics.completed_episode_seconds += episode_seconds;
        rerot_metrics.parallel_seconds += parallel_seconds;
        rerot_metrics.parallel_peak_lanes_sum += transport.parallel_peak_lanes;

        const double aggregate_tps = episode_seconds > 0.0
            ? static_cast<double>(transport.model_tokens) / episode_seconds
            : 0.0;
        const double parallel_tps = parallel_seconds > 0.0
            ? static_cast<double>(transport.parallel_model_tokens) / parallel_seconds
            : 0.0;
        SRV_INF("RERoT throughput: episode=%" PRIu64
                " model_tokens=%" PRIu64 " wall_s=%.6f aggregate_tps=%.3f"
                " parallel_tokens=%" PRIu64 " parallel_s=%.6f parallel_tps=%.3f\n",
            episode_id,
            transport.model_tokens,
            episode_seconds,
            aggregate_tps,
            transport.parallel_model_tokens,
            parallel_seconds,
            parallel_tps);
    }

    server_task rerot_clone_task(const server_task & source) const {
        server_task copy(source.type);
        copy.id = source.id;
        copy.index = source.index;
        copy.id_slot = -1;
        copy.id_parent = source.id_parent;
        copy.params = source.params;
        copy.tokens = source.tokens.clone();
        copy.is_retry = false;
        copy.cache_key.clear();
        copy.rerot_episode_id = source.rerot_episode_id;
        copy.rerot_generation = source.rerot_generation;
        copy.rerot_original_user_text = source.rerot_original_user_text;
        return copy;
    }

    static common_grammar rerot_planner_remainder_grammar() {
        // The structural opener "<ol>\n<li>" is injected before model
        // sampling. Constrain exactly the remainder: one text item containing
        // a non-whitespace character, then zero or more flat sibling items,
        // then the single closing tag. Excluding '<' from item text prevents
        // child delimiters or nested markup from entering a PENDING record.
        return {
            COMMON_GRAMMAR_TYPE_USER,
            std::string(server_rerot_planner_grammar()),
        };
    }

    static void rerot_install_planner_grammar(task_params & params) {
        (void) server_rerot_take_user_grammar(params);
        params.sampling.grammar = rerot_planner_remainder_grammar();
        params.sampling.grammar_lazy = false;
        params.sampling.grammar_triggers.clear();
        params.sampling.preserved_tokens.clear();
    }

    static void rerot_remove_planner_grammar(task_params & params) {
        params.sampling.grammar = common_grammar{};
        params.sampling.grammar_lazy = false;
        params.sampling.grammar_triggers.clear();
        params.sampling.preserved_tokens.clear();
    }

    static bool rerot_install_child_grammar(
            task_params & params,
            std::string_view close_marker) {
        std::string grammar = server_rerot_child_grammar(close_marker);
        if (grammar.empty()) {
            return false;
        }
        params.sampling.grammar = {
            COMMON_GRAMMAR_TYPE_USER,
            std::move(grammar),
        };
        params.sampling.grammar_lazy = false;
        params.sampling.grammar_triggers.clear();
        params.sampling.preserved_tokens.clear();
        return true;
    }

    void rerot_bind_sampler(server_slot & slot) {
        const bool backend_sampling =
            slot.smpl &&
            slot.task &&
            slot.task->params.sampling.backend_sampling &&
            slot.task->params.sampling.n_probs == 0 &&
            !slot.can_speculate();
        llama_set_sampler(
            ctx_tgt,
            slot.id,
            backend_sampling ? common_sampler_get(slot.smpl.get()) : nullptr);
    }

    std::string rerot_planner_control_prompt() const {
        return std::string(server_rerot_planner_prompt());
    }

    std::string rerot_worker_control_prompt(
            std::string_view,
            std::string_view) const {
        return "\n仅用一句完整事实回答上方标题，不写标签或元说明，以句号结束：";
    }

    static std::string rerot_serial_resume_prompt(bool child_fence) {
        return child_fence
            ? "</think>\n"
            : "\n这个内容块不需要并行。我完成剩余思考，"
              "现在按照当前模型的原生对话格式给出最终回答。\n";
    }

    std::pair<std::string, std::string> rerot_native_think_tags(const server_slot & slot) const {
        if (!chat_params.tmpls) {
            return {};
        }
        common_chat_templates_inputs inputs;
        inputs.messages = rerot_slot_chat_messages(slot);
        if (inputs.messages.empty()) {
            return {};
        }
        inputs.use_jinja = chat_params.use_jinja;
        inputs.enable_thinking = true;
        inputs.reasoning_format = COMMON_REASONING_FORMAT_DEEPSEEK;
        try {
            const auto applied = common_chat_templates_apply(chat_params.tmpls.get(), inputs);
            if (!applied.supports_thinking ||
                applied.thinking_start_tag.empty() ||
                applied.thinking_end_tags.empty()) {
                return {};
            }
            return {applied.thinking_start_tag, applied.thinking_end_tags.front()};
        } catch (...) {
            return {};
        }
    }

    // Detect exactly what parse_special tokenization will interpret in
    // user-controlled label/intent text: tokenize it the same way fixed
    // entries are tokenized (common_tokenize, parse_special=true) and inspect
    // the returned ids for CONTROL or USER_DEFINED. A hit means the text
    // would decode as a real native role round, so callers fail the plan
    // closed instead of rewriting it (AGENTS.md §04: intent/tool params use
    // template serialization, never string-spliced boundaries). Linear in the
    // provided text: no vocabulary scan, no cache, no exemptions. Ordinary
    // prose and mathematical '<' pass iff the tokenizer treats them normally.
    bool rerot_text_decodes_reserved_control(std::string_view text) const {
        if (text.empty()) {
            return false;
        }
        const llama_vocab * vocab = model_tgt ? llama_model_get_vocab(model_tgt) : nullptr;
        if (!vocab) {
            return true; // cannot prove clean without the live vocabulary: refuse
        }
        const llama_tokens ids = common_tokenize(ctx_tgt, std::string(text), false, true);
        for (const llama_token id : ids) {
            const auto attr = llama_vocab_get_attr(vocab, id);
            if (attr & (LLAMA_TOKEN_ATTR_CONTROL | LLAMA_TOKEN_ATTR_USER_DEFINED)) {
                return true;
            }
        }
        return false;
    }

    static bool rerot_frame_has_native_boundaries(
            std::string_view frame,
            std::string_view think_end,
            std::string_view think_start) {
        if (think_end.empty() || think_start.empty()) {
            return false;
        }
        const size_t end_pos = frame.find(think_end);
        if (end_pos == std::string::npos) {
            return false;
        }
        const size_t start_pos = frame.find(think_start, end_pos + think_end.size());
        if (start_pos == std::string::npos) {
            return false;
        }
        const bool has_tool =
            frame.find("spawn_lane") != std::string::npos ||
            frame.find("tool_call") != std::string::npos ||
            frame.find("tool_response") != std::string::npos ||
            frame.find("<tool") != std::string::npos;
        return has_tool;
    }

    llama_tokens rerot_tokenize_injection(std::string_view text) const {
        return common_tokenize(ctx_tgt, std::string(text), false, true);
    }

    std::string rerot_detokenize_injection(const llama_tokens & tokens) const {
        std::string text;
        for (const llama_token tok : tokens) {
            text += common_token_to_piece(ctx_tgt, tok, true);
        }
        return text;
    }

    // The complete map is already in P. A handoff only names its next node.
    static common_chat_tool rerot_become_tool() {
        common_chat_tool node;
        node.name = "become";
        node.parameters =
            "{\"type\":\"object\",\"properties\":{"
            "\"node\":{\"type\":\"string\"}"
            "},\"required\":[\"node\"]}";
        return node;
    }

    static common_chat_tool rerot_spawn_lane_tool() {
        common_chat_tool spawn;
        spawn.name = "spawn_lane";
        spawn.description = "Internal DAG lane handoff. Not a user-visible tool.";
        spawn.parameters =
            "{\"type\":\"object\",\"properties\":{"
            "\"id\":{\"type\":\"string\"},"
            "\"intent\":{\"type\":\"string\"},"
            "\"phase\":{\"type\":\"string\"}"
            "},\"required\":[\"id\",\"intent\"]}";
        return spawn;
    }

    static const task_params * rerot_slot_params(const server_slot & slot) {
        if (slot.task) {
            return &slot.task->params;
        }
        return nullptr;
    }

    std::vector<common_chat_msg> rerot_slot_chat_messages(const server_slot & slot) const {
        const auto * params = rerot_slot_params(slot);
        if (params == nullptr || !params->rerot_chat_messages.is_array() ||
            params->rerot_chat_messages.empty()) {
            return {};
        }
        try {
            return common_chat_msgs_parse_oaicompat(params->rerot_chat_messages);
        } catch (...) {
            return {};
        }
    }

    std::vector<common_chat_tool> rerot_slot_dag_tools(const server_slot & slot) const {
        const task_params * params = rerot_slot_params(slot);
        const std::string & wire = params ? params->rerot_plan_wire : std::string();
        std::vector<common_chat_tool> tools;
        if (params && params->rerot_chat_tools.is_array() && !params->rerot_chat_tools.empty()) {
            try {
                tools = common_chat_tools_parse_oaicompat(params->rerot_chat_tools);
            } catch (...) {
                tools.clear();
            }
        }
        tools.push_back(wire == "mindmap" ? rerot_become_tool() : rerot_spawn_lane_tool());
        return tools;
    }

    void rerot_fill_chat_inputs(common_chat_templates_inputs & inputs, const server_slot & slot) const {
        inputs.use_jinja = chat_params.use_jinja;
        inputs.enable_thinking = true;
        inputs.reasoning_format = chat_params.reasoning_format;
        inputs.chat_template_kwargs = chat_params.chat_template_kwargs;
        inputs.add_generation_prompt = true;
        inputs.tool_choice = COMMON_CHAT_TOOL_CHOICE_AUTO;
        inputs.tools = rerot_slot_dag_tools(slot);
        const auto * params = rerot_slot_params(slot);
        if (params && params->rerot_chat_now_ms != 0) {
            inputs.now = std::chrono::system_clock::time_point(
                std::chrono::milliseconds(params->rerot_chat_now_ms));
        }
    }

    void rerot_capture_sampler_snapshot(
            server_rerot_prebranch_checkpoint & cp,
            const common_sampler * smpl) {
        if (!rerot || smpl == nullptr) {
            return;
        }
        rerot->capture_checkpoint_sampler(
            cp,
            common_sampler_get_seed(smpl),
            common_sampler_get_token_history(smpl));
    }

    // Native F_i via the live chat template (AGENTS.md §04). Baseline and
    // full applies share the actual request messages (or a target-only dummy
    // user when this is not a chat completion) so F_i stays independent of
    // neighbor, slot, and frontier. If the live prefix is a token prefix of the
    // full render, that LCP is used instead.
    llama_tokens rerot_native_fixed_entry_tokens(const server_slot & slot,
                                                 const std::string & node_label,
                                                 const std::string & intent,
                                                 bool                is_synthesis,
                                                 // Legacy JSON-DAG metadata; mindmap frames do not expose it.
                                                 std::string_view    final_mode,
                                                 std::string_view    think_end,
                                                 std::string_view    think_start) const {
        if (!chat_params.tmpls || !chat_params.use_jinja || think_end.empty() || think_start.empty()) {
            return {};
        }
        try {
            const auto caps   = common_chat_templates_get_caps(chat_params.tmpls.get());
            const auto cap_it = caps.find("supports_tool_calls");
            if (cap_it == caps.end() || !cap_it->second) {
                return {};
            }
        } catch (...) {
            return {};
        }

        // Fail closed on smuggled native role boundaries in user-controlled
        // text. Never silently rewrite the task intent (no blanket '<'
        // replacement): a reserved-control-containing input is a protocol
        // failure, not extra native role rounds. Valid labels/IDs pass
        // through byte-identical.
        const std::string label = node_label.empty() ? "0" : node_label;
        if (rerot_text_decodes_reserved_control(label) || rerot_text_decodes_reserved_control(intent)) {
            return {};
        }
        const task_params * frame_params  = rerot_slot_params(slot);
        const bool          mindmap_frame = frame_params && frame_params->rerot_plan_wire == "mindmap";
        const std::string   call_id       = mindmap_frame ? std::string{} : "rerot-lane-" + label;

        common_chat_tool             spawn    = mindmap_frame ? rerot_become_tool() : rerot_spawn_lane_tool();
        std::vector<common_chat_msg> messages = rerot_slot_chat_messages(slot);
        if (messages.empty()) {
            common_chat_msg user;
            user.role    = "user";
            user.content = ".";
            messages.push_back(std::move(user));
        }

        json        call_args;
        std::string tool_content;
        if (mindmap_frame) {
            if (intent.empty()) {
                return {};
            }
            call_args = json{
                { "node", intent }
            };
            tool_content = "Now you became the node " + intent + ", please think about it.";
        } else {
            call_args = json{
                { "id",     label  },
                { "intent", intent }
            };
            if (is_synthesis) {
                call_args["phase"] = "synthesis";
                if (!final_mode.empty()) {
                    call_args["final_mode"] = std::string(final_mode);
                }
            }
            tool_content = std::string("you are Lane ") + label + ", Intent: " + intent;
        }

        common_chat_msg assistant;
        assistant.role = "assistant";
        common_chat_tool_call call;
        call.name      = spawn.name;
        call.arguments = call_args.dump();
        call.id        = call_id;
        assistant.tool_calls.push_back(std::move(call));

        common_chat_msg tool;
        tool.role         = "tool";
        tool.tool_call_id = call_id;
        tool.content      = std::move(tool_content);

        common_chat_templates_inputs base_inputs;
        rerot_fill_chat_inputs(base_inputs, slot);
        base_inputs.messages = messages;

        common_chat_templates_inputs full_inputs = base_inputs;
        full_inputs.messages                     = messages;
        full_inputs.messages.push_back(std::move(assistant));
        full_inputs.messages.push_back(std::move(tool));

        std::string baseline_prompt;
        std::string full_prompt;
        try {
            baseline_prompt = common_chat_templates_apply(chat_params.tmpls.get(), base_inputs).prompt;
            full_prompt     = common_chat_templates_apply(chat_params.tmpls.get(), full_inputs).prompt;
        } catch (...) {
            return {};
        }
        if (full_prompt.empty() || baseline_prompt.empty()) {
            return {};
        }

        llama_tokens baseline_tokens = rerot_tokenize_injection(baseline_prompt);
        llama_tokens full_tokens     = rerot_tokenize_injection(full_prompt);
        if (full_tokens.empty() || baseline_tokens.empty()) {
            return {};
        }

        const server_tokens full_st(full_tokens, false);
        llama_tokens        suffix;
        const size_t        live_n   = slot.prompt.tokens.has_mtmd ? 0 : slot.prompt.tokens.size();
        const size_t        live_lcp = (live_n == 0) ? 0 : slot.prompt.tokens.get_common_prefix(full_st);
        if (live_n > 0 && live_lcp == live_n && live_lcp < full_tokens.size()) {
            suffix.assign(full_tokens.begin() + static_cast<std::ptrdiff_t>(live_lcp), full_tokens.end());
        } else {
            const server_tokens baseline_st(std::move(baseline_tokens), false);
            const size_t        render_lcp = baseline_st.get_common_prefix(full_st);
            if (render_lcp == 0 || render_lcp >= full_tokens.size()) {
                return {};
            }
            suffix.assign(full_tokens.begin() + static_cast<std::ptrdiff_t>(render_lcp), full_tokens.end());
        }
        if (suffix.empty()) {
            return {};
        }
        const std::string suffix_text = rerot_detokenize_injection(suffix);
        if (!rerot_frame_has_native_boundaries(suffix_text, think_end, think_start)) {
            return {};
        }
        return suffix;
    }

    // Render the formal DAG-with-tools prefix and compare it with the actual
    // ordinary C0 tape. The target template prepends a # Tools system block
    // whenever tools are supplied, so the ordinary render is in general NOT
    // a prefix of the DAG render. Reports the true token LCP length in
    // *lcp_out and the full DAG render in *dag_out (AGENTS.md §02 rule 1).
    // An empty *dag_out means "no chat re-render applies" (non-chat or media
    // request): the caller keeps the legacy suffix-only behavior. The simple
    // path never calls this; it always resumes the original ordinary C0.
    bool rerot_render_dag_prefix(
            const server_slot & slot,
            llama_tokens & dag_out,
            size_t & lcp_out) const {
        dag_out.clear();
        lcp_out = 0;
        if (!chat_params.tmpls || !chat_params.use_jinja) {
            return false;
        }
        if (slot.prompt.tokens.has_mtmd) {
            // Media tokens are not re-renderable as a text LCP.
            return true;
        }
        const auto messages = rerot_slot_chat_messages(slot);
        if (messages.empty()) {
            return true;
        }
        llama_tokens ordinary;
        ordinary.reserve(slot.prompt.tokens.size());
        for (size_t i = 0; i < slot.prompt.tokens.size(); ++i) {
            const llama_token id = slot.prompt.tokens[i];
            if (id != LLAMA_TOKEN_NULL) {
                ordinary.push_back(id);
            }
        }
        common_chat_templates_inputs dag;
        rerot_fill_chat_inputs(dag, slot);
        dag.messages = messages;
        std::string dag_prompt;
        try {
            dag_prompt = common_chat_templates_apply(chat_params.tmpls.get(), dag).prompt;
        } catch (...) {
            return false;
        }
        if (dag_prompt.empty()) {
            return false;
        }
        dag_out = rerot_tokenize_injection(dag_prompt);
        if (dag_out.empty()) {
            return false;
        }
        size_t lcp = 0;
        while (lcp < ordinary.size() && lcp < dag_out.size() &&
               ordinary[lcp] == dag_out[lcp]) {
            ++lcp;
        }
        lcp_out = lcp;
        return true;
    }

    // Rebuild the DAG prefix in existing memory at the true token LCP
    // (AGENTS.md §02 rules 1-2). Startup-only: the divergent suffix is
    // re-forwarded once below as formal P; nothing here runs per frontier
    // (no dynamic reforward). Never guesses cache reuse from text similarity
    // (rule 4): physical memory, the slot tape, and the root lineage tape are
    // truncated to exactly what stays resident, then the runtime reconciles
    // the logical document (root runs/refs, archive/parked pins, position
    // watermark) via prepare_dag_prefix_rebuild before initialize_dag.
    bool rerot_rebuild_dag_prefix_memory(
            server_slot & slot,
            uint64_t episode_id,
            size_t lcp,
            const llama_tokens & dag_tokens) {
        auto * episode = rerot ? rerot->episode(episode_id) : nullptr;
        auto * root = rerot ? rerot->node(episode_id, 0) : nullptr;
        if (!episode || !root) {
            return false;
        }
        const size_t ordinary_n = slot.prompt.tokens.size();
        if (lcp > ordinary_n || lcp > dag_tokens.size()) {
            rerot->hard_abort(episode_id, "rerot_state_error: DAG prefix LCP out of range");
            return false;
        }
        if (slot.prompt.tokens.has_mtmd ||
            slot.prompt.tokens.pos_next() != (llama_pos) ordinary_n ||
            episode->c0.n_prompt_tokens != (llama_pos) ordinary_n) {
            rerot->hard_abort(episode_id, "rerot_state_error: DAG prefix rebuild needs a text-only C0 tape");
            return false;
        }
        if (lcp == ordinary_n) {
            return true; // suffix-only fast path: memory already holds C0
        }
        const int64_t t_prefix_start_us = ggml_time_us();
        // Ensure all asynchronously scheduled compute or transfer commands on this context
        // are fully retired on the GPU before issuing destructive memory resets.
        // A race between an in-flight compute kernel and an immediate host clear/write
        // causes invalid descriptor state and GPUVM page faults (ErrorDeviceLost).
        llama_memory_t memory = llama_get_memory(ctx_tgt);
        if (!memory) {
            rerot->hard_abort(episode_id, "rerot_state_error: missing memory for DAG prefix rebuild");
            return false;
        }
        llama_synchronize(ctx_tgt);
        const llama_seq_id seq = slot.id;
        size_t base = lcp;
        // Recurrent rollback first: it is non-destructive on failure, and its
        // per-token snapshot ring only reaches back n_rs_seq states. A deep
        // divergence (e.g. the target template's prepended # Tools block)
        // exceeds it, so fall back to a full replay from empty. Either way
        // the DAG prefix below is re-forwarded exactly once from `base`.
        if (!llama_memory_seq_rm_recurrent(memory, seq, (llama_pos) lcp, -1)) {
            if (!llama_memory_seq_rm_attention(memory, seq, -1, -1) ||
                !llama_memory_seq_rm_recurrent(memory, seq, -1, -1)) {
                rerot->hard_abort(episode_id, "rerot_state_error: failed to reset memory for DAG prefix rebuild");
                return false;
            }
            base = 0;
        } else if (!llama_memory_seq_rm_attention(memory, seq, (llama_pos) lcp, -1)) {
            rerot->hard_abort(episode_id, "rerot_state_error: failed to truncate memory for DAG prefix rebuild");
            return false;
        }
        slot.prompt.tokens.keep_first(base);
        auto transport_it = rerot_transport.find(episode_id);
        if (transport_it != rerot_transport.end()) {
            auto lineage_it = transport_it->second->lineage_tokens.find(0);
            if (lineage_it != transport_it->second->lineage_tokens.end()) {
                lineage_it->second.keep_first(base);
            }
        }
        std::string prep_err;
        if (!rerot->prepare_dag_prefix_rebuild(episode_id, (llama_pos) base, &prep_err)) {
            rerot->hard_abort(
                episode_id,
                "rerot_state_error: DAG prefix rebuild reconcile failed" +
                    (prep_err.empty() ? std::string() : ": " + prep_err));
            return false;
        }
        const size_t actual_replayed = dag_tokens.size() > base ? (dag_tokens.size() - base) : 0;
        SRV_INF("RERoT DAG prefix rebuild: episode=%" PRIu64 " ordinary=%zu lcp=%zu dag=%zu replay_from=%zu\n",
            episode_id, ordinary_n, lcp, dag_tokens.size(), base);
        const int64_t prefix_dur_us = ggml_time_us() - t_prefix_start_us;
        const double prefix_dur_s = (double) prefix_dur_us / 1.0e6;
        rerot_metrics.prefix_rebuild_seconds += prefix_dur_s;
        ++rerot_metrics.prefix_rebuild_count;
        rerot_metrics.ordinary_prompt_tokens += ordinary_n;
        rerot_metrics.dag_lcp_tokens += lcp;
        rerot_metrics.replay_from_tokens += base;
        rerot_metrics.actual_replayed_tokens += actual_replayed;
        if (transport_it != rerot_transport.end()) {
            transport_it->second->prefix_rebuild_seconds += prefix_dur_s;
            transport_it->second->ordinary_prompt_tokens = ordinary_n;
            transport_it->second->dag_lcp_tokens = lcp;
            transport_it->second->replay_from_tokens = base;
            transport_it->second->actual_replayed_tokens = actual_replayed;
        }
        return true;
    }

    static void rerot_install_routing_grammar(task_params & params) {
        (void) server_rerot_take_user_grammar(params);
        // The probe grammar follows the selected planning wire. An unknown
        // wire is rejected here instead of defaulting to JSON, so the probe
        // can never sample a document its own parser cannot judge.
        std::string grammar;
        if (params.rerot_plan_wire == "mindmap") {
            grammar = server_rerot_mindmap_grammar();
        } else if (params.rerot_plan_wire == "json") {
            grammar = server_rerot_routing_grammar();
        } else {
            grammar.clear();
        }
        params.sampling.grammar = {
            COMMON_GRAMMAR_TYPE_USER,
            std::move(grammar),
        };
        params.sampling.grammar_lazy = false;
        params.sampling.grammar_triggers.clear();
        params.sampling.preserved_tokens.clear();
    }

    static bool rerot_install_source_end_grammar(
            task_params & params,
            std::string_view close_marker) {
        std::string grammar = server_rerot_source_end_grammar(close_marker);
        if (grammar.empty()) {
            return false;
        }
        params.sampling.grammar = {
            COMMON_GRAMMAR_TYPE_USER,
            std::move(grammar),
        };
        params.sampling.grammar_lazy = false;
        params.sampling.grammar_triggers.clear();
        params.sampling.preserved_tokens.clear();
        return true;
    }


    bool rerot_set_injection(
            server_slot & slot,
            server_rerot_injection_kind kind,
            llama_tokens tokens) {
        slot.rerot_injection_tokens = std::move(tokens);
        slot.rerot_injection_cursor = 0;
        slot.rerot_injection = kind;
        if (slot.rerot_injection_tokens.empty()) {
            if (rerot && slot.rerot_episode_id != 0) {
                rerot->hard_abort(slot.rerot_episode_id, "rerot_protocol_error: empty forced control sequence");
            }
            return false;
        }
        return true;
    }

    bool rerot_set_injection(
            server_slot & slot,
            server_rerot_injection_kind kind,
            std::string_view text) {
        return rerot_set_injection(slot, kind, rerot_tokenize_injection(text));
    }

    bool rerot_enter_child_worker(
            server_slot & slot,
            uint64_t episode_id,
            llama_rerot_node_id node_id,
            bool direct_admission) {
        const auto * lane = rerot ? rerot->node(episode_id, node_id) : nullptr;
        const auto * episode = rerot ? rerot->episode(episode_id) : nullptr;
        const auto * logical = episode ? episode->document.node(node_id) : nullptr;
        if (!lane || !logical || !slot.task || lane->control_id().empty()) {
            return false;
        }
        if (direct_admission && !rerot->begin_worker(episode_id, node_id)) {
            return false;
        }

        server_task child_task = rerot_clone_task(*slot.task);
        rerot_remove_planner_grammar(child_task.params);
        if (!rerot_install_child_grammar(
                child_task.params, lane->exit_parser.marker())) {
            rerot->hard_abort(
                episode_id, "rerot_protocol_error: invalid child close grammar");
            return false;
        }
        common_sampler_ptr child_sampler;
        try {
            child_sampler.reset(common_sampler_init(
                model_tgt,
                child_task.params.sampling,
                (int32_t) llama_n_ctx(ctx_tgt)));
        } catch (const std::exception & e) {
            rerot->hard_abort(
                episode_id,
                std::string("rerot_sampler_error: failed to enter child worker: ") + e.what());
            return false;
        }
        slot.task = std::make_unique<const server_task>(std::move(child_task));
        slot.smpl = std::move(child_sampler);
        slot.init_sampler();
        rerot_bind_sampler(slot);

        const std::string worker_prompt = server_rerot_child_worker_prompt(
            logical->title, lane->exit_parser.marker());
        if (worker_prompt.empty() || !rerot_set_injection(
                slot,
                server_rerot_injection_kind::worker,
                worker_prompt)) {
            rerot->hard_abort(
                episode_id, "rerot_protocol_error: failed to enter child worker phase");
            return false;
        }
        return true;
    }
    // Sample the true C0 next-token decision while C0 logits are still valid.
    // Called once from post_decode for a RERoT-eligible DONE_PROMPT slot whose
    // logits row is inside the current view (tok_idx = i_batch - off, exactly
    // as ordinary sampling indexes it). Sampling on a clone leaves the slot's
    // own sampler and state untouched, so a parked root started later replays
    // the identical decision: same logits, same sampler evolution (RNG,
    // penalty, reasoning budget, user grammar) as the ordinary first token.
    // The output is built exactly like ordinary sampling, including probs.
    bool rerot_presave_c0_decision(server_slot & slot, int off) {
        if (slot.rerot_c0_ready) {
            return true;
        }
        if (!slot.smpl || !slot.task || slot.i_batch < 0) {
            return false;
        }
        const int tok_idx = slot.i_batch - off;
        if (tok_idx < 0) {
            return false;
        }
        common_sampler_ptr clone;
        clone.reset(common_sampler_clone(slot.smpl.get()));
        if (!clone) {
            return false;
        }
        const llama_token id = common_sampler_sample(clone.get(), slot.ctx_tgt, tok_idx);
        common_sampler_accept(clone.get(), id, true);
        completion_token_output output;
        output.tok = id;
        const bool special = params_base.special ||
            slot.task->params.sampling.preserved_tokens.find(id) !=
                slot.task->params.sampling.preserved_tokens.end();
        output.text_to_send = common_token_to_piece(slot.ctx_tgt, id, special);
        output.prob = 1.0f;
        if (slot.task->params.sampling.n_probs > 0) {
            populate_token_probs(
                slot, clone.get(), output, slot.task->params.post_sampling_probs,
                params_base.special, tok_idx);
        }
        // Snapshot the pristine post-prefill output/usage cursors alongside
        // the decision; the probe must leave no residue in them.
        slot.rerot_c0_smpl = std::move(clone);
        slot.rerot_c0_token = id;
        slot.rerot_c0_output = std::move(output);
        slot.rerot_c0_n_decoded = slot.n_decoded;
        slot.rerot_c0_n_decoded_start = slot.n_decoded_start;
        slot.rerot_c0_generated_text = slot.generated_text;
        slot.rerot_c0_generated_tokens = slot.generated_tokens;
        slot.rerot_c0_generated_token_probs = slot.generated_token_probs;
        slot.rerot_c0_n_sent_text = slot.n_sent_text;
        slot.rerot_c0_t_start_generation = slot.t_start_generation;
        slot.rerot_c0_has_next_token = slot.has_next_token;
        slot.rerot_c0_stop = slot.stop;
        slot.rerot_c0_stopping_word = slot.stopping_word;
        slot.rerot_c0_ready = true;
        return true;
    }

    // Prompt-cache append confirmation for a consumed token. Mirrors the
    // accept_hack_block step of ordinary sampling (see update_slots); split
    // out because the C0 decision is sampled early while C0 logits are valid.
    // Returns false when a stop condition released the slot (caller completes
    // the episode tail); the release/send/metrics steps already ran inside.
    bool rerot_confirm_appended_block(server_slot & slot, const llama_tokens & confirmed_block) {
        if (!slot.token_hack || confirmed_block.empty()) {
            return true;
        }
        llama_tokens appended = slot.token_hack->after_block(confirmed_block);
        if (appended.empty()) {
            return true;
        }
        slot.spec_draft.clear();
        slot.spec_i_batch.clear();
        slot.token_append_anchor = confirmed_block.back();
        slot.token_append_chunk = std::move(appended);
        for (llama_token token : slot.token_append_chunk) {
            common_sampler_accept(slot.smpl.get(), token, true);
            completion_token_output forced;
            forced.tok = token;
            const bool special = params_base.special ||
                slot.task->params.sampling.preserved_tokens.find(token) !=
                    slot.task->params.sampling.preserved_tokens.end();
            forced.text_to_send = common_token_to_piece(slot.ctx_tgt, token, special);
            forced.prob = 1.0f;
            slot.n_decoded += 1;
            if (!process_token(forced, slot)) {
                slot.print_timings();
                send_final_response(slot);
                metrics.on_prediction(slot);
                slot.release();
                return false;
            }
        }
        slot.sampled = slot.token_append_anchor;
        return true;
    }

    bool rerot_start_root(server_slot & slot) {
        if (!rerot || !ctx_tgt || !slot.task ||
            !slot.task->params.rerot_effective(slot.task->type)) {
            return false;
        }

        // P12: request-scoped ledger begins with the first adopted root.
        // Checked before adopt_root/emplace so "first" means "transport
        // empty"; queued roots while an episode is active keep accumulating
        // into the same ledger (their prefill is parked at completion).
        const bool rerot_prof_first_root = rerot_transport.empty();

        // The C0 decision must have been pre-saved while C0 logits were valid
        // (post_decode, possibly when this root was still parked). Without it
        // plain continuation cannot reproduce the ordinary next token, so fail
        // closed before adopting any episode state.
        if (!slot.rerot_c0_ready || !slot.rerot_c0_smpl) {
            return false;
        }
        common_sampler_ptr c0_sampler = std::move(slot.rerot_c0_smpl);

        server_task root_lane_task = rerot_clone_task(*slot.task);
        root_lane_task.params.sampling.reasoning_budget_start.clear();
        root_lane_task.params.sampling.reasoning_budget_end.clear();
        root_lane_task.params.sampling.reasoning_budget_tokens = -1;
        // The probe is a plain reasoning turn: one instruction line followed by
        // a fenced document. It must NOT see the internal lane-spawn tool
        // schema -- with it in the rendered prefix the model routes into the
        // tool-call channel and invents ids ("A", "A1", "B1") instead of
        // writing the wire. Dropping the request's tools here keeps the probe
        // honest and leaves the worker render below untouched.
        root_lane_task.params.rerot_chat_tools = json::array();
        rerot_install_routing_grammar(root_lane_task.params);
        if (root_lane_task.params.sampling.grammar.empty()) {
            return false;
        }
        if (root_lane_task.params.sampling.seed != LLAMA_DEFAULT_SEED &&
            root_lane_task.index > 0) {
            uint64_t mixed = root_lane_task.params.sampling.seed ^
                (uint64_t(root_lane_task.index) * 0x9e3779b97f4a7c15ULL);
            mixed ^= mixed >> 33;
            mixed *= 0xff51afd7ed558ccdULL;
            mixed ^= mixed >> 33;
            root_lane_task.params.sampling.seed = static_cast<uint32_t>(mixed);
            if (root_lane_task.params.sampling.seed == LLAMA_DEFAULT_SEED) {
                --root_lane_task.params.sampling.seed;
            }
        }
        common_sampler_ptr root_lane_sampler;
        try {
            root_lane_sampler.reset(common_sampler_init(
                model_tgt,
                root_lane_task.params.sampling,
                (int32_t) llama_n_ctx(ctx_tgt)));
            if (root_lane_task.params.rerot_plan_wire == "mindmap") {
                common_sampler_append_grammar(root_lane_sampler.get(), server_mindmap::init_indent_sampler(vocab));
            }
        } catch (const std::exception &) {
            return false;
        }

        const uint64_t episode_id = rerot->adopt_root(
            slot.task->id,
            slot.task->rerot_response_owner(),
            slot.id,
            slot.id,
            slot.prompt.tokens.pos_next(),
            slot.task->rerot_episode_id);
        if (episode_id == 0) {
            return false;
        }

        llama_rerot_episode_params episode_params = {
            slot.task->params.rerot_frontier,
            1,
            1,
            1,
        };
        if (!llama_rerot_episode_begin(ctx_tgt, episode_id, &episode_params)) {
            rerot->erase_episode(episode_id);
            return false;
        }

        auto * root_node = rerot->node(episode_id, 0);
        llama_memory_t memory = llama_get_memory(ctx_tgt);
        const size_t root_seed_size =
            root_node && memory
                ? llama_memory_rerot_capture_hand_seed(
                    memory, slot.id, nullptr, 0)
                : 0;
        if (!root_node) {
            rerot->erase_episode(episode_id);
            return false;
        }
        // Pure Transformer recurrent data may be empty; C0 validity is not
        // "GDN blob non-empty" (AGENTS.md §02.2).
        if (root_seed_size > 0) {
            root_node->hand_seed.resize(root_seed_size);
            if (llama_memory_rerot_capture_hand_seed(
                    memory,
                    slot.id,
                    root_node->hand_seed.data(),
                    root_node->hand_seed.size()) != root_node->hand_seed.size()) {
                rerot->erase_episode(episode_id);
                return false;
            }
        } else {
            root_node->hand_seed.clear();
        }

        // Bound total work at episode scope, never per child/depth and never
        // by reserving a synthetic final-answer quota. Total generated tokens
        // (public, private, and pending) are bounded by the total context capacity
        // minus prompt reservation; the request's n_predict governs user completion length.
        const uint64_t context_limit = std::max<uint64_t>(1, llama_n_ctx(ctx_tgt));
        const uint64_t prompt_tokens = static_cast<uint64_t>(std::max<int>(0, slot.n_prompt_tokens_original));
        const uint64_t episode_token_budget = context_limit > prompt_tokens + 32
            ? context_limit - prompt_tokens
            : context_limit;
        const uint64_t internal_seq_budget =
            LLAMA_MAX_SEQ > slots.size() ? LLAMA_MAX_SEQ - slots.size() : 1;
        rerot->set_hard_limits(episode_id, {
            episode_token_budget,
            slot.task->params.rerot_plan_wire == "mindmap"
                ? 0 : std::max<uint64_t>(64, internal_seq_budget * 16),
            slot.task->params.rerot_plan_wire == "mindmap" ? 0 : internal_seq_budget,
            context_limit,
        });

        auto transport = std::make_unique<rerot_transport_state>(
            rerot_clone_task(*slot.task));
        transport->lora = slot.lora;
        transport->lineage_tokens.emplace(0, slot.prompt.tokens.clone());
        transport->root_seed = common_sampler_get_seed(root_lane_sampler.get());
        transport->prompt_tokens_processed = slot.n_prompt_tokens_processed;
        transport->prompt_tokens_processed_accum = slot.n_prompt_tokens_processed_accum;
        transport->prompt_tokens_cache_response = slot.n_prompt_tokens_cache_response;
        transport->prompt_processing_ms = slot.t_prompt_processing;
        transport->triattention_compressed = slot.triattention_compressed;
        transport->started_us = ggml_time_us();
        transport->saved_user_grammar = slot.task->params.sampling.grammar;
        transport->c0_sampler = std::move(c0_sampler);
        rerot_transport.emplace(episode_id, std::move(transport));

        slot.task = std::make_unique<const server_task>(std::move(root_lane_task));
        slot.smpl = std::move(root_lane_sampler);
        slot.init_sampler();
        llama_set_sampler(ctx_tgt, slot.id, nullptr);

        ++rerot_metrics.episode_total;
        ++rerot_metrics.episode_active;
        ++rerot_metrics.nodes_created;
        ++rerot_metrics.nodes_started;
        rerot_metrics.max_live_lanes = std::max<uint64_t>(
            rerot_metrics.max_live_lanes, 1);

        rerot_episode_id = episode_id;
        slot.rerot_internal = true;
        slot.rerot_episode_id = episode_id;
        slot.rerot_node_id = 0;
        slot.rerot_exec_seq = slot.id;
        slot.rerot_serial_tail = false;
        slot.rerot_inflight_plan.reset();
        slot.rerot_inflight_bytes.clear();
        slot.rerot_inflight_extra_plans.clear();
        slot.rerot_inflight_extra_bytes.clear();
        slot.rerot_inflight_forced = false;
        slot.state = SLOT_STATE_GENERATING;
        slot.i_batch = -1;
        slot.spec_draft.clear();
        slot.spec_i_batch.clear();
        if (spec) {
            common_speculative_set_paused(spec.get(), slot.id, true);
        }

        auto * episode = rerot->episode(episode_id);
        if (!episode || !rerot->capture_c0(episode_id, slot.id, slot.prompt.tokens.pos_next())) {
            rerot_erase_episode(episode_id);
            return false;
        }
        {
            auto transport_it = rerot_transport.find(episode_id);
            if (transport_it != rerot_transport.end() && transport_it->second->c0_sampler) {
                rerot_capture_sampler_snapshot(episode->c0, transport_it->second->c0_sampler.get());
            }
        }
        episode->probing = true;
        episode->strategy_decided = false;
        if (rerot_prof_first_root) {
            llama_rerot_profile_begin((uint64_t) slot.task->id);
            // §4.2 phase ledger: the C0 ordinary prefill completed BEFORE the
            // first root adopted this episode (start_root runs at
            // DONE_PROMPT), so a live normal_prefill window can never be
            // observed. Accumulate the slot's own completed pp timing once
            // here (same source as metrics.on_prompt_eval; includes any
            // parked wait before admission, matching the request wall clock
            // the user experienced). Parked roots keep the current behavior
            // (prefill outside the ledger). No-op when profiling is off.
            if (llama_rerot_profile * prof = llama_rerot_profile_active()) {
                if (slot.t_prompt_processing > 0.0) {
                    prof->phase_accumulate(llama_rerot_phase::normal_prefill,
                        (uint64_t) (slot.t_prompt_processing * 1.0e3) /* ms->us */);
                }
            }
        }
        rerot_prof_phase_enter(llama_rerot_phase::probe);
        {
            auto transport_it = rerot_transport.find(episode_id);
            if (transport_it != rerot_transport.end()) {
                transport_it->second->t_probe_start_us = ggml_time_us();
            }
        }
        if (!rerot->arm_isolated_probe(episode_id, slot.id)) {
            rerot->hard_abort(episode_id, "rerot_resource_exhausted: isolated probe sequence unavailable");
            rerot_propagate_hard_abort();
            return false;
        }
        {
            auto * root = rerot->node(episode_id, 0);
            slot.rerot_exec_seq = root ? root->exec_seq : slot.id;
        }
        // Probe writes go to episode->probe_seq. C0 on slot.id is not mutated.
        // Fail closed on an unknown wire: a misconfigured request must never
        // silently run the other planner and be recorded as a different
        // experiment arm.
        const std::string & plan_wire = slot.task->params.rerot_plan_wire;
        if (plan_wire != "json" && plan_wire != "mindmap") {
            rerot->hard_abort(
                episode_id,
                "rerot_protocol_error: unknown rerot plan wire: " + plan_wire);
            rerot_propagate_hard_abort();
            return false;
        }
        {
            std::string probe_prompt(plan_wire == "mindmap"
                ? std::string(server_rerot_mindmap_probe_prompt())
                : std::string(server_rerot_routing_probe_prompt()));
            // The instruction ends on a fresh line. Mindmap then injects its
            // fixed wire prefix through the first child's indentation; its
            // grammar samples only the remaining subtree and closing fence.
            if (probe_prompt.empty() || probe_prompt.back() != '\n') {
                rerot->hard_abort(
                    episode_id,
                    "rerot_protocol_error: routing probe prompt missing trailing newline");
                rerot_propagate_hard_abort();
                return false;
            }
            if (plan_wire == "mindmap") {
                probe_prompt += server_mindmap::probe_prefix;
            }
            llama_tokens probe_tokens = rerot_tokenize_injection(probe_prompt);
            if (probe_tokens.empty()) {
                rerot->hard_abort(
                    episode_id,
                    "rerot_protocol_error: routing probe prompt tokenization failed");
                rerot_propagate_hard_abort();
                return false;
            }
            episode->probe_bytes = plan_wire == "mindmap"
                ? std::string(server_mindmap::probe_prefix) : std::string{};
            if (!rerot_set_injection(
                    slot,
                    server_rerot_injection_kind::probe,
                    std::move(probe_tokens))) {
                rerot_propagate_hard_abort();
                return false;
            }
        }

        SRV_INF("RERoT episode start: request=%d episode=%" PRIu64 " root_slot=%d frontier=%s\n",
            slot.task->id, episode_id, slot.id,
            llama_rerot_frontier_mode_name(slot.task->params.rerot_frontier));
        return true;
    }

    bool rerot_discard_probe_kv(server_slot & slot, uint64_t episode_id) {
        auto * episode = rerot ? rerot->episode(episode_id) : nullptr;
        auto transport_it = rerot_transport.find(episode_id);
        if (!episode || !episode->c0.valid() || transport_it == rerot_transport.end()) {
            return false;
        }
        llama_memory_t memory = llama_get_memory(ctx_tgt);
        const bool isolated = rerot->discard_isolated_probe(episode_id, slot.id);
        if (memory && !isolated) {
            // Fallback if this episode never armed a probe seq: drop only
            // the attention suffix written on the C0 sequence.
            if (!llama_memory_seq_rm_attention(
                    memory, slot.id, episode->c0.n_prompt_tokens, -1)) {
                rerot->hard_abort(episode_id, "rerot_state_error: failed to discard isolated probe tokens");
                return false;
            }
        }
        if (memory) {
            const auto & seed = episode->c0.gdn_recurrent_states;
            if (!seed.empty() &&
                !llama_memory_rerot_apply_hand_seed(
                    memory, slot.id, seed.data(), seed.size())) {
                rerot->hard_abort(
                    episode_id,
                    "rerot_state_error: failed to restore C0 recurrent seed after probe");
                return false;
            }
        }
        auto lineage_it = transport_it->second->lineage_tokens.find(0);
        if (lineage_it != transport_it->second->lineage_tokens.end()) {
            slot.prompt.tokens = lineage_it->second.clone();
        }
        auto * root = rerot->node(episode_id, 0);
        if (root) {
            root->storage_pos_next = episode->c0.n_prompt_tokens;
            root->exec_seq = slot.id;
        }
        slot.rerot_exec_seq = slot.id;
        episode->probing = false;
        return true;
    }

    bool rerot_enter_simple(server_slot & slot, uint64_t episode_id) {
        auto * episode = rerot ? rerot->episode(episode_id) : nullptr;
        auto transport_it = rerot_transport.find(episode_id);
        auto * root = rerot ? rerot->node(episode_id, 0) : nullptr;
        if (!episode || !root || transport_it == rerot_transport.end() || !slot.task) {
            return false;
        }
        if (!rerot_discard_probe_kv(slot, episode_id)) {
            return false;
        }
        // P12: simple continuation ends the probe phase; the ordinary
        // decode that follows is not attributed to any RERoT phase (the
        // request-level ledger still counts routes/layout/sync).
        rerot_prof_phase_exit(llama_rerot_phase::probe);
        episode->strategy_decided = true;
        episode->probing = false;
        episode->is_dag = false;
        root->planner_armed = false;

        // Plain C0 continuation: response_task predates the routing probe, so
        // it already carries the original user grammar, reasoning budget,
        // and sampling params. Restore the saved user grammar without
        // re-arming the probe, and keep the user budget as-is.
        server_task cont = rerot_clone_task(transport_it->second->response_task);
        cont.params.sampling.grammar = transport_it->second->saved_user_grammar;
        if (!transport_it->second->c0_sampler) {
            rerot->hard_abort(episode_id, "rerot_state_error: missing C0 sampler for simple continuation");
            return false;
        }
        slot.task = std::make_unique<const server_task>(std::move(cont));
        slot.smpl = std::move(transport_it->second->c0_sampler);
        // Bind the C0 clone as-is. init_sampler() would reset RNG and replay
        // the prompt, destroying the saved penalty chain (AGENTS.md §02.7).
        // The clone already sample+accepted the pre-saved C0 decision, exactly
        // matching the ordinary post-first-sample sampler evolution.
        rerot_bind_sampler(slot);
        if (spec) {
            common_speculative_set_paused(spec.get(), slot.id, false);
        }
        if (!slot.rerot_c0_ready) {
            rerot->hard_abort(episode_id, "rerot_state_error: missing C0 decision for simple continuation");
            return false;
        }
        // Restore the pristine post-prefill output/usage cursors: probe prompt
        // + routing plan generation must not count as ordinary sampled
        // continuation. Episode-level sampled count restarts; the consumed C0
        // token below brings both counters to exactly the ordinary state.
        slot.n_decoded = slot.rerot_c0_n_decoded;
        slot.n_decoded_start = slot.rerot_c0_n_decoded_start;
        slot.generated_text = std::move(slot.rerot_c0_generated_text);
        slot.generated_tokens = std::move(slot.rerot_c0_generated_tokens);
        slot.generated_token_probs = std::move(slot.rerot_c0_generated_token_probs);
        slot.n_sent_text = slot.rerot_c0_n_sent_text;
        slot.t_start_generation = slot.rerot_c0_t_start_generation;
        slot.has_next_token = slot.rerot_c0_has_next_token;
        slot.stop = slot.rerot_c0_stop;
        slot.stopping_word = std::move(slot.rerot_c0_stopping_word);
        transport_it->second->sampled_tokens = 0;
        slot.i_batch = -1;
        slot.rerot_c0_ready = false;
        episode->serial_tail = true;
        episode->serial_node = 0;
        slot.rerot_serial_tail = true;
        slot.rerot_injection = server_rerot_injection_kind::none;
        slot.rerot_injection_tokens.clear();
        slot.rerot_injection_cursor = 0;
        // Consume the pre-saved C0 decision through the ordinary accounting
        // path (sample+accept already applied at pre-save; C0 memory state is
        // intact on the isolated-probe path, so no state is re-forwarded).
        // slot.sampled lands the token for the next batch via the normal
        // handle_last_sampled_token forward, exactly as ordinary decoding.
        const llama_token first = slot.rerot_c0_token;
        completion_token_output output = std::move(slot.rerot_c0_output);
        {
            const int64_t t_now = ggml_time_us();
            if (slot.t_start_generation == 0) {
                slot.t_start_generation = t_now;
            }
            slot.n_decoded += 1;
            ++transport_it->second->sampled_tokens;
            if (slot.n_decoded == slot.n_decoded_start + 1) {
                slot.t_print_last = t_now;
                slot.n_decoded_last = slot.n_decoded_start;
                if (slot.n_decoded_start == 0) {
                    slot.t_prompt_processing = slot.t_prompt_processing_accum +
                        (slot.t_start_generation - slot.t_start_process_prompt) / 1e3;
                }
                metrics.on_prompt_eval(slot);
            }
            slot.t_token_generation = std::max<int64_t>(1, t_now - slot.t_start_generation) / 1e3;
        }
        if (!process_token(output, slot)) {
            // The first ordinary token already ends generation (e.g. immediate
            // EOS): complete exactly like the ordinary release tail.
            rerot_record_completed_episode(episode_id);
            slot.print_timings();
            send_final_response(slot);
            metrics.on_prediction(slot);
            rerot_erase_episode(episode_id);
            slot.prompt.clear();
            slot.release();
            rerot_start_next_waiting_root();
            return true;
        }
        if (!rerot_confirm_appended_block(slot, llama_tokens{first})) {
            // Stop hit inside prompt-cache append confirmation (slot already
            // released by the helper): complete the episode tail.
            rerot_record_completed_episode(episode_id);
            rerot_erase_episode(episode_id);
            rerot_start_next_waiting_root();
            return true;
        }
        slot.print_timings_tg();
        SRV_INF("RERoT simple continuation: episode=%" PRIu64 " slot=%d first_token=%d\n",
            episode_id, slot.id, first);
        return true;
    }

    bool rerot_finish_plan_prefix(server_slot & slot, uint64_t episode_id) {
        auto * episode = rerot ? rerot->episode(episode_id) : nullptr;
        auto transport_it = rerot_transport.find(episode_id);
        if (!episode || transport_it == rerot_transport.end()) {
            return false;
        }
        // C_base is the post-P seed. Do not capture before these tokens exist
        // (AGENTS.md §05).
        if (!rerot->capture_c_base(episode_id)) {
            rerot->hard_abort(episode_id, "rerot_state_error: failed to capture C_base");
            return false;
        }
        if (slot.smpl) {
            rerot_capture_sampler_snapshot(episode->c_base, slot.smpl.get());
        }
        if (llama_get_memory(ctx_tgt) && !rerot->sync_public_archive(episode_id)) {
            rerot->hard_abort(episode_id, "rerot_state_error: failed to archive C_base prefix");
            return false;
        }
        auto * root = rerot->node(episode_id, 0);
        if (root && root->storage_pos_next >= 0) {
            episode->base_prefix_end = root->storage_pos_next;
        }
        transport_it->second->segmented_active = true;
        auto & lineage = transport_it->second->lineage_tokens;
        lineage.insert_or_assign(0, slot.prompt.tokens.clone());
        const int released_slot = slot.id;
        if (!rerot->detach_node(episode_id, 0)) {
            rerot->hard_abort(episode_id, "rerot_state_error: failed to detach 0.plan after DAG submit");
            return false;
        }
        rerot_make_slot_idle(slot);
        // P12: formal P committed and C_base captured; workers are admitted
        // next (admission/prep window before the first logical frontier).
        rerot_prof_phase_transition(llama_rerot_phase::formal_p, llama_rerot_phase::workers_start);
        if (!rerot->activate_dag_frontier(episode_id) ||
            rerot_admit_ready(episode_id) == rerot_admit_ready_result::failed) {
            return false;
        }
        SRV_INF("RERoT DAG start: episode=%" PRIu64 " nodes=%zu released_slot=%d\n",
            episode_id, episode->nodes.size(), released_slot);
        return true;
    }

    bool rerot_enter_dag(
            server_slot & slot,
            uint64_t episode_id,
            const server_rerot_routing_decision & decision) {
        slot.rerot_plan_kind = decision.plan_kind();
        return rerot_enter_dag_impl(slot, episode_id, decision);
    }

    bool rerot_enter_mindmap(
            server_slot & slot,
            uint64_t episode_id,
            const server_rerot_routing_decision & decision) {
        // MM-R1 shares the whole DAG transition machinery. What changes is the
        // plan: the strict mindmap parser already produced a frozen TreePlan,
        // initialize_mindmap maps its LEAVES to workers with zero leaf edges,
        // and the formal P carries the canonical tree instead of a flat list.
        // Recording the kind here (not inside the impl) keeps the audit trail
        // truthful even when a future wire reuses the same transition.
        slot.rerot_plan_kind = "mindmap";
        return rerot_enter_dag_impl(slot, episode_id, decision);
    }

    bool rerot_enter_dag_impl(
            server_slot & slot,
            uint64_t episode_id,
            const server_rerot_routing_decision & decision) {
        auto * episode = rerot ? rerot->episode(episode_id) : nullptr;
        auto transport_it = rerot_transport.find(episode_id);
        if (!episode || transport_it == rerot_transport.end()) {
            return false;
        }
        // P12: probe decided DAG; the prefix rebuild (memory truncation +
        // re-forward) and the formal P forward are separately attributed.
        rerot_prof_phase_transition(llama_rerot_phase::probe, llama_rerot_phase::dag_prefix_rebuild);
        const auto tags = rerot_native_think_tags(slot);
        if (tags.first.empty() || tags.second.empty()) {
            rerot->hard_abort(episode_id, "rerot_protocol_error: chat template has no native reasoning tags for DAG");
            return false;
        }
        if (!rerot_discard_probe_kv(slot, episode_id)) {
            return false;
        }
        // Formal DAG prefix at the true token LCP (AGENTS.md §02). A tools
        // induced system-block prepend is rebuilt in existing memory below,
        // not rejected; the simple path keeps the original ordinary C0.
        llama_tokens dag_prefix;
        size_t dag_lcp = 0;
        if (!rerot_render_dag_prefix(slot, dag_prefix, dag_lcp)) {
            rerot->hard_abort(
                episode_id,
                "rerot_protocol_error: DAG prefix re-render failed for the ordinary C0");
            return false;
        }
        // Whole-plan FRAME boundary gate, before any worker can start and
        // before formal P is built: every plan id/intent is checked for text
        // that would tokenize as a reserved native control. MM-R1 has no model
        // ids, so its node LABELS carry the same risk: a label that decodes to
        // a native boundary would forge an extra role round inside the tree.
        // Valid inputs pass byte-identical; a smuggled boundary protocol-fails
        // the plan here rather than forging extra native role rounds at
        // admission or in P.
        {
            for (const auto & q : decision.questions) {
                if (rerot_text_decodes_reserved_control(q.id) ||
                    rerot_text_decodes_reserved_control(q.intent)) {
                    rerot->hard_abort(
                        episode_id,
                        "rerot_protocol_error: DAG plan id/intent contains a reserved native control boundary");
                    return false;
                }
            }
            if (decision.has_tree) {
                for (const auto & node : decision.tree.nodes) {
                    if (rerot_text_decodes_reserved_control(node.label)) {
                        rerot->hard_abort(
                            episode_id,
                            "rerot_protocol_error: mindmap node label contains a reserved native control boundary");
                        return false;
                    }
                }
            }
        }
        const int64_t t_entry_start_us = ggml_time_us();
        const llama_tokens native_probe = rerot_native_fixed_entry_tokens(
            slot, "1", "handoff", false, {}, tags.second, tags.first);
        const int64_t entry_dur_us = ggml_time_us() - t_entry_start_us;
        const double entry_dur_s = (double) entry_dur_us / 1.0e6;
        rerot_metrics.fixed_entry_seconds += entry_dur_s;
        ++rerot_metrics.fixed_entry_count;
        if (transport_it != rerot_transport.end()) {
            transport_it->second->fixed_entry_seconds += entry_dur_s;
        }
        if (native_probe.empty()) {
            rerot->hard_abort(
                episode_id,
                "rerot_protocol_error: chat template cannot losslessly render a native DAG fixed entry");
            return false;
        }
        size_t rebuild_base = slot.prompt.tokens.size();
        if (!dag_prefix.empty()) {
            if (!rerot_rebuild_dag_prefix_memory(slot, episode_id, dag_lcp, dag_prefix)) {
                return false;
            }
            rebuild_base = slot.prompt.tokens.size();
        }
        // P12: rebuild (or suffix-only fast path) done; the formal plan
        // prefix forward begins here.
        rerot_prof_phase_transition(llama_rerot_phase::dag_prefix_rebuild, llama_rerot_phase::formal_p);
        llama_tokens dag_tool_suffix;
        if (!dag_prefix.empty() && rebuild_base < dag_prefix.size()) {
            dag_tool_suffix.assign(
                dag_prefix.begin() + (std::ptrdiff_t) rebuild_base, dag_prefix.end());
        }
        rerot->set_dag_protocol_markers(episode_id, tags.second, tags.first);
        // DAG workers sample fresh from C_base; the pre-saved plain-continuation
        // decision must never be consumed here. Its sampler already moved into
        // transport at start; drop the flag so only simple can consume it.
        slot.rerot_c0_ready = false;
        std::string err;
        const bool mindmap = slot.rerot_plan_kind == "mindmap";
        const bool ok = mindmap
            ? rerot->initialize_mindmap(episode_id, decision, &err)
            : rerot->initialize_dag(episode_id, decision, &err);
        if (!ok) {
            rerot->hard_abort(episode_id, "rerot_protocol_error: " + (err.empty()
                ? std::string(mindmap ? "invalid mindmap plan" : "invalid DAG plan")
                : err));
            return false;
        }

        // Drop routing-grammar probe sampler before forwarding formal P.
        server_task p_task = rerot_clone_task(transport_it->second->response_task);
        rerot_remove_planner_grammar(p_task.params);
        p_task.params.sampling.reasoning_budget_start.clear();
        p_task.params.sampling.reasoning_budget_end.clear();
        p_task.params.sampling.reasoning_budget_tokens = -1;
        common_sampler_ptr p_sampler;
        try {
            p_sampler.reset(common_sampler_init(
                model_tgt, p_task.params.sampling, (int32_t) llama_n_ctx(ctx_tgt)));
        } catch (const std::exception & e) {
            rerot->hard_abort(
                episode_id,
                std::string("rerot_sampler_error: failed to arm plan-prefix sampler: ") + e.what());
            return false;
        }
        slot.task = std::make_unique<const server_task>(std::move(p_task));
        slot.smpl = std::move(p_sampler);
        slot.init_sampler();
        rerot_bind_sampler(slot);

        const std::string plan_prefix = server_rerot_format_plan_prefix(decision, tags.first);
        llama_tokens p_tokens = std::move(dag_tool_suffix);
        if (!plan_prefix.empty()) {
            llama_tokens plan_tokens = rerot_tokenize_injection(plan_prefix);
            p_tokens.insert(p_tokens.end(), plan_tokens.begin(), plan_tokens.end());
        }
        if (p_tokens.empty()) {
            return rerot_finish_plan_prefix(slot, episode_id);
        }
        // Arm PUBLIC body injection on the still-bound root. capture_c_base
        // runs only after this injection completes (see plan_prefix branch).
        // Extra DAG tool-def tokens after the ordinary C0 prefix are part of P.
        if (!rerot_set_injection(slot, server_rerot_injection_kind::plan_prefix, std::move(p_tokens))) {
            rerot->hard_abort(episode_id, "rerot_protocol_error: failed to arm DAG plan prefix");
            return false;
        }
        return true;
    }

    bool rerot_try_finish_probe(server_slot & slot) {
        auto * episode = rerot ? rerot->episode(slot.rerot_episode_id) : nullptr;
        if (!episode || !episode->probing || episode->strategy_decided) {
            return true;
        }
        // The probe verdict comes from the parser matching the wire the probe
        // was armed with; mixing them would judge a Mermaid document as JSON
        // (or vice versa) and fail the request on a legal plan.
        const std::string & plan_wire = slot.task->params.rerot_plan_wire;
        if (plan_wire != "json" && plan_wire != "mindmap") {
            rerot->hard_abort(
                slot.rerot_episode_id,
                "rerot_protocol_error: unknown rerot plan wire: " + plan_wire);
            return false;
        }
        // The final mode is only meaningful for the research line, and an
        // unknown value must fail closed rather than quietly become S1: the
        // experiment ledger could not otherwise tell which arm ran.
        const std::string & final_mode = slot.task->params.rerot_final_mode;
        if (plan_wire == "mindmap" && final_mode != "reason" && final_mode != "direct") {
            rerot->hard_abort(
                slot.rerot_episode_id,
                "rerot_protocol_error: unknown rerot final mode: " + final_mode);
            return false;
        }
        if (auto * ep_now = rerot->episode(slot.rerot_episode_id)) {
            ep_now->final_mode = final_mode;
        }
        const auto decision = plan_wire == "mindmap"
            ? server_rerot_parse_mindmap_decision(episode->probe_bytes)
            : server_rerot_parse_routing_decision(episode->probe_bytes);
        if (decision.incomplete) {
            // A truncated document may still have a legal completion. The
            // mindmap grammar and depth sampler constrain new tokens; the
            // parser remains the final fail-closed check.
            return true;
        }
        if (!decision.error.empty()) {
            // A complete plan that fails validation is final: no later token
            // can repair it. Report the parser's own diagnosis
            // immediately instead of letting the sampler emit EOG and surfacing
            // an unrelated delimiter error.
            if (slot.task && slot.task->params.rerot_trace) {
                SRV_INF("rerot.trace.probe_reject: episode=%" PRIu64 " bytes=%zu error=%s plan=%s\n",
                    slot.rerot_episode_id, episode->probe_bytes.size(),
                    decision.error.c_str(), episode->probe_bytes.c_str());
            }
            rerot->hard_abort(
                slot.rerot_episode_id,
                "rerot_protocol_error: routing plan rejected: " + decision.error);
            return false;
        }
        if (slot.task && slot.task->params.rerot_trace) {
            // Symmetric to probe_reject: the accepted plan and the route it
            // selected are the control-plane artifact worth reconstructing
            // after the fact (JSON wire format, no extra cost when untraced).
            // The plan is emitted on ONE line (newlines/tabs escaped) so a
            // multi-task plan can never be truncated by log line splitting.
            std::string plan_line;
            plan_line.reserve(episode->probe_bytes.size() + 16);
            for (const char ch : episode->probe_bytes) {
                switch (ch) {
                    case '\n': plan_line += "\\n"; break;
                    case '\r': plan_line += "\\r"; break;
                    case '\t': plan_line += "\\t"; break;
                    default:   plan_line += ch;    break;
                }
            }
            SRV_INF("rerot.trace.probe_plan: episode=%" PRIu64 " tokens=%" PRIu64
                    " strategy=%s text=%s\n",
                slot.rerot_episode_id, episode->probe_tokens,
                decision.is_simple() ? "simple"
                    : (decision.is_mindmap() ? "mindmap" : "dag"),
                plan_line.c_str());
        }
        const uint64_t probe_ep_id = slot.rerot_episode_id;
        auto probe_transport_it = rerot_transport.find(probe_ep_id);
        const int64_t t_probe_start_us = probe_transport_it != rerot_transport.end() ? probe_transport_it->second->t_probe_start_us : 0;
        bool probe_ok = false;
        if (decision.is_simple()) {
            probe_ok = rerot_enter_simple(slot, slot.rerot_episode_id);
        } else if (decision.is_mindmap()) {
            // MM-R1 reuses the DAG execution container with a frozen plan:
            // leaves become workers with NO leaf-to-leaf edge, the tree is
            // preserved on the episode, and the reader order is hierarchical.
            probe_ok = rerot_enter_mindmap(slot, slot.rerot_episode_id, decision);
        } else if (decision.is_dag()) {
            probe_ok = rerot_enter_dag(slot, slot.rerot_episode_id, decision);
        } else {
            rerot->hard_abort(slot.rerot_episode_id, "rerot_protocol_error: routing probe produced an invalid strategy");
            return false;
        }
        if (probe_ok && t_probe_start_us > 0) {
            const int64_t probe_dur_us = ggml_time_us() - t_probe_start_us;
            const double probe_dur_s = (double) probe_dur_us / 1.0e6;
            rerot_metrics.probe_seconds += probe_dur_s;
            ++rerot_metrics.probe_count;
            if (probe_transport_it != rerot_transport.end()) {
                probe_transport_it->second->probe_seconds += probe_dur_s;
            }
        }
        return probe_ok;
    }


    bool rerot_plan_next_token(server_slot & slot) {
        if (!slot.rerot_internal || !rerot || slot.rerot_episode_id == 0 ||
            slot.rerot_inflight_plan.has_value() ||
            !slot.rerot_inflight_extra_plans.empty()) {
            return false;
        }

        auto * lane = rerot->node(slot.rerot_episode_id, slot.rerot_node_id);
        if (!lane || lane->exec_seq != rerot_slot_seq(slot) || lane->physical_slot != slot.id) {
            rerot->hard_abort(slot.rerot_episode_id, "rerot_state_error: slot/Lane mapping drift");
            return false;
        }

        const bool forced =
            slot.rerot_injection != server_rerot_injection_kind::none &&
            slot.rerot_injection_cursor < slot.rerot_injection_tokens.size();
        const llama_token token = forced
            ? slot.rerot_injection_tokens[slot.rerot_injection_cursor]
            : slot.sampled;
        if (token == LLAMA_TOKEN_NULL) {
            SRV_ERR("RERoT missing input: episode=%" PRIu64 " node=%u slot=%d i_batch=%d injection=%d cursor=%zu/%zu\n",
                slot.rerot_episode_id, slot.rerot_node_id, slot.id, slot.i_batch,
                static_cast<int>(slot.rerot_injection), slot.rerot_injection_cursor,
                slot.rerot_injection_tokens.size());
            rerot->hard_abort(slot.rerot_episode_id, "rerot_state_error: Lane has no pending input token");
            return false;
        }
        const std::string bytes = common_token_to_piece(ctx_tgt, token, true);

        std::optional<server_rerot_token_plan> plan;
        if (forced && server_rerot_private_microbatch(slot.rerot_injection)) {
            auto plans = (slot.rerot_injection == server_rerot_injection_kind::dag_frame)
                ? rerot->plan_frame_span(
                    slot.rerot_episode_id,
                    slot.rerot_node_id,
                    lane->storage_pos_next,
                    rerot_private_batch_size(slot))
                : rerot->plan_private_span(
                    slot.rerot_episode_id,
                    slot.rerot_node_id,
                    lane->storage_pos_next,
                    rerot_private_batch_size(slot));
            if (plans.has_value() && !plans->empty()) {
                plan = std::move(plans->front());
                for (size_t i = 1; i < plans->size(); ++i) {
                    slot.rerot_inflight_extra_plans.push_back(std::move((*plans)[i]));
                    slot.rerot_inflight_extra_bytes.push_back(common_token_to_piece(
                        ctx_tgt,
                        slot.rerot_injection_tokens[slot.rerot_injection_cursor + i],
                        true));
                }
            }
        } else if (forced && server_rerot_public_microbatch(slot.rerot_injection)) {
            // Formal P (ordinary-prefix rebuild suffix + plan text) is framing,
            // not reasoning: commit it as FRAME/PUBLIC so stream filters and
            // the frame-skipping API export exclude it while reader views keep
            // it model-visible. This branch only serves plan_prefix injection.
            auto plans = rerot->plan_public_span(
                slot.rerot_episode_id,
                slot.rerot_node_id,
                lane->storage_pos_next,
                rerot_private_batch_size(slot),
                llama_rerot_segment_kind::frame);
            if (plans.has_value() && !plans->empty()) {
                plan = std::move(plans->front());
                for (size_t i = 1; i < plans->size(); ++i) {
                    slot.rerot_inflight_extra_plans.push_back(std::move((*plans)[i]));
                    slot.rerot_inflight_extra_bytes.push_back(common_token_to_piece(
                        ctx_tgt,
                        slot.rerot_injection_tokens[slot.rerot_injection_cursor + i],
                        true));
                }
            }
        } else if (forced &&
                   slot.rerot_injection == server_rerot_injection_kind::planner_open) {
            plan = rerot->plan_generated_token(
                slot.rerot_episode_id, slot.rerot_node_id, lane->storage_pos_next, bytes);
        } else if (forced && slot.rerot_injection == server_rerot_injection_kind::heading) {
            plan = rerot->plan_heading_token(
                slot.rerot_episode_id, slot.rerot_node_id, lane->storage_pos_next);
        } else if (slot.rerot_serial_tail) {
            plan = rerot->plan_serial_token(
                slot.rerot_episode_id, slot.rerot_node_id, lane->storage_pos_next);
        } else {
            plan = rerot->plan_generated_token(
                slot.rerot_episode_id, slot.rerot_node_id, lane->storage_pos_next, bytes);
        }

        if (!plan.has_value()) {
            SRV_ERR("RERoT plan failed: episode=%" PRIu64
                    " node=%u serial=%d forced=%d pos=%d token=%d\n",
                slot.rerot_episode_id, slot.rerot_node_id,
                slot.rerot_serial_tail ? 1 : 0, forced ? 1 : 0,
                lane->storage_pos_next, token);
            rerot->hard_abort(slot.rerot_episode_id, "rerot_protocol_error: failed to plan Lane token");
            return false;
        }

        slot.rerot_inflight_plan = std::move(plan);
        slot.rerot_inflight_bytes = bytes;
        slot.rerot_inflight_forced = forced;
        return true;
    }

    bool rerot_append_planned_token(server_slot & slot) {
        if (!slot.rerot_internal || !slot.rerot_inflight_plan.has_value() || !rerot) {
            return false;
        }
        auto transport_it = rerot_transport.find(slot.rerot_episode_id);
        const bool segmented =
            transport_it != rerot_transport.end() &&
            transport_it->second->segmented_active;
        size_t span_count = 0;
        const int64_t ddvr_started_us = segmented ? ggml_time_us() : 0;
        const bool installed = segmented
            ? rerot->install_token_plan(
                slot.rerot_episode_id,
                slot.rerot_node_id,
                *slot.rerot_inflight_plan,
                &span_count)
            : rerot->install_token_plan_write_only(
                slot.rerot_episode_id,
                slot.rerot_node_id,
                *slot.rerot_inflight_plan);
        if (segmented && installed) {
            rerot_metrics.span_count += span_count;
            rerot_metrics.ddvr_seconds +=
                static_cast<double>(ggml_time_us() - ddvr_started_us) / 1.0e6;
        }
        if (!installed) {
            SRV_ERR("RERoT install failed in server: episode=%" PRIu64
                    " node=%u serial=%d run=%u pos=%d\n",
                slot.rerot_episode_id, slot.rerot_node_id,
                slot.rerot_serial_tail ? 1 : 0,
                slot.rerot_inflight_plan->run_id,
                slot.rerot_inflight_plan->storage_pos);
            return false;
        }

        const size_t n_plans = 1 + slot.rerot_inflight_extra_plans.size();
        for (size_t i = 0; i < n_plans; ++i) {
            const auto & plan = i == 0
                ? *slot.rerot_inflight_plan
                : slot.rerot_inflight_extra_plans[i - 1];
            // Capture the forced flag and injection offset before the cursor
            // advances: each row keeps its exact known interval identity, and
            // frontier generation rows (not forced) stay distinguishable.
            const bool row_forced = slot.rerot_inflight_forced;
            const int32_t inject_offset = row_forced
                ? (int32_t) slot.rerot_injection_cursor
                : LLAMA_FLASHPREFILL_POS_UNKNOWN;
            const llama_token token = row_forced
                ? slot.rerot_injection_tokens.at(slot.rerot_injection_cursor)
                : slot.sampled;
            const bool forced_last = row_forced &&
                slot.rerot_injection_cursor + 1 == slot.rerot_injection_tokens.size();
            const bool needs_logits = !row_forced ||
                (forced_last &&
                 slot.rerot_injection != server_rerot_injection_kind::heading &&
                 slot.rerot_injection != server_rerot_injection_kind::child_open &&
                 slot.rerot_injection != server_rerot_injection_kind::planner &&
                 slot.rerot_injection != server_rerot_injection_kind::plan_prefix);
            const int32_t i_batch = batch.size();
            if (!batch.add(rerot_slot_seq(slot), token, plan.storage_pos, needs_logits)) {
                rerot->hard_abort(
                    slot.rerot_episode_id,
                    "rerot_resource_exhausted: private microbatch capacity");
                return false;
            }
            if (fp_enabled) {
                // Exact known teacher-forced interval: the whole injection was
                // tokenized up front, so [0, size) is known before the first
                // frontier commits. Frontier generation rows (row_forced false,
                // including serial-tail and planner_open generations) use an
                // unknown boundary and the REROT_FRONTIER dense role — they
                // are never mistaken for prefill, even when several share a frontier.
                llama_flashprefill_row row = {};
                row.version = LLAMA_FLASHPREFILL_ROW_VERSION;
                row.struct_size = (uint32_t) sizeof(llama_flashprefill_row);
                row.seq_id = rerot_slot_seq(slot);
                row.reader_id = slot.rerot_node_id;
                if (row_forced) {
                    row.role = LLAMA_FLASHPREFILL_ROLE_REROT_TEACHER_FORCED;
                    row.logical_pos = inject_offset;
                    row.prefill_begin = 0;
                    row.prefill_end = (int32_t) slot.rerot_injection_tokens.size();
                    row.prefill_known = true;
                } else {
                    row.role = LLAMA_FLASHPREFILL_ROLE_REROT_FRONTIER;
                    row.logical_pos = LLAMA_FLASHPREFILL_POS_UNKNOWN;
                    row.prefill_begin = LLAMA_FLASHPREFILL_SEQ_UNKNOWN;
                    row.prefill_end = LLAMA_FLASHPREFILL_SEQ_UNKNOWN;
                    row.prefill_known = false;
                }
                GGML_ASSERT(llama_flashprefill_validate_row(&row) == LLAMA_FLASHPREFILL_OK);
                batch.fp_push_row(row);
            }

            slot.i_batch = i_batch;
            slot.prompt.tokens.push_back(token);
            if (row_forced) {
                ++slot.rerot_injection_cursor;
            }
        }
        return true;
    }

    uint32_t rerot_lane_seed(
            const server_rerot_episode & episode,
            llama_rerot_node_id node_id,
            uint32_t root_seed) const {
        uint64_t hash = root_seed;
        for (const uint32_t component : episode.document.tree_path(node_id)) {
            hash ^= uint64_t(component) + 0x9e3779b97f4a7c15ULL + (hash << 6) + (hash >> 2);
        }
        hash ^= hash >> 33;
        hash *= 0xff51afd7ed558ccdULL;
        hash ^= hash >> 33;
        return static_cast<uint32_t>(hash);
    }

    llama_seq_id rerot_slot_seq(const server_slot & slot) const {
        return (slot.rerot_internal && slot.rerot_exec_seq >= 0) ? slot.rerot_exec_seq : slot.id;
    }

    // A bound member done for the open logical step (runtime-sealed or
    // already committed) must not be fed again while cohort peers pend:
    // re-forwarding fabricates tokens past the verified seal or advances a
    // member twice in one cohort. No new logical step is inferred from
    // physical batch order. Serial tails are exempt: their completion
    // lifecycle owns sampling directly.
    bool rerot_cohort_feed_blocked(const server_slot & slot) const {
        if (!slot.rerot_internal || slot.rerot_serial_tail || !rerot ||
            slot.rerot_episode_id == 0) {
            return false;
        }
        return rerot->dag_step_node_done(slot.rerot_episode_id, slot.rerot_node_id);
    }

    // Capture a RUNNING worker's pending next-source-token decision from the
    // just-committed row, before central finish/yield/admit can pull the pen
    // (W>P staleness: the resumed executor would otherwise sample a stale or
    // missing row, the fixed C0 bug in miniature). Runs after ALL commits of
    // the slice, before any scheduling mutation. Captured slots get i_batch
    // -1 from rerot_sample_slot, so the general sampling pass below skips
    // them: exactly-once capture. Skips serial tails (their completion
    // lifecycle samples later), sealed lanes, synthesis source-exits (the row
    // is retained for post-serial user-grammar sampling, never pre-sampled
    // as content), forced rows (no valid sample row), and probing episodes
    // (no yield possible before c_base; sampling stays where it is).
    bool rerot_capture_pending_decision(server_slot & slot, int off, int32_t n_batch_tokens) {
        if (!slot.rerot_internal || slot.state != SLOT_STATE_GENERATING) {
            return true;
        }
        // If a DAG frame finished injecting in this slice, slot.rerot_injection was
        // reset to none in rerot_commit_inflight, but slot.i_batch has the valid
        // logits row index for the first worker token!
        if (slot.rerot_injection != server_rerot_injection_kind::none ||
            slot.i_batch < off || slot.i_batch >= off + n_batch_tokens) {
            return true;
        }
        if (slot.rerot_serial_tail) {
            return true;
        }
        const auto * episode = rerot ? rerot->episode(slot.rerot_episode_id) : nullptr;
        const auto * logical = episode ? episode->document.node(slot.rerot_node_id) : nullptr;
        const auto * lane = rerot ? rerot->node(slot.rerot_episode_id, slot.rerot_node_id) : nullptr;
        // DAG only: legacy HTML/probe and serial-tail rows sample below, not
        // during commit. Capturing them here would sample twice or perturb
        // their order (e.g. before fork-idle).
        if (!episode || !logical || !lane || episode->hard_aborted || !episode->is_dag ||
            logical->state == llama_rerot_node_state::forked ||
            logical->state == llama_rerot_node_state::retired ||
            lane->is_sealed) {
            return true;
        }
        if (lane->stage_role == llama_rerot_stage_role::synthesis && lane->exit_intent) {
            return true;
        }
        const int tok_idx = slot.i_batch - off;
        return rerot_sample_slot(slot, tok_idx, nullptr);
    }

    void rerot_make_slot_idle(server_slot & slot) {
        slot.prompt.clear();
        slot.state = SLOT_STATE_IDLE;
        slot.reset();
    }

    void rerot_park_slot_lineage(server_slot & slot) {
        if (!rerot || slot.rerot_episode_id == 0) {
            return;
        }
        auto transport_it = rerot_transport.find(slot.rerot_episode_id);
        if (transport_it == rerot_transport.end()) {
            return;
        }
        transport_it->second->lineage_tokens.insert_or_assign(
            slot.rerot_node_id, slot.prompt.tokens.clone());
        if (slot.smpl) {
            transport_it->second->lane_samplers[slot.rerot_node_id].reset(
                common_sampler_clone(slot.smpl.get()));
        }
        // Preserve a passivated mid-frame forward: the parked KV/tape prefix
        // stays valid only if resume continues from this exact cursor.
        // Completed (or absent) injections leave no resume state behind.
        auto & parked = transport_it->second->parked_injections[slot.rerot_node_id];
        if (slot.rerot_injection != server_rerot_injection_kind::none &&
            slot.rerot_injection_cursor < slot.rerot_injection_tokens.size()) {
            parked.kind = slot.rerot_injection;
            parked.tokens = slot.rerot_injection_tokens;
            parked.cursor = slot.rerot_injection_cursor;
        } else {
            parked.kind = server_rerot_injection_kind::none;
            parked.tokens.clear();
            parked.cursor = 0;
        }
        // Preserve the pending next-token decision alongside lineage/sampler;
        // resume feeds it, never a stale logit row and never a re-forward.
        // LLAMA_TOKEN_NULL means the lane was descheduled before its first
        // decision of this frame: there is nothing to carry, and writing the
        // placeholder would make the resume path treat a normal re-entry as a
        // corrupt RUNNING lane. Drop any older entry instead of leaving a
        // stale decision behind for a lane that has not sampled yet.
        if (slot.sampled != LLAMA_TOKEN_NULL) {
            transport_it->second->pending_tokens.insert_or_assign(slot.rerot_node_id, slot.sampled);
        } else {
            transport_it->second->pending_tokens.erase(slot.rerot_node_id);
        }
    }

    bool rerot_prepare_child_slot(
            uint64_t episode_id,
            llama_rerot_node_id node_id,
            server_slot & slot) {
        auto transport_it = rerot_transport.find(episode_id);
        auto * episode = rerot ? rerot->episode(episode_id) : nullptr;
        auto * lane = rerot ? rerot->node(episode_id, node_id) : nullptr;
        if (transport_it == rerot_transport.end() || !episode || !lane ||
            lane->physical_slot != slot.id || lane->exec_seq != slot.id) {
            return false;
        }

        auto & lineage = transport_it->second->lineage_tokens;
        auto lineage_it = lineage.find(node_id);
        if (lineage_it == lineage.end() && episode->is_dag &&
            episode->starting.count(node_id) != 0 &&
            transport_it->second->lane_samplers.count(node_id) == 0) {
            const auto root_it = lineage.find(0);
            if (root_it != lineage.end()) {
                lineage_it = lineage.emplace(node_id, root_it->second.clone()).first;
            }
        }
        if (lineage_it == lineage.end()) {
            rerot->hard_abort(episode_id, "rerot_state_error: missing child lineage token tape");
            return false;
        }

        server_task task = rerot_clone_task(transport_it->second->response_task);
        rerot_remove_planner_grammar(task.params);
        // The user's reasoning budget governs 0.synthesize source reasoning so
        // it is already DONE before final content starts; workers run
        // budget-free so the budget never first activates in the final answer.
        const bool keep_budget = episode->is_dag &&
            lane->stage_role == llama_rerot_stage_role::synthesis;
        if (!keep_budget) {
            task.params.sampling.reasoning_budget_start.clear();
            task.params.sampling.reasoning_budget_end.clear();
            task.params.sampling.reasoning_budget_tokens = -1;
        }
        task.params.sampling.seed = rerot_lane_seed(
            *episode, node_id, transport_it->second->root_seed);
        task.rerot_episode_id = episode_id;

        const auto * logical = episode->document.node(node_id);
        const bool starting = logical && logical->state == llama_rerot_node_state::starting;
        auto parked_smpl = transport_it->second->lane_samplers.find(node_id);
        const bool have_parked_smpl =
            parked_smpl != transport_it->second->lane_samplers.end() &&
            parked_smpl->second;
        // A passivated stage resumes its exact sampler (RNG/history/penalty)
        // in either phase; only a fresh STARTING constructs one. A resumed
        // RUNNING stage with no parked sampler is corruption: fail closed,
        // never reseed a new sampler over the parked lineage.
        if (have_parked_smpl) {
            slot.smpl = std::move(parked_smpl->second);
        } else if (starting) {
            try {
                slot.smpl.reset(common_sampler_init(
                    model_tgt, task.params.sampling, (int32_t) llama_n_ctx(ctx_tgt)));
            } catch (const std::exception & e) {
                rerot->hard_abort(episode_id, std::string("rerot_sampler_error: ") + e.what());
                return false;
            }
        } else {
            rerot->hard_abort(episode_id, "rerot_state_error: resumed RUNNING lane has no parked sampler");
            return false;
        }

        slot.task = std::make_unique<const server_task>(std::move(task));
        llama_set_sampler(ctx_tgt, slot.id, nullptr);
        slot.lora = transport_it->second->lora;
        slot.prompt.clear();
        slot.prompt.tokens = lineage_it->second.clone();
        slot.response_prompt.clear();
        slot.generated_text.clear();
        slot.generated_tokens.clear();
        slot.generated_token_probs.clear();
        slot.n_sent_text = 0;
        slot.n_decoded = 0;
        slot.n_decoded_start = 0;
        slot.n_remaining = -1;
        slot.n_prompt_tokens_original = transport_it->second->response_task.n_tokens();
        slot.n_prompt_tokens_processed = 0;
        slot.n_prompt_tokens_processed_accum = 0;
        slot.t_start_process_prompt = transport_it->second->started_us;
        slot.t_start_generation = transport_it->second->started_us;
        slot.has_next_token = true;
        slot.has_new_line = false;
        slot.truncated = false;
        slot.stop = STOP_TYPE_NONE;
        slot.stopping_word.clear();
        slot.state = SLOT_STATE_GENERATING;
        slot.i_batch = -1;
        slot.sampled = LLAMA_TOKEN_NULL;
        slot.spec_draft.clear();
        slot.spec_i_batch.clear();
        if (spec) {
            common_speculative_set_paused(spec.get(), slot.id, !episode->is_dag);
        }

        slot.rerot_internal = true;
        slot.rerot_episode_id = episode_id;
        slot.rerot_node_id = node_id;
        slot.rerot_exec_seq = slot.id;
        slot.rerot_serial_tail = false;
        slot.rerot_inflight_plan.reset();
        slot.rerot_inflight_bytes.clear();
        slot.rerot_inflight_extra_plans.clear();
        slot.rerot_inflight_extra_bytes.clear();
        slot.rerot_inflight_forced = false;
        slot.triattention_compressed = transport_it->second->triattention_compressed;

        if (episode->is_dag) {
            const auto * logical_now = episode->document.node(node_id);
            if (logical_now && logical_now->state == llama_rerot_node_state::starting) {
                // F_i is computed once per node by contract. A passivated
                // mid-frame resume reuses its saved tokens+cursor directly
                // (kind/cursor validated); only a fresh STARTING renders once.
                // Entry template/model/adapter lineage is fixed per episode,
                // so no repeated full-render is needed. Either way the parked
                // sampler carried over above binds as-is: init_sampler()
                // would reseed RNG and replay the tape after a suspension.
                auto parked_frame_it = transport_it->second->parked_injections.find(node_id);
                const bool resume_frame =
                    parked_frame_it != transport_it->second->parked_injections.end() &&
                    parked_frame_it->second.kind == server_rerot_injection_kind::dag_frame;
                if (resume_frame) {
                    auto saved = std::move(parked_frame_it->second);
                    transport_it->second->parked_injections.erase(parked_frame_it);
                    if (saved.tokens.empty() || saved.cursor == 0 ||
                        saved.cursor > saved.tokens.size()) {
                        rerot->hard_abort(episode_id, "rerot_state_error: parked DAG frame cursor invalid");
                        return false;
                    }
                    if (!rerot_set_injection(slot, server_rerot_injection_kind::dag_frame, std::move(saved.tokens))) {
                        rerot->hard_abort(episode_id, "rerot_protocol_error: failed to resume DAG fixed entry");
                        return false;
                    }
                    slot.rerot_injection_cursor = saved.cursor;
                    rerot_bind_sampler(slot);
                } else {
                    const bool is_synth = lane->stage_role == llama_rerot_stage_role::synthesis;
                    const std::string label = lane->string_id.empty() ? "0" : lane->string_id;
                    std::string frame_intent = lane->intent;
                    if (episode->plan_kind == "mindmap") {
                        const auto & tree = episode->mindmap_tree;
                        const uint32_t tree_node = is_synth ? tree.root : lane->tree_leaf_id;
                        if (!episode->mindmap_tree_valid || tree_node >= tree.nodes.size() ||
                            (!is_synth && !tree.is_leaf(tree_node))) {
                            rerot->hard_abort(
                                episode_id,
                                "rerot_protocol_error: mindmap handoff node is not in the frozen tree");
                            return false;
                        }
                        frame_intent = tree.nodes[tree_node].label;
                    }
                    llama_tokens frame_tokens = rerot_native_fixed_entry_tokens(
                        slot,
                        label,
                        frame_intent,
                        is_synth,
                        is_synth ? rerot_final_mode_for(episode) : std::string_view{},
                        episode->source_end_marker,
                        episode->think_start_marker);
                    if (frame_tokens.empty()) {
                        rerot->hard_abort(
                            episode_id,
                            "rerot_protocol_error: chat template cannot losslessly render a native DAG fixed entry");
                        return false;
                    }
                    if (!rerot_set_injection(slot, server_rerot_injection_kind::dag_frame, std::move(frame_tokens))) {
                        rerot->hard_abort(episode_id, "rerot_protocol_error: failed to arm DAG fixed entry");
                        return false;
                    }
                }
            } else {
                slot.rerot_injection = server_rerot_injection_kind::none;
                slot.rerot_injection_tokens.clear();
                slot.rerot_injection_cursor = 0;
                // Resumed RUNNING: feed the parked pending decision through
                // the ordinary next-input path (plan/append forwards
                // slot.sampled; i_batch stays -1: no valid row exists yet).
                // Absent pending means the lane produced no decision before it
                // was descheduled (first forward of the frame). i_batch=-1 and
                // sam=\0 make the ordinary path forward the current prompt and
                // sample fresh; never reseed over the parked lineage and never
                // sample a stale logit row.
                const auto pend_it = transport_it->second->pending_tokens.find(node_id);
                if (pend_it != transport_it->second->pending_tokens.end() &&
                    pend_it->second != LLAMA_TOKEN_NULL) {
                    slot.sampled = pend_it->second;
                    transport_it->second->pending_tokens.erase(pend_it);
                } else {
                    slot.sampled = LLAMA_TOKEN_NULL;
                }
                slot.i_batch = -1;
                rerot_bind_sampler(slot);
            }
        } else {
            rerot->hard_abort(
                episode_id,
                "rerot_protocol_error: HTML planner production path is retired");
            return false;
        }

        ++rerot_metrics.nodes_started;
        rerot_metrics.queue_max = std::max<uint64_t>(
            rerot_metrics.queue_max, episode->ready_queue.size());
        const uint64_t live_lanes =
            episode->running.size() + episode->starting.size();
        rerot_metrics.max_live_lanes = std::max<uint64_t>(
            rerot_metrics.max_live_lanes, live_lanes);
        rerot_note_lane_count(episode_id, live_lanes);
        if (live_lanes > 1) {
            rerot_note_parallel_start(episode_id);
        }

        return true;
    }

    // Advisory result: `ok` = admission ran, `saturated` = pen arena full
    // (no progress this step, not an error), `failed` = episode aborted.
    enum class rerot_admit_ready_result : uint8_t { ok = 0, saturated, failed };

    rerot_admit_ready_result rerot_admit_ready(uint64_t episode_id) {
        auto * episode = rerot ? rerot->episode(episode_id) : nullptr;
        if (!episode || episode->hard_aborted) {
            return rerot_admit_ready_result::failed;
        }

        // pen_capacity is the hard in-flight-lane bound. The DAG activa-
        // tion path below admits directly into physical slots and does not
        // route through schedule_pens/allocate_pen; without this gate the
        // ready queue can bind more lanes than the pen arena owns and two
        // lanes end up sharing a physical slot (observed as slot reuse
        // under a still-RUNNING lane). Count this episode's physically
        // bound pens: ready_queue/starting hold *planned* nodes before
        // admission, so counting them would gate admission itself (a DAG
        // plan of W nodes with W == P must still admit all P). Excess
        // lanes stay queued until a running lane finishes.
        const uint64_t live_lanes = rerot->pens_for_person(episode_id).size();
        if (episode->is_dag && live_lanes >= rerot->pen_capacity()) {
            // Capacity reached: every pen is bound, so there is nothing to
            // admit. This is NOT an error and NOT progress: reporting plain
            // success made finish_frontier treat an untouched cohort as
            // advanced and re-enter admission on every decode step, which reset
            // the frame-injection cursor of the still-STARTING lane; its fixed
            // entry then never completed, no pen was released, and the episode
            // livelocked admitting the same node forever.
            return rerot_admit_ready_result::saturated;
        }

        while (!episode->suspended.empty() || !episode->ready_queue.empty()) {
            // Admission can bind several peers in this loop. Once the last
            // free pen is filled, return to decode so those STARTING lanes
            // actually consume their frames. Extra eligible workers remain
            // queued until a bound worker naturally seals.
            if (episode->is_dag &&
                rerot->pens_for_person(episode_id).size() >= rerot->pen_capacity()) {
                break;
            }
            // Select an idle executor first. All busy pens mean normal queue
            // pressure, not a recurrent allocation failure. Drop an idle
            // slot's stale prompt-cache refs before checking its reserved
            // recurrent row. prompt_clear touches only this slot's own seq;
            // C_base, archive, parked, and other owners' refs are untouched.
            server_slot * free_slot = nullptr;
            for (auto & candidate : slots) {
                if (!candidate.is_processing()) {
                    free_slot = &candidate;
                    break;
                }
            }
            if (!free_slot) {
                break;
            }
            free_slot->prompt_clear();

            llama_memory_kv_usage recurrent = {};
            if (llama_memory_get_recurrent_usage(llama_get_memory(ctx_tgt), &recurrent)) {
                // Detached fork seeds allocate a physical hand row during
                // prepare_child_slot(), so recurrent.used already includes
                // every STARTING Lane. Only the next admission is additional.
                const uint64_t required_after_cow = recurrent.used + 1;
                if (required_after_cow > recurrent.capacity) {
                    // The fixed pen count already reserves recurrent rows.
                    // A free pen without one means a prior row leaked or the
                    // fitted capacity is wrong, not that queued leaves need
                    // time-slicing or a smaller plan.
                    if (episode->is_dag) {
                        rerot->hard_abort(episode_id, "rerot_state_error: free DAG pen has no reserved recurrent row");
                        return rerot_admit_ready_result::failed;
                    }
                    break;
                }
            }

            if (episode->is_dag) {
                const auto pending = rerot->dag_step_next_pending(episode_id);
                if (pending.has_value()) {
                    const llama_rerot_node_id nid = *pending;
                    const bool is_synth = (nid == episode->synthesis_node);
                    if (episode->suspended.count(nid) != 0) {
                        if (!rerot->resume_pen(episode_id, nid, free_slot->id, free_slot->id) ||
                            !rerot_prepare_child_slot(episode_id, nid, *free_slot)) {
                            rerot->hard_abort(episode_id, "rerot_state_error: suspended pen resumption failed");
                            return rerot_admit_ready_result::failed;
                        }
                    } else if (!rerot->admit_next_child(
                                   episode_id, free_slot->id, free_slot->id, nullptr, nid) ||
                               !rerot_prepare_child_slot(episode_id, nid, *free_slot)) {
                        rerot->hard_abort(episode_id, "rerot_state_error: child admission failed");
                        return rerot_admit_ready_result::failed;
                    }
                    if (is_synth) {
                        // P12: admitting the synthesis lane ends the worker
                        // decode window (workers_finish covers the exit/fence
                        // window; synthesis decode follows).
                        rerot_prof_phase_exit(llama_rerot_phase::workers_frontier);
                        rerot_prof_phase_enter(llama_rerot_phase::synthesis);
                        const int64_t start_us = episode->t_synthesis_eligible_us > 0 ? episode->t_synthesis_eligible_us : ggml_time_us();
                        const int64_t dur_us = std::max<int64_t>(0, ggml_time_us() - start_us);
                        const double dur_s = (double) dur_us / 1.0e6;
                        rerot_metrics.synthesis_switch_seconds += dur_s;
                        ++rerot_metrics.synthesis_switch_count;
                        auto transport_it = rerot_transport.find(episode_id);
                        if (transport_it != rerot_transport.end()) {
                            transport_it->second->synthesis_switch_seconds += dur_s;
                        }
                    }
                    continue;
                }
                // Remaining ready nodes are outside this physical cohort.
                // They wait for a natural seal and the next snapshot; never
                // bypass the snapshot just because a slot is temporarily idle.
                    break;
            }

            if (!episode->suspended.empty()) {
                const llama_rerot_node_id suspended_id = *episode->suspended.begin();
                if (!rerot->resume_pen(episode_id, suspended_id, free_slot->id, free_slot->id) ||
                    !rerot_prepare_child_slot(episode_id, suspended_id, *free_slot)) {
                    rerot->hard_abort(episode_id, "rerot_state_error: suspended pen resumption failed");
                    return rerot_admit_ready_result::failed;
                }
                continue;
            }

            llama_rerot_node_id admitted = LLAMA_REROT_NODE_INVALID;
            if (!rerot->admit_next_child(
                    episode_id, free_slot->id, free_slot->id, &admitted) ||
                admitted == LLAMA_REROT_NODE_INVALID ||
                !rerot_prepare_child_slot(episode_id, admitted, *free_slot)) {
                rerot->hard_abort(episode_id, "rerot_state_error: child admission failed");
                return rerot_admit_ready_result::failed;
            }
        }
        return rerot_admit_ready_result::ok;
    }

    std::string rerot_render_public_document(
            uint64_t episode_id,
            llama_rerot_node_id reader) const {
        const auto * episode = rerot ? rerot->episode(episode_id) : nullptr;
        const auto transport_it = rerot_transport.find(episode_id);
        if (!episode || transport_it == rerot_transport.end()) {
            return {};
        }

        const auto view = episode->is_dag
            ? rerot->build_dag_view_for_reader(episode_id, reader)
            : episode->document.build_view(reader);
        std::string result;
        for (const auto & view_run : view.runs) {
            const auto * run = episode->document.run(view_run.run_id);
            if (!run) {
                continue;
            }
            if (run->kind == llama_rerot_segment_kind::frame ||
                run->kind == llama_rerot_segment_kind::source_end ||
                run->kind == llama_rerot_segment_kind::probe_control) {
                continue;
            }
            const auto prefix_it =
                transport_it->second->run_public_prefixes.find(run->id);
            if (prefix_it != transport_it->second->run_public_prefixes.end()) {
                result += prefix_it->second;
            }
            if (run->visibility != llama_rerot_visibility::public_live) {
                continue;
            }
            const auto text_it = transport_it->second->run_bytes.find(run->id);
            if (text_it != transport_it->second->run_bytes.end()) {
                result += text_it->second;
            }
        }
        return result;
    }

    void rerot_erase_episode(uint64_t episode_id) {
        // P12: close the request-scoped ledger when the LAST episode tears
        // down. rerot_transport.erase below removes this episode first, so
        // empty() after it means no queued root was admitted either (a
        // re-admitted root re-enters probe on a fresh ledger via
        // rerot_start_root's first-root begin).
        const size_t rerot_prof_remaining = rerot_transport.size() > 1 ? rerot_transport.size() - 1 : 0;
        if (ctx_tgt) {
            llama_rerot_episode_end(ctx_tgt, episode_id);
        }
        if (rerot) {
            rerot->erase_episode(episode_id);
        }
        rerot_transport.erase(episode_id);
        if (rerot_prof_remaining == 0) {
            llama_rerot_profile_end();
        }
        if (rerot_metrics.episode_active > 0) {
            --rerot_metrics.episode_active;
        }
        if (rerot_episode_id == episode_id) {
            rerot_episode_id = rerot_transport.empty() ? 0 : rerot_transport.begin()->first;
        }
    }

    void rerot_start_next_waiting_root() {
        if (!rerot || rerot_active()) {
            return;
        }
        for (auto & waiting : slots) {
            if (waiting.state != SLOT_STATE_DONE_PROMPT || !waiting.task ||
                !waiting.task->params.rerot_effective(waiting.task->type)) {
                continue;
            }
            if (rerot_start_root(waiting)) {
                break;
            }
            send_error(waiting, "failed to start queued RERoT episode", ERROR_TYPE_SERVER);
            waiting.prompt.clear();
            waiting.release();
        }
    }

    // MM-R1 final mode for this episode's global entity. "reason" is the
    // shipped S1 shape; "direct" is the S0 research arm. Anything else fails
    // closed: an unknown mode must not silently become S1.
    static std::string_view rerot_final_mode_for(const server_rerot_episode * episode) {
        if (episode == nullptr || episode->plan_kind != "mindmap") {
            return {};
        }
        if (episode->final_mode == "direct") {
            return "direct";
        }
        return "reason";
    }

    bool rerot_commit_inflight(server_slot & slot) {
        if (!rerot || !slot.rerot_inflight_plan.has_value()) {
            return false;
        }

        const server_rerot_token_plan plan = *slot.rerot_inflight_plan;
        const uint64_t episode_id = slot.rerot_episode_id;
        const llama_rerot_node_id node_id = slot.rerot_node_id;
        auto transport_it = rerot_transport.find(episode_id);
        if (transport_it == rerot_transport.end()) {
            rerot->hard_abort(episode_id, "rerot_state_error: missing transport state at commit");
            return false;
        }
        if (slot.rerot_inflight_extra_plans.size() !=
            slot.rerot_inflight_extra_bytes.size()) {
            rerot->hard_abort(episode_id, "rerot_state_error: private microbatch plan drift");
            return false;
        }

        const auto commit_one = [&](const server_rerot_token_plan & current_plan,
                                    const std::string & bytes) {
            const size_t public_prefix_bytes =
                current_plan.marker_step.public_prefix_bytes;
            if (public_prefix_bytes > bytes.size()) {
                rerot->hard_abort(
                    episode_id,
                    "rerot_state_error: marker public prefix exceeds token bytes");
                return false;
            }
            if (!rerot->commit_token(episode_id, node_id, current_plan)) {
                return false;
            }

            auto & transport = *transport_it->second;
            // Stage exact committed native-end evidence for lazy-grammar
            // activation at handoffs. Generated rows commit the token sampled
            // into slot.sampled the previous pass (single-token rows; forced
            // spans never touch the exit parser), so no id mapping is needed.
            if (!slot.rerot_inflight_forced) {
                if (current_plan.segment_kind == llama_rerot_segment_kind::source_end) {
                    auto & evidence = transport.source_end_token_ids[node_id];
                    const auto stage_it = transport.source_end_candidate_stage.find(node_id);
                    if (stage_it != transport.source_end_candidate_stage.end()) {
                        evidence.insert(evidence.end(), stage_it->second.begin(), stage_it->second.end());
                        transport.source_end_candidate_stage.erase(stage_it);
                    }
                    evidence.push_back(slot.sampled);
                } else {
                    if (current_plan.marker_step.release_previous_pending) {
                        transport.source_end_candidate_stage.erase(node_id);
                    }
                    const auto * cnode = rerot->node(episode_id, node_id);
                    if (cnode &&
                        cnode->exit_parser.state() == server_rerot_marker_state::marker_candidate) {
                        transport.source_end_candidate_stage[node_id].push_back(slot.sampled);
                    }
                }
            }
            if (public_prefix_bytes != 0) {
                const auto * node = rerot->node(episode_id, node_id);
                if (node && node->public_run.has_value() &&
                    *node->public_run != current_plan.run_id) {
                    transport.run_bytes[*node->public_run].append(
                        bytes.data(), public_prefix_bytes);
                } else {
                    transport.run_public_prefixes[current_plan.run_id].append(
                        bytes.data(), public_prefix_bytes);
                }
            }
            transport.run_bytes[current_plan.run_id].append(
                bytes.data() + public_prefix_bytes,
                bytes.size() - public_prefix_bytes);
            ++transport.model_tokens;
            if (transport.parallel_started_us != 0 &&
                !transport.parallel_finished) {
                ++transport.parallel_model_tokens;
            }
            if (!slot.rerot_serial_tail &&
                current_plan.visibility != llama_rerot_visibility::private_control &&
                current_plan.segment_kind != llama_rerot_segment_kind::frame &&
                current_plan.segment_kind != llama_rerot_segment_kind::source_end &&
                current_plan.segment_kind != llama_rerot_segment_kind::probe_control &&
                !rerot_stream_commit(
                    episode_id,
                    node_id,
                    current_plan.run_id,
                    bytes,
                    public_prefix_bytes)) {
                return false;
            }
            switch (current_plan.visibility) {
                case llama_rerot_visibility::public_live:     ++rerot_metrics.public_tokens;  break;
                case llama_rerot_visibility::private_control: ++rerot_metrics.private_tokens; break;
                case llama_rerot_visibility::pending_record:  ++rerot_metrics.pending_tokens; break;
                case llama_rerot_visibility::normal: break;
            }
            return true;
        };
        if (!commit_one(plan, slot.rerot_inflight_bytes)) {
            return false;
        }
        for (size_t i = 0; i < slot.rerot_inflight_extra_plans.size(); ++i) {
            if (!commit_one(
                    slot.rerot_inflight_extra_plans[i],
                    slot.rerot_inflight_extra_bytes[i])) {
                return false;
            }
        }

        const bool forced = slot.rerot_inflight_forced;
        auto * episode_now = rerot->episode(episode_id);
        if (episode_now && episode_now->probing && !forced) {
            const size_t previous_bytes = episode_now->probe_bytes.size();
            episode_now->probe_bytes += slot.rerot_inflight_bytes;
            for (const auto & extra : slot.rerot_inflight_extra_bytes) {
                episode_now->probe_bytes += extra;
            }
            slot.rerot_inflight_plan.reset();
            slot.rerot_inflight_bytes.clear();
            slot.rerot_inflight_extra_plans.clear();
            slot.rerot_inflight_extra_bytes.clear();
            slot.rerot_inflight_forced = false;
            // JSON keeps its short-plan limit; mindmap may keep decomposing
            // until the episode's native context token budget is reached.
            if (slot.task->params.rerot_plan_wire == "json" &&
                episode_now->probe_tokens > SERVER_REROT_PROBE_MAX_TOKENS) {
                rerot->hard_abort(
                    episode_id,
                    string_format(
                        "rerot_resource_exhausted: routing probe exceeded %" PRIu64
                        " tokens without a plan terminator",
                        SERVER_REROT_PROBE_MAX_TOKENS));
                return false;
            }
            // A large mindmap is still incomplete until its closing fence.
            // Search only newly appended bytes plus the three-byte overlap for
            // a fence split across token boundaries; parse the full tree once.
            if (slot.task->params.rerot_plan_wire == "mindmap" &&
                episode_now->probe_bytes.find("```\n", previous_bytes > 3 ? previous_bytes - 3 : 0)
                    == std::string::npos) {
                return true;
            }
            return rerot_try_finish_probe(slot);
        }
        const auto injection = slot.rerot_injection;
        const bool forced_complete = forced &&
            slot.rerot_injection_cursor == slot.rerot_injection_tokens.size();
        const bool terminal_plan =
            plan.parser_step.record_closed &&
            plan.parser_step.items.size() == 1;
        const bool lane_finished =
            plan.marker_step.marker_closed ||
            (plan.parser_step.record_closed && !terminal_plan);
        if (lane_finished && !rerot_stream_finish_lane(episode_id, node_id)) {
            return false;
        }

        slot.rerot_inflight_plan.reset();
        slot.rerot_inflight_bytes.clear();
        slot.rerot_inflight_extra_plans.clear();
        slot.rerot_inflight_extra_bytes.clear();
        slot.rerot_inflight_forced = false;

        if (terminal_plan) {
            const auto * lane = rerot->node(episode_id, node_id);
            if (!lane) {
                rerot->hard_abort(
                    episode_id, "rerot_state_error: terminal Lane disappeared");
                return false;
            }

            // A child is already sampled under its exact-close grammar.
            // Its output may legitimately contain a one-item <ol>; only the
            // planner parser becomes terminal. Rebuilding here would discard
            // the child grammar and let its private delimiter become PUBLIC.
            if (!lane->control_id().empty()) {
                return true;
            }

            // The unforked root is the only Lane still sampled under the
            // planner grammar. Remove it before native serial continuation;
            // the original user/tool grammar is restored at the final fence.
            server_task worker_task = rerot_clone_task(*slot.task);
            rerot_remove_planner_grammar(worker_task.params);
            common_sampler_ptr worker_sampler;
            try {
                worker_sampler.reset(common_sampler_init(
                    model_tgt,
                    worker_task.params.sampling,
                    (int32_t) llama_n_ctx(ctx_tgt)));
            } catch (const std::exception & e) {
                rerot->hard_abort(
                    episode_id,
                    std::string("rerot_sampler_error: failed to leave planner grammar: ") + e.what());
                return false;
            }
            slot.task = std::make_unique<const server_task>(std::move(worker_task));
            slot.smpl = std::move(worker_sampler);
            rerot_bind_sampler(slot);
            return rerot_begin_serial_tail(episode_id, node_id, false);
        }

        if (episode_now && episode_now->is_dag && plan.marker_step.marker_closed) {
            const auto * lane = rerot->node(episode_id, node_id);
            if (lane && lane->is_sealed && lane->stage_role == llama_rerot_stage_role::worker) {
                // commit_token() parked this worker's KV and freed its runtime
                // pen. Release the host executor too, before central admission:
                // retire_node() sees a parked lane and cannot report its old
                // slot. Otherwise the sealed slot stays GENERATING forever,
                // while its queued replacement prevents the next cohort from
                // completing. No sampler/lineage snapshot is needed for a
                // sealed worker: it will never resume; history is runtime-owned.
                rerot_make_slot_idle(slot);
                return true;
            }
        }

        if (!forced_complete) {
            return true;
        }

        slot.rerot_injection_tokens.clear();
        slot.rerot_injection_cursor = 0;
        slot.rerot_injection = server_rerot_injection_kind::none;

        if (injection == server_rerot_injection_kind::child_open) {
            if (!rerot_set_injection(
                    slot,
                    server_rerot_injection_kind::heading,
                    rerot->heading_text(episode_id, node_id))) {
                rerot->hard_abort(
                    episode_id,
                    "rerot_protocol_error: failed to arm child heading");
                return false;
            }
        } else if (injection == server_rerot_injection_kind::heading) {
            const auto * episode = rerot->episode(episode_id);
            const auto * document_node = episode
                ? episode->document.node(node_id)
                : nullptr;
            const auto * lane = rerot->node(episode_id, node_id);
            if (!document_node || !lane ||
                !rerot->publish_heading(episode_id, node_id, plan.run_id) ||
                !rerot->complete_admission(episode_id, node_id)) {
                rerot->hard_abort(episode_id, "rerot_protocol_error: child heading publication failed");
                return false;
            }
            // Admission starts a worker, not a mandatory extra planning wave.
            // Leave planner_armed intact so a naturally generated <ol> can
            // still fork at any depth; N=1 remains terminal for that node.
            server_task lane_task = rerot_clone_task(*slot.task);
            rerot_remove_planner_grammar(lane_task.params);
            common_sampler_ptr lane_sampler;
            try {
                lane_sampler.reset(common_sampler_init(
                    model_tgt,
                    lane_task.params.sampling,
                    (int32_t) llama_n_ctx(ctx_tgt)));
            } catch (const std::exception & e) {
                rerot->hard_abort(
                    episode_id,
                    std::string(
                        "rerot_sampler_error: failed to configure child sampler: ") +
                        e.what());
                return false;
            }
            slot.task = std::make_unique<const server_task>(std::move(lane_task));
            slot.smpl = std::move(lane_sampler);
            rerot_bind_sampler(slot);

            if (!rerot_stream_visibility_changed(episode_id, node_id) ||
                !rerot_set_injection(
                    slot,
                    server_rerot_injection_kind::worker,
                    rerot_worker_control_prompt(
                        document_node->title, lane->exit_parser.marker()))) {
                rerot->hard_abort(
                    episode_id,
                    "rerot_protocol_error: child control admission failed");
                return false;
            }
        } else if (injection == server_rerot_injection_kind::worker) {
            const auto * lane = rerot->node(episode_id, node_id);
            if (!lane || !slot.task) {
                rerot->hard_abort(
                    episode_id, "rerot_state_error: child disappeared after control prompt");
                return false;
            }
            server_task child_task = rerot_clone_task(*slot.task);
            if (!rerot_install_child_grammar(
                    child_task.params, lane->exit_parser.marker())) {
                rerot->hard_abort(
                    episode_id, "rerot_protocol_error: invalid child close grammar");
                return false;
            }
            common_sampler_ptr child_sampler;
            try {
                child_sampler.reset(common_sampler_init(
                    model_tgt,
                    child_task.params.sampling,
                    (int32_t) llama_n_ctx(ctx_tgt)));
            } catch (const std::exception & e) {
                rerot->hard_abort(
                    episode_id,
                    std::string("rerot_sampler_error: failed to arm child close grammar: ") +
                        e.what());
                return false;
            }
            slot.task = std::make_unique<const server_task>(std::move(child_task));
            slot.smpl = std::move(child_sampler);
            rerot_bind_sampler(slot);
        } else if (injection == server_rerot_injection_kind::planner) {
            rerot->hard_abort(
                episode_id,
                "rerot_protocol_error: HTML planner production path is retired");
            return false;
        } else if (injection == server_rerot_injection_kind::probe) {
            // No forced prefix enters the routing grammar: the prompt is
            // prose, probe_bytes starts empty, and the grammar stack stays at
            // root until the model samples its first task-line token.
            if (!slot.smpl) {
                rerot->hard_abort(
                    episode_id,
                    "rerot_state_error: probe sampler missing");
                return false;
            }
            return true;
        } else if (injection == server_rerot_injection_kind::plan_prefix) {
            return rerot_finish_plan_prefix(slot, episode_id);
        } else if (injection == server_rerot_injection_kind::dag_frame) {
            const auto * lane = rerot->node(episode_id, node_id);
            if (!lane ||
                !rerot->publish_heading(episode_id, node_id, plan.run_id) ||
                !rerot->complete_admission(episode_id, node_id)) {
                rerot->hard_abort(episode_id, "rerot_protocol_error: DAG frame publication failed");
                return false;
            }
            // Native source-end parser is already armed (native_end=true).
            // Do not install a must-close grammar on DAG workers (AGENTS.md §04).
            server_task lane_task = rerot_clone_task(*slot.task);
            rerot_remove_planner_grammar(lane_task.params);
            common_sampler_ptr lane_sampler;
            try {
                lane_sampler.reset(common_sampler_init(
                    model_tgt, lane_task.params.sampling, (int32_t) llama_n_ctx(ctx_tgt)));
            } catch (const std::exception & e) {
                rerot->hard_abort(
                    episode_id,
                    std::string("rerot_sampler_error: failed to arm DAG worker sampler: ") + e.what());
                return false;
            }
            slot.task = std::make_unique<const server_task>(std::move(lane_task));
            slot.smpl = std::move(lane_sampler);
            rerot_bind_sampler(slot);

            const auto * lane_now = rerot->node(episode_id, node_id);
            if (!lane_now || lane_now->physical_slot != slot.id) {
                rerot_park_slot_lineage(slot);
                rerot_make_slot_idle(slot);
            }
            // No peer admission here: this runs mid commit-loop while other
            // rows of the slice are uncommitted. Admission happens centrally
            // in rerot_handle_finished_frontier after all commits plus
            // pending-decision capture.
        }
        return true;
    }

    bool rerot_begin_serial_tail(
            uint64_t episode_id,
            llama_rerot_node_id final_node,
            bool child_fence = true) {
        auto * lane = rerot ? rerot->node(episode_id, final_node) : nullptr;
        if (!lane || lane->physical_slot < 0 ||
            lane->physical_slot >= static_cast<int>(slots.size())) {
            return false;
        }
        auto & slot = slots[lane->physical_slot];
        auto transport_it = rerot_transport.find(episode_id);
        if (transport_it == rerot_transport.end() || !slot.task) {
            return false;
        }

        // P12: the serial tail (final answer generation) is the synthesis
        // phase; workers_frontier/workers_finish end at this handoff. The
        // unforked-root path (child_fence=false) exits probe directly into
        // synthesis; phase_exit on a never-entered phase is a no-op.
        rerot_prof_phase_exit(llama_rerot_phase::workers_frontier);
        rerot_prof_phase_exit(llama_rerot_phase::workers_finish);
        rerot_prof_phase_enter(llama_rerot_phase::synthesis);

        // Final user-visible output resumes the original user params: the
        // response_task clone already carries the user reasoning budget, and
        // the saved user grammar is restored here (worker/internal phases run
        // grammar-free via rerot_remove_planner_grammar and never see it).
        // The live synthesis sampler is preserved (RNG/penalty/adaptive state
        // plus the DONE reasoning phase) and the user grammar is installed
        // onto the clone. Never fresh-init here: that would lose sampler
        // history, re-prefill generation_prompt into a new COUNTING budget
        // although reasoning already ended, and force a duplicate </think>.
        // Never re-accept history (duplicate penalty counts) and never
        // re-forward or inject a closure.
        server_task final_task =
            rerot_clone_task(transport_it->second->response_task);
        final_task.params.sampling.seed = slot.task->params.sampling.seed;
        final_task.params.sampling.grammar = transport_it->second->saved_user_grammar;
        if (!slot.smpl) {
            rerot->hard_abort(episode_id, "rerot_state_error: missing synthesis sampler for final continuation");
            return false;
        }
        common_sampler_ptr final_sampler;
        final_sampler.reset(common_sampler_clone(slot.smpl.get()));
        if (!final_sampler) {
            rerot->hard_abort(episode_id, "rerot_state_error: failed to preserve synthesis sampler");
            return false;
        }
        // Lazy user grammars activate from the committed native end: prefer
        // the recorded budget match inside replace_grammar, else this exact
        // committed token evidence (covers budget-free synthesis, whose live
        // sampler has no rbudget to record it). A DAG synthesis always exits
        // through a committed native end, so absent evidence there is a
        // provenance failure: abort rather than start the lazy grammar deaf.
        // Legacy paths keep the lenient fallback (ordinary lazy start).
        const auto * episode = rerot->episode(episode_id);
        const bool synth_handoff = episode && episode->is_dag &&
            lane->stage_role == llama_rerot_stage_role::synthesis;
        const llama_tokens * committed_end = nullptr;
        {
            const auto end_it = transport_it->second->source_end_token_ids.find(final_node);
            if (end_it != transport_it->second->source_end_token_ids.end() && !end_it->second.empty()) {
                committed_end = &end_it->second;
            }
        }
        if (synth_handoff && committed_end == nullptr) {
            rerot->hard_abort(episode_id, "rerot_state_error: missing committed native-end evidence for DAG synthesis handoff");
            return false;
        }
        if (!common_sampler_replace_grammar(final_sampler.get(), vocab, final_task.params.sampling, committed_end)) {
            rerot->hard_abort(episode_id, "rerot_state_error: failed to restore final user grammar");
            return false;
        }

        if (child_fence) {
            std::vector<uint32_t> fence_runs;
            if (!rerot->refresh_final_fence(episode_id, final_node, &fence_runs) ||
                !llama_rerot_refresh_barrier(ctx_tgt, episode_id) ||
                !rerot->complete_serial_tail(episode_id, final_node)) {
                rerot->hard_abort(episode_id, "rerot_state_error: final acquire fence failed");
                return false;
            }
        } else if (!rerot->continue_unforked_root(episode_id, final_node)) {
            rerot->hard_abort(
                episode_id, "rerot_state_error: N=1 root serial transition failed");
            return false;
        }

        // Child/planner control prompts are PRIVATE causal state. Restore the
        // fork hand before serial continuation so their instructions cannot
        // echo into the final answer; PUBLIC branch facts remain in the stable
        // DDVR view and shared brain established by the acquire fence.
        const bool dag_synth = episode && episode->is_dag;
        llama_memory_t memory = llama_get_memory(ctx_tgt);
        if (!dag_synth) {
            if (!memory || lane->hand_seed.empty() ||
                !llama_memory_rerot_apply_hand_seed(
                    memory,
                    lane->exec_seq,
                    lane->hand_seed.data(),
                    lane->hand_seed.size())) {
                rerot->hard_abort(
                    episode_id, "rerot_state_error: failed to restore final serial hand");
                return false;
            }
        }
        rerot_note_parallel_end(episode_id, ggml_time_us());

        std::string logical_reasoning =
            rerot_render_public_document(episode_id, final_node);
        if (slot.task && slot.task->params.rerot_trace) {
            SRV_INF("rerot.trace.document: episode=%" PRIu64 " node=%u bytes=%zu text=%s\n",
                episode_id, final_node, logical_reasoning.size(), logical_reasoning.c_str());
        }

        const bool chronological_stream = final_task.params.stream;
        if (chronological_stream && !transport_it->second->line_mux.empty()) {
            rerot->hard_abort(
                episode_id,
                "rerot_stream_error: final fence reached with unfinished Lane lines");
            return false;
        }
        if (chronological_stream &&
            !transport_it->second->streamed_reasoning.empty() &&
            !logical_reasoning.empty() &&
            transport_it->second->streamed_reasoning != logical_reasoning) {
            server_rerot_register_chronicle_mapping(
                transport_it->second->streamed_reasoning,
                logical_reasoning,
                "",
                episode_id);
        }

        std::string response_reasoning = chronological_stream
            ? transport_it->second->streamed_reasoning
            : std::move(logical_reasoning);
        response_reasoning += "\n\n";

        slot.task = std::make_unique<const server_task>(std::move(final_task));
        slot.smpl = std::move(final_sampler);
        llama_set_sampler(ctx_tgt, slot.id, nullptr);
        slot.generated_text = std::move(response_reasoning);
        transport_it->second->final_content_offset = slot.generated_text.size();
        slot.generated_tokens.clear();
        slot.generated_token_probs.clear();
        slot.n_sent_text = slot.generated_text.size();
        slot.n_prompt_tokens_original = transport_it->second->response_task.n_tokens();
        slot.n_prompt_tokens_processed = transport_it->second->prompt_tokens_processed;
        slot.n_prompt_tokens_processed_accum =
            transport_it->second->prompt_tokens_processed_accum;
        slot.n_prompt_tokens_cache_response =
            transport_it->second->prompt_tokens_cache_response;
        slot.t_prompt_processing = transport_it->second->prompt_processing_ms;
        slot.n_decoded = 0;
        slot.n_decoded_start = 0;
        slot.has_next_token = true;
        slot.stop = STOP_TYPE_NONE;
        slot.stopping_word.clear();
        slot.rerot_serial_tail = true;
        slot.rerot_injection = server_rerot_injection_kind::none;
        slot.rerot_injection_tokens.clear();
        slot.rerot_injection_cursor = 0;
        if (!dag_synth) {
            if (!rerot_set_injection(
                    slot,
                    server_rerot_injection_kind::serial_resume,
                    rerot_serial_resume_prompt(child_fence))) {
                rerot->hard_abort(
                    episode_id, "rerot_protocol_error: failed to resume serial reasoning");
                return false;
            }
        }

        if (child_fence) {
            ++rerot_metrics.final_fences;
            ++rerot_metrics.refresh_total;
        }
        SRV_INF("RERoT %s: episode=%" PRIu64
                " node=%u slot=%d public_bytes=%zu streamed_lines=%" PRIu64 "\n",
            child_fence ? "final child fence" : "N=1 root continuation",
            episode_id,
            final_node,
            slot.id,
            slot.generated_text.size(),
            transport_it->second->streamed_lines);
        return true;
    }

    bool rerot_handle_finished_frontier(uint64_t episode_id) {
        auto result = rerot->finish_frontier(episode_id);
        ++rerot_metrics.frontiers;
        if (result.topology_barrier) {
            ++rerot_metrics.topology_barriers;
            ++rerot_metrics.refresh_total;
        }
        if (result.hard_aborted) {
            return false;
        }

        auto transport_it = rerot_transport.find(episode_id);
        auto * episode = rerot->episode(episode_id);
        if (transport_it == rerot_transport.end() || !episode) {
            rerot->hard_abort(episode_id, "rerot_state_error: missing episode after frontier");
            return false;
        }

        rerot_metrics.nodes_retired += result.retired.size();
        rerot_metrics.archive_total += result.retired.size();
        if (!episode->is_dag) {
        for (const auto parent_id : result.forked) {
            auto * parent = rerot->node(episode_id, parent_id);
            const auto * parent_doc = episode->document.node(parent_id);
            if (!parent || !parent_doc || parent->physical_slot < 0 ||
                parent->physical_slot >= static_cast<int>(slots.size())) {
                rerot->hard_abort(episode_id, "rerot_state_error: fork parent lost physical slot");
                return false;
            }

            auto & parent_slot = slots[parent->physical_slot];
            for (const auto child_id : parent_doc->children) {
                transport_it->second->lineage_tokens.insert_or_assign(
                    child_id, parent_slot.prompt.tokens.clone());
            }

            ++rerot_metrics.forks_total;
            ++rerot_metrics.archive_total;
            rerot_metrics.parked_total += parent_doc->children.size();
            rerot_metrics.nodes_created += parent_doc->children.size();
            rerot_metrics.nodes_queued += parent_doc->children.size();
            rerot_metrics.queue_max = std::max<uint64_t>(
                rerot_metrics.queue_max, episode->ready_queue.size());
            for (const auto child_id : parent_doc->children) {
                rerot_metrics.max_depth = std::max<uint64_t>(
                    rerot_metrics.max_depth,
                    episode->document.tree_path(child_id).size());
            }

            const int released_slot = parent->physical_slot;
            if (!rerot->freeze_fork_parent(episode_id, parent_id)) {
                return false;
            }

            transport_it->second->segmented_active = true;
            transport_it->second->triattention_compressed |=
                parent_slot.triattention_compressed;
            rerot_make_slot_idle(slots[released_slot]);

            SRV_INF("RERoT fork: episode=%" PRIu64 " parent=%u children=%zu released_slot=%d\n",
                episode_id, parent_id, parent_doc->children.size(), released_slot);
        }
        }

        for (const int released_slot : result.released_slots) {
            if (released_slot >= 0 && released_slot < static_cast<int>(slots.size())) {
                rerot_make_slot_idle(slots[released_slot]);
            }
        }

        if (result.topology_barrier) {
            if (!llama_rerot_refresh_barrier(ctx_tgt, episode_id)) {
                rerot->hard_abort(episode_id, "rerot_state_error: topology barrier failed");
                return false;
            }
            // The next decode observes this completed frontier. Re-decoding a
            // synthetic newline here doubled every public step, polluted the
            // Lane's recurrent/conv state, and still only approximated a
            // same-frontier dependency. Synchronous sibling decoding uses the
            // stable previous frontier, then advances all readers together.
        }

        // §B.8.4: Frontier-boundary pen yield for multi-person fairness when B > P
        if (rerot && rerot_transport.size() > 1) {
            for (const auto & [other_ep_id, other_transport] : rerot_transport) {
                if (other_ep_id == episode_id) continue;
                auto * other_ep = rerot->episode(other_ep_id);
                if (other_ep && !other_ep->hard_aborted && rerot->has_ready_nodes(other_ep_id) &&
                    rerot->pens_for_person(other_ep_id).empty()) {
                    const auto my_pens = rerot->pens_for_person(episode_id);
                    if (my_pens.size() > 1) {
                        const rerot_pen_id yield_pen_id = my_pens.back();
                        if (yield_pen_id >= 0 && (size_t) yield_pen_id < slots.size()) {
                            auto & yield_slot = slots[yield_pen_id];
                            if (yield_slot.is_processing() && !yield_slot.rerot_serial_tail &&
                                yield_slot.rerot_injection == server_rerot_injection_kind::none) {
                                if (rerot->suspend_pen(yield_pen_id)) {
                                    rerot_park_slot_lineage(yield_slot);
                                    rerot_make_slot_idle(yield_slot);
                                    SLT_INF(yield_slot, "RERoT episode %" PRIu64 " yielded pen %d to episode %" PRIu64 "\n",
                                        episode_id, yield_pen_id, other_ep_id);
                                    (void) rerot_admit_ready(other_ep_id);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        if (rerot_admit_ready(episode_id) == rerot_admit_ready_result::failed) {
            return false;
        }

        if (result.natural_final()) {
            // P12: the exit/fence window (workers_finish) spans the last
            // frontier commit to the serial-tail handoff; begin_serial_tail
            // below exits it and enters synthesis.
            rerot_prof_phase_exit(llama_rerot_phase::workers_frontier);
            rerot_prof_phase_enter(llama_rerot_phase::workers_finish);
            if (!rerot_begin_serial_tail(episode_id, result.final_node)) {
                return false;
            }
        }

        return true;
    }

    bool rerot_sample_slot(
            server_slot & slot,
            int tok_idx,
            std::string * trace_buffer) {
        if (!slot.smpl || tok_idx < 0) {
            SRV_ERR("RERoT sample unavailable: episode=%" PRIu64
                    " node=%u sampler=%d tok_idx=%d i_batch=%d\n",
                slot.rerot_episode_id, slot.rerot_node_id,
                slot.smpl ? 1 : 0, tok_idx, slot.i_batch);
            if (rerot && slot.rerot_episode_id != 0) {
                rerot->hard_abort(
                    slot.rerot_episode_id,
                    string_format(
                        "rerot_state_error: invalid sampler/logit row (sampler=%d tok_idx=%d i_batch=%d)",
                        slot.smpl ? 1 : 0, tok_idx, slot.i_batch));
            }
            return false;
        }

        llama_token id;
        {
            scoped_timer timer(t_sampl, n_sampl);
            id = common_sampler_sample(
                slot.smpl.get(), slot.ctx_tgt, tok_idx,
                /* grammar_first = */ false,
                /* synchronize = */ false);
        }
        if (slot.task && slot.task->params.rerot_trace) {
            const std::string line = string_format(
                "sample episode=%" PRIu64 " node=%u serial=%d tok_idx=%d token=%d piece=%s\n",
                slot.rerot_episode_id, slot.rerot_node_id,
                slot.rerot_serial_tail ? 1 : 0, tok_idx, id,
                common_token_to_piece(slot.ctx_tgt, id, true).c_str());
            if (trace_buffer) {
                trace_buffer->append(line);
            } else {
                SRV_INF("rerot.trace.%s", line.c_str());
            }
        }
        common_sampler_accept(slot.smpl.get(), id, true);
        slot.i_batch = -1;
        if (const auto transport_it = rerot_transport.find(slot.rerot_episode_id);
            transport_it != rerot_transport.end()) {
            ++transport_it->second->sampled_tokens;
        }

        const int64_t now = ggml_time_us();
        if (slot.t_start_generation == 0) {
            slot.t_start_generation = now;
        }
        ++slot.n_decoded;
        slot.t_token_generation = std::max<int64_t>(1, now - slot.t_start_generation) / 1e3;

        if (!slot.rerot_serial_tail) {
            if (llama_vocab_is_eog(vocab, id)) {
                const auto * ep = rerot ? rerot->episode(slot.rerot_episode_id) : nullptr;
                const bool undecided_probe = ep && ep->probing && !ep->strategy_decided;
                rerot->hard_abort(
                    slot.rerot_episode_id,
                    undecided_probe
                        ? "rerot_protocol_error: EOG sampled while the routing plan was still undecided"
                        : "rerot_protocol_error: EOG sampled before the current child delimiter closed");
                return false;
            }
            slot.sampled = id;
            return true;
        }

        slot.sampled = id;
        completion_token_output output;
        output.tok = id;
        output.text_to_send = common_token_to_piece(
            slot.ctx_tgt,
            id,
            params_base.special ||
                slot.task->params.sampling.preserved_tokens.find(id) !=
                    slot.task->params.sampling.preserved_tokens.end());
        output.prob = 1.0f;
        if (slot.task->params.sampling.n_probs > 0) {
            populate_token_probs(
                slot, slot.smpl.get(), output, slot.task->params.post_sampling_probs,
                params_base.special, tok_idx);
        }

        if (process_token(output, slot)) {
            slot.print_timings_tg();
            return true;
        }

        const uint64_t episode_id = slot.rerot_episode_id;
        if (const auto transport_it = rerot_transport.find(episode_id);
            transport_it != rerot_transport.end()) {
            slot.n_decoded = static_cast<int32_t>(std::min<uint64_t>(
                transport_it->second->sampled_tokens,
                std::numeric_limits<int32_t>::max()));
        }
        SRV_INF("RERoT serial tail complete: episode=%" PRIu64 " node=%u token=%d stop=%d\n",
            episode_id, slot.rerot_node_id, id, slot.stop);
        // P12: result_send spans the final-response assembly/queueing; the
        // ledger closes when the last episode tears down (rerot_erase_episode
        // below may admit a queued root, which re-enters probe on the same
        // ledger only if profiling stays enabled).
        rerot_prof_phase_exit(llama_rerot_phase::synthesis);
        rerot_prof_phase_enter(llama_rerot_phase::result_send);
        rerot_record_completed_episode(episode_id);
        slot.print_timings();
        send_final_response(slot);
        rerot_prof_phase_exit(llama_rerot_phase::result_send);
        metrics.on_prediction(slot);
        rerot_erase_episode(episode_id);
        slot.prompt.clear();
        slot.release();
        rerot_start_next_waiting_root();
        return true;
    }

    // Frontier scheduling entry (§§19-20): one frontier is one atomic budget
    // unit. Delegates to runtime::begin_frontier; on hard-limit breach the
    // runtime takes whole-episode HARD_ABORT (no survivor/answer/tool call)
    // and this hook propagates it to slots. Returns false when aborted.
    bool rerot_frontier_enter() {
        if (!rerot || rerot_transport.empty()) {
            return true;
        }
        for (const auto & kv : rerot_transport) {
            const uint64_t ep_id = kv.first;
            const auto * episode = rerot->episode(ep_id);
            if (episode && episode->serial_tail) {
                continue;
            }
            // P12: the first logical frontier after admission flips the
            // ledger from workers_start to the steady-state decode window.
            // begin_frontier is per-episode; the transition is idempotent
            // because phase_exit on an un-entered phase is a no-op.
            if (episode && !rerot->begin_frontier(ep_id)) {
                rerot_propagate_hard_abort(ep_id);
                return false;
            }
            rerot_prof_phase_transition(llama_rerot_phase::workers_start, llama_rerot_phase::workers_frontier);
        }
        return true;
    }

    // Topology-barrier refresh trigger (§17): after a frontier commits with a
    // topology change, re-observe stable shared memory via a read-only
    // context refresh (no public token write; recurrent checkpoint/restore
    // handled inside llama_rerot_refresh_barrier when needed).
    void rerot_on_topology_barrier(bool barrier, uint64_t episode_id = 0) {
        if (!rerot || !barrier || ctx_tgt == nullptr) {
            return;
        }
        if (episode_id != 0) {
            if (!llama_rerot_refresh_barrier(ctx_tgt, episode_id)) {
                rerot_propagate_hard_abort(episode_id);
            }
        } else {
            for (const auto & kv : rerot_transport) {
                if (!llama_rerot_refresh_barrier(ctx_tgt, kv.first)) {
                    rerot_propagate_hard_abort(kv.first);
                }
            }
        }
    }

    // Hard-abort propagation (§20): one external error for the episode, then
    // release every internal Lane and every parked/archive reference. Lane
    // clones share the root task id, so emitting once per slot would violate
    // the single-termination response contract.
    void rerot_propagate_hard_abort(uint64_t target_episode_id = 0) {
        if (!rerot) {
            return;
        }
        std::vector<uint64_t> to_abort;
        if (target_episode_id != 0) {
            if (rerot->episode(target_episode_id)) {
                to_abort.push_back(target_episode_id);
            }
        } else {
            for (const auto & kv : rerot_transport) {
                const auto * ep = rerot->episode(kv.first);
                if (ep && ep->hard_aborted) {
                    to_abort.push_back(kv.first);
                }
            }
            if (to_abort.empty() && rerot_episode_id != 0 && rerot->episode(rerot_episode_id)) {
                to_abort.push_back(rerot_episode_id);
            }
        }
        for (uint64_t episode_id : to_abort) {
            ++rerot_metrics.hard_aborts;
            const server_rerot_episode * ep = rerot->episode(episode_id);
            const std::string reason = (ep && !ep->abort_reason.empty())
                ? ep->abort_reason : "rerot_resource_exhausted";
            rerot->hard_abort(episode_id, reason);

            const server_task * response_task = nullptr;
            const auto transport_it = rerot_transport.find(episode_id);
            if (transport_it != rerot_transport.end() && transport_it->second) {
                response_task = &transport_it->second->response_task;
            }

            server_slot * response_slot = nullptr;
            for (auto & slot : slots) {
                if (slot.rerot_internal && slot.rerot_episode_id == episode_id && slot.is_processing()) {
                    if (!response_slot) {
                        response_slot = &slot;
                    }
                }
            }
            if (response_slot) {
                send_error(*response_slot, "RERoT episode hard-aborted: " + reason, ERROR_TYPE_SERVER);
            } else if (response_task) {
                // Fork publication may have already released the last physical
                // Lane before child admission discovers recurrent exhaustion.
                // The transport owns the original response task until episode
                // teardown, so it remains the authoritative HTTP/SSE endpoint.
                send_error(*response_task, "RERoT episode hard-aborted: " + reason, ERROR_TYPE_SERVER);
            }

            for (auto & slot : slots) {
                if (slot.rerot_internal && slot.rerot_episode_id == episode_id && slot.is_processing()) {
                    slot.prompt.clear();
                    slot.release();
                }
            }
            rerot_erase_episode(episode_id);
            rerot_start_next_waiting_root();
        }
    }

    // Episode-aware slot test (§A.11): a physical slot currently borrowed by
    // an episode must never be preempted/demoted/shifted alone.
    bool rerot_owns_slot(int id_slot) const {
        if (!rerot) {
            return false;
        }
        return rerot->episode_for_slot(id_slot) != nullptr;
    }

    // --- P12 phase-ledger wiring (discussion §4.2/§13) ---------------------
    // The ledger is request-scoped: begin at the first adopted root, end when
    // the last episode tears down. Phases are entered/exited at the exact
    // protocol transitions already implemented in this file; every phase
    // boundary below is an existing, single, well-defined call site, so no
    // new state machine is introduced. All calls are no-ops when
    // LLAMA_REROT_PROFILE is unset.
    static void rerot_prof_phase_enter(llama_rerot_phase phase) {
        if (llama_rerot_profile * prof = llama_rerot_profile_active()) {
            prof->phase_enter(phase);
        }
    }

    static void rerot_prof_phase_exit(llama_rerot_phase phase) {
        if (llama_rerot_profile * prof = llama_rerot_profile_active()) {
            prof->phase_exit(phase);
        }
    }

    static void rerot_prof_phase_transition(llama_rerot_phase from, llama_rerot_phase to) {
        if (llama_rerot_profile * prof = llama_rerot_profile_active()) {
            prof->phase_exit(from);
            prof->phase_enter(to);
        }
    }

    wanxiangqi_server_token_dump request_token_dump;

    server_metrics metrics;
    server_rerot_metrics rerot_metrics;

    uint64_t tri_drain_count = 0;
    uint64_t tri_maintenance_count = 0;
    uint64_t tri_floor_exhausted_count = 0;
    uint64_t tri_atomic_fallback_kv_count = 0;
    uint64_t tri_atomic_fallback_recurrent_count = 0;

    uint64_t tri_cells_freed_total = 0;
    uint64_t tri_score_us_total = 0;
    uint64_t tri_pack_us_total = 0;

    uint64_t tri_cells_before = 0;
    uint64_t tri_cells_after = 0;
    uint64_t tri_cells_freed = 0;
    uint64_t tri_references_removed = 0;
    uint64_t tri_target_references = 0;
    uint64_t tri_hard_keep = 0;
    uint64_t tri_shared_keep = 0;
    uint32_t kv_batch_limit = UINT32_MAX;

    json json_ui_settings = json::object();

    // Necessary similarity of prompt for slot selection
    float slot_prompt_similarity = 0.0f;
    float  slot_cache_key_similarity = 0.0f;
    size_t slot_cache_key_min_prefix = 0;

    std::string model_name; // name of the loaded model, to be used by API
    std::set<std::string> model_aliases; // additional names for the model
    std::set<std::string> model_tags;    // informational tags

    bool sleeping = false;

    int64_t t_last_load_progress_ms = 0;

    void destroy() {
        // RERoT: end any active context episode gate before tearing down the
        // context, then drop the runtime (which releases parked/archive
        // lineage). OFF: both branches no-op.
        if (rerot_active() && ctx_tgt != nullptr) {
            for (const auto & kv : rerot_transport) {
                llama_rerot_episode_end(ctx_tgt, kv.first);
            }
            if (rerot_episode_id != 0) {
                llama_rerot_episode_end(ctx_tgt, rerot_episode_id);
            }
        }
        rerot.reset();
        rerot_episode_id = 0;

        // The target and detached draft can share a physical Vulkan device.
        // On a graph-compute error there may be GPU work despite zero queued
        // tokens; drain both contexts before either releases its buffers.
        if (ctx_tgt) llama_synchronize(ctx_tgt);
        if (ctx_dft) llama_synchronize(ctx_dft);

        spec.reset();
        spec_init.reset();

        ctx_dft   = nullptr;
        model_dft = nullptr;

        llama_init.reset();

        ctx_tgt = nullptr;
        model_tgt = nullptr;

        mtmd_free(mctx);
        mctx = nullptr;
    }

    void handle_sleeping_state(bool new_state) {
        GGML_ASSERT(sleeping != new_state);
        if (new_state) {
            SRV_INF("%s", "server is entering sleeping state\n");
            destroy();
        } else {
            SRV_INF("%s", "server is exiting sleeping state\n");
            if (!load_model(params_base)) {
                GGML_ABORT("failed to reload model after sleeping");
            }
        }
        sleeping = new_state;
    }

    struct load_progress_data {
        server_context_impl * ctx;
        std::string stage;
        std::vector<std::string> stages;
        int64_t t_last_load_progress_ms = 0;
        load_progress_data(server_context_impl * ctx, const std::string & stage) : ctx(ctx), stage(stage) {}
    };
    static bool load_progress_callback(float progress, void * user_data) {
        auto * d = static_cast<load_progress_data *>(user_data);
        GGML_ASSERT(d);
        // always emit the first and final sample; throttle the rest to one per 200ms
        {
            auto & t_last = d->t_last_load_progress_ms;
            const int64_t t_now = ggml_time_ms();
            const bool first = t_last == 0;
            const bool done  = progress >= 1.0f;
            const bool throttled = !first && !done && (t_now - t_last) < 200;
            if (throttled) {
                return true;
            }
            t_last = t_now;
        }
        if (d->ctx->callback_state) {
            d->ctx->callback_state(SERVER_STATE_LOADING, {
                {"stages", d->stages},
                {"current", d->stage},
                {"value", progress},
            });
        }
        return true;
    }

    // load the model and initialize llama_context
    // this may also be called to resume from sleeping state
    bool load_model(common_params & params) {
        load_progress_data load_progress_text  (this, "text_model");
        load_progress_data load_progress_mmproj(this, "mmproj_model");
        load_progress_data load_progress_spec  (this, "spec_model");

        const bool is_resume = sleeping;

        // Qualified MTP defaults determine draft horizon and placement; apply
        // them before deriving the target output-row capacity.
        common_tp5_apply_env(params);
        params_base = params;
        params_base.n_ctx_kv_reserve.clear();
        params_base.n_parallel_pp = 1;
        params_base.n_outputs_max = server_n_outputs_max(params_base);
        inference_mode = SERVER_INFERENCE_MODE_DECODE;
        id_slot_prefill = -1;

        if (!request_token_dump.init(params_base, is_resume)) {
            return false;
        }

        const bool has_mmproj = !params.mmproj.path.empty();
        const bool has_draft = params.speculative.has_dft();
        const bool spec_mtp = std::find(params_base.speculative.types.begin(),
                                        params_base.speculative.types.end(),
                                        COMMON_SPECULATIVE_TYPE_DRAFT_MTP) != params_base.speculative.types.end();
        if (params_base.rerot_enabled && spec_mtp) {
            params_base.speculative.draft.cache_type_k =
                params_base.cache_type_k;
            params_base.speculative.draft.cache_type_v =
                params_base.cache_type_v;
        }
        const bool has_spec = has_draft || spec_mtp;

        if (has_draft && (params_base.n_ctx_kv_auto || params_base.n_ctx_kv > 0)) {
            SRV_ERR("%s", "dynamic unified KV sizing is not supported with an external draft model yet\n");
            return false;
        }

        if (callback_state) {
            std::vector<std::string> stages = {"text_model"};
            if (has_spec) {
                stages.push_back("spec_model");
            }
            if (has_mmproj) {
                stages.push_back("mmproj_model");
            }
            load_progress_text.stages   = stages;
            load_progress_mmproj.stages = stages;
            load_progress_spec.stages   = stages;

            // trigger 0% progress
            load_progress_callback(0.0f, &load_progress_text);
        }


        SRV_INF("loading model '%s'\n", params.model.get_name().c_str());
        SRV_TRC("local path '%s'\n", params.model.path.c_str());

        std::string & mmproj_path = params_base.mmproj.path;
        mtmd_context_params mparams = mtmd_context_params_default();
        if (has_mmproj) {
            mparams.use_gpu          = params_base.mmproj_use_gpu;
            mparams.print_timings    = false;
            mparams.n_threads        = params_base.cpuparams.n_threads;
            mparams.flash_attn_type  = params_base.flash_attn_type;
            mparams.warmup           = params_base.warmup;
            mparams.image_min_tokens = params_base.image_min_tokens;
            mparams.image_max_tokens = params_base.image_max_tokens;
            mparams.batch_max_tokens = params_base.mtmd_batch_max_tokens;
            mparams.media_marker     = get_media_marker();
            // progress callback
            mparams.progress_callback           = load_progress_callback;
            mparams.progress_callback_user_data = &load_progress_mmproj;
        }

        // optionally get the memory usage of mmproj
        if (has_mmproj && (params_base.fit_params || params_base.n_ctx_kv_auto)) {
            int64_t t_start = ggml_time_us();
            auto mmproj_mem = mtmd_get_memory_usage(mmproj_path.c_str(), mparams);
            int64_t t_elapsed = ggml_time_us() - t_start;
            if (!mmproj_mem.empty()) {
                size_t total = 0;
                for (auto & [dev, size] : mmproj_mem) {
                    total += size;
                }
                SRV_TRC("[mtmd] estimated worst-case memory usage of mmproj is %.2f MiB (took %.2f ms)\n", total / (1024.0 * 1024.0), t_elapsed / 1000.0);
                GGML_ASSERT(!params_base.fit_params_target.empty());
                for (auto & [dev, size] : mmproj_mem) {
                    for (size_t i = 0; i < ggml_backend_dev_count(); i++) {
                        if (ggml_backend_dev_get(i) == dev) {
                            if (i < params_base.fit_params_target.size()) {
                                SRV_DBG("[mtmd] adding %.2f MiB to fit_params_target for device %s\n", size / (1024.0 * 1024.0), ggml_backend_dev_name(dev));
                                params_base.fit_params_target[i] += size;
                                params_base.n_ctx_kv_reserve.emplace_back(dev, size);
                            }
                            break;
                        }
                    }
                }
            } else {
                SRV_ERR("%s", "[mtmd] failed to get memory usage of mmproj\n");
            }
        }

        // optionally reserve VRAM for the draft / MTP context before fitting the target model
        if (params_base.fit_params) {
            if (has_spec) {
                // MTP draft context lives on the target model, only context+compute are new
                bool measure_model_bytes = has_draft;

                common_params params_dft = common_base_params_to_speculative(params_base);

                auto mparams_dft = common_model_params_to_llama(params_dft);
                auto cparams_dft = common_context_params_to_llama(params_dft);
                if (spec_mtp) {
                    cparams_dft.ctx_type = LLAMA_CONTEXT_TYPE_MTP;
                    if (params_base.n_ctx_kv_auto || params_base.n_ctx_kv > 0) {
                        // Dynamic KV/recurrent planning bootstraps from one physical
                        // recurrent state. The final MTP capacity follows the target
                        // context after unified KV sizing instead of reserving 4 here.
                        cparams_dft.n_seq_recurrent = 1;
                    }
                }
                cparams_dft.n_rs_seq = 0;

                std::vector<ggml_backend_dev_t> devs;
                uint32_t hp_ngl = 0;
                uint32_t hp_nct = 0;
                uint32_t hp_nex = 0;
                try {
                    auto dmd = common_get_device_memory_data(
                        params_dft.model.path.c_str(), &mparams_dft, &cparams_dft,
                        devs, hp_ngl, hp_nct, hp_nex, GGML_LOG_LEVEL_ERROR);

                    GGML_ASSERT(!params_base.fit_params_target.empty());
                    size_t total = 0;

                    std::vector<ggml_backend_dev_t> tgt_devices = params.devices;

                    if (tgt_devices.empty()) {
                        for(size_t i = 0; i < ggml_backend_dev_count(); ++i) {
                           tgt_devices.push_back(ggml_backend_dev_get(i));
                        }
                    }

                    for (size_t j = 0; j < devs.size(); ++j) {
                        const size_t bytes = (measure_model_bytes ? dmd[j].model : 0) + dmd[j].context + dmd[j].compute;
                        total += bytes;
                        for (size_t i = 0; i < tgt_devices.size(); i++) {
                            if (tgt_devices[i] == devs[j]) {
                                SRV_DBG("[spec] adding %.2f MiB to fit_params_target for device %s\n",
                                        bytes / (1024.0 * 1024.0), ggml_backend_dev_name(devs[j]));
                                params_base.fit_params_target[i] += bytes;
                                break;
                            }
                        }
                    }
                    SRV_TRC("[spec] estimated memory usage of %s is %.2f MiB\n",
                            has_draft ? "draft model" : "MTP context",
                            total / (1024.0 * 1024.0));
                } catch (const std::exception & e) {
                    SRV_WRN("[spec] failed to measure %s memory: %s\n",
                            has_draft ? "draft model" : "MTP context", e.what());
                }
            }
        }

        // attach a progress callback
        {
            params_base.load_progress_callback = load_progress_callback;
            params_base.load_progress_callback_user_data = &load_progress_text;
        }

        try {
            llama_init = common_init_from_params(params_base);
        } catch (const std::exception & e) {
            SRV_ERR("failed to initialize target model: %s\n", e.what());
            return false;
        }

        model_tgt = llama_init->model();
        ctx_tgt   = llama_init->context();

        if (model_tgt == nullptr) {
            SRV_ERR("failed to load model, '%s'\n", params_base.model.path.c_str());
            return false;
        }

        if (ctx_tgt == nullptr) {
            SRV_ERR("failed to create_context with model '%s'\n", params_base.model.path.c_str());
            return false;
        }

        // FlashPrefill: adopt the context policy as the single source of truth
        // (ConfigIntegration plumbed params_base.flashprefill through
        // common_context_params_to_llama; the context strict-validated it at
        // creation). fp_enabled gates the sidecar; OFF (default) keeps every
        // path byte-identical to baseline. The live-context fingerprint is the
        // policy identity for RAM-cache and slot-file isolation below (never a
        // bare diagnostic: mismatched stores are rejected, not just counted).
        fp_config = params_base.flashprefill;
        fp_enabled = llama_flashprefill_is_enabled(&fp_config);
        fp_current_fingerprint = llama_flashprefill_policy_fingerprint(ctx_tgt);
        fp_has_policy = (fp_current_fingerprint != 0);
        // Authoritative store identity (StatePolicy core key): stamped from
        // the live context alongside the fingerprint and retired on every
        // effective adapter mutation. OFF keeps key 0 (legacy path, no
        // isolation identity needed).
        fp_current_state_key = llama_flashprefill_state_cache_key(ctx_tgt);
        fp_has_state_key = (fp_current_state_key != 0);
        metrics.fp_policy_fingerprint = fp_current_fingerprint;
        metrics.fp_has_policy = fp_has_policy;
        if (fp_enabled && !fp_has_policy) {
            SRV_ERR("%s", "flashprefill enabled but policy fingerprint unavailable\n");
            return false;
        }
        if (fp_enabled && !fp_has_state_key) {
            SRV_ERR("%s", "flashprefill enabled but state cache key unavailable (no context serial or adapter identity)\n");
            return false;
        }

        vocab = llama_model_get_vocab(model_tgt);

        n_ctx = llama_n_ctx(ctx_tgt);

        add_bos_token = llama_vocab_get_add_bos(vocab);

        if (has_spec) {
            // spec_mtp doesn't use load a model internally, so we report 0.0 and 1.0 manually
            load_progress_callback(0.0f, &load_progress_spec);
            load_progress_spec.t_last_load_progress_ms = 0;  // reset so internal cbs aren't delayed

            {
                common_params params_dft = common_base_params_to_speculative(params_base);

                // progress callback
                params_dft.load_progress_callback           = load_progress_callback;
                params_dft.load_progress_callback_user_data = &load_progress_spec;

                spec_init = common_speculative_init_from_params(params_dft, model_tgt, ctx_tgt);
                model_dft = spec_init->model();
                ctx_dft   = spec_init->context();

                if (has_draft && model_dft == nullptr) {
                    SRV_ERR("failed to load draft model, '%s'\n", params_dft.model.path.c_str());
                    return false;
                }

                if (ctx_dft == nullptr) {
                    SRV_ERR("%s", "failed to create MTP context\n");
                    return false;
                }

                params_base.speculative.draft.ctx_tgt = ctx_tgt;
                params_base.speculative.draft.ctx_dft = ctx_dft;
            }

            load_progress_callback(1.0f, &load_progress_spec);
        }

        if (has_mmproj) {
            if (callback_state) {
                callback_state(SERVER_STATE_LOADING, {{"stage", "mmproj_model"}});
            }

            if (!is_resume) {
                mtmd_helper_log_set(common_log_default_callback, nullptr);
            }

            mctx = mtmd_init_from_file(mmproj_path.c_str(), model_tgt, mparams);
            if (mctx == nullptr) {
                SRV_ERR("failed to load multimodal model, '%s'\n", mmproj_path.c_str());
                return false;
            }
            SRV_INF("loaded multimodal model, '%s'\n", mmproj_path.c_str());

            if (params_base.ctx_shift) {
                params_base.ctx_shift = false;
                SRV_WRN("%s\n", "ctx_shift is not supported by multimodal, it will be disabled");
            }

            if (params_base.n_cache_reuse) {
                params_base.n_cache_reuse = 0;
                SRV_WRN("%s\n", "cache_reuse is not supported by multimodal, it will be disabled");
            }
        }

        if (!llama_memory_can_shift(llama_get_memory(ctx_tgt))) {
            if (params_base.ctx_shift) {
                params_base.ctx_shift = false;
                SRV_WRN("%s\n", "ctx_shift is not supported by this context, it will be disabled");
            }

            if (params_base.n_cache_reuse) {
                params_base.n_cache_reuse = 0;
                SRV_WRN("%s\n", "cache_reuse is not supported by this context, it will be disabled");
            }
        }

        if (llama_model_n_swa(model_tgt) == 0) {
            if (params_base.swa_full) {
                params_base.swa_full = false;
                SRV_WRN("%s\n", "swa_full is not supported by this model, it will be disabled");
            }
        }

        n_swa = params_base.swa_full ? 0 : llama_model_n_swa(model_tgt);

        // Necessary similarity of prompt for slot selection
        slot_prompt_similarity = params_base.slot_prompt_similarity;
        slot_cache_key_similarity = params_base.slot_cache_key_similarity;
        slot_cache_key_min_prefix = std::max<int32_t>(0, params_base.slot_cache_key_min_prefix);

        const int n_ctx_train = llama_model_n_ctx_train(model_tgt);

        int n_ctx_slot = llama_n_ctx_seq(ctx_tgt);
        if (n_ctx_slot > n_ctx_train) {
            SRV_WRN("the slot context (%d) exceeds the training context of the model (%d) - using rope scaling to extend\n", n_ctx_slot, n_ctx_train);
            // Do not cap: caller has configured rope scaling (--rope-scale / --rope-scaling yarn) to handle extended context.
        }

        slots.clear();

        ctx_tgt_seq_rm_type = common_context_can_seq_rm(ctx_tgt);
        if (ctx_tgt_seq_rm_type == COMMON_CONTEXT_SEQ_RM_TYPE_NO) {
            SRV_WRN("%s", "speculative decoding not supported by this context\n");
        }

        if (ctx_tgt_seq_rm_type == COMMON_CONTEXT_SEQ_RM_TYPE_FULL) {
            SRV_TRC("%s", "speculative decoding will use checkpoints\n");
        }

        const uint32_t n_seq_recr = llama_n_seq_recurrent(ctx_tgt);
        if (n_seq_recr > 0 && params_base.n_parallel > (int) n_seq_recr) {
            SRV_INF("capping n_parallel (%d -> %u) to match fitted recurrent state capacity\n",
                    params_base.n_parallel, n_seq_recr);
            params_base.n_parallel = (int) n_seq_recr;
        }

        // Outer request concurrency remains B (n_parallel); RERoT execution
        // entities use the independently fitted global P pen arena.
        const int n_exec_slots = params_base.rerot_enabled
            ? std::max(params_base.n_parallel, (int) params_base.rerot_pen_max)
            : params_base.n_parallel;
        SRV_INF("initializing, n_slots = %d, n_request_slots = %d, n_ctx_slot = %d, kv_unified = '%s'\n",
                n_exec_slots, params_base.n_parallel, n_ctx_slot,
                params_base.kv_unified ? "true" : "false");

        // initialize physical execution slots
        for (int i = 0; i < n_exec_slots; i++) {
            slots.emplace_back();
        }

        // try speculative decoding
        if (ctx_tgt_seq_rm_type != COMMON_CONTEXT_SEQ_RM_TYPE_NO) {
            try {
                spec.reset(common_speculative_init(params_base.speculative, n_exec_slots));
            } catch (const std::exception & e) {
                SRV_ERR("failed to initialize speculative decoding context: %s\n", e.what());
                return false;
            }
        }

        if (has_spec && !spec) {
            SRV_ERR("%s", "requested speculative decoding is unavailable for this context\n");
            destroy();
            return false;
        }

        if (ctx_dft) {
            ctx_dft_seq_rm_type = common_context_can_seq_rm(ctx_dft);
        }

        if (spec) {
            SRV_TRC("%s", "speculative decoding context initialized\n");
        } else {
            spec_init.reset();
            ctx_dft   = nullptr;
            model_dft = nullptr;
        }

        for (int i = 0; i < n_exec_slots; i++) {
            server_slot & slot = slots[i];

            slot.id      = i;
            slot.ctx_tgt = ctx_tgt;
            slot.ctx_dft = ctx_dft;
            slot.mem.init(ctx_tgt, ctx_dft);
            if (token_hack_factory) {
                slot.token_hack = token_hack_factory(ctx_tgt);
            }
            slot.spec    = spec.get();
            slot.n_ctx   = n_ctx_slot;

            slot.mctx                   = mctx;
            slot.prompt.tokens.has_mtmd = mctx != nullptr;

            SLT_TRC(slot, "new slot, n_ctx = %d\n", slot.n_ctx);

            slot.callback_on_release = [this](int id_slot) {
                queue_tasks.pop_deferred_task(id_slot);
            };

            slot.reset();
        }

        // RERoT runtime holder (OFF: stays null, every hook below no-ops).
        // Logical seq arena is LLAMA_MAX_SEQ; physical recurrent capacity
        // stays at n_parallel (see common.cpp wiring). Internal parked/
        // archive ids allocate from [n_parallel, LLAMA_MAX_SEQ).
        if (params_base.rerot_enabled) {
            llama_memory_t mem = ctx_tgt != nullptr ? llama_get_memory(ctx_tgt) : nullptr;
            rerot = std::make_unique<server_rerot_runtime>(
                mem, params_base.rerot_frontier,
                (uint32_t) slots.size(), (uint32_t) LLAMA_MAX_SEQ);
            const uint32_t pen_cap = params_base.rerot_pen_max > 0
                ? params_base.rerot_pen_max
                : (params_base.n_parallel > 0 ? (uint32_t) params_base.n_parallel : (uint32_t) slots.size());
            if (n_seq_recr < pen_cap) {
                SRV_ERR("RERoT pen capacity %u exceeds fitted recurrent rows %u\n", pen_cap, n_seq_recr);
                return false;
            }
            if (llama_n_batch(ctx_tgt) < pen_cap || llama_n_ubatch(ctx_tgt) < pen_cap) {
                SRV_ERR("RERoT pen capacity %u exceeds decode batch dimensions (%u, %u)\n",
                    pen_cap, llama_n_batch(ctx_tgt), llama_n_ubatch(ctx_tgt));
                return false;
            }
            rerot->set_pen_capacity(pen_cap);
            rerot_episode_id = 0;
            SRV_INF("RERoT runtime armed (frontier=%s, pen_capacity=%u)\n",
                llama_rerot_frontier_mode_name(params_base.rerot_frontier), pen_cap);
        } else {
            rerot.reset();
            rerot_episode_id = 0;
        }

        {
            const char * LLAMA_TRACE = getenv("LLAMA_TRACE");
            trace = LLAMA_TRACE ? atoi(LLAMA_TRACE) : 0;

            if (trace) {
                SRV_WRN("LLAMA_TRACE = %d\n", trace);
            }
        }

        {
            const char * LLAMA_SERVER_SLOTS_DEBUG = getenv("LLAMA_SERVER_SLOTS_DEBUG");
            slots_debug = LLAMA_SERVER_SLOTS_DEBUG ? atoi(LLAMA_SERVER_SLOTS_DEBUG) : 0;

            if (slots_debug) {
                SRV_WRN("LLAMA_SERVER_SLOTS_DEBUG = %d\n", slots_debug);
            }
        }

        // Reserve enough rows for every physical execution slot, including
        // RERoT pens beyond the number of independent request slots.
        // n_batch can exceed n_ctx (e.g. for non-causal attention models).
        {
            const int32_t n_batch = llama_n_batch(ctx_tgt);
            const int32_t n_embd  = llama_model_n_embd_inp(model_tgt);
            batch.init(std::max(n_batch, n_exec_slots), n_embd);
        }

        if (params_base.cache_ram_mib != 0) {
            if (params_base.cache_ram_mib < 0) {
                SRV_TRC("prompt cache is enabled, size limit: %s\n", "no limit");
            } else {
                SRV_TRC("prompt cache is enabled, size limit: %d MiB\n", params_base.cache_ram_mib);
            }
            SRV_TRC("%s", "use `--cache-ram 0` to disable the prompt cache\n");

            const size_t cache_token_limit = params_base.kv_unified && params_base.n_ctx_kv > 0 ? 0 : n_ctx;
            prompt_cache = std::make_unique<server_prompt_cache>(params_base.cache_ram_mib, cache_token_limit);
        } else {
            SRV_TRC("%s", "prompt cache is disabled - use `--cache-ram N` to enable it\n");
        }
        SRV_TRC("%s", "for more info see https://github.com/ggml-org/llama.cpp/pull/16391\n");

        if (params_base.n_ctx_checkpoints > 0) {
            SRV_TRC("context checkpoints enabled, max = %d, min spacing = %d\n",
                    params_base.n_ctx_checkpoints, params_base.checkpoint_min_step);
        } else {
            SRV_TRC("%s", "context checkpoints disabled\n");
        }

        if (!params_base.model_alias.empty()) {
            // backward compat: use first alias as model name
            model_name = *params_base.model_alias.begin();
        } else if (!params_base.model.get_name().empty()) {
            model_name = params_base.model.get_name();
        } else {
            // fallback: derive model name from file name
            auto model_path = std::filesystem::path(params_base.model.path);
            model_name = model_path.filename().string();
        }

        model_aliases = params_base.model_alias;
        model_tags    = params_base.model_tags;

        // propagate new defaults back to caller
        params = params_base;

        if (!is_resume) {
            return init();
        }

        if (callback_state) {
            callback_state(SERVER_STATE_READY, {});
        }

        return true;
    }

    // unlike load_model(), this is only called once during initialization
    bool init() {
        GGML_ASSERT(ctx_tgt   != nullptr);
        GGML_ASSERT(model_tgt != nullptr);

        GGML_ASSERT(!sleeping);

        // wiring up server queues
        queue_tasks.on_new_task([this](server_task && task) {
            process_single_task(std::move(task));
        });
        queue_tasks.on_update_slots([this]() {
            update_slots();
        });
        queue_tasks.on_sleeping_state([this](bool sleeping) {
            handle_sleeping_state(sleeping);
        });

        metrics.init();

        if (params_base.cache_idle_slots) {
            if (params_base.cache_ram_mib == 0) {
                SRV_WRN("%s", "--cache-idle-slots requires --cache-ram, disabling\n");
                params_base.cache_idle_slots = false;
            } else {
                if (params_base.kv_unified && params_base.n_ctx_kv > 0) {
                    SRV_TRC("%s", "idle slots will remain in unified KV and move to prompt cache on memory pressure\n");
                } else if (params_base.kv_unified) {
                    SRV_TRC("%s", "idle slots will be saved to prompt cache and cleared upon starting a new task\n");
                } else {
                    // without a unified KV cache, clearing a slot frees no reusable room, so we only
                    // publish a RAM-cache copy of idle slots (their KV stays in VRAM) [TAG_IDLE_SLOT_CLEAR]
                    SRV_TRC("%s", "idle slots will be saved to prompt cache upon starting a new task\n");
                }
                SRV_DBG("%s", "__TEST_TAG_CACHE_IDLE_SLOTS_ENABLED__\n");
            }
        }

        {
            const std::string & cfg = params_base.ui_config_json;
            if (!cfg.empty()) {
                try {
                    json json_settings = json::parse(cfg);
                    json_ui_settings = json_settings;
                } catch (const std::exception & e) {
                    SRV_ERR("%s: failed to parse UI config: %s\n", __func__, e.what());
                    return false;
                }
            }
        }

        // populate chat template params
        {
            common_chat_templates_ptr chat_templates;
            bool enable_thinking = false;

            try {
                chat_templates = common_chat_templates_init(model_tgt, params_base.chat_template);

                SRV_TRC("%s: chat template, example_format: '%s'\n", __func__,
                    common_chat_format_example(chat_templates.get(), params_base.use_jinja, params_base.default_template_kwargs).c_str());

                // thinking is enabled if:
                // 1. It's not explicitly disabled via --reasoning off
                // 2. The chat template supports it
                const bool template_supports_thinking = params_base.use_jinja && common_chat_templates_support_enable_thinking(chat_templates.get());
                enable_thinking = params_base.enable_reasoning != 0 && template_supports_thinking;
                SRV_TRC("%s: chat template, thinking = %d\n", __func__, enable_thinking);
            } catch (const std::exception & e) {
                SRV_ERR("%s: chat template parsing error: %s\n", __func__, e.what());
                SRV_ERR("%s: please consider disabling jinja via --no-jinja, or use a custom chat template via --chat-template\n", __func__);
                SRV_ERR("%s: for example: --no-jinja --chat-template chatml\n", __func__);
                return false;
            }

            // IMPORTANT: chat_params is reused across sleeping / resuming states,
            //            never store llama_context/llama_model pointers in chat_params,
            //            as they may be invalidated after sleeping
            chat_params = {
                /* use_jinja             */ params_base.use_jinja,
                /* prefill_assistant     */ params_base.prefill_assistant,
                /* reasoning_format      */ params_base.reasoning_format,
                /* chat_template_kwargs  */ params_base.default_template_kwargs,
                /* tmpls                 */ std::move(chat_templates),
                /* allow_image           */ mctx ? mtmd_support_vision(mctx) : false,
                /* allow_audio           */ mctx ? mtmd_support_audio (mctx) : false,
                /* allow_video           */ mctx ? mtmd_helper_support_video(mctx) : false,
                /* enable_thinking       */ enable_thinking,
                /* reasoning_budget      */ params_base.sampling.reasoning_budget_tokens,
                /* n_predict             */ params_base.n_predict,
                /* reasoning_budget_msg  */ params_base.sampling.reasoning_budget_message,
                /* media_path            */ params_base.media_path,
                /* force_pure_content    */ params_base.force_pure_content_parser
            };

            {
                auto caps = common_chat_templates_get_caps(chat_params.tmpls.get());
                auto it = params_base.default_template_kwargs.find("preserve_reasoning");
                bool supported = caps.at("supports_preserve_reasoning");
                bool enabled = it != params_base.default_template_kwargs.end();
                if (supported && !enabled) {
                    SRV_INF("%s", "chat template supports preserving reasoning, consider enabling it via --reasoning-preserve\n");
                }
                if (!supported && enabled) {
                    SRV_WRN("%s", "chat template does NOT support preserving reasoning, --reasoning-preserve has no effect\n");
                }
            }
        }

        // Execute decode and every legal MTP verification prefix before accepting
        // requests. Two executions exercise cold recording and its warm path;
        // success is not permission to bypass binding/coverage qualification.
        if (ctx_tgt && params_base.tp5.enabled && params_base.warmup) {
            const int   max_rows   = spec ? std::max(1, params_base.speculative.draft.n_max + 1) : 1;
            llama_token warm_token = llama_vocab_bos(vocab);
            if (warm_token == LLAMA_TOKEN_NULL) {
                warm_token = llama_vocab_eos(vocab);
            }
            if (warm_token == LLAMA_TOKEN_NULL) {
                warm_token = 0;
            }
            for (int rows = 1; rows <= max_rows; ++rows) {
                SRV_INF("%s: Prewarming TP5 decode/verify graph (%d tokens)...\n", __func__, rows);
                llama_batch batch = llama_batch_init(rows, 0, 1);
                batch.n_tokens    = rows;
                for (int k = 0; k < rows; ++k) {
                    batch.token[k]     = warm_token;
                    batch.pos[k]       = k;
                    batch.n_seq_id[k]  = 1;
                    batch.seq_id[k][0] = 0;
                    batch.logits[k]    = 1;
                }
                for (int iter = 0; iter < 2; ++iter) {
                    const int rc = llama_decode(ctx_tgt, batch);
                    llama_synchronize(ctx_tgt);
                    if (auto * mem = llama_get_memory(ctx_tgt)) {
                        llama_memory_clear(mem, true);
                    }
                    llama_synchronize(ctx_tgt);
                    if (rc != 0) {
                        llama_batch_free(batch);
                        SRV_ERR("%s: TP5 prewarm failed: rows=%d iteration=%d rc=%d; aborting model load\n", __func__,
                                rows, iter, rc);
                        return false;
                    }
                }
                llama_batch_free(batch);
            }
            llama_init->reset_samplers();
            llama_perf_context_reset(ctx_tgt);
            SRV_INF("%s: TP5 decode/verify warmup completed.\n", __func__);
        }

        return true;
    }

    server_slot * get_slot_by_id(int id_slot) {
        // note: allow id_slot to be out of bounds (wrap around)
        id_slot = id_slot % slots.size();

        for (server_slot & slot : slots) {
            if (slot.id == id_slot) {
                return &slot;
            }
        }

        return nullptr;
    }

    server_slot * get_slot_by_cache_key(const std::string & cache_key) {
        if (cache_key.empty()) {
            return nullptr;
        }

        auto it = cache_key_slots.find(cache_key);
        if (it == cache_key_slots.end()) {
            return nullptr;
        }

        server_slot * slot = get_slot_by_id(it->second);
        if (slot == nullptr) {
            cache_key_slots.erase(it);
            return nullptr;
        }

        if (slot->prompt.tokens.empty()) {
            SLT_INF(*slot, "ignoring cache_key slot with empty prompt, key = %s\n", cache_key.c_str());
            cache_key_slots.erase(it);
            return nullptr;
        }

        if (slot->is_processing()) {
            SLT_INF(*slot, "ignoring busy cache_key slot, key = %s\n", cache_key.c_str());
            return nullptr;
        }

        return slot;
    }

    bool cache_key_slot_has_enough_similarity(const server_slot & slot, const server_task & task) const {
        if (slot.prompt.tokens.empty() || task.tokens.empty()) {
            SLT_INF(slot, "ignoring cache_key slot with empty prompt or task, key = %s\n", task.cache_key.c_str());
            return false;
        }

        const size_t n_common = slot.prompt.tokens.get_common_prefix(task.tokens);
        const float  sim_cur  = float(n_common) / task.tokens.size();
        const bool enough_prefix = n_common >= slot_cache_key_min_prefix;
        const bool enough_similarity = slot_cache_key_similarity <= 0.0f || sim_cur >= slot_cache_key_similarity;
        if (enough_prefix && enough_similarity) {
            SLT_INF(slot, "selected slot by cache_key, sim = %.3f (>= %.3f thold), common = %zu (>= %zu), key = %s\n",
                    sim_cur, slot_cache_key_similarity, n_common, slot_cache_key_min_prefix, task.cache_key.c_str());
            return true;
        }

        SLT_INF(slot, "ignoring cache_key slot, sim = %.3f (< %.3f thold) or common = %zu (< %zu), key = %s\n",
                sim_cur, slot_cache_key_similarity, n_common, slot_cache_key_min_prefix, task.cache_key.c_str());
        return false;
    }

    void clear_cache_keys_for_slot(int id_slot) {
        for (auto it = cache_key_slots.begin(); it != cache_key_slots.end(); ) {
            if (it->second == id_slot) {
                it = cache_key_slots.erase(it);
            } else {
                ++it;
            }
        }
    }

    void bind_cache_key_to_slot(const std::string & cache_key, int id_slot) {
        clear_cache_keys_for_slot(id_slot);

        if (!cache_key.empty()) {
            cache_key_slots[cache_key] = id_slot;
        }
    }

    server_slot * get_slot_by_cmpl_id(const std::string & cmpl_id) {
        if (cmpl_id.empty()) {
            return nullptr;
        }

        for (server_slot & slot : slots) {
            if (slot.is_processing() && slot.task && slot.task->params.oaicompat_cmpl_id == cmpl_id) {
                return &slot;
            }
        }

        return nullptr;
    }

    bool external_slot_eligible(const server_task & task, const server_slot & slot) const {
        if (!params_base.rerot_enabled || task.is_child()) {
            return true;
        }
        // Root requests occupy the first B slots so provisional brain_row_for_seq
        // (seq_id < n_brain_rows) holds through C0 prefill. Prefer explicit B.
        const int request_cap = params_base.rerot_person_max > 0
            ? (int) params_base.rerot_person_max
            : params_base.n_parallel;
        return slot.id < request_cap;
    }

    bool rerot_person_admission_available(const server_task & task) const {
        if (!task.params.rerot_effective(task.type) || task.rerot_episode_id == 0) {
            return true;
        }

        std::set<uint64_t> people;
        for (const auto & [episode_id, _] : rerot_transport) {
            people.insert(episode_id);
        }
        for (const auto & slot : slots) {
            if (slot.task && slot.task->params.rerot_effective(slot.task->type) &&
                slot.task->rerot_episode_id != 0) {
                people.insert(slot.task->rerot_episode_id);
            }
        }

        return people.count(task.rerot_episode_id) != 0 ||
            people.size() < std::max<size_t>(1, params_base.rerot_person_max);
    }

    server_slot * get_available_slot(const server_task & task, bool allow_prompt_similarity = true) {
        server_slot * ret = nullptr;

        bool update_cache = false;

        // if a specific slot is requested, use it (still goes through cache update logic below)
        if (task.id_slot != -1) {
            ret = get_slot_by_id(task.id_slot);
            if (ret && !external_slot_eligible(task, *ret)) {
                ret = nullptr;
            }
            if (ret) {
                SLT_INF(*ret, "selected slot by id (%d)\n", task.id_slot);
            }
        }

        // find the slot that has at least n% prompt similarity
        if (allow_prompt_similarity && ret == nullptr && slot_prompt_similarity != 0.0f) {
            float f_sim_best = 0;

            for (server_slot & slot : slots) {
                if (task.id_slot != -1 && slot.id != task.id_slot) {
                    continue;
                }
                if (!external_slot_eligible(task, slot)) {
                    continue;
                }

                // skip the slot if it is not available
                if (slot.is_processing()) {
                    SLT_TRC(slot, " - skipping, is_processing = %d\n", slot.is_processing());
                    continue;
                }

                const auto & tokens = slot.prompt.tokens;

                // skip the slot if it does not contains cached tokens
                if (tokens.empty()) {
                    SLT_TRC(slot, "%s", " - skipping, slot is empty\n");
                    continue;
                }

                // fraction of the Longest Common Prefix length with respect to the input prompt length
                const size_t lcp_len = tokens.get_common_prefix(task.tokens);
                const float f_sim_cur = float(lcp_len) / task.tokens.size();

                SLT_TRC(slot, " - checking sim = %.3f (%zu/%zu) > %.3f\n", f_sim_cur, lcp_len, task.tokens.size(), slot_prompt_similarity);

                // select the current slot if the criteria match
                if (f_sim_cur > f_sim_best && f_sim_cur > slot_prompt_similarity) {
                    f_sim_best = f_sim_cur;

                    ret = &slot;
                }
            }

            if (ret != nullptr) {
                const float f_keep = (f_sim_best*task.tokens.size()) / ret->prompt.tokens.size();

                if (task.id_slot == -1) {
                    SLT_INF(*ret, "selected slot by LCP similarity, f_sim_best = %.3f (> %.3f thold), f_keep = %.3f\n",
                            f_sim_best, slot_prompt_similarity, f_keep);
                }

                // if we are about to lose a large portion of the existing context - save it in the prompt cache
                if (f_keep < 0.5f) {
                    update_cache = true;
                }
            }
        }

        // find the slot that has been least recently used
        if (ret == nullptr) {
            int64_t t_last = -1;

            for (server_slot & slot : slots) {
                if (!external_slot_eligible(task, slot)) {
                    continue;
                }
                // skip the slot if it is not available
                if (slot.is_processing()) {
                    continue;
                }

                // select the current slot if the criteria match
                if (!ret || slot.t_last_used <= t_last) {
                    t_last = slot.t_last_used;
                    ret = &slot;
                }
            }

            if (ret != nullptr) {
                SLT_INF(*ret, "selected slot by LRU, t_last = %" PRId64 "\n", t_last);

                update_cache = true;
            }
        }

        if (ret) {
            update_cache = update_cache || task.is_retry;
            update_cache = update_cache && prompt_cache;

            // cache prompts only for completion tasks
            update_cache = update_cache && task.type == SERVER_TASK_TYPE_COMPLETION;

            if (update_cache) {
                SRV_TRC("%s", "updating prompt cache\n");

                const int64_t t_start = ggml_time_us();

                ret->prompt_save(*prompt_cache);

                if (!ret->prompt_load(*prompt_cache, task.tokens)) {
                    ret->prompt_clear();
                }

                prompt_cache->update();

                SRV_TRC("prompt cache update took %.2f ms\n", (ggml_time_us() - t_start) / 1000.0);
            }
        }

        return ret;
    }

    bool try_clear_idle_slots() {
        if (!params_base.kv_unified) {
            return false;
        }

        server_slot * victim = nullptr;
        for (auto & slot : slots) {
            if (slot.is_processing() || slot.prompt.n_tokens() == 0) {
                continue;
            }
            // RERoT episode-aware idle demotion (§A.11.2): the episode is the
            // minimum reliable unit. Never demote a single Lane slot alone;
            // idle slots never belong to an active episode (lanes are
            // processing, queued children hold no physical slot), so this
            // only skips on a race. OFF: rerot_owns_slot false.
            if (rerot_owns_slot(slot.id)) {
                continue;
            }
            if (victim == nullptr || slot.t_last_used < victim->t_last_used) {
                victim = &slot;
            }
        }

        if (victim == nullptr) {
            return false;
        }

        SLT_DBG(*victim, "demoting idle KV, n_tokens = %zu\n", victim->prompt.tokens.size());
        if (prompt_cache && params_base.cache_idle_slots) {
            victim->prompt_save(*prompt_cache);
            prompt_cache->update();
        }
        victim->prompt_clear();
        clear_cache_keys_for_slot(victim->id);
        return true;
    }

    server_slot * find_preemption_victim(int32_t id_slot_protected, bool recurrent_pressure) {
        server_slot * victim = nullptr;
        uint64_t victim_kv_used = 0;
        size_t n_preemptible = 0;
        llama_memory_t mem_tgt = llama_get_memory(ctx_tgt);
        llama_memory_t mem_dft = ctx_dft ? llama_get_memory(ctx_dft) : nullptr;

        for (auto & slot : slots) {
            if (slot.id == id_slot_protected || slot.state != SLOT_STATE_GENERATING || !slot.task) {
                continue;
            }
            // RERoT episode-aware active preemption (§A.11.1/A.27): never
            // leave an orphan Lane. A borrowed Lane slot is not independently
            // preemptible; the whole episode is the resource unit (freeze /
            // cancel all writers, release all exec/parked/pending handles
            // together via rerot_propagate_hard_abort or a whole-episode
            // retry). Skipping here forces the pressure planner to treat the
            // episode as one atomic victim. OFF: false.
            if (rerot_owns_slot(slot.id)) {
                continue;
            }
            ++n_preemptible;

            const bool has_recurrent_tgt = llama_memory_seq_get_recurrent_used(mem_tgt, slot.id) != 0;
            const bool has_recurrent_dft = mem_dft && mem_dft != mem_tgt &&
                llama_memory_seq_get_recurrent_used(mem_dft, slot.id) != 0;
            if (recurrent_pressure && !has_recurrent_tgt && !has_recurrent_dft) {
                continue;
            }

            uint64_t kv_used = llama_memory_seq_get_kv_used(mem_tgt, slot.id);
            if (mem_dft && mem_dft != mem_tgt) {
                kv_used += llama_memory_seq_get_kv_used(mem_dft, slot.id);
            }
            if (victim == nullptr || kv_used > victim_kv_used) {
                victim = &slot;
                victim_kv_used = kv_used;
            }
        }

        if (id_slot_protected < 0 && n_preemptible <= 1) {
            return nullptr;
        }

        return victim;
    }

    server_task make_retry_task(const server_slot & slot) const {
        GGML_ASSERT(slot.task);
        GGML_ASSERT(slot.state == SLOT_STATE_GENERATING);

        server_task retry(slot.task->type);
        retry.id        = slot.task->id;
        retry.index     = slot.task->index;
        retry.id_target = slot.task->id_target;
        retry.id_slot   = -1;
        retry.cache_key = slot.task->cache_key;
        retry.id_parent = -1;
        retry.params    = slot.task->params;
        if (retry.params.n_keep < 0) {
            retry.params.n_keep = slot.n_prompt_tokens_original;
        }
        retry.tokens    = slot.prompt.tokens.clone();
        retry.is_retry  = true;

        if (!slot.token_append_chunk.empty()) {
            GGML_ASSERT(slot.token_append_anchor != LLAMA_TOKEN_NULL);
            retry.tokens.push_back(slot.token_append_anchor);
            retry.tokens.insert(slot.token_append_chunk);
        } else if (slot.sampled != LLAMA_TOKEN_NULL) {
            retry.tokens.push_back(slot.sampled);
        }

        return retry;
    }

    bool preempt_slot(server_slot & slot) {
        if (!slot.task || slot.state != SLOT_STATE_GENERATING) {
            return false;
        }

        // RERoT: refuse single-Lane preemption (§A.11.1). Whole-episode
        // handling lives in rerot_propagate_hard_abort / future whole-episode
        // retry; preempting one Lane would orphan siblings and leak
        // parked/archive lineage. OFF: false.
        if (rerot_owns_slot(slot.id)) {
            SLT_WRN(slot, "%s", "refusing single-Lane preemption while a RERoT episode is active "
                "(whole-episode unit; use rerot_propagate_hard_abort)\n");
            return false;
        }

        const int id_task = slot.task->id;
        server_task retry = make_retry_task(slot);

        if (prompt_cache) {
            slot.prompt_save(*prompt_cache);
            prompt_cache->update();
        }

        server_retry_state state;
        state.n_decoded                      = slot.n_decoded;
        state.n_prompt_tokens_original       = slot.n_prompt_tokens_original;
        state.n_prompt_tokens_cache_response = slot.n_prompt_tokens_cache_response;
        state.n_prompt_tokens_processed      = slot.n_prompt_tokens_processed_total();
        state.response_prompt                = slot.response_prompt.empty() ? slot.task->tokens.clone() : std::move(slot.response_prompt);
        state.last_nl_pos              = slot.last_nl_pos;
        state.generated_text           = std::move(slot.generated_text);
        state.generated_tokens         = std::move(slot.generated_tokens);
        state.generated_token_probs    = std::move(slot.generated_token_probs);
        state.n_sent_text              = slot.n_sent_text;
        state.has_new_line             = slot.has_new_line;
        state.truncated                = slot.truncated;
        state.t_start_generation       = slot.t_start_generation;
        state.t_prompt_processing      = slot.t_prompt_processing;
        retry_states[id_task]          = std::move(state);

        SLT_WRN(slot, "preempting task %d, committed_kv = %d, retry_tokens = %d, n_decoded = %d\n",
                id_task, slot.prompt.n_tokens(), retry.n_tokens(), slot.n_decoded);

        slot.prompt_clear();
        clear_cache_keys_for_slot(slot.id);
        queue_tasks.defer(std::move(retry));
        slot.release(false);
        return true;
    }

    uint32_t estimate_next_kv_cells(int32_t & id_slot_protected) {
        id_slot_protected = -1;

        if (inference_mode == SERVER_INFERENCE_MODE_DECODE) {
            uint64_t required = 0;
            server_slot * slot_batched = nullptr;
            const int n_draft_cfg = common_speculative_n_max(&params_base.speculative);

            for (auto & slot : slots) {
                if (slot.state != SLOT_STATE_GENERATING) {
                    continue;
                }
                if (slot_batched == nullptr) {
                    slot_batched = &slot;
                } else if (!slot_batched->can_batch_with(slot)) {
                    continue;
                }

                uint32_t n = 1;
                if (slot.rerot_internal &&
                    (server_rerot_private_microbatch(slot.rerot_injection) ||
                     server_rerot_public_microbatch(slot.rerot_injection)) &&
                    slot.rerot_injection_cursor < slot.rerot_injection_tokens.size()) {
                    n = static_cast<uint32_t>(rerot_private_batch_size(slot));
                } else if (!slot.token_append_chunk.empty()) {
                    n += slot.token_append_chunk.size();
                } else if (slot.can_speculate() && n_draft_cfg > 0) {
                    n += std::min(n_draft_cfg, std::max(0, slot.get_n_draft_max()));
                }
                required += n;
            }

            return (uint32_t) std::min<uint64_t>(required, UINT32_MAX);
        }

        server_slot * slot = id_slot_prefill >= 0 ? get_slot_by_id(id_slot_prefill) : nullptr;
        if (slot == nullptr || !slot->task || !slot->is_processing()) {
            return 0;
        }

        id_slot_protected = slot->id;

        size_t n_past = slot->prompt.n_tokens();
        if (slot->state == SLOT_STATE_STARTED) {
            n_past = (slot->task->params.cache_prompt || slot->task->is_retry) ? slot->prompt.tokens.get_common_prefix(slot->task->tokens) : 0;
        }

        const size_t n_task_tokens = slot->task->n_tokens();
        const size_t n_remaining = n_task_tokens > n_past ? n_task_tokens - n_past : 0;
        return (uint32_t) std::min<size_t>(n_remaining, llama_n_batch(ctx_tgt));
    }

    uint32_t estimate_next_recurrent_cells(llama_memory_t mem, bool draft_only) {
        if (inference_mode == SERVER_INFERENCE_MODE_DECODE) {
            uint32_t required = 0;
            server_slot * slot_batched = nullptr;
            for (auto & slot : slots) {
                if (slot.state != SLOT_STATE_GENERATING || (draft_only && !slot.can_speculate())) {
                    continue;
                }
                if (slot_batched == nullptr) {
                    slot_batched = &slot;
                } else if (!slot_batched->can_batch_with(slot)) {
                    continue;
                }
                required += llama_memory_seq_get_recurrent_used(mem, slot.id) == 0 ? 1 : 0;
            }
            return required;
        }

        if (draft_only) {
            return 0;
        }

        server_slot * slot = id_slot_prefill >= 0 ? get_slot_by_id(id_slot_prefill) : nullptr;
        if (slot == nullptr || !slot->task || !slot->is_processing()) {
            return 0;
        }
        return llama_memory_seq_get_recurrent_used(mem, slot->id) == 0 ? 1 : 0;
    }

    bool ensure_next_kv_capacity() {
        kv_batch_limit = UINT32_MAX;

        // XKV maintenance runs inside the loop below, after admission and
        // required cells are known (fill-first): sealing a full segment while
        // hot slots remain would violate Tri fill-first. OFF: zero change.
        llama_memory_maintenance_status xkv_maintain_status = LLAMA_MEMORY_MAINTENANCE_NO_ACTION;
        int xkv_maintain_attempts = 0;
        bool xkv_tri_allowed = true;
        // Checked progress: hot_free before the last maintain, to detect
        // unchanged (no-progress) maintenance and fall through to Tri.
        uint32_t xkv_last_hot_free = 0;
        bool xkv_have_last_hot = false;

        if (!params_base.kv_unified || params_base.n_ctx_kv == 0) {
            return true;
        }

        // One pressure-planning call can iterate several times while idle
        // slots are cleared or victims are preempted. Count each fallback
        // reason once per planner invocation rather than once per loop pass.
        bool counted_kv_fallback = false;
        bool counted_recurrent_fallback = false;

        // Combined XKV admission across the resident attention memories.
        // The batch must fit every memory it runs on (target + split draft
        // context): the combined token/hot bound is the tighter side, the
        // new-sequence gate is the OR. Querying only the target over-admits
        // whenever the draft memory is the tighter one. Recurrent-only
        // memories bypass (attention domain only).
        struct xkv_admission_pair {
            llama_memory_admission_snapshot tgt = {};
            llama_memory_admission_snapshot dft = {};
            llama_memory_admission_snapshot combined = {};
            bool have_tgt = false;
            bool have_dft = false;
            bool have_combined = false;
        };
        auto query_xkv_admission = [&](llama_memory_t mem_t, llama_memory_t mem_d,
                bool has_t, bool has_d) {
            xkv_admission_pair out;
            if (!llama_xkv_is_enabled(params_base.xkv_mode) || (!has_t && !has_d)) {
                return out;
            }
            out.have_tgt = has_t && mem_t &&
                llama_memory_get_admission_snapshot(mem_t, &out.tgt);
            out.have_dft = has_d && mem_d && mem_d != mem_t &&
                llama_memory_get_admission_snapshot(mem_d, &out.dft);
            if (out.have_tgt && out.have_dft) {
                out.combined = out.tgt.safe_next_ubatch <= out.dft.safe_next_ubatch
                    ? out.tgt : out.dft;
                out.combined.hot_free =
                    std::min(out.tgt.hot_free, out.dft.hot_free);
                out.combined.recurrent_blocks_new_seq =
                    out.tgt.recurrent_blocks_new_seq || out.dft.recurrent_blocks_new_seq;
                out.have_combined = true;
            } else if (out.have_tgt) {
                out.combined = out.tgt;
                out.have_combined = true;
            } else if (out.have_dft) {
                out.combined = out.dft;
                out.have_combined = true;
            }
            return out;
        };

        while (true) {
            llama_memory_kv_usage usage_tgt = {};
            llama_memory_kv_usage usage_dft = {};
            llama_memory_kv_usage usage_recurrent_tgt = {};
            llama_memory_kv_usage usage_recurrent_dft = {};
            llama_memory_t mem_tgt = llama_get_memory(ctx_tgt);
            llama_memory_t mem_dft = ctx_dft ? llama_get_memory(ctx_dft) : nullptr;
            const bool has_tgt_usage = llama_memory_get_kv_usage(mem_tgt, &usage_tgt);
            const bool has_dft_usage = mem_dft && mem_dft != mem_tgt && llama_memory_get_kv_usage(mem_dft, &usage_dft);
            const bool has_recurrent_tgt = llama_memory_get_recurrent_usage(mem_tgt, &usage_recurrent_tgt);
            const bool has_recurrent_dft = mem_dft && mem_dft != mem_tgt &&
                llama_memory_get_recurrent_usage(mem_dft, &usage_recurrent_dft);
            if (!has_tgt_usage && !has_dft_usage && !has_recurrent_tgt && !has_recurrent_dft) {
                return true;
            }

            int32_t id_slot_protected = -1;
            const uint32_t required_kv = estimate_next_kv_cells(id_slot_protected);
            const uint32_t required_recurrent_tgt = has_recurrent_tgt ? estimate_next_recurrent_cells(mem_tgt, false) : 0;
            const uint32_t required_recurrent_dft = has_recurrent_dft ? estimate_next_recurrent_cells(mem_dft, true) : 0;
            const uint64_t available_tgt = has_tgt_usage ? usage_tgt.capacity - std::min(usage_tgt.capacity, usage_tgt.used) : UINT64_MAX;
            const uint64_t available_dft = has_dft_usage ? usage_dft.capacity - std::min(usage_dft.capacity, usage_dft.used) : UINT64_MAX;
            const uint64_t available_recurrent_tgt = has_recurrent_tgt ? usage_recurrent_tgt.capacity - std::min(usage_recurrent_tgt.capacity, usage_recurrent_tgt.used) : UINT64_MAX;
            const uint64_t available_recurrent_dft = has_recurrent_dft ? usage_recurrent_dft.capacity - std::min(usage_recurrent_dft.capacity, usage_recurrent_dft.used) : UINT64_MAX;

            bool kv_pressure = required_kv > available_tgt || required_kv > available_dft;
            bool recurrent_pressure = required_recurrent_tgt > available_recurrent_tgt ||
                                        required_recurrent_dft > available_recurrent_dft;

            // Combined target + draft admission: the batch must fit each
            // resident attention memory. Recurrent sequence slots never enter
            // the token minimum; each memory gates only its own new-sequence
            // demand, while continuation batches on full recurrent slots stay
            // valid.
            xkv_admission_pair xkv_adm =
                query_xkv_admission(mem_tgt, mem_dft, has_tgt_usage, has_dft_usage);
            llama_memory_admission_snapshot xkv_snap = xkv_adm.combined;
            bool have_xkv_snap = xkv_adm.have_combined;
            if ((xkv_adm.have_tgt && required_recurrent_tgt > 0 &&
                    xkv_adm.tgt.recurrent_blocks_new_seq) ||
                (xkv_adm.have_dft && required_recurrent_dft > 0 &&
                    xkv_adm.dft.recurrent_blocks_new_seq)) {
                recurrent_pressure = true;
            }
            // Fill-first XKV maintenance: sealing runs only when hot slots
            // cannot cover the upcoming batch (SHADOW evaluate-only always
            // runs). After maintenance the snapshot is re-queried fresh;
            // PROGRESS re-plans and maintains again only if still
            // insufficient; RETRY_STALE bounded-retries with a fresh snapshot
            // instead of skipping into a zero-bound error.
            if (llama_xkv_is_enabled(params_base.xkv_mode)) {
                const bool is_shadow = params_base.xkv_mode == LLAMA_XKV_MODE_SHADOW;
                // Deficit-derived bound (no fixed constant): seals ~one
                // segment per run, so allow ceil(deficit/seg) + domains.
                const uint64_t xkv_max = server_task_result_metrics::xkv_maintain_max_attempts(
                    true, have_xkv_snap,
                    have_xkv_snap ? xkv_snap.hot_free : 0, have_xkv_snap ? xkv_snap.hot_capacity : 0,
                    required_kv, params_base.xkv_segment_tokens);
                // Unchanged maintenance (PROGRESS with identical hot_free and
                // still insufficient) is not progress: stop and fall through.
                const bool xkv_unchanged =
                    xkv_have_last_hot && have_xkv_snap && xkv_snap.hot_free == xkv_last_hot_free &&
                    xkv_snap.hot_free < required_kv;
                if (!xkv_unchanged &&
                    (server_task_result_metrics::xkv_should_maintain(true, is_shadow, have_xkv_snap,
                         have_xkv_snap ? xkv_snap.hot_free : 0, required_kv,
                         (uint64_t) xkv_maintain_attempts, xkv_max) ||
                     (xkv_maintain_status == LLAMA_MEMORY_MAINTENANCE_RETRY_STALE &&
                      (uint64_t) xkv_maintain_attempts < xkv_max))) {
                    xkv_maintain_attempts++;
                    if (have_xkv_snap) {
                        xkv_last_hot_free = xkv_snap.hot_free;
                        xkv_have_last_hot = true;
                    }
                    auto run_maintain = [](llama_memory_t m) {
                        return m ? llama_memory_maintain_safe_boundary(m)
                                 : LLAMA_MEMORY_MAINTENANCE_NO_ACTION;
                    };
                    auto st = run_maintain(has_tgt_usage ? mem_tgt : nullptr);
                    if (mem_dft && mem_dft != mem_tgt) {
                        const auto st_dft = run_maintain(has_dft_usage ? mem_dft : nullptr);
                        if (st_dft == LLAMA_MEMORY_MAINTENANCE_ERROR ||
                            st == LLAMA_MEMORY_MAINTENANCE_ERROR) {
                            st = LLAMA_MEMORY_MAINTENANCE_ERROR;
                        } else if (st_dft == LLAMA_MEMORY_MAINTENANCE_PROGRESS ||
                                   st == LLAMA_MEMORY_MAINTENANCE_PROGRESS) {
                            st = LLAMA_MEMORY_MAINTENANCE_PROGRESS;
                        } else if (st_dft == LLAMA_MEMORY_MAINTENANCE_RETRY_STALE ||
                                   st == LLAMA_MEMORY_MAINTENANCE_RETRY_STALE) {
                            st = LLAMA_MEMORY_MAINTENANCE_RETRY_STALE;
                        } else if (!(st_dft == LLAMA_MEMORY_MAINTENANCE_FLOOR_EXHAUSTED &&
                                     st == LLAMA_MEMORY_MAINTENANCE_FLOOR_EXHAUSTED)) {
                            st = LLAMA_MEMORY_MAINTENANCE_NO_ACTION;
                        }
                    }
                    xkv_maintain_status = st;
                    if (st == LLAMA_MEMORY_MAINTENANCE_ERROR) {
                        SRV_ERR("%s", "XKV safe-boundary maintenance failed; refusing decode rather than masking the failure\n");
                        const int32_t err_id = id_slot_protected >= 0 ? id_slot_protected : id_slot_prefill;
                        if (err_id >= 0) {
                            if (server_slot * err_slot = get_slot_by_id(err_id)) {
                                if (err_slot->is_processing()) {
                                    send_error(*err_slot, "XKV maintenance failed (codec/workspace); cannot proceed safely");
                                    err_slot->release();
                                }
                            }
                        }
                        return false;
                    }
                    // Fresh snapshot after maintenance for the replan below.
                    if (has_tgt_usage || has_dft_usage) {
                        xkv_adm = query_xkv_admission(mem_tgt, mem_dft, has_tgt_usage, has_dft_usage);
                        xkv_snap = xkv_adm.combined;
                        have_xkv_snap = xkv_adm.have_combined;
                    }
                    if (st == LLAMA_MEMORY_MAINTENANCE_RETRY_STALE ||
                        st == LLAMA_MEMORY_MAINTENANCE_PROGRESS) {
                        continue; // replan against the fresh snapshot (bounded above)
                    }
                }
            }
            xkv_tri_allowed = !llama_xkv_is_enabled(params_base.xkv_mode) ||
                xkv_maintain_status == LLAMA_MEMORY_MAINTENANCE_NO_ACTION ||
                xkv_maintain_status == LLAMA_MEMORY_MAINTENANCE_FLOOR_EXHAUSTED;
            uint32_t kv_deficit_tgt = has_tgt_usage && required_kv > available_tgt
                ? (uint32_t) std::min<uint64_t>(UINT32_MAX, (uint64_t) required_kv - available_tgt)
                : 0;
            // XKV hot pressure (bounded hot): logical capacity stays huge while
            // physical hot slots exhaust, so the hot deficit from the fresh
            // snapshot joins overall KV pressure, deficit, Tri trigger, floor
            // logging/counters, fallback, and batch limiting. Each memory sizes
            // its own Tri reclaim request; legacy logical capacity is never
            // conflated: only XKV hot deficits.
            if (xkv_adm.have_tgt && required_kv > xkv_adm.tgt.hot_free) {
                kv_pressure = true;
                const uint64_t hot_d = (uint64_t) required_kv - xkv_adm.tgt.hot_free;
                const uint32_t hot_deficit =
                    (uint32_t) std::min<uint64_t>(hot_d, UINT32_MAX);
                kv_deficit_tgt = std::max(kv_deficit_tgt, hot_deficit);
            }
            uint32_t kv_deficit_dft = has_dft_usage && required_kv > available_dft
                ? (uint32_t) std::min<uint64_t>(UINT32_MAX, (uint64_t) required_kv - available_dft)
                : 0;
            if (xkv_adm.have_dft && required_kv > xkv_adm.dft.hot_free) {
                kv_pressure = true;
                const uint64_t hot_d = (uint64_t) required_kv - xkv_adm.dft.hot_free;
                kv_deficit_dft = std::max(kv_deficit_dft,
                    (uint32_t) std::min<uint64_t>(hot_d, UINT32_MAX));
            }

            bool tri_maintenance_due = false;
            if (params_base.triattention_enabled && !kv_pressure) {
                // Multi-person Tri maintenance check (§§B.9.3, B.13 Phase 7)
                for (const auto & kv : rerot_transport) {
                    const auto * ep = rerot ? rerot->episode(kv.first) : nullptr;
                    if (!ep || !kv.second || !kv.second->triattention_compressed) {
                        continue;
                    }
                    const uint64_t synced = kv.second->triattention_synced_public_tokens;
                    const uint64_t current = ep->generated_public_tokens;
                    if (current > synced) {
                        const uint64_t base = static_cast<uint64_t>(
                            std::max<llama_pos>(0, ep->base_prefix_end));
                        const uint64_t old_target = std::max<uint64_t>(
                            128,
                            static_cast<uint64_t>(std::ceil(
                                double(base + synced) * params_base.triattention_ratio)));
                        const uint64_t new_target = std::max<uint64_t>(
                            128,
                            static_cast<uint64_t>(std::ceil(
                                double(base + current) * params_base.triattention_ratio)));
                        const uint64_t target_growth = new_target - old_target;
                        if (current - synced > target_growth + 128) {
                            tri_maintenance_due = true;
                            break;
                        }
                    }
                }
                for (const auto & slot : slots) {
                    if (!slot.is_processing() || !slot.triattention_compressed ||
                        slot.rerot_internal) {
                        continue;
                    }

                    const uint32_t logical_tokens = (uint32_t) slot.prompt.n_tokens();
                    const uint32_t target = std::max<uint32_t>(128, (uint32_t) std::ceil((double) logical_tokens * params_base.triattention_ratio));
                    const uint32_t resident = llama_memory_seq_get_kv_used(mem_tgt, slot.id);
                    if (resident > target + 128) {
                        tri_maintenance_due = true;
                        break;
                    }
                }
            }

            if (!kv_pressure && !recurrent_pressure && !tri_maintenance_due) {
                return true;
            }

            // TriAttention only reclaims KV. Recurrent-only pressure must go directly
            // to the existing recurrent fallback path.
            // XKV: Tri/atomic runs only on confirmed floor/no-action; a new
            // sequence blocked on recurrent slots goes to the recurrent
            // victim path below without Tri (Tri reclaims KV, not recurrent).
            if (params_base.triattention_enabled && xkv_tri_allowed && (kv_pressure || tri_maintenance_due)) {
                // Initial pressure drains every resident sequence. Maintenance only
                // touches sequences that have already entered compressed mode.
                std::vector<llama_memory_kv_reclaim_seq_hint> seq_hints;

                // Sync public archive and build hints for every active person/episode (§B.9.3)
                for (const auto & kv : rerot_transport) {
                    const auto * ep = rerot ? rerot->episode(kv.first) : nullptr;
                    if (!ep || !kv.second) {
                        continue;
                    }
                    std::vector<llama_seq_id> rerot_semantic_seq_ids;
                    if (!rerot->sync_public_archive(ep->id, &rerot_semantic_seq_ids)) {
                        rerot->hard_abort(
                            ep->id,
                            "rerot_state_error: failed to synchronize PUBLIC archive before TriAttention reclaim");
                        rerot_propagate_hard_abort(ep->id);
                        return false;
                    }
                    if (ep->archive_seq >= 0 &&
                        (kv_pressure || kv.second->triattention_compressed) &&
                        llama_memory_seq_get_kv_used(mem_tgt, ep->archive_seq) > 0) {
                        const uint64_t logical_u64 =
                            uint64_t(std::max<llama_pos>(0, ep->base_prefix_end)) +
                            ep->generated_public_tokens;
                        llama_memory_kv_reclaim_seq_hint hint;
                        hint.seq_id = ep->archive_seq;
                        hint.logical_tokens = static_cast<uint32_t>(
                            std::min<uint64_t>(UINT32_MAX, logical_u64));
                        hint.tail_guard = 128;
                        hint.eligible = true;
                        hint.semantic_episode_id = ep->id;
                        hint.semantic_seq_ids = std::move(rerot_semantic_seq_ids);
                        seq_hints.push_back(std::move(hint));
                    }
                }

                // Add non-internal slot hints
                for (auto & slot : slots) {
                    if (slot.prompt.n_tokens() == 0 ||
                        slot.rerot_internal ||
                        (!kv_pressure && !slot.triattention_compressed)) {
                        continue;
                    }
                    llama_memory_kv_reclaim_seq_hint hint;
                    hint.seq_id = slot.id;
                    hint.logical_tokens = (uint32_t) slot.prompt.n_tokens();
                    hint.tail_guard = 128; // recent window
                    hint.eligible = true;
                    seq_hints.push_back(hint);
                }

                llama_memory_kv_reclaim_request req;
                // required_free is a deficit, not the whole incoming batch.
                // drain_to_floor still makes the initial pressure event perform
                // the configured-ratio drain regardless of the deficit size.
                req.required_free = kv_deficit_tgt;
                req.drain_to_floor = true;
                req.seq_hints = std::move(seq_hints);

                // Context-level reclaim synchronizes pending compute before any
                // physical K/V movement and invalidates graph reservations after.
                auto result_tgt = llama_context_reclaim_kv(ctx_tgt, &req);
                if (result_tgt.supported && result_tgt.changed) {
                    if (kv_pressure) {
                        tri_drain_count++;
                    } else {
                        tri_maintenance_count++;
                    }
                    tri_cells_before       = result_tgt.physical_before;
                    tri_cells_after        = result_tgt.physical_after;
                    tri_cells_freed        = result_tgt.physical_freed;
                    tri_references_removed = result_tgt.references_removed;
                    tri_target_references  = result_tgt.target_references;
                    tri_hard_keep          = result_tgt.hard_keep;
                    tri_shared_keep        = result_tgt.shared_keep;
                    tri_cells_freed_total += result_tgt.physical_freed;
                    tri_score_us_total    += result_tgt.score_us;
                    tri_pack_us_total     += result_tgt.pack_us;

                    for (const auto & kv : rerot_transport) {
                        const auto * ep = rerot ? rerot->episode(kv.first) : nullptr;
                        if (ep && kv.second) {
                            kv.second->triattention_synced_public_tokens = ep->generated_public_tokens;
                        }
                    }

                    SRV_INF("TriAttention %s: before=%u after=%u freed=%u refs_removed=%u deficit=%u target_refs=%u hard_keep=%u shared_keep=%u score_ms=%.3f pack_ms=%.3f floor_reached=%s\n",
                            kv_pressure ? "drain" : "maintenance",
                            result_tgt.physical_before, result_tgt.physical_after, result_tgt.physical_freed,
                            result_tgt.references_removed, kv_deficit_tgt,
                            result_tgt.target_references, result_tgt.hard_keep,
                            result_tgt.shared_keep,
                            result_tgt.score_us / 1000.0, result_tgt.pack_us / 1000.0,
                            result_tgt.floor_reached ? "true" : "false");

                    if (kv_pressure) {
                        for (auto & slot : slots) {
                            if (slot.prompt.n_tokens() > 0 &&
                                llama_memory_seq_get_kv_used(mem_tgt, slot.id) > 0) {
                                slot.triattention_compressed = true;
                            }
                        }
                        for (const auto & kv : rerot_transport) {
                            const auto * ep = rerot ? rerot->episode(kv.first) : nullptr;
                            if (ep && kv.second) {
                                for (const auto & slot : slots) {
                                    if (slot.rerot_internal &&
                                        slot.rerot_episode_id == ep->id &&
                                        slot.triattention_compressed) {
                                        kv.second->triattention_compressed = true;
                                        break;
                                    }
                                }
                                if (ep->archive_seq >= 0 &&
                                    llama_memory_seq_get_kv_used(mem_tgt, ep->archive_seq) > 0) {
                                    kv.second->triattention_compressed = true;
                                }
                            }
                        }
                    }

                    // Also reclaim on draft if separate
                    if (has_dft_usage && mem_dft != mem_tgt) {
                        llama_memory_kv_reclaim_request req_dft = req;
                        req_dft.required_free = kv_deficit_dft;
                        auto result_dft = llama_context_reclaim_kv(ctx_dft, &req_dft);
                        if (result_dft.supported && result_dft.changed) {
                            tri_cells_freed_total += result_dft.physical_freed;
                            tri_score_us_total    += result_dft.score_us;
                            tri_pack_us_total     += result_dft.pack_us;
                        }
                    }
                    // Re-check capacity by continuing the while loop
                    continue;
                }

                if (kv_pressure && result_tgt.supported) {
                    if ((!result_tgt.changed || (result_tgt.floor_reached && !result_tgt.capacity_satisfied)) &&
                        !counted_kv_fallback) {
                        tri_floor_exhausted_count++;
                        tri_atomic_fallback_kv_count++;
                        counted_kv_fallback = true;
                    }
                    SRV_INF("TriAttention KV floor exhausted: used=%u deficit=%u target_refs=%u hard_keep=%u shared_keep=%u; entering atomic fallback\n",
                            result_tgt.physical_after, kv_deficit_tgt, result_tgt.target_references,
                            result_tgt.hard_keep, result_tgt.shared_keep);
                } else if (kv_pressure && !result_tgt.supported) {
                    SRV_ERR("%s\n", "TriAttention enabled but target KV memory does not support reclaim; entering atomic fallback");
                }
            }

            if (!kv_pressure && !recurrent_pressure) {
                return true;
            }

            if (params_base.triattention_enabled && recurrent_pressure && !counted_recurrent_fallback) {
                tri_atomic_fallback_recurrent_count++;
                counted_recurrent_fallback = true;
                SRV_INF("%s\n", "recurrent pressure: entering atomic fallback without TriAttention KV reclaim");
            }

            if (try_clear_idle_slots()) {
                continue;
            }

            server_slot * victim = find_preemption_victim(id_slot_protected, recurrent_pressure);
            if (victim == nullptr) {
                SRV_DBG("dynamic memory needs kv=%u recurrent_tgt=%u recurrent_dft=%u, target available=%" PRIu64 ", draft available=%" PRIu64 ", recurrent_tgt available=%" PRIu64 ", recurrent_dft available=%" PRIu64 "\n",
                        required_kv, required_recurrent_tgt, required_recurrent_dft,
                        available_tgt, available_dft, available_recurrent_tgt, available_recurrent_dft);

                // The current prefill slot is protected from preemption. Process only
                // the cells that fit, then re-enter the pressure planner before adding
                // more tokens. This avoids exhausting the cache inside decode's
                // smaller-batch retry loop.
                if (kv_pressure && id_slot_protected >= 0) {
                    const uint64_t available = std::min(available_tgt, available_dft);
                    kv_batch_limit = (uint32_t) std::min<uint64_t>(available, llama_n_batch(ctx_tgt));
                    if (kv_batch_limit > 0) {
                        SRV_INF("KV floor exhausted during prefill; limiting next batch to %u cells\n", kv_batch_limit);
                    }
                }
                // XKV admission (snapshot taken above): tighten the next batch
                // to the live token bound. A zero bound with a real reason
                // means do NOT decode — with no preemption victim left, error
                // the protected prefill slot instead of clamping to one cell.
                // Only an unknown snapshot (NONE) defers to the legacy size.
                // Recurrent gating needs no batch tightening: continuation
                // batches proceed, and a blocked new sequence with no victim
                // takes the same no-decode error path here.
                if (have_xkv_snap && xkv_snap.limit_reason != LLAMA_MEMORY_LIMIT_NONE) {
                    if (xkv_snap.safe_next_ubatch == 0) {
                        SRV_ERR("XKV admission exhausted (%s); refusing decode\n",
                            llama_memory_limit_reason_name(xkv_snap.limit_reason));
                        if (id_slot_protected >= 0) {
                            if (server_slot * stuck = get_slot_by_id(id_slot_protected)) {
                                if (stuck->is_processing()) {
                                    send_error(*stuck, "Context size has been exceeded.");
                                    stuck->release();
                                }
                            }
                        }
                        return false;
                    }
                    const uint32_t cap = (uint32_t) std::min<uint64_t>(
                        xkv_snap.safe_next_ubatch, (uint64_t) llama_n_batch(ctx_tgt));
                    if (cap < kv_batch_limit) {
                        kv_batch_limit = cap;
                        SRV_INF("XKV admission (%s): limiting next batch to %u cells\n",
                            llama_memory_limit_reason_name(xkv_snap.limit_reason), kv_batch_limit);
                }
                }
                // Per-memory gate (matches the pressure planning above): a new
                // sequence blocked on either memory with no victim left refuses
                // decode instead of clamping to one cell.
                if ((xkv_adm.have_tgt && required_recurrent_tgt > 0 &&
                        xkv_adm.tgt.recurrent_blocks_new_seq) ||
                    (xkv_adm.have_dft && required_recurrent_dft > 0 &&
                        xkv_adm.dft.recurrent_blocks_new_seq)) {
                    SRV_ERR("%s", "XKV recurrent admission: no free recurrent slot for the new sequence\n");
                    if (id_slot_protected >= 0) {
                        if (server_slot * stuck = get_slot_by_id(id_slot_protected)) {
                            if (stuck->is_processing()) {
                                send_error(*stuck, "Context size has been exceeded.");
                                stuck->release();
                            }
                        }
                    }
                    return false;
                }
                return true;
            }

            if (!preempt_slot(*victim)) {
                return false;
            }
        }
    }

    std::vector<common_adapter_lora_info> construct_lora_list(const std::map<int, float> & config) const {
        std::vector<common_adapter_lora_info> output = params_base.lora_adapters; // copy
        for (size_t i = 0; i < output.size(); ++i) {
            auto it = config.find(i);
            if (it != config.end()) {
                output[i].scale = it->second;
            } else {
                output[i].scale = 0.0f;
            }
        }
        return output;
    }

    bool launch_slot_with_task(server_slot & slot, server_task && task) {
        // process per-request lora adapters
        if (!task.params.lora.empty()) {
            auto task_loras = construct_lora_list(task.params.lora);
            if (!are_lora_equal(task_loras, slot.lora)) {
                // if lora has changed, check to see if the cache should be cleared
                if (lora_should_clear_cache(slot.lora, task_loras)) {
                    SLT_TRC(slot, "clearing cache for lora change. %zu loras -> %zu loras\n", slot.lora.size(), task.params.lora.size());
                    slot.prompt.clear();
                } else {
                    SLT_TRC(slot, "keeping cache for alora. %zu target loras\n", task_loras.size());
                }
                slot.lora = task_loras;
            }
        } else {
            slot.lora = params_base.lora_adapters;
        }

        // if using alora, make sure it's only a single one requested and active
        size_t alora_invocation_start = task.tokens.size();
        if (lora_all_alora(slot.lora)) {
            const auto & enabled_ids = lora_get_enabled_ids(slot.lora);
            // TODO: This will error out if a user requests two aloras, but only
            // provides the activation string for one. We could, instead search
            // for all requested alora activation strings and then either keep
            // only the last one, or reject if multiple are found.
            if (enabled_ids.size() != 1) {
                send_error(task, "Cannot run multiple aLoRAs in a single request", ERROR_TYPE_INVALID_REQUEST);
                return false;
            }
            const auto & lora = slot.lora[enabled_ids[0]].ptr;

            // get the pointer and count for the invocation tokens
            const uint64_t      n_invocation_tokens = llama_adapter_get_alora_n_invocation_tokens(lora);
            const llama_token * invocation_tokens   = llama_adapter_get_alora_invocation_tokens  (lora);

            // scan backwards through the prompt tokens to find the last
            // occurrence of the invocation sequence
            int match_idx = static_cast<int>(n_invocation_tokens) - 1;
            for (int i = task.tokens.size() - 1; i >= 0; --i) {
                // the token in this position matches the next token to find in
                // the invocation sequence
                if (task.tokens[i] == invocation_tokens[match_idx]) {
                    // if it's a full match, we've found the start
                    if (match_idx == 0) {
                        alora_invocation_start = i;
                        break;
                    }
                    // otherwise, check the next token in the sequence
                    --match_idx;
                } else {
                    // no match in this position, so start looking over again
                    match_idx = static_cast<int>(n_invocation_tokens) - 1;
                }
            }

            // if the activation string is not found, disable the alora
            if (alora_invocation_start == task.tokens.size()) {
                SLT_DBG(slot, "alora %zu requested, but not found. deactivating\n", enabled_ids[0]);
                slot.lora[enabled_ids[0]].scale = 0.0f;
            } else {
                SLT_DBG(slot, "alora %zu activated starting at %zu\n", enabled_ids[0], alora_invocation_start);
                slot.alora_invocation_start = alora_invocation_start;
            }
        }

        if (!task.tokens.validate(ctx_tgt)) {
            send_error(task, "Prompt contains invalid tokens", ERROR_TYPE_INVALID_REQUEST);
            return false;
        }

        SLT_DBG(slot, "launching slot : %s\n", safe_json_to_str(slot.to_json()).c_str());

        // Initialize the ordinary sampler unchanged; internal RERoT phases
        // clear their own copies only after the pristine C0 boundary.
        if (task.need_sampling()) {
            try {
                slot.smpl.reset(common_sampler_init(
                        model_tgt, task.params.sampling, (int32_t) llama_n_ctx(ctx_tgt)));
            } catch (std::exception & e) {
                std::string err_msg = std::string("Failed to initialize samplers: ") + e.what();
                send_error(task, err_msg, ERROR_TYPE_INVALID_REQUEST);
                return false;
            }

            const bool need_pre_sample_logits = task.params.sampling.n_probs > 0 && !task.params.post_sampling_probs;

            bool backend_sampling = true;

            backend_sampling &= task.params.sampling.backend_sampling;

            // TODO: speculative decoding requires multiple samples per batch - not supported yet
            backend_sampling &= !(slot.can_speculate());

            // TODO: getting pre sampling logits is not yet supported with backend sampling
            backend_sampling &= !need_pre_sample_logits;

            // TODO: tmp until backend sampling is fully implemented
            if (backend_sampling) {
                llama_set_sampler(ctx_tgt, slot.id, common_sampler_get(slot.smpl.get()));
            } else {
                llama_set_sampler(ctx_tgt, slot.id, nullptr);
            }

            SLT_TRC(slot, "sampler chain: %s\n", common_sampler_print(slot.smpl.get()).c_str());
            SLT_TRC(slot, "sampler params: \n%s\n", task.params.sampling.print().c_str());
        } else {
            slot.smpl.reset();
        }

        slot.task = std::make_unique<const server_task>(std::move(task));

        auto retry_it = retry_states.find(slot.task->id);
        if (retry_it != retry_states.end()) {
            auto & retry = retry_it->second;
            slot.n_decoded_start                  = retry.n_decoded;
            slot.n_prompt_tokens_original         = retry.n_prompt_tokens_original;
            slot.n_prompt_tokens_cache_response   = retry.n_prompt_tokens_cache_response;
            slot.n_prompt_tokens_processed_accum  = retry.n_prompt_tokens_processed;
            slot.response_prompt                  = std::move(retry.response_prompt);
            slot.last_nl_pos             = retry.last_nl_pos;
            slot.generated_text          = std::move(retry.generated_text);
            slot.generated_tokens        = std::move(retry.generated_tokens);
            slot.generated_token_probs   = std::move(retry.generated_token_probs);
            slot.n_sent_text             = retry.n_sent_text;
            slot.has_new_line            = retry.has_new_line;
            slot.truncated               = retry.truncated;
            slot.t_start_generation      = retry.t_start_generation;
            slot.t_prompt_processing_accum = retry.t_prompt_processing;
            retry_states.erase(retry_it);
        } else {
            slot.n_decoded_start                 = 0;
            slot.n_prompt_tokens_original        = slot.task->n_tokens();
            slot.n_prompt_tokens_cache_response  = 0;
            slot.n_prompt_tokens_processed_accum = 0;
            slot.response_prompt.clear();
            slot.t_start_generation              = 0;
            slot.t_prompt_processing_accum       = 0.0;
        }

        slot.n_decoded   = slot.n_decoded_start;
        slot.n_remaining = -1;

        slot.state = slot.task->is_child()
            ? SLOT_STATE_WAIT_OTHER // wait for the parent to process prompt
            : SLOT_STATE_STARTED;

        if (spec && slot.smpl && vocab && common_sampler_is_greedy_argmax_eligible(slot.smpl.get(), vocab)) {
            common_sampler_set_verify_argmax_host(slot.smpl.get(), true);
            SLT_INF(slot, "%s", "verify-argmax host sampling enabled (greedy chain)\n");
        }

        bind_cache_key_to_slot(slot.task->cache_key, slot.id);

        // reset server kill-switch counter
        n_empty_consecutive = 0;

        SLT_INF(slot, "processing task, is_child = %d\n", slot.task->is_child());
        return true;
    }

    bool process_token(completion_token_output & result, server_slot & slot) {
        // remember which tokens were sampled - used for repetition penalties during sampling
        const std::string token_str = result.text_to_send;
        slot.sampled = result.tok;

        slot.generated_text += token_str;
        if (slot.task->params.return_tokens) {
            slot.generated_tokens.push_back(result.tok);
        }
        slot.has_next_token = true;

        if (!slot.task->params.stream && slot.task->params.antiprompt.empty()) {
            result.text_to_send = token_str;
            slot.n_sent_text += token_str.size();
            slot.add_token(result);
        } else {
        // check if there is incomplete UTF-8 character at the end
        bool incomplete = validate_utf8(slot.generated_text) < slot.generated_text.size();

        // search stop word and delete it
        if (!incomplete) {
            size_t pos = std::min(slot.n_sent_text, slot.generated_text.size());

            const std::string str_test = slot.generated_text.substr(pos);
            bool send_text = true;

            size_t stop_pos = slot.find_stopping_strings(str_test, token_str.size(), true);
            if (stop_pos != std::string::npos) {
                slot.generated_text.erase(
                    slot.generated_text.begin() + pos + stop_pos,
                    slot.generated_text.end());
                pos = std::min(slot.n_sent_text, slot.generated_text.size());
            } else if (slot.has_next_token && !llama_vocab_is_eog(vocab, result.tok) ) {
                stop_pos = slot.find_stopping_strings(str_test, token_str.size(), false);
                send_text = stop_pos == std::string::npos;
            }

            // check if there is any token to predict
            if (send_text) {
                // no send the stop word in the response
                result.text_to_send = slot.generated_text.substr(pos, std::string::npos);
                slot.n_sent_text += result.text_to_send.size();
                // add the token to slot queue and cache
            } else {
                result.text_to_send = "";
            }

            slot.add_token(result);
            if (slot.task->params.stream) {
                send_partial_response(slot, result, false);
            }
            if (incomplete) {
                slot.has_next_token = true;
            }
        }
        }

        // if context shifting is disabled, make sure that we don't run out of context
        if (!params_base.ctx_shift && slot.prompt.n_tokens() + 1 >= slot.n_ctx) {
            slot.truncated      = true;
            slot.stop           = STOP_TYPE_LIMIT;
            slot.has_next_token = false;

            SLT_DBG(slot, "stopped due to running out of context capacity, prompt.n_tokens() = %d, task.n_tokens = %d, n_decoded = %d, n_ctx = %d\n",
                    slot.prompt.n_tokens(), slot.task->n_tokens(), slot.n_decoded, slot.n_ctx);
        }

        // check the limits
        if (slot.n_decoded > 0 && slot.has_next_token && !slot.has_budget(params_base)) {
            slot.stop           = STOP_TYPE_LIMIT;
            slot.has_next_token = false;

            SLT_DBG(slot, "stopped by limit, n_decoded = %d, n_predict = %d\n", slot.n_decoded, slot.task->params.n_predict);
        }

        if (slot.has_new_line) {
            // require that each new line has a whitespace prefix (i.e. indentation) of at least slot.params.n_indent
            if (slot.task->params.n_indent > 0) {
                // check the current indentation
                // TODO: improve by not doing it more than once for each new line
                if (slot.last_nl_pos > 0) {
                    size_t pos = slot.last_nl_pos;

                    int n_indent = 0;
                    while (pos < slot.generated_text.size() && (slot.generated_text[pos] == ' ' || slot.generated_text[pos] == '\t')) {
                        n_indent++;
                        pos++;
                    }

                    if (pos < slot.generated_text.size() && n_indent < slot.task->params.n_indent) {
                        slot.stop           = STOP_TYPE_LIMIT;
                        slot.has_next_token = false;

                        // cut the last line
                        slot.generated_text.erase(pos, std::string::npos);

                        SLT_DBG(slot, "stopped by indentation limit, n_decoded = %d, n_indent = %d\n", slot.n_decoded, n_indent);
                    }
                }

                // find the next new line
                {
                    const size_t pos = slot.generated_text.find('\n', slot.last_nl_pos);

                    if (pos != std::string::npos) {
                        slot.last_nl_pos = pos + 1;
                    }
                }
            }
        }

        // check if there is a new line in the generated text
        if (result.text_to_send.find('\n') != std::string::npos) {
            slot.has_new_line = true;

            // if we have seen a new line, we stop after a certain time limit, but only upon another new line
            if (slot.task->params.t_max_predict_ms > 0 && (ggml_time_us() - slot.t_start_generation > 1000.0f*slot.task->params.t_max_predict_ms)) {
                slot.stop           = STOP_TYPE_LIMIT;
                slot.has_next_token = false;

                SLT_DBG(slot, "stopped by time limit, n_decoded = %d, t_max_predict_ms = %d ms\n", slot.n_decoded, (int) slot.task->params.t_max_predict_ms);
            }
        }

        if (llama_vocab_is_eog(vocab, result.tok)) {
            slot.stop           = STOP_TYPE_EOS;
            slot.has_next_token = false;

            SLT_DBG(slot, "%s", "stopped by EOS\n");
        }

        SLT_DBG(slot, "n_decoded = %d, n_remaining = %d, next token: %5d '%s'\n", slot.n_decoded, slot.n_remaining, result.tok, token_str.c_str());

        return slot.has_next_token; // continue
    }

    void populate_token_probs(const server_slot & slot, common_sampler * sampler, completion_token_output & result, bool post_sampling, bool special, int idx) const {
        const size_t n_probs_request = slot.task->params.sampling.n_probs;

        if (post_sampling) {
            const auto * cur_p = common_sampler_get_candidates(sampler, true);
            const size_t max_probs = cur_p->size;
            const size_t n_probs = std::min(max_probs, n_probs_request);

            // set probability for sampled token
            for (size_t i = 0; i < max_probs; i++) {
                if (cur_p->data[i].id == result.tok) {
                    result.prob = cur_p->data[i].p;
                    break;
                }
            }

            // set probability for top n_probs tokens
            result.probs.reserve(n_probs);
            for (size_t i = 0; i < n_probs; i++) {
                // Some samplers do return 0.0 probabilities, others don't.
                // Filter 0.0 probailities, to ensure the behavior is consistent.
                if (cur_p->data[i].p == 0.0) {
                    break;
                }

                result.probs.push_back({
                    cur_p->data[i].id,
                    common_token_to_piece(ctx_tgt, cur_p->data[i].id, special),
                    cur_p->data[i].p
                });
            }
        } else {
            std::vector<llama_token_data> cur = get_token_probabilities(ctx_tgt, idx, n_probs_request);
            const size_t max_probs = cur.size();
            const size_t n_probs = std::min(max_probs, n_probs_request);

            // set probability for sampled token
            for (size_t i = 0; i < max_probs; i++) {
                // set probability for sampled token
                if (cur[i].id == result.tok) {
                    result.prob = cur[i].p;
                    break;
                }
            }

            // set probability for top n_probs tokens
            result.probs.reserve(n_probs);
            for (size_t i = 0; i < n_probs; i++) {
                result.probs.push_back({
                    cur[i].id,
                    common_token_to_piece(ctx_tgt, cur[i].id, special),
                    cur[i].p
                });
            }
        }
    }

    void send_error(const server_task & task, const std::string & error, const enum error_type type = ERROR_TYPE_SERVER) {
        send_error(task.id, error, type);
    }

    void send_error(const server_slot & slot, const std::string & error, const enum error_type type = ERROR_TYPE_SERVER) {
        send_error(slot.task->id, error, type, slot.task->n_tokens(), slot.n_ctx);
    }

    void send_error(const int id_task, const std::string & error, const enum error_type type = ERROR_TYPE_SERVER, const int32_t n_prompt_tokens = 0, const int32_t n_ctx = 0) {
        SRV_ERR("task id = %d, error: %s\n", id_task, error.c_str());

        if (type == ERROR_TYPE_EXCEED_CONTEXT_SIZE) {
            GGML_ASSERT(n_ctx > 0 && n_prompt_tokens > 0);
        }

        auto res = std::make_unique<server_task_result_error>();
        res->id              = id_task;
        res->err_type        = type;
        res->err_msg         = error;
        res->n_prompt_tokens = n_prompt_tokens;
        res->n_ctx           = n_ctx;

        queue_results.send(std::move(res));
    }

    // Gate slot save/restore/erase on slot content (does it hold media),
    // not model capability: a multimodal model may hold a pure-text slot.
    bool check_slot_no_media(const server_slot & slot, const int id_task) {
        if (slot.prompt.tokens.has_media()) {
            send_error(id_task,
                "This operation is not supported while the slot holds image/audio tokens (a pure-text prefix is supported)",
                ERROR_TYPE_NOT_SUPPORTED);
            return false;
        }
        return true;
    }

    void send_partial_response(server_slot & slot, const completion_token_output & tkn, bool is_progress, bool is_begin = false) {
        auto res = std::make_unique<server_task_result_cmpl_partial>();
        const auto * episode = slot.rerot_serial_tail && rerot
            ? rerot->episode(slot.rerot_episode_id) : nullptr;
        const bool dag_channels = episode && episode->is_dag;

        res->id    = slot.task->id;
        res->index = slot.task->index;

        if (is_progress) {
            res->is_progress        = true;
            res->progress.total     = slot.task->n_tokens();
            res->progress.cache     = slot.n_prompt_tokens_cache;
            res->progress.processed = slot.prompt.tokens.size();
            res->progress.time_ms   = (ggml_time_us() - slot.t_start_process_prompt) / 1000;
        }
        if (is_begin) {
            res->is_begin = true;
        } else {
            res->content = tkn.text_to_send;
            res->tokens  = { tkn.tok };
            if (dag_channels) {
                res->is_rerot_content = true;
            }
        }

        res->n_decoded             = slot.n_decoded;
        res->n_prompt_tokens       = slot.n_prompt_tokens_original;
        res->n_prompt_tokens_cache = slot.n_prompt_tokens_cache_response;
        res->post_sampling_probs   = slot.task->params.post_sampling_probs;

        res->verbose           = slot.task->params.verbose;
        res->res_type          = slot.task->params.res_type;
        res->oaicompat_model   = slot.task->params.oaicompat_model;
        res->oaicompat_cmpl_id = slot.task->params.oaicompat_cmpl_id;

        // populate res.probs_output
        if (slot.task->params.sampling.n_probs > 0) {
            res->prob_output = tkn; // copy the token probs
        }

        // populate timings if this is final response or timings_per_token is enabled
        if (slot.stop != STOP_TYPE_NONE || slot.task->params.timings_per_token) {
            res->timings = slot.get_timings();
        }

        queue_results.send(std::move(res));
    }

    void send_final_response(server_slot & slot) {
        auto res = std::make_unique<server_task_result_cmpl_final>();
        const auto * episode = slot.rerot_serial_tail && rerot
            ? rerot->episode(slot.rerot_episode_id) : nullptr;
        const bool dag_channels = episode && episode->is_dag;

        res->id      = slot.task->id;
        res->id_slot = slot.id;

        res->index = slot.task->index;

        // keep copy of last generated text for debugging purposes
        if (slots_debug) {
            slot.debug_generated_text = slot.generated_text;
        }

        // in stream mode, content and tokens are already in last partial chunk
        if (slot.task->params.stream) {
            res->content = "";
            res->tokens = llama_tokens{};
            if (dag_channels) {
                res->rerot_explicit_channels = true;
            }
        } else if (dag_channels) {
            const auto transport_it = rerot_transport.find(slot.rerot_episode_id);
            GGML_ASSERT(transport_it != rerot_transport.end());
            const size_t offset = transport_it->second->final_content_offset;
            GGML_ASSERT(offset <= slot.generated_text.size());
            res->rerot_reasoning = slot.generated_text.substr(0, offset);
            res->content = slot.generated_text.substr(offset);
            res->rerot_explicit_channels = true;
            res->tokens = std::move(slot.generated_tokens);
        } else {
            res->content     = std::move(slot.generated_text);
            res->tokens      = std::move(slot.generated_tokens);
        }
        res->timings         = slot.get_timings();
        res->prompt          = (slot.response_prompt.empty() ? slot.task->tokens : slot.response_prompt).detokenize(ctx_tgt, true);
        res->response_fields = std::move(slot.task->params.response_fields);

        res->truncated             = slot.truncated;
        res->n_decoded             = slot.n_decoded;
        res->n_prompt_tokens       = slot.n_prompt_tokens_original;
        res->n_prompt_tokens_cache = slot.n_prompt_tokens_cache_response;
        res->n_tokens_cached       = slot.prompt.n_tokens();
        res->has_new_line          = slot.has_new_line;
        res->stopping_word         = slot.stopping_word;
        res->stop                  = slot.stop;
        res->post_sampling_probs   = slot.task->params.post_sampling_probs;

        res->verbose           = slot.task->params.verbose;
        res->stream            = slot.task->params.stream;
        res->include_usage     = slot.task->params.include_usage;
        res->res_type          = slot.task->params.res_type;
        res->oaicompat_model   = slot.task->params.oaicompat_model;
        res->oaicompat_cmpl_id = slot.task->params.oaicompat_cmpl_id;

        // populate res.probs_output
        if (slot.task->params.sampling.n_probs > 0) {
            if (!slot.task->params.stream && slot.stop == STOP_TYPE_WORD) {
                const llama_tokens stop_word_toks = common_tokenize(ctx_tgt, slot.stopping_word, false);

                size_t safe_offset = std::min(slot.generated_token_probs.size(), stop_word_toks.size());
                res->probs_output = std::vector<completion_token_output>(
                        slot.generated_token_probs.begin(),
                        slot.generated_token_probs.end() - safe_offset);
            } else {
                res->probs_output = std::vector<completion_token_output>(
                        slot.generated_token_probs.begin(),
                        slot.generated_token_probs.end());
            }
        }

        res->generation_params = slot.task->params; // copy the parameters

        if (rerot && slot.rerot_episode_id != 0) {
            if (const auto * episode = rerot->episode(slot.rerot_episode_id)) {
                res->rerot_probe_tokens = episode->probe_tokens;
                res->rerot_frame_tokens = episode->frame_tokens;
                res->rerot_source_end_tokens = episode->source_end_tokens;
            }
            auto transport_it = rerot_transport.find(slot.rerot_episode_id);
            if (transport_it != rerot_transport.end()) {
                res->rerot_probe_seconds = transport_it->second->probe_seconds;
                res->rerot_prefix_rebuild_seconds = transport_it->second->prefix_rebuild_seconds;
                res->rerot_ordinary_prompt_tokens = transport_it->second->ordinary_prompt_tokens;
                res->rerot_dag_lcp_tokens = transport_it->second->dag_lcp_tokens;
                res->rerot_replay_from_tokens = transport_it->second->replay_from_tokens;
                res->rerot_actual_replayed_tokens = transport_it->second->actual_replayed_tokens;
                res->rerot_fixed_entry_seconds = transport_it->second->fixed_entry_seconds;
                res->rerot_synthesis_switch_seconds = transport_it->second->synthesis_switch_seconds;
            }
        }

        queue_results.send(std::move(res));
    }

    void send_embedding(const server_slot & slot, const llama_batch & batch) {
        auto res = std::make_unique<server_task_result_embd>();
        res->id        = slot.task->id;
        res->index     = slot.task->index;
        res->n_tokens  = slot.task->n_tokens();
        res->res_type  = slot.task->params.res_type;

        const int n_embd_out = llama_model_n_embd_out(model_tgt);

        std::vector<float> embd_res(n_embd_out, 0.0f);

        for (int i = 0; i < batch.n_tokens; ++i) {
            if (!batch.logits[i] || batch.seq_id[i][0] != slot.id) {
                continue;
            }

            const float * embd = nullptr;
            if (llama_pooling_type(slot.ctx_tgt) == LLAMA_POOLING_TYPE_NONE) {
                embd = llama_get_embeddings_ith(slot.ctx_tgt, i);
            } else {
                embd = llama_get_embeddings_seq(slot.ctx_tgt, batch.seq_id[i][0]);
            }

            if (embd == nullptr) {
                SLT_ERR(slot, "failed to get embeddings, token = %d, seq_id = %d\n", batch.token[i], batch.seq_id[i][0]);

                res->embedding.push_back(std::vector<float>(n_embd_out, 0.0f));
                continue;
            }

            // normalize only when there is pooling
            if (llama_pooling_type(slot.ctx_tgt) != LLAMA_POOLING_TYPE_NONE) {
                common_embd_normalize(embd, embd_res.data(), n_embd_out, slot.task->params.embd_normalize);
                res->embedding.push_back(embd_res);
                break;
            }

            res->embedding.emplace_back(embd, embd + n_embd_out);
        }

        SLT_DBG(slot, "%s", "sending embeddings\n");

        queue_results.send(std::move(res));
    }

    void send_rerank(const server_slot & slot, const llama_batch & batch) {
        auto res = std::make_unique<server_task_result_rerank>();
        res->id       = slot.task->id;
        res->index    = slot.task->index;
        res->n_tokens = slot.task->n_tokens();

        for (int i = 0; i < batch.n_tokens; ++i) {
            if (!batch.logits[i] || batch.seq_id[i][0] != slot.id) {
                continue;
            }

            const float * embd = llama_get_embeddings_seq(ctx_tgt, batch.seq_id[i][0]);
            if (embd == NULL) {
                embd = llama_get_embeddings_ith(ctx_tgt, i);
            }

            if (embd == NULL) {
                SLT_ERR(slot, "failed to get embeddings, token = %d, seq_id = %d\n", batch.token[i], batch.seq_id[i][0]);

                res->score = -1e6;
                continue;
            }

            res->score = embd[0];
        }

        SLT_DBG(slot, "sending rerank result, res.score = %f\n", res->score);

        queue_results.send(std::move(res));
    }

    //
    // Functions to process the task
    //

    // tokenize the input if it's set by CLI, return false on error
    bool tokenize_cli_input(server_task & task) {
        try {
            auto & prompt = task.cli_prompt;
            if (mctx != nullptr) {
                task.tokens = process_mtmd_prompt(mctx, prompt, task.cli_files);
            } else {
                task.tokens = std::move(tokenize_input_prompts(vocab, mctx, prompt, true, true)[0]);
            }
            task.cli_prompt.clear();
            task.cli_files.clear();
        } catch (const std::exception & e) {
            send_error(task, std::string("Failed to format input: ") + e.what(), ERROR_TYPE_INVALID_REQUEST);
            return false;
        }
        return true;
    }

    std::vector<server_slot *> get_free_slots(size_t n_slots_needed, int exclude_id_slot) {
        std::vector<server_slot *> free_slots;
        for (auto & slot : slots) {
            if (params_base.rerot_enabled && slot.id >= params_base.n_parallel) {
                continue;
            }
            if (!slot.is_processing() && slot.id != exclude_id_slot) {
                free_slots.push_back(&slot);
            }
            if (free_slots.size() >= n_slots_needed) {
                break;
            }
        }
        return free_slots;
    }

    // launch multiple slots for parent + child tasks
    bool launch_slots_with_parent_task(server_slot & parent_slot, std::vector<server_slot *> & child_slots, server_task && parent_task) {
        GGML_ASSERT(!parent_slot.is_processing());
        GGML_ASSERT(parent_task.is_parent());
        GGML_ASSERT(child_slots.size() == parent_task.child_tasks.size());

        int id_parent = parent_task.id;

        SRV_TRC("launching slots for parent task id_task = %d with %zu child tasks\n", id_parent, parent_task.child_tasks.size());

        // to be called in case of failure to release all launched slots
        auto release_slots = [this, id_parent]() {
            for (auto & slot : slots) {
                if (slot.is_processing() && (
                        slot.task->id == id_parent ||
                        slot.task->id_parent == id_parent
                )) {
                    slot.release();
                }
            }
        };

        // launch all child tasks first
        size_t idx = 0;
        GGML_ASSERT(child_slots.size() == parent_task.child_tasks.size());
        for (auto * slot : child_slots) {
            int id_child = parent_task.child_tasks[idx].id;
            if (!launch_slot_with_task(*slot, std::move(parent_task.child_tasks[idx]))) {
                SRV_ERR("failed to launch slot with child task, id_task = %d\n", id_child);
                release_slots();
                return false;
            }
            idx++;
        }

        // finally, launch the parent task
        if (!launch_slot_with_task(parent_slot, std::move(parent_task))) {
            SRV_ERR("failed to launch slot with task, id_task = %d\n", id_parent);
            release_slots();
            return false;
        }

        return true;
    }

    // n_tokens_cur: the number of tokens added to the batch for the current slot
    void create_checkpoint(server_slot & slot, const int64_t n_tokens_cur, llama_pos pos_min, llama_pos pos_max) {
        const int id_task = slot.task->id;

        // evict checkpoints within min-step of a previous checkpoint, unless they were
        // created by the current task
        int64_t last = -1;
        for (auto it = slot.prompt.checkpoints.begin(); it != slot.prompt.checkpoints.end(); ) {
            if (it->id_task != id_task && last >= 0 && it->n_tokens <= last + params_base.checkpoint_min_step) {
                SLT_TRC(slot, "erasing context checkpoint too close to an earlier one (pos_min = %d, pos_max = %d, n_tokens = %" PRId64 ", size = %.3f MiB)\n",
                        it->pos_min, it->pos_max, it->n_tokens, (float) it->size() / 1024 / 1024);

                it = slot.prompt.checkpoints.erase(it);
                continue;
            }

            last = it->n_tokens;
            ++it;
        }

        while (slot.prompt.checkpoints.size() >= (size_t) params_base.n_ctx_checkpoints) {
            // make room for the new checkpoint, if needed
            const auto & cur = slot.prompt.checkpoints.front();

            SLT_WRN(slot, "erasing old context checkpoint (pos_min = %d, pos_max = %d, n_tokens = %" PRId64 ", size = %.3f MiB)\n",
                    cur.pos_min, cur.pos_max, cur.n_tokens, (float) cur.size() / 1024 / 1024);

            slot.prompt.checkpoints.erase(slot.prompt.checkpoints.begin());
        }

        auto & cur = slot.prompt.checkpoints.emplace_back();

        cur.id_task = id_task;

        // [TAG_CHECKPOINTS_FIX_POS_MIN]
        // TODO: here we incorrectly deterimne that the saved checkpoint data covers the [pos_min, pos_max] range
        //       this is not true for SWA models: https://github.com/ggml-org/llama.cpp/pull/24411#issuecomment-4677983225
        cur.update_pos(slot.prompt.n_tokens() - n_tokens_cur, pos_min, pos_max);

        cur.update_tgt(ctx_tgt, slot.id, LLAMA_STATE_SEQ_FLAGS_PARTIAL_ONLY);
        cur.update_dft(ctx_dft, slot.id, LLAMA_STATE_SEQ_FLAGS_PARTIAL_ONLY);
        // stash the draft's speculative state with the checkpoint
        common_speculative_get_state(spec.get(), slot.id, cur.data_spec);

        SLT_TRC(slot,
                "created context checkpoint %d of %d (pos_min = %d, pos_max = %d, n_tokens = %" PRId64 ", size = %.3f MiB)\n",
                (int) slot.prompt.checkpoints.size(), params_base.n_ctx_checkpoints, cur.pos_min,
                cur.pos_max, cur.n_tokens, (float) cur.size() / 1024 / 1024);
    }

    void process_single_task(server_task && task) {
        switch (task.type) {
            case SERVER_TASK_TYPE_COMPLETION:
            case SERVER_TASK_TYPE_INFILL:
            case SERVER_TASK_TYPE_EMBEDDING:
            case SERVER_TASK_TYPE_RERANK:
                {
                    // special case: if input is provided via CLI, tokenize it first
                    // otherwise, no need to tokenize as it's already done inside the HTTP thread
                    if (task.cli) {
                        if (!tokenize_cli_input(task)) {
                            break;
                        }
                    }
                    if (task.params.rerot_effective(task.type) &&
                        task.rerot_episode_id == 0) {
                        uint64_t generation = rerot_task_generation_next++;
                        if (generation == 0) {
                            generation = rerot_task_generation_next++;
                        }
                        task.assign_rerot_episodes(
                            rerot_task_episode_id_next, generation);
                    } else if (task.params.rerot_effective(task.type) &&
                               task.is_retry) {
                        task.rerot_bump_generation();
                    }

                    const int id_slot = task.id_slot;
                    const int id_task = task.id;

                    if (!rerot_person_admission_available(task)) {
                        SRV_DBG("RERoT person capacity is full, defer task, id_task = %d\n", id_task);
                        queue_tasks.defer(std::move(task));
                        break;
                    }

                    server_slot * slot = nullptr;
                    if (id_slot != -1) {
                        slot = get_slot_by_id(id_slot);
                    } else if (!task.cache_key.empty()) {
                        server_slot * slot_cache_key = get_slot_by_cache_key(task.cache_key);
                        if (slot_cache_key != nullptr && cache_key_slot_has_enough_similarity(*slot_cache_key, task)) {
                            slot = slot_cache_key;
                        }
                    }
                    if (slot == nullptr) {
                        slot = get_available_slot(task, task.cache_key.empty());
                    }

                    //
                    // slot scheduling logic
                    //

                    if (slot == nullptr) {
                        // if no slot is available, we defer this task for processing later
                        SRV_DBG("no slot is available, defer task, id_task = %d\n", id_task);
                        queue_tasks.defer(std::move(task));
                        break;
                    }

                    if (slot->is_processing()) {
                        // if requested slot is unavailable, we defer this task for processing later
                        SRV_DBG("requested slot is unavailable, defer task, id_task = %d\n", id_task);
                        queue_tasks.defer(std::move(task));
                        break;
                    }

                    if (task.is_parent()) {
                        // try getting free slots for all child tasks
                        size_t n_child_tasks = task.child_tasks.size();
                        std::vector<server_slot *> child_slots = get_free_slots(n_child_tasks, slot->id);
                        if (child_slots.size() < n_child_tasks) {
                            SRV_DBG("not enough free slots for child tasks, n_free = %zu, n_children = %zu, defer task, id_task = %d\n", child_slots.size(), n_child_tasks, id_task);
                            queue_tasks.defer(std::move(task));
                            break;
                        }
                        if (!launch_slots_with_parent_task(*slot, child_slots, std::move(task))) {
                            SRV_ERR("failed to launch slot with parent task, id_task = %d\n", id_task);
                            break; // drop the task
                        }
                    } else if (!launch_slot_with_task(*slot, std::move(task))) {
                        SRV_ERR("failed to launch slot with task, id_task = %d\n", id_task);
                        break; // drop the task
                    }

                    if (params_base.cache_idle_slots && params_base.n_ctx_kv == 0) {
                        for (auto & slot : slots) {
                            if (!slot.is_processing()) {
                                SLT_TRC(slot, "%s", "saving idle slot to prompt cache\n");

                                if (slot.prompt_save(*prompt_cache)) {
                                    SLT_DBG(slot, "%s", "__TEST_TAG_CACHE_IDLE_SLOT__\n");
                                    prompt_cache->update();
                                }

                                if (params_base.kv_unified && params_base.n_ctx_kv == 0) {
                                    // [TAG_IDLE_SLOT_CLEAR]
                                    slot.prompt_clear();
                                }
                            }
                        }
                    }
                } break;
            case SERVER_TASK_TYPE_CANCEL:
                {
                    retry_states.erase(task.id_target);

                    // A request owns the whole RERoT episode, not one cloned
                    // Lane slot. Cancel every writer and release archive/
                    // parked state atomically; releasing only the first clone
                    // would orphan siblings under the same response task id.
                    uint64_t cancelled_episode = 0;
                    for (const auto & entry : rerot_transport) {
                        if (entry.second && entry.second->response_task.id == task.id_target) {
                            cancelled_episode = entry.first;
                            break;
                        }
                    }
                    if (cancelled_episode == 0) {
                        for (const auto & slot : slots) {
                            if (slot.task && slot.task->id == task.id_target &&
                                slot.rerot_internal) {
                                cancelled_episode = slot.rerot_episode_id;
                                break;
                            }
                        }
                    }
                    if (cancelled_episode != 0 && rerot &&
                        rerot->episode(cancelled_episode)) {
                        rerot->hard_abort(cancelled_episode, "rerot_cancelled");
                        for (auto & slot : slots) {
                            if (slot.rerot_internal &&
                                slot.rerot_episode_id == cancelled_episode) {
                                slot.prompt.clear();
                                slot.release();
                            }
                        }
                        rerot_erase_episode(cancelled_episode);
                        rerot_start_next_waiting_root();
                        break;
                    }

                    // Ordinary requests and queued (not-yet-started) RERoT
                    // roots retain the stock one-task/one-slot cancellation.
                    for (auto & slot : slots) {
                        if (slot.task && slot.task->id == task.id_target) {
                            slot.release();
                            break;
                        }
                    }
                } break;
            case SERVER_TASK_TYPE_CONTROL:
                {
                    auto res = std::make_unique<server_task_result_control>();
                    res->id = task.id;

                    server_slot * slot = get_slot_by_cmpl_id(task.params.control_cmpl_id);
                    if (slot == nullptr) {
                        SRV_WRN("control %s on unknown completion id=%s, no live slot\n",
                                task.params.control_action.c_str(), task.params.control_cmpl_id.c_str());
                        res->success = false;
                        res->message = "no active completion for this id";
                        queue_results.send(std::move(res));
                        break;
                    }

                    if (task.params.control_action == "reasoning_end") {
                        // the budget sampler only exists when reasoning control was armed
                        if (!slot->task->params.sampling.reasoning_control) {
                            res->success = false;
                            res->message = "reasoning control not enabled for this completion";
                            queue_results.send(std::move(res));
                            break;
                        }
                        // act on the live slot mid generation, never defer
                        common_sampler_reasoning_budget_force(slot->smpl.get());
                        res->success = true;
                    } else {
                        res->success = false;
                        res->message = "unknown control action";
                    }

                    queue_results.send(std::move(res));
                } break;
            case SERVER_TASK_TYPE_NEXT_RESPONSE:
                {
                    // do nothing
                } break;
            case SERVER_TASK_TYPE_METRICS:
                {
                    json slots_data = json::array();

                    int n_idle_slots       = 0;
                    int n_processing_slots = 0;

                    for (server_slot & slot : slots) {
                        json slot_data = slot.to_json(slots_debug == 0);

                        if (slot.is_processing()) {
                            n_processing_slots++;
                        } else {
                            n_idle_slots++;
                        }

                        slots_data.push_back(slot_data);
                    }
                    SRV_DBG("n_idle_slots = %d, n_processing_slots = %d\n", n_idle_slots, n_processing_slots);

                    auto res = std::make_unique<server_task_result_metrics>();
                    res->id                  = task.id;
                    res->slots_data          = std::move(slots_data);
                    res->n_idle_slots        = n_idle_slots;
                    res->n_processing_slots  = n_processing_slots;
                    res->n_tasks_deferred    = queue_tasks.queue_tasks_deferred_size();
                    res->t_start             = metrics.t_start;

                    res->n_prompt_tokens_processed_total = metrics.n_prompt_tokens_processed_total;
                    res->t_prompt_processing_total       = metrics.t_prompt_processing_total;
                    res->n_tokens_predicted_total        = metrics.n_tokens_predicted_total;
                    res->t_tokens_generation_total       = metrics.t_tokens_generation_total;

                    res->n_tokens_max = metrics.n_tokens_max;

                    res->n_prompt_tokens_processed = metrics.n_prompt_tokens_processed;
                    res->t_prompt_processing       = metrics.t_prompt_processing;
                    res->n_tokens_predicted        = metrics.n_tokens_predicted;
                    res->t_tokens_generation       = metrics.t_tokens_generation;

                    res->n_decode_total          = metrics.n_decode_total;
                    res->n_busy_slots_total      = metrics.n_busy_slots_total;

                    res->tri_drain_total              = tri_drain_count;
                    res->tri_maintenance_total        = tri_maintenance_count;
                    res->tri_floor_exhausted_total    = tri_floor_exhausted_count;
                    res->tri_atomic_fallback_kv_total = tri_atomic_fallback_kv_count;
                    res->tri_atomic_fallback_recurrent_total = tri_atomic_fallback_recurrent_count;
                    res->tri_cells_freed_total        = tri_cells_freed_total;
                    res->tri_score_us_total           = tri_score_us_total;
                    res->tri_pack_us_total            = tri_pack_us_total;

                    res->tri_cells_before       = tri_cells_before;
                    res->tri_cells_after        = tri_cells_after;
                    res->tri_cells_freed        = tri_cells_freed;
                    res->tri_references_removed = tri_references_removed;
                    res->tri_target_references  = tri_target_references;
                    res->tri_hard_keep          = tri_hard_keep;
                    res->tri_shared_keep        = tri_shared_keep;

                    // FlashPrefill (MetricsIntegration owner for the GPU
                    // totals; ServerRouting owner for eligible/dense/policy).
                    // Successful-only cumulative totals; all zero while OFF.
                    res->fp_sparse_rows            = metrics.fp_gpu.sparse_rows;
                    res->fp_dense_packed           = metrics.fp_gpu.dense_packed;
                    for (int i = 0; i < 10; ++i) {
                        res->fp_dense_rows[i] = metrics.fp_gpu.dense_rows[i];
                    }
                    res->fp_selected_blocks        = metrics.fp_gpu.selected_blocks;
                    res->fp_corrected_blocks       = metrics.fp_gpu.corrected_blocks;
                    res->fp_visible_tokens         = metrics.fp_gpu.visible_tokens;
                    res->fp_exact_tokens           = metrics.fp_gpu.exact_tokens;
                    for (int i = 0; i < 2; ++i) {
                        res->fp_pool_rebuild[i] = metrics.fp_gpu.pool_rebuild[i];
                    }
                    for (int i = 0; i < 3; ++i) {
                        res->fp_plan_invalidations[i] = metrics.fp_gpu.plan_invalidations[i];
                    }
                    res->fp_scratch_live_bytes     = metrics.fp_gpu.scratch_live_bytes;
                    res->fp_scratch_peak_bytes     = metrics.fp_gpu.scratch_peak_bytes;
                    res->fp_layout_us_total        = metrics.fp_gpu.layout_us_total;
                    res->fp_layout_slices_measured = metrics.fp_gpu.layout_slices_measured;
                    res->fp_gpu_pool_us_total      = metrics.fp_gpu.gpu_pool_us_total;
                    res->fp_gpu_select_us_total    = metrics.fp_gpu.gpu_select_us_total;
                    res->fp_gpu_attn_us_total      = metrics.fp_gpu.gpu_attn_us_total;
                    res->fp_gpu_slices_measured    = metrics.fp_gpu.gpu_slices_measured;
                    res->fp_eligible_rows          = metrics.fp_eligible_rows;
                    for (int i = 0; i < 7; ++i) {
                        res->fp_dense_by_reason[i] = metrics.fp_dense_by_reason[i];
                    }
                    res->fp_policy_fingerprint     = metrics.fp_policy_fingerprint;
                    res->fp_has_policy             = metrics.fp_has_policy;

                    // XKV admission snapshot (enabled only). Store/runtime
                    // counters stay zero until the XKV runtime fills them;
                    // OFF leaves res->xkv empty so the schema is unchanged.
                    if (llama_xkv_is_enabled(params_base.xkv_mode)) {
                        llama_memory_admission_snapshot snap = {};
                        llama_memory_t mem_metrics = ctx_tgt ? llama_get_memory(ctx_tgt) : nullptr;
                        if (mem_metrics && llama_memory_get_admission_snapshot(mem_metrics, &snap)) {
                            auto & xm = res->xkv;
                            xm.has_admission = true;
                            xm.safe_next_ubatch = snap.safe_next_ubatch;
                            xm.limit_reason = llama_memory_limit_reason_name(snap.limit_reason);
                            xm.logical_capacity = snap.logical_capacity;
                            xm.logical_used = snap.logical_used;
                            xm.hot_capacity = snap.hot_capacity;
                            xm.hot_used = snap.hot_used;
                            xm.hot_free = snap.hot_free;
                            xm.hot_reserved = snap.hot_reserved;
                            xm.factor_live_bytes = snap.factor_live_bytes;
                            xm.factor_reserved_bytes = snap.factor_reserved_bytes;
                            xm.factor_budget_bytes = snap.factor_budget_bytes;
                            xm.factor_free_bytes = snap.factor_free_bytes;
                            xm.factor_safe_tokens = snap.factor_safe_tokens;
                            xm.workspace_live_bytes = snap.workspace_live_bytes;
                            xm.workspace_peak_bytes = snap.workspace_peak_bytes;
                            xm.workspace_budget_bytes = snap.workspace_budget_bytes;
                            xm.workspace_free_bytes = snap.workspace_free_bytes;
                            xm.workspace_safe_tokens = snap.workspace_safe_tokens;
                            xm.recurrent_capacity = snap.recurrent_capacity;
                            xm.recurrent_used = snap.recurrent_used;
                            xm.requested_profile = llama_xkv_storage_profile_name(params_base.xkv_storage_profile);
                            xm.requested_mode = llama_xkv_mode_name(params_base.xkv_mode);
                            xm.requested_a_k = ggml_type_name(params_base.xkv_factor_a_k);
                            xm.requested_b_k = ggml_type_name(params_base.xkv_factor_b_k);
                            xm.requested_a_v = ggml_type_name(params_base.xkv_factor_a_v);
                            xm.requested_b_v = ggml_type_name(params_base.xkv_factor_b_v);
                            xm.requested_landmark = ggml_type_name(params_base.xkv_landmark_type);
                            xm.requested_factorizer = llama_xkv_factorizer_name(params_base.xkv_factorizer);
                            xm.requested_balance = llama_xkv_factor_balance_name(params_base.xkv_factor_balance);
                            {
                                std::ostringstream s;
                                s << "0x" << std::hex << std::nouppercase << std::setw(16) << std::setfill('0') << params_base.xkv_seed;
                                xm.requested_seed = s.str();
                            }
                            {
                                // Canonical landmark codec table seed (777). No CLI
                                // override exists; the seal path uses this default
                                // verbatim, so requested == effective constant.
                                std::ostringstream s_lm;
                                s_lm << "0x" << std::hex << std::nouppercase << std::setw(16) << std::setfill('0') << (uint64_t) 777;
                                xm.requested_landmark_seed = s_lm.str();
                            }
                            if (std::fabs(params_base.triattention_ratio - (3.0 / 32.0)) < 1e-6) {
                                xm.tri_ratio_str = "3/32";
                            } else {
                                std::ostringstream s_ratio;
                                s_ratio << params_base.triattention_ratio;
                                xm.tri_ratio_str = s_ratio.str();
                            }
                            xm.tri_recent_window = 128;
                            if (model_tgt != nullptr) {
                                uint8_t msha[32] = {};
                                if (llama_model_source_artifact_sha256(model_tgt, msha)) {
                                    std::ostringstream ss;
                                    for (int i = 0; i < 32; ++i) {
                                        ss << std::hex << std::nouppercase << std::setw(2) << std::setfill('0') << (int) msha[i];
                                    }
                                    xm.model_sha256 = ss.str();
                                }
                            }
                            // Requested profile is the request; effective config comes
                            // ONLY from the observed runtime snapshot when armed.
                            // Missing/failed runtime => not_evaluated (fields stay
                            // zero), never a copy of the request.
                            llama_memory_xkv_runtime_snapshot rsnap = {};
                            // Zero-init contract: the filler sets struct_size and
                            // version; anything else is not_evaluated.
                            // observed marks XKV-enabled with a runtime present even
                            // when no snapshot is armed yet: ratios/timers then render
                            // as null/NaN (not_evaluated) instead of 0.0. Fully
                            // unobserved (OFF) snapshots keep exact all-zero output.
                            auto & xr0 = res->xkv;
                            xr0.observed = (mem_metrics != nullptr);
                            if (mem_metrics && llama_memory_get_xkv_runtime_snapshot(mem_metrics, &rsnap) &&
                                rsnap.armed && rsnap.version == 1 &&
                                rsnap.struct_size == sizeof(rsnap)) {
                                auto & xr = res->xkv;
                                xr.effective_profile = llama_xkv_storage_profile_name(rsnap.effective_profile);
                                xr.effective_mode = llama_xkv_mode_name(rsnap.mode);
                                if (rsnap.codec_a_k >= 0 && rsnap.codec_a_k < GGML_TYPE_COUNT) {
                                    xr.effective_a_k = ggml_type_name((enum ggml_type) rsnap.codec_a_k);
                                }
                                if (rsnap.codec_b_k >= 0 && rsnap.codec_b_k < GGML_TYPE_COUNT) {
                                    xr.effective_b_k = ggml_type_name((enum ggml_type) rsnap.codec_b_k);
                                }
                                if (rsnap.codec_a_v >= 0 && rsnap.codec_a_v < GGML_TYPE_COUNT) {
                                    xr.effective_a_v = ggml_type_name((enum ggml_type) rsnap.codec_a_v);
                                }
                                if (rsnap.codec_b_v >= 0 && rsnap.codec_b_v < GGML_TYPE_COUNT) {
                                    xr.effective_b_v = ggml_type_name((enum ggml_type) rsnap.codec_b_v);
                                }
                                if (rsnap.codec_landmark >= 0 && rsnap.codec_landmark < GGML_TYPE_COUNT) {
                                    xr.effective_landmark = ggml_type_name((enum ggml_type) rsnap.codec_landmark);
                                }
                                if (rsnap.codec_factorizer >= 0 && rsnap.codec_factorizer <= (int) LLAMA_XKV_FACTORIZER_CUDA) {
                                    xr.effective_factorizer = llama_xkv_factorizer_name((enum llama_xkv_factorizer) rsnap.codec_factorizer);
                                }
                                if (rsnap.codec_balance >= 0 && rsnap.codec_balance <= (int) LLAMA_XKV_FACTOR_BALANCE_DIAGONAL) {
                                    xr.effective_balance = llama_xkv_factor_balance_name((enum llama_xkv_factor_balance) rsnap.codec_balance);
                                }
                                xr.tri_calibration_fingerprint = rsnap.tri_calibration_fingerprint;
                                bool has_tri_sha = false;
                                for (int i = 0; i < 32; ++i) {
                                    if (rsnap.tri_calibration_sha256[i] != 0) { has_tri_sha = true; break; }
                                }
                                if (has_tri_sha) {
                                    std::ostringstream ss_tsha;
                                    for (int i = 0; i < 32; ++i) {
                                        ss_tsha << std::hex << std::nouppercase << std::setw(2) << std::setfill('0') << (int) rsnap.tri_calibration_sha256[i];
                                    }
                                    xr.tri_calibration_sha256 = ss_tsha.str();
                                }
                                if (std::fabs(rsnap.tri_ratio - (3.0 / 32.0)) < 1e-6) {
                                    xr.tri_ratio_str = "3/32";
                                } else if (rsnap.tri_ratio > 0.0) {
                                    std::ostringstream s_ratio;
                                    s_ratio << rsnap.tri_ratio;
                                    xr.tri_ratio_str = s_ratio.str();
                                }
                                xr.tri_recent_window = rsnap.tri_recent_window;
                                xr.tri_scorer_valid = rsnap.tri_scorer_valid;
                                xr.graph_timings_evaluated = rsnap.graph_timings_evaluated;
                                xr.pack_timer_evaluated = rsnap.pack_timer_evaluated;
                                xr.sr_counters_evaluated = rsnap.sr_counters_evaluated;
                                xr.spec_counters_evaluated = rsnap.spec_counters_evaluated;
                                {
                                    std::ostringstream s_eff_seed;
                                    s_eff_seed << "0x" << std::hex << std::nouppercase << std::setw(16) << std::setfill('0') << rsnap.factor_seed;
                                    xr.effective_seed = s_eff_seed.str();
                                }
                                {
                                    std::ostringstream s_eff_lm;
                                    s_eff_lm << "0x" << std::hex << std::nouppercase << std::setw(16) << std::setfill('0') << (uint64_t) 777;
                                    xr.effective_landmark_seed = s_eff_lm.str();
                                }
                                xr.compression_goal_evaluated = rsnap.compression_goal_evaluated;
                                xr.source = llama_xkv_source_name(rsnap.source);
                                xr.rank_k = rsnap.rank_k;
                                xr.rank_v = rsnap.rank_v;
                                xr.factor_streams = rsnap.factor_streams;
                                xr.codec_fingerprint = rsnap.codec_fingerprint;
                                xr.backend_fingerprint = rsnap.backend_fingerprint;
                                xr.source_fingerprint = rsnap.source_fingerprint;
                                xr.profile_fingerprint = rsnap.profile_fingerprint;
                                xr.config_fingerprint = rsnap.profile_fingerprint;
                                xr.actual_bytes = rsnap.factor_payload_bytes + rsnap.landmark_payload_bytes;
                                xr.nominal_bytes = rsnap.baseline_covered_bytes;
                                xr.hot_bytes = rsnap.hot_bytes;
                                xr.flat_bytes = rsnap.flat_bytes;
                                xr.factor_ak_bytes = rsnap.factor_ak_bytes;
                                xr.factor_bk_bytes = rsnap.factor_bk_bytes;
                                xr.factor_av_bytes = rsnap.factor_av_bytes;
                                xr.factor_bv_bytes = rsnap.factor_bv_bytes;
                                xr.factor_payload_bytes = rsnap.factor_payload_bytes;
                                xr.factor_metadata_bytes = rsnap.factor_metadata_bytes;
                                xr.factor_padding_bytes = rsnap.factor_padding_bytes;
                                xr.landmark_payload_bytes = rsnap.landmark_payload_bytes;
                                xr.landmark_metadata_bytes = rsnap.landmark_metadata_bytes;
                                xr.landmark_exception_bytes = rsnap.landmark_exception_bytes;
                                xr.index_bytes = rsnap.index_bytes;
                                xr.codec_shared_bytes = rsnap.codec_shared_bytes;
                                xr.decode_tile_cache_bytes = rsnap.decode_tile_cache_bytes;
                                xr.capture_bytes = rsnap.capture_bytes;
                                xr.candidate_bytes = rsnap.candidate_bytes;
                                // No separate staging ring in decoded-hot mode: transient
                                // staging lives inside the workspace arena / candidate
                                // scratch, so observed staging is 0 (never inferred).
                                xr.staging_bytes = 0;
                                xr.snapshot_pinned_bytes = rsnap.snapshot_pinned_bytes;
                                xr.allocator_live_bytes = rsnap.allocator_live_bytes;
                                xr.allocator_reserved_bytes = rsnap.allocator_reserved_bytes;
                                xr.device_peak_bytes = rsnap.device_peak_bytes;
                                xr.host_peak_bytes = rsnap.host_peak_bytes;
                                xr.unique_payloads = rsnap.unique_payloads;
                                xr.aliased_payloads = rsnap.aliased_payloads;
                                xr.baseline_same_rows_bytes = rsnap.baseline_covered_bytes;
                                xr.covered_compressed_bytes = rsnap.covered_compressed_bytes;
                                xr.factored_baseline_byte_coverage = rsnap.factored_baseline_byte_coverage;
                                xr.factor_quant_ratio = rsnap.factor_quant_ratio;
                                xr.net_extra_compression_ratio = rsnap.net_extra_compression_ratio;
                                xr.net_extra_compression_ratio_reserved = rsnap.net_extra_compression_ratio_reserved;
                                {
                                    const uint64_t peak_alloc = rsnap.device_peak_bytes + rsnap.host_peak_bytes;
                                    xr.net_extra_compression_ratio_peak =
                                        (rsnap.baseline_covered_bytes > 0 && peak_alloc > 0)
                                            ? (double) rsnap.baseline_covered_bytes / (double) peak_alloc
                                            : 0.0;
                                }
                                xr.ratios_evaluated = rsnap.ratios_evaluated;
                                xr.seal_timers_evaluated = rsnap.seal_timers_evaluated;
                                xr.quant_timers_evaluated = rsnap.quant_timers_evaluated;
                                xr.seal_seconds = rsnap.seal_seconds;
                                xr.factor_quant_seconds = rsnap.factor_quant_seconds;
                                xr.landmark_quant_seconds = rsnap.landmark_quant_seconds;
                                xr.select_seconds = rsnap.select_seconds;
                                xr.refine_seconds = rsnap.refine_seconds;
                                xr.reconstruct_seconds = rsnap.reconstruct_seconds;
                                xr.read_seconds = rsnap.read_seconds;
                                xr.pack_seconds = rsnap.pack_seconds;
                                xr.segments_sealed = rsnap.segments_sealed;
                                for (int ri = 0; ri < LLAMA_MEMORY_XKV_SKIP_REASON_COUNT; ++ri) {
                                    const uint64_t c = rsnap.skip_counts[ri];
                                    if (c > 0) {
                                        xr.segments_skipped_by_reason[llama_memory_xkv_skip_reason_name(
                                            (enum llama_memory_xkv_skip_reason) ri)] += c;
                                    }
                                }
                                xr.sr_selected_rows = rsnap.sr_selected_rows;
                                xr.sr_fragments = rsnap.sr_fragments;
                                xr.effective_chunk_size = rsnap.effective_chunk_size;
                                xr.landmark_refine_rows = rsnap.landmark_refine_rows;
                                xr.landmark_refine_cap_hits = rsnap.landmark_refine_cap_hits;
                                xr.spec_stale_total = rsnap.spec_stale_total;
                                xr.transaction_abort_total = rsnap.transaction_abort_total;
                                xr.synchronize_total = rsnap.synchronize_total;
                                xr.compression_goal_met = rsnap.compression_goal_met;
                            }
                            if (snap.limit_reason != LLAMA_MEMORY_LIMIT_NONE) {
                                xm.throttle_reason = xm.limit_reason;
                            }
                        }
                    }

                    if (rerot) {
                        const uint32_t people_cap = params_base.rerot_person_max > 0
                            ? params_base.rerot_person_max
                            : (params_base.n_parallel > 0 ? (uint32_t) params_base.n_parallel : (uint32_t) slots.size());
                        rerot_metrics.people_capacity = people_cap;
                        rerot_metrics.people_resident = rerot_transport.size();
                        uint64_t runnable_people = 0;
                        uint64_t waiting_people = 0;
                        for (const auto & [ep_id, ep_trans] : rerot_transport) {
                            const auto * episode = rerot->episode(ep_id);
                            if (episode && (!episode->running.empty() || !episode->ready_queue.empty() || !episode->suspended.empty())) {
                                ++runnable_people;
                            }
                        }
                        for (const auto & waiting : slots) {
                            if (waiting.state == SLOT_STATE_DONE_PROMPT && waiting.task &&
                                waiting.task->params.rerot_effective(waiting.task->type)) {
                                ++waiting_people;
                            }
                        }
                        rerot_metrics.people_runnable = runnable_people;
                        rerot_metrics.people_waiting = waiting_people;

                        rerot_metrics.pens_capacity = rerot->pen_capacity();
                        rerot_metrics.pens_allocated = rerot->pens_allocated();
                        rerot_metrics.pens_running = rerot->pens_running();
                        rerot_metrics.pens_suspended = rerot->pens_suspended();
                        uint64_t total_queue = 0;
                        uint64_t max_pens_person = 0;
                        for (const auto & [ep_id, ep] : rerot_transport) {
                            const auto * episode = rerot->episode(ep_id);
                            if (episode) {
                                total_queue += episode->ready_queue.size();
                            }
                            const auto p_count = rerot->pens_for_person(ep_id).size();
                            if (p_count > max_pens_person) {
                                max_pens_person = p_count;
                            }
                        }
                        rerot_metrics.pen_queue_depth = total_queue;
                        rerot_metrics.pens_per_person_max_observed = std::max(rerot_metrics.pens_per_person_max_observed, max_pens_person);
                        if (rerot_metrics.pens_capacity > 0) {
                            rerot_metrics.pen_utilization = (double) rerot_metrics.pens_allocated / (double) rerot_metrics.pens_capacity;
                        }

                        // Recurrent brain and hand byte estimates (§§B.1.4, B.14)
                        if (ctx_tgt) {
                            const uint32_t b_resident = std::max<uint32_t>(1, (uint32_t) rerot_metrics.people_resident);
                            const uint32_t p_alloc = std::max<uint32_t>(1, (uint32_t) rerot_metrics.pens_allocated);
                            rerot_metrics.brain_bytes = (uint64_t) b_resident * 54ULL * 1024ULL * 1024ULL;
                            rerot_metrics.hand_bytes = (uint64_t) p_alloc * 6ULL * 1024ULL * 1024ULL;
                            rerot_metrics.grouped_scratch_bytes = (uint64_t) p_alloc * 2ULL * 1024ULL * 1024ULL;
                        }
                    }
                    res->rerot = rerot_metrics;

                    if (task.metrics_reset_bucket) {
                        metrics.reset_bucket();
                    }
                    queue_results.send(std::move(res));
                } break;
            case SERVER_TASK_TYPE_SLOT_SAVE:
                {
                    const int id_slot = task.slot_action.id_slot;
                    server_slot * slot = get_slot_by_id(id_slot);
                    if (slot == nullptr) {
                        send_error(task, "Invalid slot ID", ERROR_TYPE_INVALID_REQUEST);
                        break;
                    }
                    if (!check_slot_no_media(*slot, task.id)) {
                        break;
                    }
                    if (slot->is_processing()) {
                        // if requested slot is unavailable, we defer this task for processing later
                        SRV_DBG("requested slot is unavailable, defer task, id_task = %d\n", task.id);
                        queue_tasks.defer(std::move(task));
                        break;
                    }

                    // RERoT v1 refusal (§§25,A.8): no per-slot persist of an
                    // active episode Lane (tree/run/epoch/parked/archive/MTP
                    // lineage has no versioned format yet). OFF: false.
                    if (rerot_owns_slot(id_slot)) {
                        send_error(task, "RERoT episode active: manual slot save is unsupported in v1 "
                            "(no versioned RERoT state with REROT_STATE_MAGIC/VERSION + fingerprint)", ERROR_TYPE_INVALID_REQUEST);
                        break;
                    }

                    const int64_t t_start = ggml_time_us();

                    std::string filename = task.slot_action.filename;
                    std::string filepath = task.slot_action.filepath;

                    const llama_tokens tokens = slot->prompt.tokens.get_text_tokens();
                    const size_t token_count = tokens.size();
                    const size_t nwrite = llama_state_seq_save_file(ctx_tgt, filepath.c_str(), slot->id, tokens.data(), token_count);

                    // FlashPrefill store isolation: when enabled, the saved KV
                    // bytes carry the 64-byte core envelope (store identity)
                    // ahead of the memory payload, validated before any KV is
                    // consumed on restore. No sidecar is written: the envelope
                    // is the single authority. OFF: legacy bytes unchanged.

                    const int64_t t_end = ggml_time_us();
                    const double t_save_ms = (t_end - t_start) / 1000.0;

                    auto res = std::make_unique<server_task_result_slot_save_load>();
                    res->id       = task.id;
                    res->id_slot  = id_slot;
                    res->filename = filename;
                    res->is_save  = true;
                    res->n_tokens = token_count;
                    res->n_bytes  = nwrite;
                    res->t_ms     = t_save_ms;
                    queue_results.send(std::move(res));
                } break;
            case SERVER_TASK_TYPE_SLOT_RESTORE:
                {
                    const int id_slot = task.slot_action.id_slot;
                    server_slot * slot = get_slot_by_id(id_slot);
                    if (slot == nullptr) {
                        send_error(task, "Invalid slot ID", ERROR_TYPE_INVALID_REQUEST);
                        break;
                    }
                    if (slot->is_processing()) {
                        // if requested slot is unavailable, we defer this task for processing later
                        SRV_DBG("requested slot is unavailable, defer task, id_task = %d\n", task.id);
                        queue_tasks.defer(std::move(task));
                        break;
                    }

                    // RERoT v1 refusal (§§25,A.8): no manual restore into an
                    // active episode Lane; future restores must match
                    // REROT_STATE_MAGIC/VERSION + model/rope/Tri fingerprint.
                    // OFF: false.
                    if (rerot_owns_slot(id_slot)) {
                        send_error(task, "RERoT episode active: manual slot restore is unsupported in v1", ERROR_TYPE_INVALID_REQUEST);
                        break;
                    }

                    // FlashPrefill store isolation: no pre-check here — the
                    // single authority is the core envelope validated inside
                    // the load below (before any KV is consumed). A mismatched
                    // identity (policy, process, context, or adapter) fails
                    // the load (nread == 0) with a re-prefill error; OFF loads
                    // keep exact old behavior. Rejected restores leave the
                    // slot salvageable so the client can re-prefill.
                    const int64_t t_start = ggml_time_us();

                    std::string filename = task.slot_action.filename;
                    std::string filepath = task.slot_action.filepath;

                    llama_tokens tokens;
                    tokens.resize(slot->n_ctx);
                    size_t token_count = 0;
                    size_t nread = llama_state_seq_load_file(ctx_tgt, filepath.c_str(), slot->id, tokens.data(), tokens.size(), &token_count);
                    if (nread == 0) {
                        slot->prompt.clear(); // KV may already been invalidated?
                        if (fp_enabled) {
                            send_error(task, "Unable to restore slot: save file was produced under a different FlashPrefill store identity (policy, process, context, or adapter mismatch) or the cache is full: re-prefill instead of restoring", ERROR_TYPE_INVALID_REQUEST);
                        } else {
                            send_error(task, "Unable to restore slot, no available space in KV cache or invalid slot save file", ERROR_TYPE_INVALID_REQUEST);
                        }
                        break;
                    }
                    tokens.resize(token_count);
                    slot->prompt.clear();
                    slot->prompt.tokens.insert(tokens);
                    slot->triattention_compressed =
                        llama_memory_seq_get_kv_used(llama_get_memory(ctx_tgt), slot->id) < token_count;

                    const int64_t t_end = ggml_time_us();
                    const double t_restore_ms = (t_end - t_start) / 1000.0;

                    auto res = std::make_unique<server_task_result_slot_save_load>();
                    res->id       = task.id;
                    res->id_slot  = id_slot;
                    res->filename = filename;
                    res->is_save  = false;
                    res->n_tokens = token_count;
                    res->n_bytes  = nread;
                    res->t_ms     = t_restore_ms;
                    queue_results.send(std::move(res));
                } break;
            case SERVER_TASK_TYPE_SLOT_ERASE:
                {
                    const int id_slot = task.slot_action.id_slot;
                    server_slot * slot = get_slot_by_id(id_slot);
                    if (slot == nullptr) {
                        send_error(task, "Invalid slot ID", ERROR_TYPE_INVALID_REQUEST);
                        break;
                    }
                    // Gate on slot content, consistent with save/restore.
                    if (!check_slot_no_media(*slot, task.id)) {
                        break;
                    }
                    if (slot->is_processing()) {
                        // if requested slot is unavailable, we defer this task for processing later
                        SRV_DBG("requested slot is unavailable, defer task, id_task = %d\n", task.id);
                        queue_tasks.defer(std::move(task));
                        break;
                    }

                    // Erase token cache
                    const size_t n_erased = slot->prompt.tokens.size();

                    slot->prompt_clear();

                    auto res = std::make_unique<server_task_result_slot_erase>();
                    res->id       = task.id;
                    res->id_slot  = id_slot;
                    res->n_erased = n_erased;
                    queue_results.send(std::move(res));
                } break;
            case SERVER_TASK_TYPE_GET_LORA:
                {
                    // TODO @ngxson : make lora_adapters a dedicated member of server_context
                    auto & loras = params_base.lora_adapters;
                    auto res = std::make_unique<server_task_result_get_lora>();
                    res->id = task.id;
                    for (size_t i = 0; i < loras.size(); ++i) {
                        auto & lora = loras[i];
                        std::string alora_invocation_string = "";
                        const uint64_t n_alora_tokens = llama_adapter_get_alora_n_invocation_tokens(lora.ptr);
                        llama_tokens alora_invocation_tokens;
                        if (n_alora_tokens) {
                            const llama_token * alora_tokens = llama_adapter_get_alora_invocation_tokens(lora.ptr);
                            for (uint64_t j = 0; j < n_alora_tokens; ++j) {
                                alora_invocation_string += common_token_to_piece(vocab, alora_tokens[j]);
                                alora_invocation_tokens.push_back(alora_tokens[j]);
                            }
                        }
                        res->loras.push_back(server_task_result_get_lora::lora{
                            lora,
                            alora_invocation_string,
                            alora_invocation_tokens,
                        });
                    }
                    queue_results.send(std::move(res));
                } break;
            case SERVER_TASK_TYPE_SET_LORA:
                {
                    auto new_loras = construct_lora_list(task.set_lora);
                    // logging
                    for (size_t i = 0; i < new_loras.size(); ++i) {
                        SRV_TRC("set lora adapter idx=%zu scale=%f\n", i, new_loras[i].scale);
                    }
                    // TODO @ngxson : make lora_adapters a dedicated member of server_context
                    params_base.lora_adapters = new_loras;
                    auto res = std::make_unique<server_task_result_apply_lora>();
                    res->id = task.id;
                    queue_results.send(std::move(res));
                } break;
        }
    }

    void iterate(std::vector<server_slot> & slots, std::function<void(server_slot &)> callback) {
        for (auto & slot : slots) {
            try {
                callback(slot);
            } catch (const std::exception & e) {
                SLT_ERR(slot, "got exception: %s\n", e.what());
                if (slot.rerot_internal && rerot &&
                    rerot->episode(slot.rerot_episode_id)) {
                    rerot->hard_abort(
                        slot.rerot_episode_id,
                        std::string("rerot_backend_error: ") + e.what());
                    rerot_propagate_hard_abort(slot.rerot_episode_id);
                } else {
                    send_error(slot, std::string("got exception: ") + e.what(), ERROR_TYPE_SERVER);
                    slot.release();
                }
            }
        }
    }

    void iterate(std::vector<server_slot *> & slots, std::function<void(server_slot &)> callback) {
        for (auto & slot : slots) {
            try {
                callback(*slot);
            } catch (const std::exception & e) {
                SLT_ERR(*slot, "got exception: %s\n", e.what());
                if (slot->rerot_internal && rerot &&
                    rerot->episode(slot->rerot_episode_id)) {
                    rerot->hard_abort(
                        slot->rerot_episode_id,
                        std::string("rerot_backend_error: ") + e.what());
                    rerot_propagate_hard_abort(slot->rerot_episode_id);
                } else {
                    send_error(*slot, std::string("got exception: ") + e.what(), ERROR_TYPE_SERVER);
                    slot->release();
                }
            }
        }
    }

    void abort_all_slots(const std::string & reason) {
        retry_states.clear();

        // RERoT hard-abort propagation (§20): a fatal scheduler error while
        // an episode is active must not leave parked/archive lineage or a
        // context episode gate behind. OFF: rerot_active false, no change.
        if (rerot_active()) {
            rerot_propagate_hard_abort();
        }

        for (auto & slot : slots) {
            if (slot.is_processing()) {
                send_error(slot, reason, ERROR_TYPE_SERVER);
                slot.release();
            }
        }
    }

    // @ngxson : for debugging only
    int64_t t_pre_decode  = 0;
    int64_t t_decode      = 0;
    int64_t t_post_decode = 0;
    int64_t t_sampl       = 0;
    int64_t n_pre_decode  = 0;
    int64_t n_decode      = 0;
    int64_t n_post_decode = 0;
    int64_t n_sampl       = 0;
// #define DEBUG_TIMINGS
#ifdef DEBUG_TIMINGS
    struct scoped_timer {
        int64_t & t;
        int64_t & n;
        int64_t t_start;
        scoped_timer(int64_t & t_, int64_t & n_) : t(t_), n(n_) {
            t_start = ggml_time_us();
        }
        ~scoped_timer() {
            t += ggml_time_us() - t_start;
            n++;
        }
    };
#else
    struct scoped_timer {
        scoped_timer(int64_t &, int64_t &) {}
        ~scoped_timer() {}
    };
#endif

    bool is_prefill_slot(const server_slot & slot) const {
        return slot.state == SLOT_STATE_STARTED || slot.state == SLOT_STATE_PROCESSING_PROMPT;
    }

    server_inference_mode select_inference_mode() {
        if (id_slot_prefill >= 0 && id_slot_prefill < (int32_t) slots.size()) {
            if (is_prefill_slot(slots[id_slot_prefill])) {
                return SERVER_INFERENCE_MODE_PREFILL;
            }
        }

        id_slot_prefill = -1;
        for (auto & slot : slots) {
            if (is_prefill_slot(slot)) {
                id_slot_prefill = slot.id;
                return SERVER_INFERENCE_MODE_PREFILL;
            }
        }

        return SERVER_INFERENCE_MODE_DECODE;
    }

    void update_inference_mode() {
        const auto new_mode = select_inference_mode();
        if (new_mode == inference_mode) {
            return;
        }

        llama_synchronize(ctx_tgt);
        if (ctx_dft) {
            llama_synchronize(ctx_dft);
        }

        inference_mode = new_mode;
        SRV_DBG("inference mode = %s, prefill slot = %d\n",
                inference_mode == SERVER_INFERENCE_MODE_PREFILL ? "prefill" : "decode", id_slot_prefill);
    }

    void update_slots() {
#ifdef DEBUG_TIMINGS
        static int64_t t_prev = 0;
        int64_t t_start = ggml_time_us();
        if (t_start - t_prev > 5 * 1000 * 1000) { // every 5 seconds
            t_prev = t_start;
            SRV_INF("n_pre_decode      = %" PRId64 "\n", n_pre_decode);
            SRV_INF("avg t_pre_decode  = %f ms\n", (double) t_pre_decode / n_pre_decode / 1000.0);
            SRV_INF("avg t_decode      = %f ms\n", (double) t_decode / n_decode / 1000.0);
            SRV_INF("avg t_post_decode = %f ms\n", (double) t_post_decode / n_post_decode / 1000.0);
            SRV_INF("avg t_sampl       = %f ms\n", (double) t_sampl / n_sampl / 1000.0);
        }
#endif

        // check if all slots are idle
        {
            bool all_idle = true;

            for (auto & slot : slots) {
                if (slot.is_processing()) {
                    all_idle = false;
                    break;
                }
            }

            if (all_idle) {
                SRV_TRC("%s", "all slots are idle\n");
                return; // skip further processing

            } else {
                SRV_DBG("%s", "posting NEXT_RESPONSE\n");

                server_task task(SERVER_TASK_TYPE_NEXT_RESPONSE);
                task.id = queue_tasks.get_new_id();
                queue_tasks.post(std::move(task));
            }
        }

        update_inference_mode();

        // FlashPrefill store isolation: enforce the RAM prompt-cache policy
        // stamp before building or consuming any batch in this iteration.
        fp_guard_prompt_cache();

        // RERoT frontier entry (§§19.3,20): one frontier is one atomic budget
        // unit; when hard limits are crossed the whole episode HARD_ABORTs
        // here instead of running a partial Lane subset. OFF: no-op true.
        if (!rerot_frontier_enter()) {
            return;
        }

        if (!ensure_next_kv_capacity()) {
            return;
        }

        try {
            scoped_timer t(t_pre_decode, n_pre_decode);
            pre_decode();
            batch.render();
        } catch (const std::exception & e) {
            SRV_ERR("pre_decode() failed: %s\n", e.what());
            abort_all_slots("pre_decode() failed: " + std::string(e.what()));
        }

        GGML_ASSERT(batch.slot_batched || batch.size() == 0);

        if (batch.slot_batched) {
            auto & slot_batched      = batch.slot_batched;
            auto & alora_scale       = batch.alora_scale;
            auto & alora_disabled_id = batch.alora_disabled_id;

            // TODO @ngxson : alora handling is too messy, need to refactor it to be more clear and maintainable
            // apply lora, only need to do it once per batch
            // A refusal (FlashPrefill enabled atop an active RERoT episode) is
            // a request failure, never silent: the core applied nothing, so the
            // batched slots must not decode under the stale adapters. Fail
            // exactly the batched (same-lora) slots and return; the next
            // iteration rebuilds the batch from the survivors. OFF and
            // identical-set calls always succeed, so this path is unreachable
            // for them and old behavior is byte-identical.
            if (!common_set_adapter_lora(ctx_tgt, slot_batched->lora)) {
                std::set<int32_t> refused;
                for (int32_t i = 0; i < batch.size(); ++i) {
                    refused.insert(batch.tokens[i].id_slot);
                }
                for (const int32_t id_slot : refused) {
                    server_slot * slot = get_slot_by_id(id_slot);
                    if (slot != nullptr && slot->is_processing()) {
                        send_error(*slot, "LoRA adapter change refused: FlashPrefill is enabled atop an active RERoT episode — end the episode (or disable the policy) and retry");
                        slot->prompt_clear();
                        slot->release();
                    }
                }
                return;
            }

            // if the lora is temporarily disabled for an alora, re-enable it
            // for next time
            if (alora_scale > 0.0f) {
                SRV_DBG("re-enabling alora with scale %f\n", alora_scale);
                slot_batched->lora[alora_disabled_id].scale = alora_scale;
            }

            llama_set_embeddings(ctx_tgt, slot_batched->need_embd());
        }

        llama_batch batch_view;
        int32_t off_next = 0;
        int32_t n_batch = llama_n_batch(ctx_tgt);
        for (int32_t off = 0; off < batch.size(); off = off_next) {
            const int32_t n_tokens = std::min(n_batch, batch.size() - off);
            try {
                scoped_timer t(t_decode, n_decode);
                // TODO @ngxson : maybe handle n_batch == 1 here instead of inside decode()

                batch_view = batch.get_view(off, n_tokens);
                // FlashPrefill: borrowed exec view sliced by the same off/n
                // as the batch view, so every retry keeps stage, token
                // offset, output row, sequence, and reader view aligned to
                // the same source row. OFF: empty view (no allocation).
                // decode() validates the view and dispatches to
                // llama_decode_with_flashprefill() (ContextIntegration owns
                // the pre-async copy + per-ubatch propagation).
                const llama_flashprefill_exec fp_exec = batch.fp_exec_view(off, n_tokens);
                bool ok = decode(n_batch, off, batch_view, fp_exec);
#ifdef DEBUG_TIMINGS
                llama_synchronize(ctx_tgt);
#endif

                if (ok) {
                    // move the head of the batch forward with the number of tokens we just processed
                    off_next = off + n_tokens;

                    // on successful decode, restore the original batch size
                    n_batch = llama_n_batch(ctx_tgt);
                } else {
                    // try again with the updated n_batch
                    continue;
                }
            } catch (const std::exception & e) {
                SRV_ERR("decode() failed: %s\n", e.what());
                abort_all_slots("decode() failed: " + std::string(e.what()));
                break; // stop any further processing
            }

            try {
                scoped_timer t(t_post_decode, n_post_decode);
                post_decode(n_tokens, off, batch_view);
            } catch (const std::exception & e) {
                SRV_ERR("post_decode() failed: %s\n", e.what());
                abort_all_slots("post_decode() failed: " + std::string(e.what()));
                break; // stop any further processing
            }
        }

        // RERoT barrier/fence poll (Stage 7, §§17,21): all gates inside are
        // episode-active checks, so OFF costs one null + one zero compare.
        // The full per-token frontier loop (plan/commit/finish_frontier) will
        // drive these flags; this poll only ensures a pending barrier still
        // refreshes read-only logits and a finalized single survivor still
        // takes the acquire fence + serial-tail transition even if the loop
        // lands in a later slice.
        if (rerot_active()) {
            std::vector<uint64_t> active_eps;
            if (!rerot_transport.empty()) {
                for (const auto & kv : rerot_transport) {
                    active_eps.push_back(kv.first);
                }
            } else if (rerot_episode_id != 0) {
                active_eps.push_back(rerot_episode_id);
            }
            for (uint64_t ep_id : active_eps) {
                if (const server_rerot_episode * ep = rerot->episode(ep_id)) {
                    if (ep->topology_barrier_pending && !ep->hard_aborted && !ep->serial_tail) {
                        rerot_on_topology_barrier(true, ep_id);
                    }
                    if (ep->finalizing && !ep->hard_aborted && !ep->serial_tail &&
                        ep->ready_queue.empty() && ep->starting.empty() && ep->running.size() == 1) {
                        rerot_begin_serial_tail(ep_id, *ep->running.begin());
                    }
                    if (ep->hard_aborted) {
                        rerot_propagate_hard_abort(ep_id);
                    }
                }
            }
        }
    }

    void pre_decode() {
        // apply context-shift if needed
        // TODO: simplify and improve
        iterate(slots, [&](server_slot & slot) {
            if (inference_mode != SERVER_INFERENCE_MODE_DECODE) {
                return;
            }

            if (slot.state == SLOT_STATE_GENERATING && slot.prompt.n_tokens() + 1 >= slot.n_ctx) {
                if (!params_base.ctx_shift) {
                    // this check is redundant (for good)
                    // we should never get here, because generation should already stopped in process_token()
                    send_error(slot, "context shift is disabled", ERROR_TYPE_SERVER);
                    slot.release();
                    return;
                }

                if (mctx) {
                    // we should never reach this because params_base.ctx_shift is automatically disabled if mmproj is loaded
                    // we don't support ctx_shift because an image chunk may contains multiple tokens
                    GGML_ABORT("not supported by multimodal");
                }

                if (slot.task->is_parent() || slot.task->is_child()) {
                    send_error(slot, "context shift cannot be used for shared prompt", ERROR_TYPE_SERVER);
                    slot.release();
                    return;
                }

                // RERoT semantic context shift (§25.2, §A.9): no linear seq_rm/seq_add shift
                // on an active episode Lane. Shared history uses episode-aware
                // semantic truncation (oldest PUBLIC region dropped for all
                // readers + run-table repack + layout/publish bump + MTP
                // invalidation, recurrent state never rewritten). OFF: false.
                if (rerot_owns_slot(slot.id)) {
                    server_rerot_shift_result shift_res;
                    std::string shift_err;
                    const int n_left = slot.prompt.n_tokens() - 4;
                    const int n_discard = slot.task->params.n_discard ? slot.task->params.n_discard : std::max(1, n_left / 2);
                    if (rerot->context_shift(slot.rerot_episode_id, (uint64_t) n_discard, &shift_res, &shift_err)) {
                        if (shift_res.tokens_removed > 0) {
                            if (ctx_tgt) {
                                llama_rerot_context_apply_shift(
                                    ctx_tgt,
                                    slot.rerot_episode_id,
                                    shift_res.tokens_removed,
                                    shift_res.new_layout_epoch,
                                    shift_res.new_publish_epoch);
                            }
                            ++rerot_metrics.context_shifts;
                            SLT_INF(slot, "RERoT episode %" PRIu64 " context shifted: removed %" PRIu64 " tokens, %u runs truncated\n",
                                slot.rerot_episode_id, shift_res.tokens_removed, shift_res.runs_truncated);
                            rerot_on_topology_barrier(true, slot.rerot_episode_id);
                            return;
                        }
                    }
                    // If no unpinned public tokens could be removed, then context is genuinely exhausted.
                    rerot->hard_abort(
                        slot.rerot_episode_id,
                        "rerot_resource_exhausted: active episode reached context-shift boundary with no unpinned public tokens");
                    rerot_propagate_hard_abort(slot.rerot_episode_id);
                    return;
                }

                // Shift context
                int n_keep = slot.task->params.n_keep < 0 ? slot.task->n_tokens() : slot.task->params.n_keep;

                if (add_bos_token) {
                    n_keep += 1;
                }

                n_keep = std::min(slot.n_ctx - 4, n_keep);

                const int n_left    = slot.prompt.n_tokens() - n_keep;
                int       n_discard = slot.task->params.n_discard ? slot.task->params.n_discard : (n_left / 2);

                // ref: https://github.com/ggml-org/llama.cpp/pull/24786
                n_discard = std::clamp(n_discard, 0, std::max(0, n_left - 1));

                SLT_WRN(slot, "slot context shift, n_keep = %d, n_left = %d, n_discard = %d\n", n_keep, n_left, n_discard);

                slot.mem.seq_rm (slot.id, n_keep            , n_keep + n_discard);
                slot.mem.seq_add(slot.id, n_keep + n_discard, slot.prompt.tokens.pos_next(), -n_discard);

                // add generated tokens to cache
                // ref: https://github.com/ggml-org/llama.cpp/pull/16818#discussion_r2473269481
                {
                    GGML_ASSERT(!slot.prompt.tokens.has_mtmd);

                    llama_tokens new_tokens = slot.prompt.tokens.get_tokens(); // copy
                    for (size_t i = n_keep + n_discard; i < new_tokens.size(); i++) {
                        new_tokens[i - n_discard] = new_tokens[i];
                    }

                    new_tokens.resize(slot.prompt.tokens.size() - n_discard);

                    slot.prompt.clear();
                    slot.prompt.tokens.insert(new_tokens);
                }

                slot.truncated = true;
            }
        });

        // start populating the batch for this iteration
        batch.clear();

        // FlashPrefill: bound the sidecar once per iteration while enabled so
        // per-row pushes never regrow; OFF skips this entirely (no alloc).
        if (fp_enabled && batch.n_tokens_alloc > 0) {
            batch.fp_rows.reserve((size_t) batch.n_tokens_alloc);
        }

        // track if given slot can be batched with slots already in the batch
        auto & slot_batched = batch.slot_batched;

        std::vector<server_slot *> generating;
        std::vector<server_slot *> drafting;

        // determine which slots are generating and drafting
        iterate(slots, [&](server_slot & slot) {
            if (inference_mode != SERVER_INFERENCE_MODE_DECODE) {
                return;
            }

            if (slot.state != SLOT_STATE_GENERATING) {
                return;
            }

            // check if we can batch this slot with the previous one
            if (!slot_batched) {
                slot_batched = &slot;
            } else if (!slot_batched->can_batch_with(slot)) {
                return;
            }

            generating.push_back(&slot);

            if (spec) {
                common_speculative_get_draft_params(spec.get(), slot.id).drafting = false;

                if (!slot.token_append_chunk.empty()) {
                    return;
                }

                // RERoT MTP: drafts bind to the reader view stamp. Stale drafts
                // (peer PUBLIC / topology / layout change) restore checkpoint
                // and re-draft. Forced control injection never drafts. Do not
                // permanently disable drafting for episode lanes.
                if (rerot_owns_slot(slot.id)) {
                    if (slot.rerot_has_draft_stamp && ctx_tgt != nullptr &&
                        llama_rerot_mtp_is_stale(ctx_tgt, slot.id, &slot.rerot_draft_stamp)) {
                        slot.spec_ckpt.load_tgt(slot.ctx_tgt, slot.id, get_spec_checkpoint_flags(slot.ctx_tgt));
                        if (slot.ctx_dft) {
                            slot.spec_ckpt.load_dft(slot.ctx_dft, slot.id, get_spec_checkpoint_flags(slot.ctx_dft));
                        }
                        common_speculative_set_state(spec.get(), slot.id, slot.spec_ckpt.data_spec);
                        slot.mem.seq_rm(slot.id, slot.spec_ckpt.pos_max + 1, -1);
                        slot.spec_draft.clear();
                        slot.spec_i_batch.clear();
                        slot.rerot_has_draft_stamp = false;
                    }
                    if (slot.rerot_injection != server_rerot_injection_kind::none) {
                        return;
                    }
                }

                const bool use_ckpt_tgt = ctx_tgt_seq_rm_type == COMMON_CONTEXT_SEQ_RM_TYPE_FULL;
                const bool use_ckpt_dft = ctx_dft_seq_rm_type == COMMON_CONTEXT_SEQ_RM_TYPE_FULL;

                const int n_draft_max = slot.get_n_draft_max();

                if (n_draft_max > 0) {
                    GGML_ASSERT(slot.can_speculate());

                    if (!slot.spec_draft.empty()) {
                        // we have a previous (partial) draft to reuse
                        if (use_ckpt_tgt) {
                            GGML_ASSERT(!slot.spec_ckpt.empty());
                        }
                    } else {
                        GGML_ASSERT(slot.spec_i_batch.empty());

                        slot.spec_ckpt.update_pos(
                                slot.prompt.n_tokens(),
                                llama_memory_seq_pos_min(llama_get_memory(ctx_tgt), slot.id),
                                llama_memory_seq_pos_max(llama_get_memory(ctx_tgt), slot.id));

                        if (use_ckpt_dft) {
                            slot.spec_ckpt.update_dft(ctx_dft, slot.id, get_spec_checkpoint_flags(ctx_dft));
                        }
                        slot.spec_ckpt.data_spec.clear();
                        common_speculative_get_state(spec.get(), slot.id, slot.spec_ckpt.data_spec);

                        slot.spec_prompt = slot.prompt.tokens.get_text_tokens();

                        common_speculative_get_draft_params(spec.get(), slot.id) = {
                            /* .drafting = */ true,
                            /* .n_max    = */ n_draft_max,
                            /* .n_past   = */ slot.prompt.n_tokens(),
                            /* .id_last  = */ slot.sampled,
                            /* .prompt   = */ &slot.spec_prompt,
                            /* .result   = */ &slot.spec_draft,
                        };

                        drafting.push_back(&slot);
                        if (rerot_owns_slot(slot.id) && rerot) {
                            if (const auto * ep = rerot->episode(slot.rerot_episode_id)) {
                                slot.rerot_draft_stamp = {
                                    ep->topology_epoch,
                                    ep->publish_epoch,
                                    ep->layout_epoch,
                                };
                                slot.rerot_has_draft_stamp = true;
                            }
                        }
                    }
                }
            }
        });

        // generate the actual drafts (if any)
        if (inference_mode == SERVER_INFERENCE_MODE_DECODE) {
            common_speculative_draft(spec.get());
        }

        // make checkpoints if needed
        iterate(drafting, [&](server_slot & slot) {
            auto & draft = slot.spec_draft;
            auto & ckpt  = slot.spec_ckpt;

            slot.n_draft_total += draft.size();

            // TODO: avoid restoring the draft context and re-evaluating the drafted tokens when not needed [TAG_SPEC_AVOID_DRAFT_REEVAL]
            const bool use_ckpt_dft = ctx_dft_seq_rm_type == COMMON_CONTEXT_SEQ_RM_TYPE_FULL;

            if (ctx_dft) {
                if (use_ckpt_dft) {
                    ckpt.load_dft(ctx_dft, slot.id, get_spec_checkpoint_flags(ctx_dft));
                }

                if (!llama_memory_seq_rm(llama_get_memory(ctx_dft), slot.id, ckpt.pos_max + 1, -1)) {
                    GGML_ABORT("failed to remove sequence %d\n", slot.id);
                }
            }

            if (!draft.empty()) {
                const bool use_ckpt_tgt =
                    ctx_tgt_seq_rm_type == COMMON_CONTEXT_SEQ_RM_TYPE_FULL ||
                   (ctx_tgt_seq_rm_type == COMMON_CONTEXT_SEQ_RM_TYPE_RS && draft.size() > llama_n_rs_seq(ctx_tgt));

                const bool use_ckpt_dft =
                   (ctx_dft_seq_rm_type == COMMON_CONTEXT_SEQ_RM_TYPE_RS && draft.size() > llama_n_rs_seq(ctx_dft));

                if (use_ckpt_tgt) {
                    ckpt.update_tgt(ctx_tgt, slot.id, get_spec_checkpoint_flags(ctx_tgt));
                }

                if (use_ckpt_dft) {
                    ckpt.update_dft(ctx_dft, slot.id, get_spec_checkpoint_flags(ctx_dft));
                }
            }
        });

        // Plan every Lane first, then install every reader view. This
        // two-phase ordering is required for strong-frontier visibility: the
        // first reader's PAC-DFS order must already contain peer runs created
        // later in the same frontier.
        bool rerot_plan_ok = true;
        iterate(generating, [&](server_slot & slot) {
            if (slot.rerot_internal && !rerot_cohort_feed_blocked(slot) &&
                !rerot_plan_next_token(slot)) {
                rerot_plan_ok = false;
            }
        });
        if (!rerot_plan_ok) {
            rerot_propagate_hard_abort();
            return;
        }

        iterate(generating, [&](server_slot & slot) {
            if (slot.rerot_internal) {
                if (rerot_cohort_feed_blocked(slot)) {
                    slot.i_batch = -1;
                } else if (!rerot_append_planned_token(slot)) {
                    rerot_plan_ok = false;
                }
            } else {
                slot.handle_last_sampled_token(batch, fp_enabled);
            }
        });
        if (!rerot_plan_ok) {
            rerot_propagate_hard_abort();
            return;
        }

        // process in chunks of params.n_batch, capped when the pressure planner
        // can only fit a partial prefill batch at the TriAttention floor.
        int32_t n_batch  = (int32_t) std::min<uint32_t>(llama_n_batch(ctx_tgt), kv_batch_limit);
        int32_t n_ubatch = llama_n_ubatch(ctx_tgt);

        auto & alora_scale       = batch.alora_scale;
        auto & alora_disabled_id = batch.alora_disabled_id;

        // next, batch any pending prompts without exceeding n_batch
        if (params_base.cont_batching || batch.size() == 0) {
            bool add_ok = true; // false means the batch is full, skip remaining slots

            iterate(slots, [&](server_slot & slot) {
                if (inference_mode != SERVER_INFERENCE_MODE_PREFILL || slot.id != id_slot_prefill) {
                    return;
                }

                if (!add_ok || batch.size() >= n_batch) {
                    return; // batch is full, skip remaining slots
                }

                if (!slot.is_processing()) {
                    return;
                }

                // check if we can batch this slot with the previous one
                if (slot_batched && !slot_batched->can_batch_with(slot)) {
                    return;
                }

                // check if this is a child slot
                if (slot.state == SLOT_STATE_WAIT_OTHER) {
                    SLT_DBG(slot, "%s", "waiting for parent slot to complete\n");
                    return;
                }

                // this slot still has a prompt to be processed
                if (slot.state == SLOT_STATE_PROCESSING_PROMPT || slot.state == SLOT_STATE_STARTED) {
                    const auto & input_tokens = slot.task->tokens;

                    // used to determine the number of tokens added to the batch for the current slot
                    const auto n_tokens_prev = batch.size();

                    // TODO: maybe move branch to outside of this loop in the future
                    if (slot.state == SLOT_STATE_STARTED) {
                        slot.t_start_process_prompt = ggml_time_us();
                        if (slot.n_decoded_start == 0) {
                            slot.t_start_generation = 0;
                        }

                        slot.state = SLOT_STATE_PROCESSING_PROMPT;

                        SLT_TRC(slot, "new prompt, n_ctx_slot = %d, n_keep = %d, task.n_tokens = %d\n",
                                slot.n_ctx, slot.task->params.n_keep, slot.task->n_tokens());

                        // print prompt tokens (for debugging)
                        /*if (1) {
                            // first 16 tokens (avoid flooding logs)
                            for (int i = 0; i < std::min<int>(16, input_tokens.size()); i++) {
                                SLT_DBG(slot, "prompt token %3d: %6d '%s'\n", i, input_tokens[i], common_token_to_piece(ctx_tgt, input_tokens[i]).c_str());
                            }
                        } else {
                            // all
                            for (int i = 0; i < (int) input_tokens.size(); i++) {
                                SLT_DBG(slot, "prompt token %3d: %6d '%s'\n", i, input_tokens[i], common_token_to_piece(ctx_tgt, input_tokens[i]).c_str());
                            }
                        }*/

                        // keep track how many tokens we can reuse from the previous state
                        int n_past = 0;

                        // empty prompt passed -> release the slot and send empty response
                        if (input_tokens.empty()) {
                            SLT_WRN(slot, "%s", "empty prompt - releasing slot\n");

                            slot.print_timings();
                            send_final_response(slot);
                            slot.release();

                            return;
                        }

                        // TODO: support memory-less logits computation
                        if (slot.task->need_logits() && !llama_get_memory(ctx_tgt)) {
                            send_error(slot, "the current context does not logits computation. skipping", ERROR_TYPE_SERVER);
                            slot.release();
                            return;
                        }

                        if (!slot.can_split()) {
                            if (slot.task->n_tokens() > n_ubatch) {
                                send_error(slot,
                                           string_format(
                                               "input (%d tokens) is too large to process. increase the physical batch "
                                               "size (current batch size: %d)",
                                               slot.task->n_tokens(), n_ubatch),
                                           ERROR_TYPE_SERVER);
                                slot.release();
                                return;
                            }

                            if (slot.task->n_tokens() > slot.n_ctx) {
                                send_error(
                                    slot,
                                    string_format(
                                        "input (%d tokens) is larger than the max context size (%d tokens). skipping",
                                        slot.task->n_tokens(), slot.n_ctx),
                                    ERROR_TYPE_EXCEED_CONTEXT_SIZE);
                                slot.release();
                                return;
                            }
                        } else {
                            if (slot.task->n_tokens() >= slot.n_ctx) {
                                send_error(slot,
                                           string_format("request (%d tokens) exceeds the available context size (%d "
                                                         "tokens), try increasing it",
                                                         slot.task->n_tokens(), slot.n_ctx),
                                           ERROR_TYPE_EXCEED_CONTEXT_SIZE);
                                slot.release();
                                return;
                            }

                            if (slot.task->params.cache_prompt || slot.task->is_retry) {
                                // reuse any previously computed tokens that are common with the new prompt
                                n_past = slot.prompt.tokens.get_common_prefix(input_tokens);

                                // if there is an alora invoked, don't cache after the invocation start
                                if (slot.alora_invocation_start > 0) {
                                    SLT_DBG(slot, "only caching to alora invocation start (n_past = %d, alora_invocation_start = %d)\n", n_past, slot.alora_invocation_start);
                                    n_past = std::min(n_past, slot.alora_invocation_start - 1);
                                }

                                const auto n_cache_reuse = slot.task->params.n_cache_reuse;

                                // RERoT compat (§A.10.3): ordinary chunk-reuse
                                // shifting is only legal on serial prefixes /
                                // frozen ordinary coordinates, never on active
                                // DDVR PUBLIC runs. llama_memory_can_shift
                                // already returns false while an episode is
                                // active; this explicit lane check keeps the
                                // refusal obvious at the call site. OFF: false.
                                const bool can_cache_reuse =
                                    llama_memory_can_shift(llama_get_memory(ctx_tgt)) &&
                                    !slot.prompt.tokens.has_mtmd &&
                                    !rerot_owns_slot(slot.id);

                                if (!can_cache_reuse && n_cache_reuse > 0) {
                                    SLT_WRN(slot, "cache reuse is not supported - ignoring n_cache_reuse = %d\n", n_cache_reuse);
                                }

                                // reuse chunks from the cached prompt by shifting their KV cache in the new position
                                if (can_cache_reuse && n_cache_reuse > 0) {
                                    GGML_ASSERT(!slot.prompt.tokens.has_mtmd);

                                    size_t head_c = n_past; // cache
                                    size_t head_p = n_past; // current prompt

                                    if (mctx) {
                                        // we should never reach this
                                        GGML_ABORT("not supported by multimodal");
                                    }

                                    SLT_DBG(slot, "trying to reuse chunks with size > %d, n_past = %d\n", n_cache_reuse, n_past);

                                    while (head_c < slot.prompt.tokens.size() &&
                                           head_p < input_tokens.size()) {

                                        size_t n_match = 0;
                                        while (head_c + n_match < slot.prompt.tokens.size() &&
                                               head_p + n_match < input_tokens.size()       &&
                                               slot.prompt.tokens[head_c + n_match] == input_tokens[head_p + n_match]) {
                                            n_match++;
                                        }

                                        if (n_match >= (size_t) n_cache_reuse) {
                                            SLT_TRC(slot, "reusing chunk with size %zu, shifting KV cache [%zu, %zu) -> [%zu, %zu)\n", n_match, head_c, head_c + n_match, head_p, head_p + n_match);
                                            //for (size_t i = head_p; i < head_p + n_match; i++) {
                                            //    SLT_DBG(slot, "cache token %3zu: %6d '%s'\n", i, prompt_tokens[i], common_token_to_piece(ctx_tgt, prompt_tokens[i]).c_str());
                                            //}

                                            const int64_t kv_shift = (int64_t) head_p - (int64_t) head_c;

                                            slot.mem.seq_rm (slot.id, head_p, head_c);
                                            slot.mem.seq_add(slot.id, head_c, head_c + n_match, kv_shift);

                                            for (size_t i = 0; i < n_match; i++) {
                                                slot.prompt.tokens.set_token(head_p + i, slot.prompt.tokens[head_c + i]);
                                                n_past++;
                                            }

                                            head_c += n_match;
                                            head_p += n_match;
                                        } else {
                                            head_c += 1;
                                        }
                                    }

                                    SLT_DBG(slot, "after context reuse, new n_past = %d\n", n_past);
                                }
                            } else {
                                // if we don't cache the prompt, we have to remove all previous tokens
                                n_past = 0;
                            }

                            llama_pos pos_next = slot.prompt.tokens.pos_next(n_past);

                            // ref: https://github.com/ggml-org/llama.cpp/pull/24110
                            const bool has_new_tokens = (n_past < slot.task->n_tokens());

                            // the largest pos_min required for a checkpoint to be useful
                            const auto pos_min_thold = std::max(0, pos_next - n_swa - (has_new_tokens ? 0 : 1));

                            if (n_past > 0 && n_past <= slot.prompt.n_tokens()) {
                                const auto pos_min = llama_memory_seq_pos_min(llama_get_memory(ctx_tgt), slot.id);
                                if (pos_min == -1) {
                                    SLT_ERR(slot, "n_past = %d, slot.prompt.tokens.size() = %d, seq_id = %d, pos_min = %d\n", n_past, (int) slot.prompt.tokens.size(), slot.id, pos_min);
                                    GGML_ABORT("pos_min == -1, but n_past > 0 - should not happen: https://github.com/ggml-org/llama.cpp/pull/13833#discussion_r2116181237");
                                }

                                // when the prompt prefix does not match, print the tokens around the mismatch
                                // this is useful for debugging prompt caching
                                if (slots_debug) {
                                    const int np0 = std::max<int>(n_past - 4, 0);
                                    const int np1 = std::min<int>(n_past + 6, std::min(slot.prompt.tokens.size(), slot.task->tokens.size()));

                                    std::stringstream ss0;
                                    std::stringstream ss1;

                                    std::stringstream st0;
                                    std::stringstream st1;

                                    ss0 << "old: ... ";
                                    ss1 << "new: ... ";

                                    for (int i = np0; i < np1; i++) {
                                        if (i == n_past) {
                                            ss0 << " | ";
                                            ss1 << " | ";
                                        }

                                        {
                                            const auto token = slot.prompt.tokens[i];
                                            const auto piece = token != LLAMA_TOKEN_NULL ? common_token_to_piece(ctx_tgt, token) : "[mtmd]";
                                            ss0 << piece;
                                            st0 << std::setw(8) << token;
                                        }

                                        {
                                            const auto token = slot.task->tokens[i];
                                            const auto piece = token != LLAMA_TOKEN_NULL ? common_token_to_piece(ctx_tgt, token) : "[mtmd]";
                                            ss1 << piece;
                                            st1 << std::setw(8) << token;
                                        }
                                    }

                                    SLT_WRN(slot, "%s\n", ss0.str().c_str());
                                    SLT_WRN(slot, "%s\n", ss1.str().c_str());

                                    SLT_WRN(slot, "%s\n", st0.str().c_str());
                                    SLT_WRN(slot, "%s\n", st1.str().c_str());
                                }

                                const bool can_reuse_sparse_frontier =
                                    slot.triattention_compressed &&
                                    has_new_tokens &&
                                    n_past == slot.prompt.n_tokens();

                                if (pos_min >= pos_min_thold && !can_reuse_sparse_frontier) {
                                    // search for a context checkpoint
                                    const auto it = std::find_if(
                                        slot.prompt.checkpoints.rbegin(),
                                        slot.prompt.checkpoints.rend(),
                                        [&](const auto & cur) {
                                            // guarantee that a checkpoint will result in at least one token being processed [TAG_PROMPT_LOGITS]
                                            SLT_TRC(slot, "checking checkpoint with [%d, %d] against %d...\n", cur.pos_min, cur.pos_max, pos_min_thold);
                                            // workaround for [TAG_CHECKPOINTS_FIX_POS_MIN]
                                            if (cur.pos_max > pos_next) {
                                                return false;
                                            }
                                            return cur.pos_min < pos_min_thold || cur.pos_min == 0;
                                        }
                                    );

                                    bool do_reset = it == slot.prompt.checkpoints.rend();

                                    if (!do_reset) {
                                        // restore the context checkpoint
                                        it->load_tgt(ctx_tgt, slot.id, LLAMA_STATE_SEQ_FLAGS_PARTIAL_ONLY);
                                        it->load_dft(ctx_dft, slot.id, LLAMA_STATE_SEQ_FLAGS_PARTIAL_ONLY);
                                        // restore the draft's speculative state
                                        common_speculative_set_state(spec.get(), slot.id, it->data_spec);

                                        pos_next = std::min(pos_next, std::max(it->pos_min + 1, it->pos_max));
                                        n_past   = std::min(slot.prompt.tokens.size_up_to_pos(pos_next), (size_t) it->n_tokens);
                                        SLT_TRC(slot, "restored context checkpoint (pos_min = %d, pos_max = %d, n_tokens = %" PRId64 ", n_past = %d, size = %.3f MiB)\n", it->pos_min, it->pos_max, it->n_tokens, n_past, (float) it->size() / 1024 / 1024);
                                    }

                                    if (do_reset) {
                                        SLT_TRC(slot, "forcing full prompt re-processing due to lack of cache data (likely due to SWA or hybrid/recurrent memory, see %s)\n",
                                                "https://github.com/ggml-org/llama.cpp/pull/13194#issuecomment-2868343055");
                                        pos_next = 0;
                                        n_past = 0;
                                    }
                                }
                            }

                            {
                                // erase any checkpoints with pos_max > pos_next
                                for (auto it = slot.prompt.checkpoints.begin(); it != slot.prompt.checkpoints.end();) {
                                    const auto & cur = *it;
                                    if (cur.pos_max > pos_next) {
                                        SLT_TRC(slot, "erased invalidated context checkpoint (pos_min = %d, pos_max = %d, n_tokens = %" PRId64 ", n_swa = %d, pos_next = %d, size = %.3f MiB)\n", cur.pos_min, cur.pos_max, cur.n_tokens, n_swa, pos_next, (float) cur.size() / 1024 / 1024);
                                        it = slot.prompt.checkpoints.erase(it);
                                    } else {
                                        ++it;
                                    }
                                }
                            }
                        }

                        // [TAG_PROMPT_LOGITS]
                        if (n_past == slot.task->n_tokens() && n_past > 0) {
                            SLT_WRN(slot, "need to evaluate at least 1 token for each active slot (n_past = %d, task.n_tokens() = %d)\n", n_past, slot.task->n_tokens());
                            n_past--;
                            SLT_WRN(slot, "n_past was set to %d\n", n_past);
                        }

                        // FlashPrefill: freeze the ordinary logical-prefill
                        // suffix AFTER every prefix-cache adjustment above
                        // (common prefix, alora clamp, chunk-reuse shifts,
                        // checkpoint restore, TAG_PROMPT_LOGITS). The frozen
                        // [n_past, task.n_tokens) interval persists on the
                        // slot across ubatches; later chunk boundaries must
                        // not re-derive it from n_tokens>1 guessing, and the
                        // three lengths (cached count, batch count, dialogue
                        // length) must not be conflated. OFF: untouched.
                        if (fp_enabled) {
                            slot.fp_boundary = server_flashprefill_routing::freeze_prefill_boundary(
                                (int32_t) n_past, slot.task->n_tokens());
                        }

                        slot.n_prompt_tokens_cache = n_past;
                        if (slot.n_decoded_start == 0) {
                            slot.n_prompt_tokens_cache_response = n_past;
                        }
                        slot.n_prompt_tokens_processed = 0;

                        slot.prompt.tokens.keep_first(n_past);

                        // this is to signal the client that the request has started processing
                        if (slot.task->params.stream && slot.n_decoded_start == 0) {
                            if (slot.task->params.return_progress) {
                                // send initial 0% progress update if needed
                                send_partial_response(slot, {}, true);
                            } else {
                                // otherwise, for streaming without progress, signal HTTP to send the headers (i.e. 200 status)
                                send_partial_response(slot, {}, false, true);
                            }
                        }
                    } // end of SLOT_STATE_STARTED

                    if (!slot.can_split()) {
                        // cannot fit the prompt in the current batch - will try next iter
                        if (batch.size() + slot.task->n_tokens() > n_batch) {
                            return;
                        }
                    }

                    const int64_t t_now = ggml_time_us();
                    slot.t_prompt_processing = slot.t_prompt_processing_accum + (t_now - slot.t_start_process_prompt) / 1e3;
                    slot.print_timings_pp();

                    // truncate any tokens that are beyond n_past for this slot
                    const llama_pos p0 = slot.prompt.tokens.pos_next();

                    SLT_TRC(slot, "cached n_tokens = %d, memory_seq_rm [%d, end)\n", slot.prompt.n_tokens(), p0);

                    slot.mem.seq_rm(slot.id, p0, -1);

                    // A cache mismatch can discard every sparse gap. Once the
                    // retained prefix is dense again, this is a new fill-first
                    // sequence rather than a sticky compressed continuation.
                    if (slot.triattention_compressed &&
                        llama_memory_seq_get_kv_used(llama_get_memory(ctx_tgt), slot.id) >= (uint32_t) slot.prompt.n_tokens()) {
                        slot.triattention_compressed = false;
                    }

                    // If using an alora, there may be uncached tokens that come
                    // before the invocation sequence. When this happens, the
                    // tokens before the invocation sequence need to be
                    // processed without the adapter in a separate batch, then
                    // the adapter needs to be enabled for the remaining tokens.
                    if (lora_all_alora(slot.lora) && slot.alora_invocation_start - 1 > slot.prompt.n_tokens()) {
                        SLT_DBG(slot, "processing pre-alora tokens without the adapter (n_tokens = %d, alora_invocation_start = %d)\n", slot.prompt.n_tokens(), slot.alora_invocation_start);
                        const auto & enabled_loras = lora_get_enabled_ids(slot.lora);
                        GGML_ASSERT(enabled_loras.size() == 1);
                        alora_scale = slot.lora[enabled_loras[0]].scale;
                        slot.lora[enabled_loras[0]].scale = 0.0f;
                        alora_disabled_id = enabled_loras[0];
                    }

                    bool do_checkpoint = params_base.n_ctx_checkpoints > 0;

                    // make checkpoints only for completion tasks
                    do_checkpoint = do_checkpoint && slot.task->type == SERVER_TASK_TYPE_COMPLETION;

                    // make a checkpoint of the parts of the memory that cannot be rolled back.
                    // checkpoints are created only if:
                    // - the model does not support partial sequence removal
                    // - the model uses SWA (and we are not using `swa_full`)
                    // - the model supports partial sequence removal but only up to a fixed bound
                    do_checkpoint = do_checkpoint && (
                            ctx_tgt_seq_rm_type == COMMON_CONTEXT_SEQ_RM_TYPE_FULL ||
                            ctx_tgt_seq_rm_type == COMMON_CONTEXT_SEQ_RM_TYPE_RS ||
                            n_swa > 0);

                    bool has_mtmd = false;

                    // check if we should process the image
                    while (true) {
                        auto cur_token_idx = slot.prompt.n_tokens();
                        if (
                            cur_token_idx >= slot.task->n_tokens() ||
                            input_tokens[cur_token_idx] != LLAMA_TOKEN_NULL // encountered a text token
                        ) {
                            break;
                        }

                        // process the image
                        size_t n_tokens_out = 0;
                        int32_t res = slot.process_mtmd_chunk(cur_token_idx, n_tokens_out);
                        if (res != 0) {
                            SLT_ERR(slot, "failed to process image, res = %d\n", res);
                            send_error(slot, "failed to process image", ERROR_TYPE_SERVER);
                            slot.release();
                            continue;
                        }

                        if (ctx_dft && llama_get_ctx_other(ctx_dft) != ctx_tgt) {
                            // TODO: in the future, figure out how to infuse target embeddings to the images
                            //       for now, we skip this for simplicity
                            //       maybe we simply need to call `common_speculative_process()` on the mtmd batches in the `process_chunk` above?
                            //       [TAG_MTMD_DRAFT_PROCESSING]
                            res = input_tokens.process_chunk(ctx_dft, mctx, slot.prompt.n_tokens(), slot.prompt.tokens.pos_next(), slot.id, n_tokens_out);
                            if (res != 0) {
                                GGML_ABORT("failed to process multi-modal data on draft context\n");
                            }
                        }

                        slot.n_prompt_tokens_processed += n_tokens_out;

                        // add the image chunk to cache
                        {
                            const auto & chunk = input_tokens.find_chunk(cur_token_idx);
                            slot.prompt.tokens.push_back(chunk.get()); // copy
                        }

                        has_mtmd = true;
                    }

                    const auto & spans = slot.task->params.message_spans;
                    const auto last_user_pos = spans.last_user_message_pos();

                    // add prompt tokens for processing in the current batch
                    while (slot.prompt.n_tokens() < slot.task->n_tokens() && batch.size() < n_batch) {
                        // get next token to process
                        llama_token cur_tok = input_tokens[slot.prompt.n_tokens()];
                        if (cur_tok == LLAMA_TOKEN_NULL) {
                            break; // end of text chunk
                        }

                        // if this is an alora request with pre-invocation
                        // tokens that are not cached, we need to stop filling
                        // this batch at those pre-invocation tokens.
                        if (alora_scale > 0 && slot.prompt.n_tokens() == slot.alora_invocation_start - 1) {
                            SLT_DBG(slot, "stop prompt batch filling at (n_tokens = %d, alora_invocation_start = %d)\n", slot.prompt.n_tokens(), slot.alora_invocation_start);
                            break;
                        }

                        // embedding requires all tokens in the batch to be output;
                        // MTP also wants logits at every prompt position so the
                        // streaming hook can mirror t_h_nextn into ctx_dft.
                        {
                            const bool ok = batch.add(slot.id,
                                cur_tok,
                                slot.prompt.tokens.pos_next(),
                                slot.need_embd());
                            add_ok &= ok;
                            // FlashPrefill: only true prompt rows are eligible,
                            // with the frozen suffix interval above. Embedding,
                            // rerank, and multimodal rows take explicit dense
                            // roles with a reason; never guessed from the
                            // batch size. OFF: no push, no allocation.
                            if (fp_enabled && ok) {
                                namespace fp = server_flashprefill_routing;
                                fp::fp_row_inputs in;
                                in.is_embedding = slot.task->type == SERVER_TASK_TYPE_EMBEDDING;
                                in.is_rerank = slot.task->type == SERVER_TASK_TYPE_RERANK;
                                in.has_mtmd = has_mtmd || slot.prompt.tokens.has_mtmd;
                                in.rerot_internal = false;
                                in.rerot_forced = false;
                                in.is_mtp_verify = false;
                                in.is_spec_replay = false;
                                in.is_prompt_row = true;
                                const int32_t role = fp::classify_row_role(in);
                                const int32_t logical_pos = (int32_t) slot.prompt.n_tokens();
                                const llama_flashprefill_row row = fp::make_row(
                                    role, slot.id, LLAMA_FLASHPREFILL_READER_NONE,
                                    logical_pos, slot.fp_boundary);
                                GGML_ASSERT(llama_flashprefill_validate_row(&row) == LLAMA_FLASHPREFILL_OK);
                                batch.fp_push_row(row);
                            }
                        }
                        slot.prompt.tokens.push_back(cur_tok);

                        slot.n_prompt_tokens_processed++;

                        // break at the last user message, or at user messages at least min step past the last checkpoint
                        if (do_checkpoint && spans.is_user_start(slot.prompt.n_tokens())) {
                            const auto pos = slot.prompt.n_tokens();
                            const auto & checkpoints = slot.prompt.checkpoints;

                            if (pos == last_user_pos || checkpoints.empty() || pos > checkpoints.back().n_tokens + params_base.checkpoint_min_step) {
                                break;
                            }
                        }

                        // process the last few tokens of the prompt separately in order to allow for a checkpoint to be created.
                        // create checkpoints that many tokens before the end of the prompt:
                        //  - 4 + n_ubatch
                        //  - 4
                        // ref: https://github.com/ggml-org/llama.cpp/pull/20288
                        if (do_checkpoint) {
                            static const int checkpoint_offsets[] = {4 + n_ubatch, 4};

                            bool should_break = false;
                            for (int offset : checkpoint_offsets) {
                                const int n_last = std::min(n_batch, offset);
                                if (slot.task->n_tokens() == slot.prompt.n_tokens() + n_last) {
                                    should_break = true;
                                    break;
                                }
                            }
                            if (should_break) {
                                break;
                            }
                        }
                    }

                    // the number of tokens added to the batch for the current slot
                    const auto n_tokens_cur = batch.size() - n_tokens_prev;

                    const auto n_tokens_start = slot.prompt.n_tokens() - n_tokens_cur;

                    const bool near_prompt_end = slot.task->n_tokens() < slot.prompt.n_tokens() + n_ubatch;

                    const bool is_user_start = spans.is_user_start(n_tokens_start);
                    const bool is_last_user_message = n_tokens_start == last_user_pos;

                    // entire prompt has been processed
                    if (slot.prompt.n_tokens() == slot.task->n_tokens()) {
                        slot.state = SLOT_STATE_DONE_PROMPT;

                        GGML_ASSERT(batch.size() > 0);

                        // extract the logits only for the last token
                        batch.set_output(batch.size() - 1, true);

                        slot.n_decoded = slot.n_decoded_start;
                        slot.i_batch   = batch.size() - 1;

                        slot.init_sampler();
                    } else {
                        // skip ordinary mid-prompt checkpoints, unless the batch starts a user
                        // message or we are near the end of the prompt
                        if (!is_user_start && !near_prompt_end) {
                            do_checkpoint = false;
                        }
                    }

                    const auto pos_min = llama_memory_seq_pos_min(llama_get_memory(ctx_tgt), slot.id);
                    const auto pos_max = llama_memory_seq_pos_max(llama_get_memory(ctx_tgt), slot.id);

                    // nothing to checkpoint yet
                    // TODO: is this check needed?
                    if (do_checkpoint && pos_min < 0) {
                        do_checkpoint = false;
                    }

                    // do not checkpoint after mtmd chunks
                    do_checkpoint = do_checkpoint && !has_mtmd;

                    // no need to create checkpoints that are too close together, unless it's the last user message
                    do_checkpoint = do_checkpoint && (
                            slot.prompt.checkpoints.empty() ||
                            is_last_user_message || near_prompt_end ||
                            n_tokens_start > slot.prompt.checkpoints.back().n_tokens + params_base.checkpoint_min_step);
                    SLT_DBG(slot, "main/do_checkpoint = %s, pos_min = %d, pos_max = %d\n", do_checkpoint ? "yes" : "no", pos_min, pos_max);

                    // note: we create the checkpoint before calling llama_decode(), so the current batch is not
                    //       yet processed and therefore it is not part of the checkpoint.
                    if (do_checkpoint) {
                        create_checkpoint(slot, n_tokens_cur, pos_min, pos_max);
                    }
                }

                if (!slot_batched) {
                    slot_batched = &slot;
                }
            });
        }
    }

    // returns true = success ; false = retry with smaller batch size
    // throw std::runtime_error on fatal error
    // fp_exec is the borrowed versioned execution view for this slice
    // (same off/n as batch_view; empty while OFF). It is validated here so
    // every narrowed-batch retry keeps role/boundary alignment, then
    // dispatched below: non-empty views go through llama_decode_with_flash-
    // prefill (ContextIntegration owns validation/copy/propagation), empty
    // views keep the ordinary llama_decode() path. All roles — MTP draft/
    // target verification and speculative replay included — ride without a
    // new global disable and with the active-lane pause unchanged.
    bool decode(int32_t & n_batch, int32_t off, llama_batch & batch_view, const llama_flashprefill_exec & fp_exec) {
        SRV_DBG("n_batch (effective) = %d, off = %d\n", n_batch, off);

        if (batch.size() == 0) {
            SRV_WRN("%s", "no tokens to decode\n");

            if (++n_empty_consecutive > 3) {
                GGML_ABORT("fatal error - please provide logs and repro in %s\n", "https://github.com/ggml-org/llama.cpp/pull/20277");
            }

            return true; // nothing to decode
        } else {
            n_empty_consecutive = 0;
        }

        // FlashPrefill view validation (cheap, OFF-empty passes): version and
        // struct size must match the frozen contract, and a non-empty view
        // must cover exactly this slice's rows. A mismatch is a routing bug,
        // not a performance fallback, so it fails loudly like the existing
        // speculative-index check in post_decode.
        if (fp_exec.version != LLAMA_FLASHPREFILL_EXEC_VERSION ||
            fp_exec.struct_size != (uint32_t) sizeof(llama_flashprefill_exec)) {
            throw std::runtime_error("flashprefill exec view has wrong version/size");
        }
        if (!batch.fp_rows.empty()) {
            if (fp_exec.n_rows != (uint32_t) batch_view.n_tokens || fp_exec.rows == nullptr) {
                throw std::runtime_error("flashprefill exec view does not match batch slice");
            }
            if (llama_flashprefill_validate_exec(&fp_exec) != LLAMA_FLASHPREFILL_OK) {
                throw std::runtime_error("flashprefill exec view failed validation");
            }
        } else if (fp_exec.n_rows != 0 || fp_exec.rows != nullptr) {
            throw std::runtime_error("flashprefill exec view must be empty while OFF");
        }

        // TODO @ngxson : dft model may have different n_embd than the tgt model, so we check & reject if that's the case
        // this case is not currently used by any models, but may need to be supported in the future
        if (spec && batch.has_embd) {
            if (llama_model_n_embd_inp(model_dft) != llama_model_n_embd_inp(model_tgt)) {
                SRV_ERR("%s", "unsupported batch.has_embd + spec case\n");
                throw std::runtime_error("unsupported batch.has_embd + spec case");
            }
        }

        // Versioned execution dispatch (ContextIntegration owns the copy
        // semantics + per-ubatch propagation; ConfigIntegration declares the
        // C API in llama.h). Non-empty views carry every submission slice's
        // roles/boundaries with row identity intact; the context validates
        // version/size/n_rows and copies rows before async work. Empty views
        // (OFF) keep the ordinary dense route. MTP draft/target verification
        // and speculative replay rows are dense by role, so they ride the same
        // call without a global disable and with the active-lane pause intact.
        const bool mtp_prof_active = spec && (std::getenv("GGML_TP5_PROFILE") != nullptr || std::getenv("GGML_TP5_MTP_PROFILE") != nullptr);
        t_tgt_verify_start = mtp_prof_active ? ggml_time_us() : 0;

        const int ret = batch.fp_rows.empty()
            ? llama_decode(ctx_tgt, batch_view)
            : llama_decode_with_flashprefill(ctx_tgt, batch_view, &fp_exec);

        metrics.on_decoded(slots);

        if (ret != 0) {
            if (rerot_active() && batch.slot_batched && batch.slot_batched->rerot_internal) {
                const std::string reason = ret == 1
                    ? "rerot_resource_exhausted: memory cannot commit the complete frontier"
                    : "rerot_backend_error: complete frontier decode failed";
                std::vector<uint64_t> active_to_abort;
                for (const auto & kv : rerot_transport) {
                    active_to_abort.push_back(kv.first);
                }
                if (active_to_abort.empty() && rerot_episode_id != 0) {
                    active_to_abort.push_back(rerot_episode_id);
                }
                for (uint64_t ep_id : active_to_abort) {
                    rerot->hard_abort(ep_id, reason);
                }
                rerot_propagate_hard_abort();
                throw std::runtime_error(reason);
            }
            if (ret == 1 && n_batch == 1 && params_base.kv_unified && params_base.n_ctx_kv > 0 && try_clear_idle_slots()) {
                return false;
            }

            {
                std::string err;

                if (n_batch == 1 && ret == 1) {
                    // TODO: try to terminate only the largest active slot/sequence and continue with the rest
                    //       need to remove the tokens from the current batch too
                    err = "Context size has been exceeded.";
                }

                if (ret == -1) {
                    err = "Invalid input batch.";
                }

                if (ret < -1) {
                    // TODO: update slot state based on llama_memory_seq_pos_min() and llama_memory_seq_pos_max()
                    err = "Compute error.";
                }

                // TODO: handle ret == 2 (abort) when we start aborting

                if (!err.empty()) {
                    SRV_ERR("%s off = %d, n_batch = %d, ret = %d\n", err.c_str(), off, n_batch, ret);

                    for (auto & slot : slots) {
                        if (slot.is_processing()) {
                            send_error(slot, err);
                            slot.release();

                            // note: it's complicated to keep track of how much of the current batch has been
                            //       processed before the error occurred, so we simply clear the entire context
                            slot.prompt_clear();
                        }
                    }

                    // stop, do not retry with smaller batch size
                    throw std::runtime_error(err);
                }
            }

            // retry with half the batch size to try to find a free slot in the KV cache
            if (!try_clear_idle_slots()) {
                n_batch /= 2;
            }

            SRV_WRN("failed to find free space in the KV cache, retrying with smaller batch size, off = %d, n_batch = %d, ret = %d\n", off, n_batch, ret);

            return false; // retry with the updated n_batch
        }

        // TODO: avoid restoring the draft context and re-evaluating the drafted tokens when not needed [TAG_SPEC_AVOID_DRAFT_REEVAL]
        //       for now, always re-evaluate for simplicity
        //       ref: https://github.com/ggml-org/llama.cpp/pull/22728#issuecomment-4400925384
        if (!common_speculative_process(spec.get(), batch_view, /*defer_mtp=*/ true)) {
            SRV_ERR("%s", "failed to process speculative batch\n");

            // TODO: handle error
            throw std::runtime_error("failed to process speculative batch");
        }

        // handle `n_cmpl > 1` tasks - when the main prompt is processed, activate all child tasks too
        for (auto & slot : slots) {
            if (slot.state == SLOT_STATE_DONE_PROMPT && slot.task->is_parent()) {
                std::vector<server_slot *> children;
                for (auto & other : slots) {
                    if (other.state == SLOT_STATE_WAIT_OTHER && slot.task->id == other.task->id_parent) {
                        children.push_back(&other);
                    }
                }

                // all children slots should already launched by launch_slots_with_parent_task()
                // copy state to the child slots
                for (auto & child : children) {
                    SLT_TRC(slot, " - copying state to child %d\n", child->id);

                    GGML_ASSERT(child->state == SLOT_STATE_WAIT_OTHER);

                    slot.copy_state_to(*child);
                    child->state = SLOT_STATE_DONE_PROMPT;
                }
            }
        }

        return true;
    }

    void post_decode(int32_t n_batch_tokens, int32_t off, llama_batch & batch_view) {
        // for checking if a given batch index is inside batch_view
        auto is_inside_view = [&](int32_t idx) {
            return idx >= off && idx < off + n_batch_tokens;
        };

        // FlashPrefill successful-only accounting: this runs solely after its
        // decode slice returned 0, so each row in [off, off+n) is counted
        // exactly once. Narrowed-batch retries (decode false), fatal errors
        // (throw + abort_all_slots), and slot cancel/release paths never reach
        // here, so canceled/failed/retried rows are never double counted.
        // No GPU work is claimed here (see fp_gpu_deltas); only eligible vs
        // server-dense attribution.
        fp_count_slice_success(off, n_batch_tokens);
        // GPU-determined drain for the same successful slice (consume-once:
        // narrowed-batch retries can never double count). OFF or empty drain
        // merges nothing.
        fp_merge_gpu_slice();

        // TODO @ngxson : it's tricky to make sub-batch compatible with common_sampler_sample_and_accept_n,
        // so for now we will throw an error in this case: https://github.com/ggml-org/llama.cpp/issues/24840
        iterate(slots, [&](server_slot & slot) {
            for (auto & i : slot.spec_i_batch) {
                if (!is_inside_view(i)) {
                    throw std::runtime_error(string_format("speculative batch index %d is not inside the current sub-batch [%d, %d)", i, off, off + n_batch_tokens));
                }
            }
        });

        // RERoT owns its token lifecycle: first commit every physical KV
        // write in the frontier, then capture each RUNNING worker's pending
        // next-token decision from its just-committed row, and only then run
        // central finish/yield/admit. Sampling after a yield would read a
        // stale or missing row on the resumed executor.
        std::set<uint64_t> rerot_committed_episodes;
        bool rerot_ok = true;
        uint64_t rerot_batch_rows = 0;
        iterate(slots, [&](server_slot & slot) {
            if (!is_inside_view(slot.i_batch)) {
                return;
            }
            if (slot.rerot_internal && slot.state == SLOT_STATE_GENERATING) {
                ++rerot_batch_rows;
            }

            if (slot.state == SLOT_STATE_DONE_PROMPT && slot.task &&
                slot.task->params.rerot_effective(slot.task->type)) {
                // Pre-save the true C0 next-token decision while C0 logits
                // are valid (this row is inside the view by the guard above).
                // A parked root started later replays it identically, so the
                // hook runs before the active-episode check, not only at
                // immediate start.
                if (!slot.rerot_c0_ready && !rerot_presave_c0_decision(slot, off)) {
                    send_error(slot, "failed to sample RERoT C0 decision", ERROR_TYPE_SERVER);
                    slot.release();
                    rerot_ok = false;
                    return;
                }
                // The context-level memory registry currently executes one
                // RERoT visibility domain at a time. Keep additional outer
                // n_cmpl/concurrent roots parked at their completed prelude;
                // completion/abort starts the next root without re-prefill.
                if (rerot_active()) {
                    return;
                }
                if (!rerot_start_root(slot)) {
                    send_error(slot, "failed to start RERoT episode", ERROR_TYPE_SERVER);
                    slot.release();
                    rerot_ok = false;
                }
                return;
            }

            if (slot.state == SLOT_STATE_GENERATING && slot.rerot_internal &&
                slot.rerot_inflight_plan.has_value()) {
                const uint64_t episode_id = slot.rerot_episode_id;
                if (!rerot_commit_inflight(slot)) {
                    rerot_ok = false;
                    return;
                }
                rerot_committed_episodes.insert(episode_id);
            }
        });
        rerot_metrics.batch_people = rerot_batch_rows != 0 ? 1 : 0;
        rerot_metrics.batch_pens = rerot_batch_rows;
        rerot_metrics.frontier_rows += rerot_batch_rows;
        if (rerot_batch_rows >= 6) {
            ++rerot_metrics.six_row_batches;
        }

        bool rerot_capture_needed = false;
        bool rerot_decode_synchronized = false;
        if (rerot_ok) {
            iterate(slots, [&](server_slot & slot) {
                const auto * episode = rerot && slot.rerot_episode_id != 0
                    ? rerot->episode(slot.rerot_episode_id) : nullptr;
                rerot_capture_needed |=
                    slot.rerot_internal &&
                    slot.state == SLOT_STATE_GENERATING &&
                    episode && episode->is_dag && !slot.rerot_serial_tail &&
                    slot.rerot_injection == server_rerot_injection_kind::none &&
                    slot.i_batch >= off && slot.i_batch < off + n_batch_tokens;
            });
            if (rerot_capture_needed) {
                const int64_t t0 = ggml_time_us();
                llama_synchronize(ctx_tgt);
                rerot_decode_synchronized = true;
                const int64_t dur_us = ggml_time_us() - t0;
                // Completed-token generation: n_p_eval + n_eval only advance
                // inside llama_context::synchronize() after real GPU work
                // drained. A repeated sync with no new submissions reports
                // the same generation — the dedup evidence P11 needs.
                const llama_perf_context_data perf = llama_perf_context(ctx_tgt);
                const uint64_t sync_gen = (uint64_t) perf.n_p_eval + (uint64_t) perf.n_eval;
                if (llama_rerot_profile * prof = llama_rerot_profile_active()) {
                    prof->record_sync((uint64_t) dur_us, sync_gen);
                }
                rerot_metrics.sync_capture_us += dur_us;
                ++rerot_metrics.sync_capture_count;
                rerot_metrics.sync_capture_with_work_us += dur_us;
                ++rerot_metrics.sync_capture_with_work_count;
            }
            iterate(slots, [&](server_slot & slot) {
                if (!rerot_capture_pending_decision(slot, off, n_batch_tokens)) {
                    rerot_ok = false;
                }
            });
        }

        if (rerot_ok && !rerot_capture_needed) {
            // A forced frame has no logit row to sample, so the capture pass
            // above did not synchronize. finish_frontier may retire sequences,
            // and subsequent DAG admission copies and clears KV and
            // recurrent rows. Do not mutate those buffers while this slice's
            // asynchronous Vulkan graph is still reading them.
            for (const uint64_t episode_id : rerot_committed_episodes) {
                const auto * episode = rerot->episode(episode_id);
                if (episode && episode->is_dag) {
                    llama_synchronize(ctx_tgt);
                    rerot_decode_synchronized = true;
                    break;
                }
            }
        }

        if (rerot_ok) {
            for (const uint64_t episode_id : rerot_committed_episodes) {
                if (!rerot_handle_finished_frontier(episode_id)) {
                    rerot_ok = false;
                    break;
                }
            }
        }

        if (!rerot_ok) {
            rerot_propagate_hard_abort();
            return;
        } else {
            bool rerot_needs_sample = false;
            iterate(slots, [&](server_slot & slot) {
                rerot_needs_sample |=
                    slot.rerot_internal &&
                    slot.state == SLOT_STATE_GENERATING &&
                    is_inside_view(slot.i_batch) &&
                    slot.rerot_injection ==
                        server_rerot_injection_kind::none;
            });
            if (rerot_needs_sample) {
                // Capture or a topology-safe forced-frame barrier already
                // drained this decode. Frontier bookkeeping can move KV but
                // does not generate a new logit row for this sample.
                if (!rerot_decode_synchronized) {
                    const int64_t t0 = ggml_time_us();
                    llama_synchronize(ctx_tgt);
                    const int64_t dur_us = ggml_time_us() - t0;
                    const llama_perf_context_data perf = llama_perf_context(ctx_tgt);
                    const uint64_t sync_gen = (uint64_t) perf.n_p_eval + (uint64_t) perf.n_eval;
                    if (llama_rerot_profile * prof = llama_rerot_profile_active()) {
                        prof->record_sync((uint64_t) dur_us, sync_gen);
                    }
                    rerot_metrics.sync_sample_us += dur_us;
                    ++rerot_metrics.sync_sample_count;
                    rerot_metrics.sync_sample_with_work_us += dur_us;
                    ++rerot_metrics.sync_sample_with_work_count;
                }
            }

            std::string rerot_trace_batch;
            iterate(slots, [&](server_slot & slot) {
                if (!slot.rerot_internal || slot.state != SLOT_STATE_GENERATING ||
                    !is_inside_view(slot.i_batch)) {
                    return;
                }

                if (slot.rerot_injection != server_rerot_injection_kind::none) {
                    slot.i_batch = -1;
                    return;
                }

                const auto * episode = rerot ? rerot->episode(slot.rerot_episode_id) : nullptr;
                const auto * logical = episode
                    ? episode->document.node(slot.rerot_node_id)
                    : nullptr;
                if (!episode || !logical || episode->hard_aborted ||
                    logical->state == llama_rerot_node_state::forked ||
                    logical->state == llama_rerot_node_state::retired ||
                    rerot_cohort_feed_blocked(slot)) {
                    if (slot.task && slot.task->params.rerot_trace) {
                        rerot_trace_batch += string_format(
                            "skip episode=%" PRIu64
                            " node=%u episode=%d hard_abort=%d logical_state=%d\n",
                            slot.rerot_episode_id, slot.rerot_node_id,
                            episode ? 1 : 0,
                            episode && episode->hard_aborted ? 1 : 0,
                            logical ? static_cast<int>(logical->state) : -1);
                    }
                    return;
                }

                const int tok_idx = slot.i_batch - off;
                if (!rerot_sample_slot(slot, tok_idx, &rerot_trace_batch)) {
                    rerot_ok = false;
                }
            });
            if (!rerot_trace_batch.empty()) {
                SRV_INF("rerot.trace.frontier:\n%s", rerot_trace_batch.c_str());
            }
            if (!rerot_ok) {
                rerot_propagate_hard_abort();
                return;
            }
        }

        auto accept_special_token = [&](server_slot & slot, llama_token token) {
            return params_base.special ||
                slot.task->params.sampling.preserved_tokens.find(token) != slot.task->params.sampling.preserved_tokens.end();
        };

        auto accept_hack_block = [&](server_slot & slot, const llama_tokens & confirmed_block) {
            if (!slot.token_hack || confirmed_block.empty()) {
                return true;
            }

            llama_tokens appended = slot.token_hack->after_block(confirmed_block);
            if (appended.empty()) {
                return true;
            }

            slot.spec_draft.clear();
            slot.spec_i_batch.clear();
            slot.token_append_anchor = confirmed_block.back();
            slot.token_append_chunk = std::move(appended);

            for (llama_token token : slot.token_append_chunk) {
                common_sampler_accept(slot.smpl.get(), token, true);

                completion_token_output forced;
                forced.tok          = token;
                forced.text_to_send = common_token_to_piece(slot.ctx_tgt, token, accept_special_token(slot, token));
                forced.prob         = 1.0f;

                slot.n_decoded += 1;
                if (!process_token(forced, slot)) {
                    slot.print_timings();
                    send_final_response(slot);
                    metrics.on_prediction(slot);
                    slot.release();
                    return false;
                }
            }

            slot.sampled = slot.token_append_anchor;
            return true;
        };

        iterate(slots, [&](server_slot & slot) {
            if (slot.rerot_internal ||
                (slot.state == SLOT_STATE_DONE_PROMPT && slot.task &&
                 slot.task->params.rerot_effective(slot.task->type))) {
                return;
            }

            // optionally send prompt processing progress
            if (slot.state == SLOT_STATE_PROCESSING_PROMPT || slot.state == SLOT_STATE_DONE_PROMPT) {
                if (slot.task->params.stream && slot.task->params.return_progress && slot.n_decoded_start == 0) {
                    send_partial_response(slot, {}, true);
                }
            }

            if (!is_inside_view(slot.i_batch)) {
                // the required token not in this sub-batch, skip
                return;
            }

            if (slot.state == SLOT_STATE_DONE_PROMPT) {
                if (slot.task->type == SERVER_TASK_TYPE_EMBEDDING) {
                    // prompt evaluated for embedding
                    send_embedding(slot, batch_view);
                    slot.release();
                    slot.i_batch = -1;
                    return;
                }

                if (slot.task->type == SERVER_TASK_TYPE_RERANK) {
                    send_rerank(slot, batch_view);
                    slot.release();
                    slot.i_batch = -1;
                    return;
                }

                GGML_ASSERT(slot.task->need_sampling());

                // prompt evaluated for next-token prediction
                slot.state = SLOT_STATE_GENERATING;

                if (slot.can_speculate()) {
                    common_speculative_begin(spec.get(), slot.id, slot.prompt.tokens.get_text_tokens());
                }
            } else if (slot.state != SLOT_STATE_GENERATING) {
                return;
            }

            if (slot.can_speculate() && !slot.spec_draft.empty()) {
                return; // sample using speculative decoding
            }

            // shifted according to the current sub-batch
            const int tok_idx = slot.i_batch - off;

            llama_token id;
            {
                scoped_timer timer(t_sampl, n_sampl);
                id = common_sampler_sample(slot.smpl.get(), slot.ctx_tgt, tok_idx);
            }

            slot.i_batch = -1;

            common_sampler_accept(slot.smpl.get(), id, true);

            // here we have synchronized the llama_context (due to the sampling above), so we can do time measurement
            const int64_t t_now = ggml_time_us();

            slot.n_decoded += 1;

            if (slot.t_start_generation == 0) {
                slot.t_start_generation = t_now;
            }
            if (slot.n_decoded == slot.n_decoded_start + 1) {
                slot.t_print_last = t_now;
                slot.n_decoded_last = slot.n_decoded_start;
                if (slot.n_decoded_start == 0) {
                    slot.t_prompt_processing = slot.t_prompt_processing_accum + (slot.t_start_generation - slot.t_start_process_prompt) / 1e3;
                }
                metrics.on_prompt_eval(slot);
            }

            slot.t_token_generation = std::max<int64_t>(1, t_now - slot.t_start_generation) / 1e3;

            completion_token_output result;
            result.tok          = id;
            result.text_to_send = common_token_to_piece(slot.ctx_tgt, result.tok, accept_special_token(slot, result.tok));
            result.prob         = 1.0f; // TODO: set it here instead of doing inside populate_token_probs

            if (slot.task->params.sampling.n_probs > 0) {
                populate_token_probs(slot, slot.smpl.get(), result, slot.task->params.post_sampling_probs, params_base.special, tok_idx);
            }

            if (!process_token(result, slot)) {
                // release slot because of stop condition
                slot.print_timings();
                send_final_response(slot);
                metrics.on_prediction(slot);
                slot.release();

                return;
            }

            if (!accept_hack_block(slot, llama_tokens { id })) {
                return;
            }

            slot.print_timings_tg();
        });

        // speculative decoding - main model sample and accept
        iterate(slots, [&](server_slot & slot) {
            if (slot.state != SLOT_STATE_GENERATING || !slot.can_speculate() || slot.spec_draft.empty()) {
                return;
            }

            // RERoT MTP epoch invalidation (§A.6): a draft bound to an old
            // view stamp must not verify against new shared memory. Drop it,
            // restore the checkpoint, and re-draft next frontier. OFF: false.
            if (rerot_owns_slot(slot.id) && slot.rerot_has_draft_stamp && ctx_tgt != nullptr &&
                llama_rerot_mtp_is_stale(ctx_tgt, slot.id, &slot.rerot_draft_stamp)) {
                slot.spec_ckpt.load_tgt(slot.ctx_tgt, slot.id, get_spec_checkpoint_flags(slot.ctx_tgt));
                if (slot.ctx_dft) {
                    slot.spec_ckpt.load_dft(slot.ctx_dft, slot.id, get_spec_checkpoint_flags(slot.ctx_dft));
                }
                common_speculative_set_state(spec.get(), slot.id, slot.spec_ckpt.data_spec);
                slot.mem.seq_rm(slot.id, slot.spec_ckpt.pos_max + 1, -1);
                slot.prompt.tokens.keep_first(slot.spec_ckpt.n_tokens);
                slot.spec_draft.clear();
                slot.spec_i_batch.clear();
                slot.rerot_has_draft_stamp = false;
                // XKV abort side: the seq_rm above is the full rollback (no
                // accepted prefix exists); sealing is forbidden here by design.
                return;
            }

            // save the original draft size
            const size_t n_draft = slot.spec_draft.size();

            GGML_ASSERT(n_draft > 0);

            // verify and try to accept the draft
            {
                // save the sampler sampler state in case we need to restore it
                // The candidate array belongs to the preceding decode and is
                // rebuilt before any sampler state can observe it again.
                common_sampler_ptr smpl_save(common_sampler_clone_checkpoint(slot.smpl.get()));

                GGML_ASSERT(slot.spec_i_batch.size() == n_draft + 1);
                auto accepted = common_sampler_sample_and_accept_n(slot.smpl.get(), slot.ctx_tgt, slot.spec_i_batch, slot.spec_draft);
                slot.spec_i_batch.clear();

                GGML_ASSERT(accepted.size() >= 1);

                const uint32_t n_rollback = slot.spec_draft.size() + 1 - accepted.size();

                const bool use_ckpt_tgt =
                    ctx_tgt_seq_rm_type == COMMON_CONTEXT_SEQ_RM_TYPE_FULL ||
                    (ctx_tgt_seq_rm_type == COMMON_CONTEXT_SEQ_RM_TYPE_RS && n_rollback > llama_n_rs_seq(ctx_tgt));

                // check for partial draft acceptance
                if (n_rollback > 0) {
                    if (use_ckpt_tgt) {
                        if (trace > 0) {
                            SLT_INF(slot, "accepted %2zu/%2zu draft tokens (restore checkpoint)\n", accepted.size() - 1, slot.spec_draft.size());
                        }

                        // partial acceptance is not supported by the context -> truncate the draft and restore the state
                        slot.spec_is_replay = true;
                        slot.spec_draft = std::move(accepted);

                        const auto & ckpt = slot.spec_ckpt;

                        SLT_DBG(slot, "restoring speculative checkpoint (pos_min = %d, pos_max = %d, size = %zu)\n", ckpt.pos_min, ckpt.pos_max, ckpt.size());

                        ckpt.load_tgt(slot.ctx_tgt, slot.id, get_spec_checkpoint_flags(slot.ctx_tgt));

                        if (slot.ctx_dft) {
                            ckpt.load_dft(slot.ctx_dft, slot.id, get_spec_checkpoint_flags(slot.ctx_dft));
                        }
                        common_speculative_set_state(spec.get(), slot.id, ckpt.data_spec);

                        slot.mem.seq_rm(slot.id, ckpt.pos_max + 1, -1);

                        slot.prompt.tokens.keep_first(ckpt.n_tokens);
                        slot.smpl = std::move(smpl_save);

                        // XKV abort side: checkpoint restore + seq_rm reset the
                        // tentative rows; no accepted prefix exists yet, so no
                        // sealing may run on this path.

                        return;
                    }
                }

                if (trace > 0) {
                    SLT_INF(slot, "accepted %2zu/%2zu draft tokens\n", accepted.size() - 1, n_draft);
                }

                common_speculative_accept(spec.get(), slot.id, accepted.size() - 1);

                slot.spec_draft = std::move(accepted);
            }

            const int64_t t_now = ggml_time_us();

            const auto ids = std::move(slot.spec_draft);

            size_t n_accepted = ids.size() - 1;
            if (slot.spec_is_replay && n_accepted > 0) {
                n_accepted--;
            }
            slot.spec_is_replay = false;

            slot.t_token_generation = std::max<int64_t>(1, t_now - slot.t_start_generation) / 1e3;

            // update how many tokens out of those tested were accepted
            slot.n_draft_accepted += n_accepted;
            slot.n_draft_verif_steps += 1;

            if (slot.n_accepted_per_pos.empty()) {
                slot.n_accepted_per_pos.resize(common_speculative_n_max(&params_base.speculative), 0);
            }
            for (size_t i = 0; i < n_accepted && i < slot.n_accepted_per_pos.size(); ++i) {
                slot.n_accepted_per_pos[i]++;
            }

            // add accepted tokens to the prompt
            slot.prompt.tokens.keep_first(slot.prompt.n_tokens() - n_draft);
            slot.prompt.tokens.insert({ids.begin(), ids.end() - 1});

            slot.sampled = ids.back(); // last accepted token
            SLT_DBG(slot, "add accepted tokens: sampled=%d, ids.size=%zu, n_draft=%zu\n", slot.sampled, ids.size(), n_draft);

            slot.mem.seq_rm(slot.id, slot.prompt.tokens.pos_next(), -1);

            // XKV settle at the acceptance decision boundary. The seq_rm above
            // rolled back the rejected suffix (fail-closed: common_memory aborts
            // on removal failure), so only accepted-prefix rows remain
            // hot_committed. Publication (sealing) is legal only from this point
            // on — never at the generic decode tail before acceptance. Seal here
            // only when hot pressure is actually due (hot_free == 0 mirrors the
            // old fill-first trigger), so no unconditional sync happens when
            // maintenance is not needed; the pre-batch admission path remains
            // the primary seal driver. Errors are logged, never masking the
            // already-accepted decode.
            if (llama_xkv_is_enabled(params_base.xkv_mode)) {
                if (llama_memory_t mem_settle = llama_get_memory(slot.ctx_tgt)) {
                    llama_memory_admission_snapshot snap = {};
                    if (llama_memory_get_admission_snapshot(mem_settle, &snap) && snap.hot_free == 0) {
                        const auto mst = llama_memory_maintain_safe_boundary(mem_settle);
                        if (mst == LLAMA_MEMORY_MAINTENANCE_RETRY_STALE) {
                            const auto mst2 = llama_memory_maintain_safe_boundary(mem_settle);
                            if (mst2 == LLAMA_MEMORY_MAINTENANCE_ERROR) {
                                SLT_ERR(slot, "%s", "XKV settle maintain retry failed (decode already accepted; continuing without sealing)\n");
                            }
                        } else if (mst == LLAMA_MEMORY_MAINTENANCE_ERROR) {
                            SLT_ERR(slot, "%s", "XKV settle maintain failed (decode already accepted; continuing without sealing)\n");
                        }
                    }
                }
            }

            for (size_t i = 0; i < ids.size(); ++i) {
                completion_token_output result;

                result.tok          = ids[i];
                result.text_to_send = common_token_to_piece(slot.ctx_tgt, result.tok, accept_special_token(slot, result.tok));
                result.prob         = 1.0f; // set later

                // TODO: set result.probs

                slot.n_decoded += 1;

                if (!process_token(result, slot)) {
                    slot.print_timings();
                    send_final_response(slot);
                    metrics.on_prediction(slot);
                    slot.release();

                    return;
                }
            }

            if (!accept_hack_block(slot, llama_tokens(ids.begin(), ids.end()))) {
                return;
            }

            slot.print_timings_tg();

            SLT_DBG(slot, "accepted %d/%d draft tokens, new n_tokens = %d\n", (int) n_accepted, (int) n_draft, slot.prompt.n_tokens());
        });

        const bool mtp_prof_active = spec && (std::getenv("GGML_TP5_PROFILE") != nullptr || std::getenv("GGML_TP5_MTP_PROFILE") != nullptr);
        if (mtp_prof_active && t_tgt_verify_start > 0) {
            const int64_t t_tgt_verify_us = ggml_time_us() - t_tgt_verify_start;
            common_speculative_record_target_verify_us(spec.get(), t_tgt_verify_us);
            t_tgt_verify_start = 0;
        }

        if (!common_speculative_commit(spec.get())) {
            throw std::runtime_error("failed to commit deferred speculative state");
        }
    }

    int get_slot_n_ctx() {
        return slots.back().n_ctx;
    }

    server_response_reader get_response_reader() {
        return server_response_reader(queue_tasks, queue_results, HTTP_POLLING_SECONDS);
    }
};

//
// server_context (public API)
//

server_context::server_context() : impl(new server_context_impl()) {}
server_context::~server_context() = default;

bool server_context::load_model(common_params & params) {
    return impl->load_model(params);
}

void server_context::start_loop() {
    auto & params = impl->params_base;
    impl->queue_tasks.start_loop(params.sleep_idle_seconds * 1000);
}

void server_context::terminate() {
    impl->queue_tasks.terminate();
}

void server_context::destroy() {
    impl->destroy();
}

llama_context * server_context::get_llama_context() const {
    return impl->ctx_tgt;
}

server_response_reader server_context::get_response_reader() {
    return impl->get_response_reader();
}

server_context_meta server_context::get_meta() const {
    auto bos_id = llama_vocab_bos(impl->vocab);
    auto eos_id = llama_vocab_eos(impl->vocab);
    auto bos_token_str = bos_id != LLAMA_TOKEN_NULL ? common_token_to_piece(impl->ctx_tgt, bos_id, true) : "";
    auto eos_token_str = eos_id != LLAMA_TOKEN_NULL ? common_token_to_piece(impl->ctx_tgt, eos_id, true) : "";

    const char * ftype_name = llama_ftype_name(llama_model_ftype(impl->model_tgt));

    return server_context_meta {
        /* build_info             */ std::string(llama_build_info()),
        /* model_name             */ impl->model_name,
        /* model_aliases          */ impl->model_aliases,
        /* model_tags             */ impl->model_tags,
        /* model_path             */ impl->params_base.model.path,
        /* has_mtmd               */ impl->mctx != nullptr,
        /* has_inp_image          */ impl->chat_params.allow_image,
        /* has_inp_audio          */ impl->chat_params.allow_audio,
        /* has_inp_video          */ impl->chat_params.allow_video,
        /* json_ui_settings       */ impl->json_ui_settings,
        /* slot_n_ctx             */ impl->get_slot_n_ctx(),
        /* pooling_type           */ llama_pooling_type(impl->ctx_tgt),

        /* chat_params            */ impl->chat_params,
        /* chat_template_caps     */ common_chat_templates_get_caps(impl->chat_params.tmpls.get()),

        /* bos_token_str          */ bos_token_str,
        /* eos_token_str          */ eos_token_str,
        /* fim_pre_token          */ llama_vocab_fim_pre(impl->vocab),
        /* fim_sub_token          */ llama_vocab_fim_suf(impl->vocab),
        /* fim_mid_token          */ llama_vocab_fim_mid(impl->vocab),
        /* fim_pad_token          */ llama_vocab_fim_pad(impl->vocab),
        /* fim_rep_token          */ llama_vocab_fim_rep(impl->vocab),
        /* fim_sep_token          */ llama_vocab_fim_sep(impl->vocab),

        /* logit_bias_eog         */ impl->params_base.sampling.logit_bias_eog,

        /* model_vocab_type       */ llama_vocab_type(impl->vocab),
        /* model_vocab_n_tokens   */ llama_vocab_n_tokens(impl->vocab),
        /* model_n_ctx_train      */ llama_model_n_ctx_train(impl->model_tgt),
        /* model_n_embd_inp       */ llama_model_n_embd(impl->model_tgt),
        /* model_n_params         */ llama_model_n_params(impl->model_tgt),
        /* model_size             */ llama_model_size(impl->model_tgt),
        /* model_ftype            */ ftype_name,
    };
}

// generator-like API for HTTP response generation
// may have bypass_sleep = true if the task does not use ctx_server
struct server_res_generator : server_res_spipe {
    server_response_reader rd;
    server_res_generator(server_queue & queue_tasks, server_response & queue_results, int sleep_idle_seconds, bool bypass_sleep = false)
            : rd(queue_tasks, queue_results, HTTP_POLLING_SECONDS) {
        // fast path in case sleeping is disabled
        bypass_sleep |= sleep_idle_seconds < 0;
        if (!bypass_sleep) {
            queue_tasks.wait_until_no_sleep();
        }
    }
    void ok(const json & response_data) {
        status = 200;
        data = safe_json_to_str(response_data);
    }
    void error(const json & error_data) {
        status = json_value(error_data, "code", 500);
        data = safe_json_to_str({{ "error", error_data }});
    }
};

void server_context::set_token_hack_factory(server_token_hack_factory_t factory) {
    GGML_ASSERT(impl->ctx_tgt == nullptr && "token hack factory must be set before load_model");
    impl->token_hack_factory = std::move(factory);
}

void server_context::set_state_callback(server_state_callback_t callback) {
    impl->callback_state = std::move(callback);
    impl->queue_tasks.on_sleeping_state([this](bool sleeping) {
        if (sleeping) {
            impl->callback_state(SERVER_STATE_SLEEPING, {});
        }
        // for sleeping == false, event is emitted by load_model()
    });
}

// server_routes
//

static void server_accumulate_oai_usage(json & total, const json & part, bool count_prompt) {
    if (total.is_null()) {
        total = {
            {"completion_tokens", int64_t(0)},
            {"prompt_tokens", int64_t(0)},
            {"total_tokens", int64_t(0)},
            {"prompt_tokens_details", {{"cached_tokens", int64_t(0)}}},
        };
    }
    total["completion_tokens"] = total["completion_tokens"].get<int64_t>() +
        part.at("completion_tokens").get<int64_t>();
    if (count_prompt) {
        total["prompt_tokens"] = total["prompt_tokens"].get<int64_t>() +
            part.at("prompt_tokens").get<int64_t>();
        total["prompt_tokens_details"]["cached_tokens"] =
            total["prompt_tokens_details"]["cached_tokens"].get<int64_t>() +
            part.at("prompt_tokens_details").at("cached_tokens").get<int64_t>();
    }
    total["total_tokens"] = total["prompt_tokens"].get<int64_t>() +
        total["completion_tokens"].get<int64_t>();
    if (part.contains("rerot")) {
        auto & summed = total["rerot"];
        for (const char * key : {"probe_tokens", "frame_tokens", "sampled_tokens", "source_end_tokens"}) {
            const int64_t prior = summed.is_null() ? 0 : summed.value(key, int64_t(0));
            summed[key] = prior + part.at("rerot").at(key).get<int64_t>();
        }
    }
    if (total.contains("rerot")) {
        total["rerot"]["prompt_tokens"] = total["prompt_tokens"];
        total["rerot"]["cached_tokens"] = total["prompt_tokens_details"]["cached_tokens"];
    }
}

static void server_aggregate_stream_usage(
        server_task_result & result, json & rendered, json & total,
        size_t completions_per_prompt, bool last) {
    auto * final = dynamic_cast<server_task_result_cmpl_final *>(&result);
    if (!final) {
        return;
    }
    server_accumulate_oai_usage(
        total, final->usage_json_oaicompat(), final->index % completions_per_prompt == 0);
    if (rendered.is_array()) {
        for (auto it = rendered.begin(); it != rendered.end();) {
            if (!it->contains("usage")) {
                ++it;
            } else if (last) {
                (*it)["usage"] = total;
                ++it;
            } else {
                if (it != rendered.begin() && it->contains("timings")) {
                    (*(it - 1))["timings"] = std::move((*it)["timings"]);
                }
                it = rendered.erase(it);
            }
        }
    } else if (rendered.is_object() && rendered.contains("usage")) {
        if (last) {
            rendered["usage"] = total;
        } else {
            rendered.erase("usage");
        }
    }
}

std::unique_ptr<server_res_generator> server_routes::handle_completions_impl(
            const server_http_req & req,
            server_task_type type,
            const json & data,
            const std::vector<raw_buffer> & files,
            task_response_type res_type) {
    GGML_ASSERT(type == SERVER_TASK_TYPE_COMPLETION || type == SERVER_TASK_TYPE_INFILL);

    auto res = create_response();
    auto completion_id = gen_chatcmplid();
    auto & rd = res->rd;
    auto & params = this->params;

    res->set_req(&req); // will also set spipe if needed

    int32_t sse_ping_interval = params.sse_ping_interval;
    size_t completions_per_prompt = 1;
    bool aggregate_usage = false;

    try {
        std::vector<server_task> tasks;

        const auto & prompt = data.at("prompt");
        // TODO: this log can become very long, put it behind a flag or think about a more compact format
        //SRV_DBG("Prompt: %s\n", prompt.is_string() ? prompt.get<std::string>().c_str() : prompt.dump(2).c_str());

        if (!params.path_prompts_log_dir.empty()) {
            const auto file_path = std::filesystem::path(params.path_prompts_log_dir) / string_format("%012" PRId64 ".txt", ggml_time_ms());
            std::ofstream f(file_path);
            if (f) {
                f << (prompt.is_string() ? prompt.get<std::string>().c_str() : prompt.dump(2).c_str());
            } else {
                SRV_ERR("failed to create %s\n", file_path.string().c_str());
            }
        }

        // process prompt
        std::vector<server_tokens> inputs;

        if (res_type != TASK_RESPONSE_TYPE_NONE && ctx_server.mctx != nullptr) {
            // This is the case used by OAI compatible chat path with MTMD. TODO It can be moved to the path below.
            inputs.push_back(process_mtmd_prompt(ctx_server.mctx, prompt.get<std::string>(), files));
        } else {
            // Everything else, including multimodal completions.
            inputs = tokenize_input_prompts(ctx_server.vocab, ctx_server.mctx, prompt, true, true);
        }

        // tasks.reserve(inputs.size()); // TODO: this is inaccurate due to child tasks

        // message delimiters for checkpointing
        auto delimiters = common_chat_msg_delimiters_parse(json_value(data, "message_delimiters", json::array()));
        delimiters.tokenize(ctx_server.vocab);

        for (size_t i = 0; i < inputs.size(); i++) {
            server_task task = server_task(type);

            task.id = rd.get_new_id();

            task.tokens = std::move(inputs[i]);
            task.params = server_schema::eval_llama_cmpl_schema(
                    ctx_server.vocab,
                    params,
                    meta->slot_n_ctx,
                    meta->logit_bias_eog,
                    data);
            server_rerot_apply_request_json(task, data, params);

            std::string rerot_error;
            if (!server_rerot_validate_task(task, rerot_error)) {
                throw std::invalid_argument(rerot_error);
            }

            task.params.message_spans = task.tokens.find_message_spans(delimiters);

            task.id_slot = json_value(data, "id_slot", -1);
            sse_ping_interval = task.params.sse_ping_interval;
            completions_per_prompt = static_cast<size_t>(task.params.n_cmpl);
            aggregate_usage =
                (res_type == TASK_RESPONSE_TYPE_OAI_CHAT || res_type == TASK_RESPONSE_TYPE_OAI_CMPL) &&
                (inputs.size() > 1 || completions_per_prompt > 1);

            // OAI-compat
            task.params.res_type          = res_type;
            task.params.oaicompat_cmpl_id = completion_id;
            task.params.oaicompat_model   = meta->model_name;
            task.cache_key = json_value(data, "cache_key", json_value(data, "session_id", std::string()));

            // prepare child tasks
            if (task.params.n_cmpl > 1) {
                int n_children = task.params.n_cmpl - 1;
                for (int j = 0; j < n_children; j++) {
                    task.add_child(task.id, rd.get_new_id());
                }
            }

            ctx_server.dump_request_tokens(
                task.tokens.get_text_tokens(),
                type == SERVER_TASK_TYPE_INFILL
                    ? server_token_dump_kind::infill
                    : server_token_dump_kind::completion);

            tasks.push_back(std::move(task));
        }

        rd.post_tasks(std::move(tasks));
    } catch (const std::exception & e) {
        res->error(format_error_response(e.what(), ERROR_TYPE_INVALID_REQUEST));
        return res;
    }

    bool stream = json_value(data, "stream", false);

    if (!stream) {
        // non-stream, wait for the results
        auto all_results = rd.wait_for_all(req.should_stop);
        if (all_results.is_terminated) {
            return res; // connection is closed
        } else if (all_results.error) {
            res->error(all_results.error->to_json());
            return res;
        } else {
            json arr = json::array();
            for (auto & res : all_results.results) {
                GGML_ASSERT(dynamic_cast<server_task_result_cmpl_final*>(res.get()) != nullptr);
                arr.push_back(res->to_json());
            }
            GGML_ASSERT(!arr.empty() && "empty results");
            if (arr.size() == 1) {
                // if single request, return single object instead of array
                res->ok(arr[0]);
            } else if (res_type == TASK_RESPONSE_TYPE_OAI_CHAT || res_type == TASK_RESPONSE_TYPE_OAI_CMPL) {
                // if multiple results in OAI format, we need to re-format them
                json & choices = arr[0]["choices"];
                json usage;
                for (size_t i = 0; i < arr.size(); i++) {
                    server_accumulate_oai_usage(
                        usage, arr[i].at("usage"),
                        all_results.results[i]->index % completions_per_prompt == 0);
                    if (i > 0) {
                        choices.push_back(std::move(arr[i]["choices"][0]));
                    }
                }
                arr[0]["usage"] = std::move(usage);
                res->ok(arr[0]);
            } else {
                // multi-results, non-OAI compat
                res->ok(arr);
            }
        }
    } else {
        // in streaming mode, the first error must be treated as non-stream response
        // this is to match the OAI API behavior
        // ref: https://github.com/ggml-org/llama.cpp/pull/16486#discussion_r2419657309
        auto first_result = rd.next(req.should_stop);
        if (first_result == nullptr) {
            GGML_ASSERT(req.should_stop());
            return res; // connection is closed
        }

        if (first_result->is_error()) {
            res->error(first_result->to_json());
            return res;
        }

        GGML_ASSERT(
            dynamic_cast<server_task_result_cmpl_partial*>(first_result.get()) != nullptr ||
            dynamic_cast<server_task_result_cmpl_final*>  (first_result.get()) != nullptr
        );

        // next responses are streamed
        // to be sent immediately
        json first_result_json = first_result->to_json();
        json stream_usage;
        if (aggregate_usage) {
            server_aggregate_stream_usage(
                *first_result, first_result_json, stream_usage, completions_per_prompt, !rd.has_next());
        }
        if (first_result_json == nullptr) {
            res->data = ""; // simply send HTTP headers and status code
        } else if (res_type == TASK_RESPONSE_TYPE_ANTHROPIC) {
            res->data = format_anthropic_sse(first_result_json);
        } else if (res_type == TASK_RESPONSE_TYPE_OAI_RESP) {
            res->data = format_oai_resp_sse(first_result_json);
        } else {
            res->data = format_oai_sse(first_result_json);
        }
        res->status = 200;
        res->content_type = "text/event-stream";
        res->set_next([res_this = res.get(), res_type, sse_ping_interval,
                       aggregate_usage, completions_per_prompt,
                       stream_usage = std::move(stream_usage)](std::string & output) mutable -> bool {
            static auto format_error = [](task_response_type res_type, const json & res_json) {
                if (res_type == TASK_RESPONSE_TYPE_ANTHROPIC) {
                    return format_anthropic_sse({
                        {"event", "error"},
                        {"data", res_json},
                    });
                } else {
                    return format_oai_sse(json {{ "error", res_json }});
                }
            };

            auto effective_should_stop = [&res_this]() {
                return res_this->should_stop();
            };

            try {
                if (effective_should_stop()) {
                    SRV_DBG("%s", "stopping streaming due to should_stop condition\n");
                    return false; // should_stop condition met
                }

                if (!res_this->data.empty()) {
                    // flush the first chunk
                    output = std::move(res_this->data);
                    res_this->data.clear();
                    return true;
                }

                server_response_reader & rd = res_this->rd;

                // check if there is more data
                if (!rd.has_next()) {
                    switch (res_type) {
                        case TASK_RESPONSE_TYPE_NONE:
                        case TASK_RESPONSE_TYPE_OAI_RESP:
                        case TASK_RESPONSE_TYPE_ANTHROPIC:
                            output = "";
                            break;

                        default:
                            output = "data: [DONE]\n\n";
                            break;
                    }
                    SRV_DBG("%s", "all results received, terminating stream\n");
                    return false; // no more data, terminate
                }

                // receive subsequent results
                bool timeout = false;
                int64_t start_time = ggml_time_ms();
                auto result = rd.next([&timeout, &start_time, sse_ping_interval, &effective_should_stop]() {
                    if (effective_should_stop()) {
                        return true; // should_stop condition met
                    } else if (sse_ping_interval > 0 && ggml_time_ms() - start_time > (int64_t)sse_ping_interval * 1000) {
                        timeout = true;
                        return true; // timeout
                    }
                    return false;
                });

                if (timeout) {
                    // some clients may time out (e.g. undici) will time out if no data is received for a while, so we need to send a ping to keep the connection alive
                    SRV_DBG("%s", "sending SSE ping\n");
                    output = ":\n\n";
                    return true;
                }

                if (result == nullptr) {
                    SRV_DBG("%s", "stopping streaming due to should_stop condition\n");
                    GGML_ASSERT(effective_should_stop());
                    return false; // should_stop condition met
                }

                // send the results
                if (result->is_error()) {
                    json res_json = result->to_json();
                    output = format_error(res_type, res_json);
                    SRV_DBG("%s", "error received during streaming, terminating stream\n");
                    return false; // terminate on error
                } else {
                    GGML_ASSERT(
                        dynamic_cast<server_task_result_cmpl_partial*>(result.get()) != nullptr
                        || dynamic_cast<server_task_result_cmpl_final*>(result.get()) != nullptr
                    );
                    json res_json = result->to_json();
                    if (aggregate_usage) {
                        server_aggregate_stream_usage(
                            *result, res_json, stream_usage, completions_per_prompt, !rd.has_next());
                    }
                    if (res_json.is_null()) {
                        // Later input groups also send a headers-only begin
                        // event; it is not a client-visible JSON null chunk.
                        output.clear();
                    } else if (res_type == TASK_RESPONSE_TYPE_ANTHROPIC) {
                        output = format_anthropic_sse(res_json);
                    } else if (res_type == TASK_RESPONSE_TYPE_OAI_RESP) {
                        output = format_oai_resp_sse(res_json);
                    } else {
                        output = format_oai_sse(res_json);
                    }
                }

                // has next data, continue
                return true;

            } catch (const std::exception & e) {
                json error_json = format_error_response(e.what(), ERROR_TYPE_SERVER);
                output = format_error(res_type, error_json);

                // terminate on exception
                return false;
            }
        });
    }

    return res;
}

std::unique_ptr<server_res_generator> server_routes::create_response(bool bypass_sleep) {
    return std::make_unique<server_res_generator>(queue_tasks, queue_results, params.sleep_idle_seconds, bypass_sleep);
}

server_routes::server_routes(const common_params & params, server_context & ctx_server)
        : params(params),
          ctx_server(*ctx_server.impl),
          queue_tasks(ctx_server.impl->queue_tasks),
          queue_results(ctx_server.impl->queue_results) {
    init_routes();
}

void server_routes::init_routes() {
    // IMPORTANT: all lambda functions must start with create_response()
    // this is to ensure that the server_res_generator can handle sleeping case correctly

    this->get_health = [this](const server_http_req &) {
        // error and loading states are handled by middleware
        auto res = create_response(true);

        // this endpoint can be accessed during sleeping
        // the next LOC is to avoid someone accidentally use ctx_server
        bool ctx_server; // do NOT delete this line
        GGML_UNUSED(ctx_server);

        res->ok({{"status", "ok"}});
        return res;
    };

    this->get_metrics = [this](const server_http_req & req) {
        auto res = create_response();
        if (!params.endpoint_metrics) {
            res->error(format_error_response("This server does not support metrics endpoint. Start it with `--metrics`", ERROR_TYPE_NOT_SUPPORTED));
            return res;
        }

        // request slots data using task queue
        {
            server_task task(SERVER_TASK_TYPE_METRICS);
            task.id = res->rd.get_new_id();
            res->rd.post_task(std::move(task), true); // high-priority task
        }

        // get the result
        auto result = res->rd.next(req.should_stop);
        if (!result) {
            // connection was closed
            GGML_ASSERT(req.should_stop());
            return res;
        }

        if (result->is_error()) {
            res->error(result->to_json());
            return res;
        }

        // TODO: get rid of this dynamic_cast
        auto res_task = dynamic_cast<server_task_result_metrics*>(result.get());
        GGML_ASSERT(res_task != nullptr);

        // metrics definition: https://prometheus.io/docs/practices/naming/#metric-names
        json all_metrics_def = json {
            {"counter", {{
                    {"name",  "prompt_tokens_total"},
                    {"help",  "Number of prompt tokens processed."},
                    {"value",  (uint64_t) res_task->n_prompt_tokens_processed_total}
            }, {
                    {"name",  "prompt_seconds_total"},
                    {"help",  "Prompt process time"},
                    {"value",  (uint64_t) res_task->t_prompt_processing_total / 1.e3}
            }, {
                    {"name",  "tokens_predicted_total"},
                    {"help",  "Number of generation tokens processed."},
                    {"value",  (uint64_t) res_task->n_tokens_predicted_total}
            }, {
                    {"name",  "tokens_predicted_seconds_total"},
                    {"help",  "Predict process time"},
                    {"value",  (uint64_t) res_task->t_tokens_generation_total / 1.e3}
            }, {
                    {"name",  "n_decode_total"},
                    {"help",  "Total number of llama_decode() calls"},
                    {"value",  res_task->n_decode_total}
            }, {
                    {"name",  "n_tokens_max"},
                    {"help",  "Largest observed n_tokens."},
                    {"value",  res_task->n_tokens_max}
            }, {
                    {"name",  "tri_drain_total"},
                    {"help",  "TriAttention initial pressure drains completed."},
                    {"value",  res_task->tri_drain_total}
            }, {
                    {"name",  "tri_maintenance_total"},
                    {"help",  "TriAttention sticky maintenance reclaims completed."},
                    {"value",  res_task->tri_maintenance_total}
            }, {
                    {"name",  "tri_floor_exhausted_total"},
                    {"help",  "KV pressure events that reached the TriAttention residency floor."},
                    {"value",  res_task->tri_floor_exhausted_total}
            }, {
                    {"name",  "tri_cells_freed_total"},
                    {"help",  "Physical KV cells freed by TriAttention over the process lifetime."},
                    {"value",  res_task->tri_cells_freed_total}
            }, {
                    {"name",  "tri_score_seconds"},
                    {"help",  "Wall time spent in TriAttention importance scoring."},
                    {"value",  res_task->tri_score_us_total / 1.e6}
            }, {
                    {"name",  "tri_pack_seconds"},
                    {"help",  "Wall time spent compacting TriAttention K/V data."},
                    {"value",  res_task->tri_pack_us_total / 1.e6}
            }}},
            {"gauge", {{
                    {"name",  "prompt_tokens_seconds"},
                    {"help",  "Average prompt throughput in tokens/s."},
                    {"value",  res_task->n_prompt_tokens_processed ? 1.e3 / res_task->t_prompt_processing * res_task->n_prompt_tokens_processed : 0.}
            },{
                    {"name",  "predicted_tokens_seconds"},
                    {"help",  "Average generation throughput in tokens/s."},
                    {"value",  res_task->n_tokens_predicted ? 1.e3 / res_task->t_tokens_generation * res_task->n_tokens_predicted : 0.}
            },{
                    {"name",  "requests_processing"},
                    {"help",  "Number of requests processing."},
                    {"value",  (uint64_t) res_task->n_processing_slots}
            },{
                    {"name",  "requests_deferred"},
                    {"help",  "Number of requests deferred."},
                    {"value",  (uint64_t) res_task->n_tasks_deferred}
            },{
                    {"name",  "n_busy_slots_per_decode"},
                    {"help",  "Average number of busy slots per llama_decode() call"},
                    {"value",  (float) res_task->n_busy_slots_total / std::max((float) res_task->n_decode_total, 1.f)}
            },{
                    {"name",  "tri_cells_before"},
                    {"help",  "Physical KV cells before the most recent successful TriAttention reclaim."},
                    {"value",  res_task->tri_cells_before}
            },{
                    {"name",  "tri_cells_after"},
                    {"help",  "Physical KV cells after the most recent successful TriAttention reclaim."},
                    {"value",  res_task->tri_cells_after}
            },{
                    {"name",  "tri_cells_freed"},
                    {"help",  "Physical KV cells freed by the most recent successful TriAttention reclaim."},
                    {"value",  res_task->tri_cells_freed}
            },{
                    {"name",  "tri_references_removed"},
                    {"help",  "Per-sequence KV references removed by the most recent successful TriAttention reclaim."},
                    {"value",  res_task->tri_references_removed}
            },{
                    {"name",  "tri_target_references"},
                    {"help",  "Reference-level residency targets in the most recent successful TriAttention reclaim."},
                    {"value",  res_task->tri_target_references}
            },{
                    {"name",  "tri_hard_keep"},
                    {"help",  "Hard-protected KV references in the most recent successful TriAttention reclaim."},
                    {"value",  res_task->tri_hard_keep}
            },{
                    {"name",  "tri_shared_keep"},
                    {"help",  "Physical KV cells retained by multiple sequences after the most recent TriAttention reclaim."},
                    {"value",  res_task->tri_shared_keep}
            }}}
        };

        std::stringstream prometheus;

        for (const auto & el : all_metrics_def.items()) {
            const auto & type        = el.key();
            const auto & metrics_def = el.value();

            for (const auto & metric_def : metrics_def) {
                const std::string name = metric_def.at("name");
                const std::string help = metric_def.at("help");

                auto value = json_value(metric_def, "value", 0.);
                prometheus << "# HELP llamacpp:" << name << " " << help  << "\n"
                            << "# TYPE llamacpp:" << name << " " << type  << "\n"
                            << "llamacpp:"        << name << " " << value << "\n";
            }
        }

        if (!res_task->rerot.empty()) {
            const auto emit_rerot = [&prometheus](
                    const char * type,
                    const char * name,
                    const char * help,
                    const auto & value) {
                prometheus << "# HELP llamacpp:" << name << " " << help << "\n"
                           << "# TYPE llamacpp:" << name << " " << type << "\n"
                           << "llamacpp:" << name << " " << value << "\n";
            };
            const auto & r = res_task->rerot;
            emit_rerot("counter", "rerot_episode_total", "RERoT episodes started.", r.episode_total);
            emit_rerot("gauge", "rerot_episode_active", "RERoT episodes currently active.", r.episode_active);
            emit_rerot("counter", "rerot_nodes_created", "RERoT logical nodes created.", r.nodes_created);
            emit_rerot("counter", "rerot_nodes_started", "RERoT logical nodes admitted to execution.", r.nodes_started);
            emit_rerot("counter", "rerot_nodes_retired", "RERoT logical nodes retired.", r.nodes_retired);
            emit_rerot("counter", "rerot_nodes_queued", "RERoT logical nodes enqueued.", r.nodes_queued);
            emit_rerot("gauge", "rerot_queue_max", "Largest observed RERoT ready queue.", r.queue_max);
            emit_rerot("counter", "rerot_forks_total", "RERoT fork publications.", r.forks_total);
            emit_rerot("gauge", "rerot_max_depth", "Largest observed RERoT tree depth.", r.max_depth);
            emit_rerot("gauge", "rerot_max_live_lanes", "Largest observed concurrent RERoT Lane count.", r.max_live_lanes);
            emit_rerot("counter", "rerot_public_tokens", "RERoT PUBLIC tokens committed.", r.public_tokens);
            emit_rerot("counter", "rerot_private_tokens", "RERoT PRIVATE control tokens committed.", r.private_tokens);
            emit_rerot("counter", "rerot_pending_tokens", "RERoT PENDING record tokens committed.", r.pending_tokens);
            emit_rerot("counter", "rerot_completed_episode_total", "RERoT episodes that produced a final response.", r.completed_episodes);
            emit_rerot("counter", "rerot_completed_model_tokens", "Model-forward tokens committed by completed RERoT episodes; includes PUBLIC, PRIVATE, and PENDING tokens.", r.completed_model_tokens);
            emit_rerot("counter", "rerot_parallel_model_tokens", "Model-forward tokens committed between first multi-Lane admission and the final acquire fence.", r.parallel_model_tokens);
            emit_rerot("counter", "rerot_completed_episode_seconds", "RERoT episode wall time after prompt prefill; divide completed model tokens by this value for aggregate throughput.", r.completed_episode_seconds);
            emit_rerot("counter", "rerot_parallel_seconds", "Multi-Lane phase wall time; divide parallel model tokens by this value for parallel aggregate throughput.", r.parallel_seconds);
            emit_rerot("counter", "rerot_parallel_peak_lanes_total", "Sum over completed RERoT episodes of peak concurrent Lane count during the episode's multi-Lane phase (C02 evidence counter).", r.parallel_peak_lanes_sum);
            emit_rerot("counter", "rerot_frontiers", "RERoT frontiers committed.", r.frontiers);
            emit_rerot("counter", "rerot_topology_barriers", "RERoT topology barriers completed.", r.topology_barriers);
            emit_rerot("counter", "rerot_refresh_total", "RERoT view refreshes completed.", r.refresh_total);
            emit_rerot("counter", "rerot_mtp_invalidations", "RERoT-stale speculative drafts invalidated.", r.mtp_invalidations);
            emit_rerot("counter", "rerot_context_shifts", "RERoT shared-log context shifts completed.", r.context_shifts);
            emit_rerot("counter", "rerot_hard_aborts", "RERoT episodes atomically aborted.", r.hard_aborts);
            emit_rerot("counter", "rerot_final_fences", "RERoT final acquire fences completed.", r.final_fences);
            emit_rerot("counter", "rerot_span_count", "DDVR spans rendered for RERoT views.", r.span_count);
            emit_rerot("counter", "rerot_parked_total", "RERoT recurrent lineages parked.", r.parked_total);
            emit_rerot("counter", "rerot_archive_total", "RERoT public runs archived.", r.archive_total);
            emit_rerot("counter", "rerot_ddvr_seconds", "Wall time spent building RERoT DDVR views.", r.ddvr_seconds);

            emit_rerot("counter", "rerot_probe_seconds", "Wall time spent in RERoT isolated routing probe.", r.probe_seconds);
            emit_rerot("counter", "rerot_probe_count", "Total RERoT isolated routing probe executions.", r.probe_count);
            emit_rerot("counter", "rerot_prefix_rebuild_seconds", "Wall time spent in RERoT DAG prefix rebuild.", r.prefix_rebuild_seconds);
            emit_rerot("counter", "rerot_prefix_rebuild_count", "Total RERoT DAG prefix rebuild executions.", r.prefix_rebuild_count);
            emit_rerot("counter", "rerot_ordinary_prompt_tokens", "Cumulative ordinary prompt tokens before RERoT DAG prefix rebuild.", r.ordinary_prompt_tokens);
            emit_rerot("counter", "rerot_dag_lcp_tokens", "Cumulative token LCP between ordinary prompt and DAG template in RERoT rebuild.", r.dag_lcp_tokens);
            emit_rerot("counter", "rerot_replay_from_tokens", "Cumulative rebuild replay starting positions in RERoT prefix rebuild.", r.replay_from_tokens);
            emit_rerot("counter", "rerot_actual_replayed_tokens", "Cumulative tokens actually replayed during RERoT DAG prefix rebuild.", r.actual_replayed_tokens);
            emit_rerot("counter", "rerot_fixed_entry_seconds", "Wall time spent rendering RERoT fixed entry templates.", r.fixed_entry_seconds);
            emit_rerot("counter", "rerot_fixed_entry_count", "Total RERoT fixed entry template renders.", r.fixed_entry_count);
            emit_rerot("counter", "rerot_synthesis_switch_seconds", "Wall time spent switching and admitting DAG synthesis.", r.synthesis_switch_seconds);
            emit_rerot("counter", "rerot_synthesis_switch_count", "Total DAG synthesis transitions executed.", r.synthesis_switch_count);

            emit_rerot("counter", "rerot_sync_capture_us", "GPU synchronization duration at post-decode decision capture.", r.sync_capture_us);
            emit_rerot("counter", "rerot_sync_capture_count", "Total GPU synchronizations at post-decode decision capture.", r.sync_capture_count);
            emit_rerot("counter", "rerot_sync_sample_us", "GPU synchronization duration at post-decode sampling.", r.sync_sample_us);
            emit_rerot("counter", "rerot_sync_sample_count", "Total GPU synchronizations at post-decode sampling.", r.sync_sample_count);
            emit_rerot("counter", "rerot_sync_sample_no_work_us", "GPU synchronization duration at sampling where no new GPU work was submitted since last sync (redundant wait).", r.sync_sample_no_work_us);
            emit_rerot("counter", "rerot_sync_sample_no_work_count", "Total GPU synchronizations at sampling without new GPU work since last sync.", r.sync_sample_no_work_count);
            emit_rerot("counter", "rerot_sync_sample_with_work_us", "GPU synchronization duration at sampling with un-synchronized GPU work.", r.sync_sample_with_work_us);
            emit_rerot("counter", "rerot_sync_sample_with_work_count", "Total GPU synchronizations at sampling with un-synchronized GPU work.", r.sync_sample_with_work_count);

            emit_rerot("gauge", "rerot_people_capacity", "Maximum concurrent people / independent brains (B).", r.people_capacity);
            emit_rerot("gauge", "rerot_people_resident", "Currently resident people / independent brains.", r.people_resident);
            emit_rerot("gauge", "rerot_people_runnable", "Currently runnable people / independent brains.", r.people_runnable);
            emit_rerot("gauge", "rerot_people_waiting", "Currently waiting people in admission queue.", r.people_waiting);

            emit_rerot("gauge", "rerot_pens_capacity", "Total execution pens / decode rows (P).", r.pens_capacity);
            emit_rerot("gauge", "rerot_pens_allocated", "Currently allocated pens.", r.pens_allocated);
            emit_rerot("gauge", "rerot_pens_running", "Currently running pens.", r.pens_running);
            emit_rerot("gauge", "rerot_pens_suspended", "Currently suspended pens awaiting resume.", r.pens_suspended);
            emit_rerot("gauge", "rerot_pen_queue_depth", "Current queue depth of unadmitted children awaiting pens.", r.pen_queue_depth);
            emit_rerot("gauge", "rerot_pens_per_person_max_observed", "Maximum pens observed allocated to a single person.", r.pens_per_person_max_observed);
            emit_rerot("gauge", "rerot_pen_utilization", "Fraction of pen capacity currently allocated.", r.pen_utilization);

            emit_rerot("gauge", "rerot_batch_people", "People present in last decoded batch.", r.batch_people);
            emit_rerot("gauge", "rerot_batch_pens", "Pens / rows present in last decoded batch.", r.batch_pens);
            emit_rerot("counter", "rerot_frontier_rows", "Cumulative frontier rows decoded across all pens.", r.frontier_rows);
            emit_rerot("counter", "rerot_six_row_batches", "Successful decode slices containing at least six RERoT pen rows in one llama_decode call.", r.six_row_batches);

            emit_rerot("gauge", "rerot_brain_bytes", "Estimated recurrent brain memory in bytes.", r.brain_bytes);
            emit_rerot("gauge", "rerot_hand_bytes", "Estimated recurrent hand memory in bytes.", r.hand_bytes);
            emit_rerot("gauge", "rerot_grouped_scratch_bytes", "Estimated grouped multi-reader / RBB scratch in bytes.", r.grouped_scratch_bytes);
        }

        // XKV suite (§16): additive; OFF (empty) emits nothing.
        if (!res_task->xkv.empty()) {
            res_task->xkv.to_prometheus(prometheus);
        }

        // Labeled fallback counter is emitted separately because the compact
        // metric-definition helper above intentionally models unlabeled series.
        prometheus << "# HELP llamacpp:tri_atomic_fallback_total Atomic fallback entries after dynamic-memory pressure, by reason.\n"
                   << "# TYPE llamacpp:tri_atomic_fallback_total counter\n"
                   << "llamacpp:tri_atomic_fallback_total{reason=\"kv\"} "
                   << res_task->tri_atomic_fallback_kv_total << "\n"
                   << "llamacpp:tri_atomic_fallback_total{reason=\"recurrent\"} "
                   << res_task->tri_atomic_fallback_recurrent_total << "\n";

        // FlashPrefill V2 series (MetricsIntegration owner; ServerRouting
        // owns the eligible/dense-reason source rows). Always emitted —
        // including zeros while OFF, which cost no GPU work or counting
        // overhead (the matrix off_baseline expects the counters present);
        // only the fingerprint info is policy-gated (no value while OFF).
        // All labels are bounded (9 granular dense reasons, 7 frozen server
        // reasons, 2 pool reasons, 3 plan reasons, one fingerprint value);
        // no sequence ids, prompt text, or unbounded reader ids. Units:
        // sparse/dense_packed are packed execution rows (plan-confirmed);
        // dense breakdowns are packed rows by reason; selected/corrected are
        // plan use counts; visible/exact are 64-bit use-record token sums.
        // Keep one unit per ratio: sparse/(sparse+dense_packed), or
        // exact/visible. Timings: layout is host-measured; pool/select/
        // attention are GPU dispatch times sampled post-completion from the
        // VulkanDispatch timestamp hook (0 until it reports — never faked).
        {
            const auto emit_fp = [&prometheus](
                    const char * type,
                    const char * name,
                    const char * help,
                    const auto & value) {
                prometheus << "# HELP llamacpp:" << name << " " << help << "\n"
                           << "# TYPE llamacpp:" << name << " " << type << "\n"
                           << "llamacpp:" << name << " " << value << "\n";
            };
            namespace fp = server_flashprefill_routing;
            emit_fp("counter", "flashprefill_eligible_rows_total",
                    "Source rows presented with a sparse-eligible role and known boundary.",
                    res_task->fp_eligible_rows);
            emit_fp("counter", "flashprefill_sparse_rows_total",
                    "Packed execution rows confirmed sparse by the plan headers after successful completion.",
                    res_task->fp_sparse_rows);
            emit_fp("counter", "flashprefill_dense_packed_rows_total",
                    "Packed execution rows the plans ran dense.",
                    res_task->fp_dense_packed);
            emit_fp("counter", "flashprefill_selected_blocks_total",
                    "Plan exact uses summed over layers.",
                    res_task->fp_selected_blocks);
            emit_fp("counter", "flashprefill_corrected_blocks_total",
                    "Plan proxy (mean-corrected) uses summed over layers.",
                    res_task->fp_corrected_blocks);
            emit_fp("counter", "flashprefill_visible_tokens_total",
                    "Plan use-record token sum over layers (64-bit, subhead fan-out not multiplied).",
                    res_task->fp_visible_tokens);
            emit_fp("counter", "flashprefill_exact_tokens_total",
                    "Plan exact-use token sum over layers (64-bit).",
                    res_task->fp_exact_tokens);
            emit_fp("gauge", "flashprefill_scratch_bytes",
                    "Live FlashPrefill scratch bytes from the last successful slice.",
                    res_task->fp_scratch_live_bytes);
            emit_fp("gauge", "flashprefill_scratch_peak_bytes",
                    "Peak FlashPrefill scratch bytes over successful slices.",
                    res_task->fp_scratch_peak_bytes);
            emit_fp("counter", "flashprefill_layout_seconds",
                    "Host layout time over measured slices.",
                    res_task->fp_layout_us_total / 1.e6);
            emit_fp("counter", "flashprefill_pool_seconds",
                    "GPU pool-dispatch time over sampled calls (0 until the timestamp hook reports).",
                    res_task->fp_gpu_pool_us_total / 1.e6);
            emit_fp("counter", "flashprefill_select_seconds",
                    "GPU select-dispatch time over sampled calls (0 until the timestamp hook reports).",
                    res_task->fp_gpu_select_us_total / 1.e6);
            emit_fp("counter", "flashprefill_attention_seconds",
                    "GPU attention-dispatch time over sampled calls, merge included (0 until the timestamp hook reports).",
                    res_task->fp_gpu_attn_us_total / 1.e6);
            prometheus << "# HELP llamacpp:flashprefill_dense_rows_total Packed rows executed dense by granular reason.\n"
                       << "# TYPE llamacpp:flashprefill_dense_rows_total counter\n";
            for (int i = 0; i < 10; ++i) {
                prometheus << "llamacpp:flashprefill_dense_rows_total{reason=\""
                           << fp::fp_gpu_dense_name(i) << "\"} " << res_task->fp_dense_rows[i] << "\n";
            }
            prometheus << "# HELP llamacpp:flashprefill_server_dense_rows_total Source rows routed dense by frozen server reason.\n"
                       << "# TYPE llamacpp:flashprefill_server_dense_rows_total counter\n";
            for (int i = 0; i < 7; ++i) {
                const int32_t route = fp::fp_dense_index_to_route(i);
                prometheus << "llamacpp:flashprefill_server_dense_rows_total{reason=\""
                           << llama_flashprefill_route_name(route) << "\"} "
                           << res_task->fp_dense_by_reason[i] << "\n";
            }
            prometheus << "# HELP llamacpp:flashprefill_pool_rebuild_total Pool-mean rebuilds by reason.\n"
                       << "# TYPE llamacpp:flashprefill_pool_rebuild_total counter\n";
            for (int i = 0; i < 2; ++i) {
                prometheus << "llamacpp:flashprefill_pool_rebuild_total{reason=\""
                           << fp::fp_gpu_pool_name(i) << "\"} " << res_task->fp_pool_rebuild[i] << "\n";
            }
            prometheus << "# HELP llamacpp:flashprefill_plan_invalidations_total Plan invalidations by reason.\n"
                       << "# TYPE llamacpp:flashprefill_plan_invalidations_total counter\n";
            for (int i = 0; i < 3; ++i) {
                prometheus << "llamacpp:flashprefill_plan_invalidations_total{reason=\""
                           << fp::fp_gpu_plan_name(i) << "\"} " << res_task->fp_plan_invalidations[i] << "\n";
            }
            if (res_task->fp_has_policy) {
                const std::string fphex = string_format("%016" PRIx64, (uint64_t) res_task->fp_policy_fingerprint);
                prometheus << "# HELP llamacpp:flashprefill_policy_fingerprint_info Active FlashPrefill policy fingerprint (single series).\n"
                           << "# TYPE llamacpp:flashprefill_policy_fingerprint_info gauge\n"
                           << "llamacpp:flashprefill_policy_fingerprint_info{fingerprint=\"" << fphex << "\"} 1\n";
            }
        }

        res->headers["Process-Start-Time-Unix"] = std::to_string(res_task->t_start);
        res->content_type = "text/plain; version=0.0.4";
        res->status = 200;
        res->data = prometheus.str();
        return res;
    };

    this->get_slots = [this](const server_http_req & req) {
        auto res = create_response();
        if (!params.endpoint_slots) {
            res->error(format_error_response("This server does not support slots endpoint. Start it with `--slots`", ERROR_TYPE_NOT_SUPPORTED));
            return res;
        }

        // request slots data using task queue
        {
            server_task task(SERVER_TASK_TYPE_METRICS);
            task.id = res->rd.get_new_id();
            res->rd.post_task(std::move(task), true); // high-priority task
        }

        // get the result
        auto result = res->rd.next(req.should_stop);
        if (!result) {
            // connection was closed
            GGML_ASSERT(req.should_stop());
            return res;
        }

        if (result->is_error()) {
            res->error(result->to_json());
            return res;
        }

        // TODO: get rid of this dynamic_cast
        auto * res_task = dynamic_cast<server_task_result_metrics*>(result.get());
        GGML_ASSERT(res_task != nullptr);

        // optionally return "fail_on_no_slot" error
        if (!req.get_param("fail_on_no_slot").empty()) {
            if (res_task->n_idle_slots == 0) {
                res->error(format_error_response("no slot available", ERROR_TYPE_UNAVAILABLE));
                return res;
            }
        }

        res->ok(res_task->slots_data);
        return res;
    };

    this->post_slots = [this](const server_http_req & req) {
        auto res = create_response();
        if (params.slot_save_path.empty()) {
            res->error(format_error_response("This server does not support slots action. Start it with `--slot-save-path`", ERROR_TYPE_NOT_SUPPORTED));
            return res;
        }

        std::string id_slot_str = req.get_param("id_slot");

        int id_slot;
        try {
            id_slot = std::stoi(id_slot_str);
        } catch (const std::exception &) {
            res->error(format_error_response("Invalid slot ID", ERROR_TYPE_INVALID_REQUEST));
            return res;
        }

        std::string action = req.get_param("action");

        if (action == "save") {
            return handle_slots_save(req, id_slot);
        }
        if (action == "restore") {
            return handle_slots_restore(req, id_slot);
        }
        if (action == "erase") {
            return handle_slots_erase(req, id_slot);
        }

        res->error(format_error_response("Invalid action", ERROR_TYPE_INVALID_REQUEST));
        return res;
    };

    this->get_props = [this](const server_http_req &) {
        auto res = create_response(true);

        // this endpoint can be accessed during sleeping
        // the next LOC is to avoid someone accidentally use ctx_server
        bool ctx_server; // do NOT delete this line
        GGML_UNUSED(ctx_server);

        task_params tparams;
        tparams.sampling = params.sampling;
        json default_generation_settings_for_props = json {
            { "params", tparams.to_json(true) },
            { "n_ctx",  meta->slot_n_ctx },
        };

        std::string tmpl_default = common_chat_templates_source(meta->chat_params.tmpls.get(), "");
        std::string tmpl_tools   = common_chat_templates_source(meta->chat_params.tmpls.get(), "tool_use");

        json props = {
            { "default_generation_settings", default_generation_settings_for_props },
            { "total_slots",                 params.n_parallel },
            { "model_alias",                 meta->model_name },
            { "model_ftype",                 meta->model_ftype },
            { "model_path",                  meta->model_path },
            { "modalities",                  json {
                {"vision", meta->has_inp_image},
                {"video",  meta->has_inp_video},
                {"audio",  meta->has_inp_audio},
            } },
            { "media_marker",                get_media_marker() },
            { "endpoint_slots",              params.endpoint_slots },
            { "endpoint_props",              params.endpoint_props },
            { "endpoint_metrics",            params.endpoint_metrics },
            { "ui",                          params.ui },
            { "ui_settings",                 meta->json_ui_settings },
            { "chat_template",               tmpl_default },
            { "chat_template_caps",          meta->chat_template_caps },
            { "bos_token",                   meta->bos_token_str },
            { "eos_token",                   meta->eos_token_str },
            { "build_info",                  meta->build_info },
            { "is_sleeping",                 queue_tasks.is_sleeping() },
            { "cors_proxy_enabled",          params.ui_mcp_proxy },
        };

        // Evaluator identity keys: content-checksum model identity (never path),
        // exact XKV mode, factorization seed, Tri calibration identity, RERoT
        // frontier mode, and speculative draft bounds.
        const llama_model * pmodel = this->ctx_server.model_tgt;
        if (pmodel != nullptr) {
            uint8_t msha[32] = {};
            if (llama_model_source_artifact_sha256(pmodel, msha)) {
                std::ostringstream ss;
                for (int i = 0; i < 32; ++i) {
                    ss << std::hex << std::nouppercase << std::setw(2) << std::setfill('0') << (int) msha[i];
                }
                props["model_sha256"] = ss.str();
            }
        }
        props["xkv_mode"] = llama_xkv_mode_name(params.xkv_mode);
        {
            std::ostringstream ss;
            ss << "0x" << std::hex << std::nouppercase << std::setw(16) << std::setfill('0') << params.xkv_seed;
            props["xkv_seed"] = ss.str();
            props["xkv_factor_seed"] = ss.str();
        }
        props["xkv_storage_profile"] = llama_xkv_storage_profile_name(params.xkv_storage_profile);
        {
            std::ostringstream ss_lm;
            ss_lm << "0x" << std::hex << std::nouppercase << std::setw(16) << std::setfill('0') << (uint64_t) 777;
            props["xkv_landmark_seed"] = ss_lm.str();
        }
        props["rerot_frontier"] = std::string(llama_rerot_frontier_mode_name(params.rerot_frontier));
        props["rerot"] = {
            { "enabled", params.rerot_enabled },
            { "wire", params.rerot_enabled ? params.rerot_plan_wire : "none" },
            { "final", params.rerot_enabled ? params.rerot_final_mode : "plain" },
            { "order", !params.rerot_enabled ? "plain" :
                params.rerot_plan_wire == "mindmap" ? "hierarchical-cyclic-dfs" : "kahn" },
            { "deps", !params.rerot_enabled ? "none" :
                params.rerot_plan_wire == "mindmap" ? "none" : "model" },
        };
        props["spec_draft_n_max"] = params.speculative.draft.n_max;
        props["triattention_ratio"] = "3/32";
        props["tri_recent_window"] = 128;
        if (params.use_jinja) {
            if (!tmpl_tools.empty()) {
                props["chat_template_tool_use"] = tmpl_tools;
            }
        }
        res->ok(props);
        return res;
    };

    this->post_props = [this](const server_http_req &) {
        auto res = create_response();
        if (!params.endpoint_props) {
            res->error(format_error_response("This server does not support changing global properties. Start it with `--props`", ERROR_TYPE_NOT_SUPPORTED));
            return res;
        }
        // update any props here

        res->ok({{ "success", true }});
        return res;
    };

    this->post_infill = [this](const server_http_req & req) {
        auto res = create_response();
        // check model compatibility
        std::string err;
        if (llama_vocab_fim_pre(ctx_server.vocab) == LLAMA_TOKEN_NULL) {
            err += "prefix token is missing. ";
        }
        if (llama_vocab_fim_suf(ctx_server.vocab) == LLAMA_TOKEN_NULL) {
            err += "suffix token is missing. ";
        }
        if (llama_vocab_fim_mid(ctx_server.vocab) == LLAMA_TOKEN_NULL) {
            err += "middle token is missing. ";
        }
        if (!err.empty()) {
            res->error(format_error_response(string_format("Infill is not supported by this model: %s", err.c_str()), ERROR_TYPE_NOT_SUPPORTED));
            return res;
        }

        // validate input
        json data = json::parse(req.body);
        if (data.contains("prompt") && !data.at("prompt").is_string()) {
            // prompt is optional
            res->error(format_error_response("\"prompt\" must be a string", ERROR_TYPE_INVALID_REQUEST));
        }

        if (!data.contains("input_prefix")) {
            res->error(format_error_response("\"input_prefix\" is required", ERROR_TYPE_INVALID_REQUEST));
        }

        if (!data.contains("input_suffix")) {
            res->error(format_error_response("\"input_suffix\" is required", ERROR_TYPE_INVALID_REQUEST));
        }

        if (data.contains("input_extra") && !data.at("input_extra").is_array()) {
            // input_extra is optional
            res->error(format_error_response("\"input_extra\" must be an array of {\"filename\": string, \"text\": string}", ERROR_TYPE_INVALID_REQUEST));
            return res;
        }

        json input_extra = json_value(data, "input_extra", json::array());
        for (const auto & chunk : input_extra) {
            // { "text": string, "filename": string }
            if (!chunk.contains("text") || !chunk.at("text").is_string()) {
                res->error(format_error_response("extra_context chunk must contain a \"text\" field with a string value", ERROR_TYPE_INVALID_REQUEST));
                return res;
            }
            // filename is optional
            if (chunk.contains("filename") && !chunk.at("filename").is_string()) {
                res->error(format_error_response("extra_context chunk's \"filename\" field must be a string", ERROR_TYPE_INVALID_REQUEST));
                return res;
            }
        }
        data["input_extra"] = input_extra; // default to empty array if it's not exist

        std::string prompt = json_value(data, "prompt", std::string());
        std::vector<server_tokens> tokenized_prompts = tokenize_input_prompts(ctx_server.vocab, ctx_server.mctx, prompt, false, true);
        SRV_DBG("creating infill tasks, n_prompts = %d\n", (int) tokenized_prompts.size());
        data["prompt"] = format_prompt_infill(
            ctx_server.vocab,
            data.at("input_prefix"),
            data.at("input_suffix"),
            data.at("input_extra"),
            params.n_batch,
            params.n_predict,
            meta->slot_n_ctx,
            params.spm_infill,
            tokenized_prompts[0].get_tokens() // TODO: this could maybe be multimodal.
        );

        std::vector<raw_buffer> files; // dummy
        return handle_completions_impl(
            req,
            SERVER_TASK_TYPE_INFILL,
            data,
            files,
            TASK_RESPONSE_TYPE_NONE); // infill is not OAI compatible
    };

    this->post_completions = [this](const server_http_req & req) {
        auto res = create_response();
        std::vector<raw_buffer> files; // dummy
        const json body = json::parse(req.body);
        return handle_completions_impl(
            req,
            SERVER_TASK_TYPE_COMPLETION,
            body,
            files,
            TASK_RESPONSE_TYPE_NONE);
    };

    this->post_completions_oai = [this](const server_http_req & req) {
        auto res = create_response();
        std::vector<raw_buffer> files; // dummy
        const json body = json::parse(req.body);
        return handle_completions_impl(
            req,
            SERVER_TASK_TYPE_COMPLETION,
            body,
            files,
            TASK_RESPONSE_TYPE_OAI_CMPL);
    };

    this->post_chat_completions = [this](const server_http_req & req) {
        auto res = create_response();
        std::vector<raw_buffer> files;
        json body = json::parse(req.body);
        json body_parsed = oaicompat_chat_params_parse(
            body,
            meta->chat_params,
            files);
        return handle_completions_impl(
            req,
            SERVER_TASK_TYPE_COMPLETION,
            body_parsed,
            files,
            TASK_RESPONSE_TYPE_OAI_CHAT);
    };

    this->post_chat_completions_tok = [this](const server_http_req & req) {
        return handle_count_tokens(ctx_server.vocab, ctx_server.mctx, req, TASK_RESPONSE_TYPE_OAI_CHAT);
    };

    this->post_control = [this](const server_http_req & req) {
        auto res = create_response();
        const json body = json::parse(req.body);

        const std::string cmpl_id = json_value(body, "id", std::string());
        const std::string action  = json_value(body, "action", std::string());
        if (cmpl_id.empty()) {
            res->error(format_error_response("missing completion id", ERROR_TYPE_INVALID_REQUEST));
            return res;
        }
        if (action != "reasoning_end") {
            res->error(format_error_response("unknown control action", ERROR_TYPE_INVALID_REQUEST));
            return res;
        }

        auto & rd = res->rd;
        {
            server_task task(SERVER_TASK_TYPE_CONTROL);
            task.id              = rd.get_new_id();
            task.params.control_cmpl_id = cmpl_id;
            task.params.control_action  = action;
            rd.post_task(std::move(task));
        }

        auto result = rd.next(req.should_stop);
        if (!result) {
            GGML_ASSERT(req.should_stop());
            return res;
        }
        if (result->is_error()) {
            res->error(result->to_json());
            return res;
        }
        res->ok(result->to_json());
        return res;
    };

    this->post_responses_oai = [this](const server_http_req & req) {
        auto res = create_response();
        std::vector<raw_buffer> files;
        json body = server_chat_convert_responses_to_chatcmpl(json::parse(req.body));
        SRV_DBG("%s\n", "Request converted: OpenAI Responses -> OpenAI Chat Completions");
        SRV_DBG("converted request: %s\n", body.dump().c_str());
        json body_parsed = oaicompat_chat_params_parse(
            body,
            meta->chat_params,
            files);
        return handle_completions_impl(
            req,
            SERVER_TASK_TYPE_COMPLETION,
            body_parsed,
            files,
            TASK_RESPONSE_TYPE_OAI_RESP);
    };

    this->post_responses_tok_oai = [this](const server_http_req & req) {
        return handle_count_tokens(ctx_server.vocab, ctx_server.mctx, req, TASK_RESPONSE_TYPE_OAI_RESP);
    };

    this->post_transcriptions_oai = [this](const server_http_req & req) {
        auto res = create_response();

        if (!meta->has_mtmd || !meta->chat_params.allow_audio) {
            res->error(format_error_response("The current model does not support audio input.", ERROR_TYPE_NOT_SUPPORTED));
            return res;
        }

        std::vector<raw_buffer> files;
        json body = convert_transcriptions_to_chatcmpl(
            json::parse(req.body),
            meta->chat_params.tmpls.get(),
            req.files,
            files);
        SRV_DBG("%s\n", "Request converted: OpenAI Transcriptions -> OpenAI Chat Completions");
        SRV_DBG("converted request: %s\n", body.dump().c_str());
        json body_parsed = oaicompat_chat_params_parse(
            body,
            meta->chat_params,
            files);
        return handle_completions_impl(
            req,
            SERVER_TASK_TYPE_COMPLETION,
            body_parsed,
            files,
            TASK_RESPONSE_TYPE_OAI_ASR);
    };

    this->post_anthropic_messages = [this](const server_http_req & req) {
        auto res = create_response();
        std::vector<raw_buffer> files;
        json body = server_chat_convert_anthropic_to_oai(json::parse(req.body));
        SRV_DBG("%s\n", "Request converted: Anthropic -> OpenAI Chat Completions");
        SRV_DBG("converted request: %s\n", body.dump().c_str());
        json body_parsed = oaicompat_chat_params_parse(
            body,
            meta->chat_params,
            files);
        return handle_completions_impl(
            req,
            SERVER_TASK_TYPE_COMPLETION,
            body_parsed,
            files,
            TASK_RESPONSE_TYPE_ANTHROPIC);
    };

    this->post_anthropic_count_tokens = [this](const server_http_req & req) {
        return handle_count_tokens(ctx_server.vocab, ctx_server.mctx, req, TASK_RESPONSE_TYPE_ANTHROPIC);
    };

    // same with handle_chat_completions, but without inference part
    this->post_apply_template = [this](const server_http_req & req) {
        auto res = create_response();
        std::vector<raw_buffer> files; // dummy, unused
        json body = json::parse(req.body);
        json data = oaicompat_chat_params_parse(
            body,
            meta->chat_params,
            files);
        res->ok({{ "prompt", std::move(data.at("prompt")) }});
        return res;
    };

    this->get_models = [this](const server_http_req &) {
        auto res = create_response(true);

        // this endpoint can be accessed during sleeping
        // the next LOC is to avoid someone accidentally use ctx_server
        bool ctx_server; // do NOT delete this line
        GGML_UNUSED(ctx_server);

        json models = {
            {"models", {
                {
                    {"name",  meta->model_name},
                    {"model", meta->model_name},
                    {"modified_at", ""},
                    {"size", ""},
                    {"digest", ""}, // dummy value, llama.cpp does not support managing model file's hash
                    {"type", "model"},
                    {"description", ""},
                    {"tags", {""}},
                    {"capabilities", meta->has_mtmd ? json({"completion","multimodal"}) : json({"completion"})},
                    {"parameters", ""},
                    {"details", {
                        {"parent_model", ""},
                        {"format", "gguf"},
                        {"family", ""},
                        {"families", {""}},
                        {"parameter_size", ""},
                        {"quantization_level", ""}
                    }}
                }
            }},
            {"object", "list"},
            {"data", {
                get_model_info(),
            }}
        };

        res->ok(models);
        return res;
    };

    this->post_tokenize = [this](const server_http_req & req) {
        auto res = create_response();
        const json body = json::parse(req.body);
        json tokens_response = json::array();
        if (body.count("content") != 0) {
            const bool add_special = json_value(body, "add_special", false);
            const bool parse_special = json_value(body, "parse_special", true);
            const bool with_pieces = json_value(body, "with_pieces", false);

            llama_tokens tokens = tokenize_mixed(ctx_server.vocab, body.at("content"), add_special, parse_special);

            if (with_pieces) {
                for (const auto& token : tokens) {
                    std::string piece = common_token_to_piece(ctx_server.vocab, token);
                    json piece_json;

                    // Check if the piece is valid UTF-8
                    if (is_valid_utf8(piece)) {
                        piece_json = piece;
                    } else {
                        // If not valid UTF-8, store as array of byte values
                        piece_json = json::array();
                        for (unsigned char c : piece) {
                            piece_json.push_back(static_cast<int>(c));
                        }
                    }

                    tokens_response.push_back({
                        {"id", token},
                        {"piece", piece_json}
                    });
                }
            } else {
                tokens_response = tokens;
            }
        }

        res->ok(json{{"tokens", std::move(tokens_response)}});
        return res;
    };

    this->post_detokenize = [this](const server_http_req & req) {
        auto res = create_response();
        const json body = json::parse(req.body);

        std::string content;
        if (body.count("tokens") != 0) {
            const llama_tokens tokens = body.at("tokens");
            content = tokens_to_str(ctx_server.vocab, tokens);
        }

        res->ok(json{{"content", std::move(content)}});
        return res;
    };

    this->post_embeddings = [this](const server_http_req & req) {
        return handle_embeddings_impl(req, TASK_RESPONSE_TYPE_NONE);
    };

    this->post_embeddings_oai = [this](const server_http_req & req) {
        return handle_embeddings_impl(req, TASK_RESPONSE_TYPE_OAI_EMBD);
    };

    this->post_rerank = [this](const server_http_req & req) {
        auto res = create_response();
        if (!params.embedding || params.pooling_type != LLAMA_POOLING_TYPE_RANK) {
            res->error(format_error_response("This server does not support reranking. Start it with `--reranking`", ERROR_TYPE_NOT_SUPPORTED));
            return res;
        }

        const json body = json::parse(req.body);

        // if true, use TEI API format, otherwise use Jina API format
        // Jina: https://jina.ai/reranker/
        // TEI: https://huggingface.github.io/text-embeddings-inference/#/Text%20Embeddings%20Inference/rerank
        bool is_tei_format = body.contains("texts");

        json query;
        if (body.count("query") == 1) {
            query = body.at("query");
            if (!query.is_string()) {
                res->error(format_error_response("\"query\" must be a string", ERROR_TYPE_INVALID_REQUEST));
                return res;
            }
        } else {
            res->error(format_error_response("\"query\" must be provided", ERROR_TYPE_INVALID_REQUEST));
            return res;
        }

        std::vector<std::string> documents = json_value(body, "documents",
                                             json_value(body, "texts", std::vector<std::string>()));
        if (documents.empty()) {
            res->error(format_error_response("\"documents\" must be a non-empty string array", ERROR_TYPE_INVALID_REQUEST));
            return res;
        }

        int top_n = json_value(body, "top_n", (int)documents.size());

        // create and queue the task
        json responses = json::array();
        auto & rd = res->rd;
        {
            std::vector<server_task> tasks;
            tasks.reserve(documents.size());
            for (size_t i = 0; i < documents.size(); i++) {
                auto tmp = format_prompt_rerank(ctx_server.model_tgt, ctx_server.vocab, ctx_server.mctx, query, documents[i]);
                server_task task = server_task(SERVER_TASK_TYPE_RERANK);
                task.id     = rd.get_new_id();
                ctx_server.dump_request_tokens(tmp.get_text_tokens(), server_token_dump_kind::rerank);
                task.tokens = std::move(tmp);
                tasks.push_back(std::move(task));
            }
            rd.post_tasks(std::move(tasks));
        }

        // wait for the results
        auto all_results = rd.wait_for_all(req.should_stop);

        // collect results
        if (all_results.is_terminated) {
            return res; // connection is closed
        } else if (all_results.error) {
            res->error(all_results.error->to_json());
            return res;
        } else {
            for (auto & res : all_results.results) {
                GGML_ASSERT(dynamic_cast<server_task_result_rerank*>(res.get()) != nullptr);
                responses.push_back(res->to_json());
            }
        }

        // write JSON response
        json root = format_response_rerank(
            body,
            meta->model_name,
            responses,
            is_tei_format,
            documents,
            top_n);

        res->ok(root);
        return res;
    };

    this->get_lora_adapters = [this](const server_http_req & req) {
        auto res = create_response();

        auto & rd = res->rd;
        {
            server_task task(SERVER_TASK_TYPE_GET_LORA);
            task.id = rd.get_new_id();
            rd.post_task(std::move(task));
        }

        // get the result
        auto result = rd.next(req.should_stop);
        if (!result) {
            // connection was closed
            GGML_ASSERT(req.should_stop());
            return res;
        }

        if (result->is_error()) {
            res->error(result->to_json());
            return res;
        }

        GGML_ASSERT(dynamic_cast<server_task_result_get_lora*>(result.get()) != nullptr);
        res->ok(result->to_json());
        return res;
    };

    this->post_lora_adapters = [this](const server_http_req & req) {
        auto res = create_response();
        const json body = json::parse(req.body);
        if (!body.is_array()) {
            res->error(format_error_response("Request body must be an array", ERROR_TYPE_INVALID_REQUEST));
            return res;
        }

        auto & rd = res->rd;
        {
            server_task task(SERVER_TASK_TYPE_SET_LORA);
            task.id = rd.get_new_id();
            task.set_lora = parse_lora_request(body);
            rd.post_task(std::move(task));
        }

        // get the result
        auto result = rd.next(req.should_stop);
        if (!result) {
            // connection was closed
            GGML_ASSERT(req.should_stop());
            return res;
        }

        if (result->is_error()) {
            res->error(result->to_json());
            return res;
        }

        GGML_ASSERT(dynamic_cast<server_task_result_apply_lora*>(result.get()) != nullptr);
        res->ok(result->to_json());
        return res;
    };
}

json server_routes::get_model_info() const {
    return json {
        {"id",       meta->model_name},
        {"aliases",  meta->model_aliases},
        {"tags",     meta->model_tags},
        {"object",   "model"},
        {"created",  std::time(0)},
        {"owned_by", "llamacpp"},
        {"meta",     {
            {"vocab_type",  meta->model_vocab_type},
            {"n_vocab",     meta->model_vocab_n_tokens},
            {"n_ctx",       meta->slot_n_ctx},
            {"n_ctx_train", meta->model_n_ctx_train},
            {"n_embd",      meta->model_n_embd_inp},
            {"n_params",    meta->model_n_params},
            {"size",        meta->model_size},
            {"ftype",       meta->model_ftype},
        }},
    };
}

std::unique_ptr<server_res_generator> server_routes::handle_slots_save(const server_http_req & req, int id_slot) {
    auto res = create_response();
    const json request_data = json::parse(req.body);
    std::string filename = request_data.at("filename");
    if (!fs_validate_filename(filename)) {
        res->error(format_error_response("Invalid filename", ERROR_TYPE_INVALID_REQUEST));
        return res;
    }
    std::string filepath = params.slot_save_path + filename;

    auto & rd = res->rd;
    {
        server_task task(SERVER_TASK_TYPE_SLOT_SAVE);
        task.id = rd.get_new_id();
        task.slot_action.id_slot  = id_slot;
        task.slot_action.filename = filename;
        task.slot_action.filepath = filepath;
        rd.post_task(std::move(task));
    }

    auto result = rd.next(req.should_stop);
    if (!result) {
        // connection was closed
        GGML_ASSERT(req.should_stop());
        return res;
    }

    if (result->is_error()) {
        res->error(result->to_json());
        return res;
    }

    res->ok(result->to_json());
    return res;
}

std::unique_ptr<server_res_generator> server_routes::handle_slots_restore(const server_http_req & req, int id_slot) {
    auto res = create_response();
    const json request_data = json::parse(req.body);
    std::string filename = request_data.at("filename");
    if (!fs_validate_filename(filename)) {
        res->error(format_error_response("Invalid filename", ERROR_TYPE_INVALID_REQUEST));
        return res;
    }
    std::string filepath = params.slot_save_path + filename;

    auto & rd = res->rd;
    {
        server_task task(SERVER_TASK_TYPE_SLOT_RESTORE);
        task.id = rd.get_new_id();
        task.slot_action.id_slot  = id_slot;
        task.slot_action.filename = filename;
        task.slot_action.filepath = filepath;
        rd.post_task(std::move(task));
    }

    auto result = rd.next(req.should_stop);
    if (!result) {
        // connection was closed
        GGML_ASSERT(req.should_stop());
        return res;
    }

    if (result->is_error()) {
        res->error(result->to_json());
        return res;
    }

    GGML_ASSERT(dynamic_cast<server_task_result_slot_save_load*>(result.get()) != nullptr);
    res->ok(result->to_json());
    return res;
}

std::unique_ptr<server_res_generator> server_routes::handle_slots_erase(const server_http_req & req, int id_slot) {
    auto res = create_response();
    auto & rd = res->rd;
    {
        server_task task(SERVER_TASK_TYPE_SLOT_ERASE);
        task.id = rd.get_new_id();
        task.slot_action.id_slot = id_slot;
        rd.post_task(std::move(task));
    }

    auto result = rd.next(req.should_stop);
    if (!result) {
        // connection was closed
        GGML_ASSERT(req.should_stop());
        return res;
    }

    if (result->is_error()) {
        res->error(result->to_json());
        return res;
    }

    GGML_ASSERT(dynamic_cast<server_task_result_slot_erase*>(result.get()) != nullptr);
    res->ok(result->to_json());
    return res;
}

std::unique_ptr<server_res_generator> server_routes::handle_embeddings_impl(const server_http_req & req, task_response_type res_type) {
    auto res = create_response();
    if (!params.embedding) {
        res->error(format_error_response("This server does not support embeddings. Start it with `--embeddings`", ERROR_TYPE_NOT_SUPPORTED));
        return res;
    }

    if (res_type != TASK_RESPONSE_TYPE_NONE && meta->pooling_type == LLAMA_POOLING_TYPE_NONE) {
        res->error(format_error_response("Pooling type 'none' is not OAI compatible. Please use a different pooling type", ERROR_TYPE_INVALID_REQUEST));
        return res;
    }

    const json body = json::parse(req.body);

    // for the shape of input/content, see tokenize_input_prompts()
    json prompt;
    if (body.count("input") != 0) {
        prompt = body.at("input");
    } else if (body.contains("content")) {
        res_type = TASK_RESPONSE_TYPE_NONE; // "content" field is not OAI compatible
        prompt = body.at("content");
    } else {
        res->error(format_error_response("\"input\" or \"content\" must be provided", ERROR_TYPE_INVALID_REQUEST));
        return res;
    }

    bool use_base64 = false;
    if (body.count("encoding_format") != 0) {
        const std::string & format = body.at("encoding_format");
        if (format == "base64") {
            use_base64 = true;
        } else if (format != "float") {
            res->error(format_error_response("The format to return the embeddings in. Can be either float or base64", ERROR_TYPE_INVALID_REQUEST));
            return res;
        }
    }

    auto tokenized_prompts = tokenize_input_prompts(ctx_server.vocab, ctx_server.mctx, prompt, true, true);
    for (const auto & tokens : tokenized_prompts) {
        // this check is necessary for models that do not add BOS token to the input
        if (tokens.empty()) {
            res->error(format_error_response("Input content cannot be empty", ERROR_TYPE_INVALID_REQUEST));
            return res;
        }
    }

    int embd_normalize = params.embd_normalize;
    if (body.count("embd_normalize") != 0) {
        embd_normalize = body.at("embd_normalize");
        if (meta->pooling_type == LLAMA_POOLING_TYPE_NONE) {
            SRV_DBG("embd_normalize is not supported by pooling type %d, ignoring it\n", meta->pooling_type);
        }
    }

    // create and queue the task
    json responses = json::array();
    auto & rd = res->rd;
    {
        std::vector<server_task> tasks;
        for (size_t i = 0; i < tokenized_prompts.size(); i++) {
            server_task task = server_task(SERVER_TASK_TYPE_EMBEDDING);

            task.id     = rd.get_new_id();
            ctx_server.dump_request_tokens(
                tokenized_prompts[i].get_text_tokens(),
                server_token_dump_kind::embedding);
            task.tokens = std::move(tokenized_prompts[i]);

            // OAI-compat
            task.params.res_type = res_type;
            task.params.embd_normalize = embd_normalize;

            tasks.push_back(std::move(task));
        }
        rd.post_tasks(std::move(tasks));
    }

    // wait for the results
    auto all_results = rd.wait_for_all(req.should_stop);

    // collect results
    if (all_results.is_terminated) {
        return res; // connection is closed
    } else if (all_results.error) {
        res->error(all_results.error->to_json());
        return res;
    } else {
        for (auto & res : all_results.results) {
            GGML_ASSERT(dynamic_cast<server_task_result_embd*>(res.get()) != nullptr);
            responses.push_back(res->to_json());
        }
    }

    // write JSON response
    json root = res_type == TASK_RESPONSE_TYPE_OAI_EMBD
        ? format_embeddings_response_oaicompat(body, meta->model_name, responses, use_base64)
        : json(responses);
    res->ok(root);
    return res;
}

std::unique_ptr<server_res_generator> server_routes::handle_count_tokens(const llama_vocab * vocab, mtmd_context * mctx, const server_http_req & req, task_response_type res_type) {
    auto res = create_response();
    std::vector<raw_buffer> files;
    json body = json::parse(req.body);
    bool is_oai = false;

    switch (res_type) {
        case TASK_RESPONSE_TYPE_OAI_CHAT:
            {
                is_oai = true;
            } break;
        case TASK_RESPONSE_TYPE_OAI_RESP:
            {
                is_oai = true;
                body = server_chat_convert_responses_to_chatcmpl(body);
            } break;
        case TASK_RESPONSE_TYPE_ANTHROPIC:
            {
                body = server_chat_convert_anthropic_to_oai(body);
            } break;
        default:
            res->error(format_error_response("invalid res_type", ERROR_TYPE_INVALID_REQUEST));
            return res;
    }

    json body_parsed = oaicompat_chat_params_parse(
            body,
            meta->chat_params,
            files);
    json prompt = body_parsed.at("prompt");
    // SRV_DBG("prompt = %s\n", prompt.dump().c_str());

    // TODO @ngxson : refactor this code block, move this to server-common and reuse it in other places
    size_t n_tokens;
    if (mctx != nullptr) {
        if (!prompt.is_string()) {
            throw std::runtime_error("for mtmd, input prompt must be a string.");
        }
        n_tokens = process_mtmd_prompt(mctx, prompt.get<std::string>(), files, true).size();
    } else {
        n_tokens = tokenize_mixed(vocab, prompt, true, true).size();
    }

    json response = {{"input_tokens", static_cast<int64_t>(n_tokens)}};
    if (is_oai) {
        response["object"] = "response.input_tokens";
    }
    res->ok(response);
    return res;
}
