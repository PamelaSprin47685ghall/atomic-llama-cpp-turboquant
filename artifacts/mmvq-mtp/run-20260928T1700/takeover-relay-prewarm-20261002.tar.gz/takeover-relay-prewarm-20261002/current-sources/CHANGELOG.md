# Changelog

One section per release, keyed by the exact tag. `verify-version` refuses to cut
a release whose tag has no section here, so this gets written *before* the tag is
pushed — the release notes are generated from it verbatim.

Write it for the person who downloads the build: what they get, what changed for
them, what to watch out for. Not a commit dump — the notes already carry the full
commit list underneath.

Releases before `b10269-1.5.0` predate this file; see the git history.

## Unreleased

- **TP5 prepared decode uses a qualified two-bank definition, not a bank-only topology lock.**
  Linear lowering checks compute command identity, plan keys/indices, capacity,
  capture/isolation and resource generations against one definition recorded for
  both mailbox polarities. Replaced definitions retain both command-pool owners
  until actual native submissions complete. Graph rebuilds invalidate prepared
  handles; a failed native submission cannot fall through to fallback execution.
  TP5 warmup covers decode and configured MTP verification prefixes, restores
  memory/sampler/performance state and aborts model loading on failure;
  `--no-warmup` remains an explicit opt-out. CPU control-plane and single-device
  replay/MMVQ smoke checks passed. Five-RX6800 decode and performance acceptance
  remain blocked by the missing `0000:0c:00.0` device; no new speedup is claimed.

Earlier TP5 measurements using `--no-mmap` ran with an empty lazy PLE table.
Those historical throughput and GPU-to-GPU equivalence results are not
full-model correctness acceptance; repaired-model measurements are required.


- **Vulkan matvec row tile spills at 13-18 columns; prefill gained 28%.**
  The multi-column matvec pipelines kept the 4x row tile from the wide-
  dispatch widening at every column count, so at NUM_COLS 13..18 the
  per-thread accumulator array (13-18 x 8 floats) spilled past the register
  budget. Measured on Bonsai PQ2_0 / RX 6800, prefill throughput fell off a
  4x cliff exactly at 13 columns (112.8 t/s at npp=12 versus 28.2 at npp=13)
  and the n=16 prefill shape ran at 35 GB/s effective weight bandwidth
  against 129-141 GB/s for the n=6 decode shapes. Halving the row tile for
  those widths (rm_wide 2) keeps the accumulator in registers: npp=13..18
  now all measure 111-116 t/s, the single-stream n=16 prefill gains 28%
  (86.6 -> 110.9 t/s at npl=1). Decode is untouched (1-8 column pipelines
  unchanged); repeated runs confirm 1/4/6/8-lane decode at
  32.6/81.6/97.6-98/102.5 t/s, matching the pre-change baseline within
  noise. Greedy 6-lane decode remains byte-identical to the single-lane
  path; test-backend-ops passes (368 s).

  Routing small-N decode through the scalar mul_mm GEMM instead was
  measured with a temporary env hook and rejected: 3-7x slower than the
  matvec at these shapes on this no-coopmat RADV device (TG 33.4 -> 4.4
  t/s at one lane). The matvec stays the decode path; the GEMM threshold is
  not widened.

- **RERoT grouped-head attention is now the DEFAULT.** The
  `GGML_VK_REROT_GROUPED_HEADS path (one subgroup per Q head, KV tile
  staged once per GQA group) was qualified on a full episode for the first
  time. Attention cost drops from 18.7 s to 4.2 s per episode (per-call
  460 us -> ~150-200 us at n_kv 4-5k) and the indexed shader's efficiency
  gap versus ordinary FA narrows from 2.7x (273 -> 478 GFLOPS/s at the
  production shape). Precision gates pass on both paths (indexed error
  < 1.2e-7 vs F64; test-rerot-attn 0 failures).

  The earlier qualification run FAILED, and the two defects responsible
  were both found, fixed, and re-verified -- neither was in the grouped
  shader itself:
  (1) The synthesis lane leaked a `<|fim_prefix|>become` tool call as
  the public answer, spelling the reserved marker character-by-character
  (the token-level sampling ban only covers the single-token spelling).
  Fixed by KV-level occlusion of the advertised tools block from the
  planner and synthesis readers (workers keep it; see the occlusion
  commit). The deterministic leak seed is now clean 3/3.
  (2) Every third back-to-back episode died 42 ms after start with a bare
  rerot_resource_exhausted. Pinned by backtrace + slot-state dump to a
  force-sealed worker whose host slot was never released (an inverted
  branch in the lane hard stop), leaving a GENERATING slot pointing at
  a deleted episode; the bare propagation then killed the next innocent
  episode. Fixed by releasing the slot on seal success; the failing
  three-episode sequence now completes on scalar and grouped alike.

  With both fixed, the complete paired run (seeds 777/12345/20260923
  back-to-back, thinking wire, Bonsai PQ2_0 / RX 6800) passes 3/3 on the
  grouped path, so grouped is now the default. Devices or shapes that
  cannot stage the group keep the single-head scalar path;
  GGML_VK_REROT_GROUPED_HEADS=0 restores Br=1 for A/B.

- **Multi-lane decode is now worth its lanes, and RERoT finally beats serial.**
  Two Vulkan matvec fixes and two scheduling bounds. The shader dequantized each
  weight block once per (column,row) pair, because the generic loop nests columns
  outside rows and the existing shared-dequant fast path only covered
  `num_rows == 1`, which quantized pipelines never reach; and every workgroup
  re-reads the whole activation vector, which at six columns is 1.07 GB against
  23.7 MB of weights. The loop is inverted for multi-column dispatches and PQ2_0
  matvec pipelines widen their row tile when the dispatch is wide.
  `llama-batched-bench` decode t/s: 33.10 -> 33.47 at one lane (no regression),
  51.09 -> 82.54 at four, 68.99 -> 98.90 at six, 63.03 -> 103.40 at eight;
  scaling against one lane goes 2.08x -> 2.95x at six and eight lanes stops
  regressing. Output is bitwise identical (greedy decode, six concurrent requests
  versus one).

  Parallel thinking then has to fit a token budget to pay off, so
  `--rerot-lane-wrap-tokens` (default 256) gives a long worker lane, and the
  synthesis lane at three times that allowance, escalating in-voice reminders to
  close. Without them lanes ran past 1240 tokens each and the request never
  finished; with a worker-only bound the synthesis took over as the unbounded
  phase. On the geography prompt against a fixed eight-item checklist:
  serial 134.37 s / 3085 tokens / full coverage; RERoT at 256 **101.51 s / 2959
  tokens / full coverage** (1.32x faster on fewer total tokens, terser answer);
  at 512 it regresses to 251.65 s / 5575 tokens; at 128 it finishes in 53.37 s but
  coverage collapses to 1/8, which is what the checklist is there to catch.
  Earlier drafts of this entry quoted an "end-to-end tok/s" built from
  `timings.predicted_n`, which counts lane tokens and therefore flatters RERoT;
  the numbers above are wall clock at equal coverage. Details in `RERoT.md` §22.6.

- **RERoT planning wire: parallel thinking aspects instead of Mermaid indentation.**
  New `--rerot-plan-wire thinking` injects one instruction sentence plus
  `<ul>Let me see what can be thought through on its own here...`, then constrains
  generation with a six-rule GBNF and stops at the first `</ul>`. Items are bare
  `<li>` sub-titles in words with no punctuation at all (path characters `/ _ -`
  stay legal), so the wire cannot drift into indentation, outline numbering or
  `&lt;` escaping. Execution is the flat shape the pen cohort wants: synthetic
  root plus one peer worker per aspect. `json` / `mindmap` / `todo` remain
  selectable controls.

  Two structural facts drove the design and are worth knowing before tuning it.
  First, the unit is an *aspect* because that is what the model's own
  unconstrained thinking is made of: an RERoT-off capture on a real
  agent-coding task spends about 25 of 41 paragraphs circling one unknown about
  the codebase and the rest covering the requested deliverables. Second, the
  escape token that ends a free-form region is not merely unlikely under the
  model card's thinking-mode sampling, it is masked: measured on the real probe
  context, `<` sits at rank 2 with p=0.086 while the head is empty and falls
  below 1.2e-3 (2.7e-3 of the top token) after one sentence, i.e. under
  `min_p=0.05` it leaves the pool. An unbounded region therefore never
  terminates — one head ran 1749 tokens with no list, one item ran 1670 tokens
  with no close. The server answers this in two ways: when the lane ends a head
  line the newline is replaced by a reminder plus that same newline (capped), and
  item text carries no punctuation, so a label cannot hold prose.

  The `become` frame was rewritten for all tree wires: the tool carries a
  one-clause description, the tool reply is a data echo, and the contract is the
  lane's own first-person sentence at the start of its thinking, ending on a colon
  so the thought continues. Second person in the reply does not survive a shared
  KV (6/6 mindmap workers dismissed the handoff and re-answered the whole
  request; 3/3 coding workers claimed the same node; a numeric tag only made the
  tag the anchor), and a seed ending in a full stop made every worker sample
  `</think>` immediately while the synthesis lane emitted a `become` tool call as
  the public answer. On a single RX 6800 with Bonsai-2 27B PQ2_0 and six pens, the
  wire planned a `/healthz` endpoint task in 286 probe tokens (8 aspects, 7
  workers each on their own) and a geography prompt in 148 (3 aspects, 3
  workers). Every run hit its 60 s client deadline: there is no completed
  episode, no public answer and no throughput comparison. Evidence, including the
  distribution measurement and the natural-thinking baseline:
  `artifacts/rerot-thinking-wire/`; scope and limits in `RERoT.md` §22.5.

- **Meta rank-local asynchronous readback.** Eligible contiguous F32 vocabulary
  shards now copy into persistent per-device pinned host slots, submit every
  rank before waiting, and assemble at the existing consumption boundary.
  Pending reads retire before a subsequent read, slot growth, fallback, or
  backend destruction; unsupported layouts retain the original getter.
  Five-device byte/lifetime regressions and MTP acceptance prefixes 0–6 pass.
  `GGML_META_ASYNC_READBACK=0` provides a same-binary control; timing evidence
  and the unchanged model/sampler contract are recorded in `TP5.md`. Five paired
  ABBA blocks measured 72.25→74.27 decode tok/s (+2.80%); all 60 retained cold
  and steady requests were exact 171-token natural stops. This is not 100 tok/s.

- **Vulkan skinny MMVQ projections keep distinct input identities.** The converted
  activation cache now keys on the graph tensor, not a temporary stack view
  reused by successive projections. Forced MMVQ could otherwise give the second
  projection the first input's values. A sparse-weight numerical regression
  checks distinct inputs and changed inputs across cold execution and replay;
  it fails with the old backend and passes with the repair.

- **TP5 counting acceptance preserves exact request evidence.** The cross-matrix
  runner now records the submitted request alongside the full response, including
  responses missing token usage. Counting gates no longer trim whitespace before
  claiming a byte-for-byte match. The 171-token workload explicitly disables
  thinking and prompt reuse; a reasoning-enabled request is a different workload
  and needs its own context/output budget. A 40-character response preview is
  not evidence of a miscount. See the September 24 correctness investigation in
  `TP5.md` for the restored non-MTP binary and full-response evidence.

- **MM-R1 logical leaves no longer inherit a physical pen budget.** Removed
  the incremental mindmap probe guard and parser node/leaf/wire-byte/depth/
  label budgets; the JSON probe retains its separate 512-token policy. After one English
  instruction, the mindmap probe injects the Mermaid `mindmap` header, the
  literal `root` line, and four child-indentation spaces; grammar generates
  the subtree at any even indentation depth; the parser runs only once the
  closing fence arrives, rather than rescanning every generated token.
  `root` is a synthetic container, excluded from logical node and worker
  counts. Persisted RERoT state advances to v8 rather than misreading older
  trees. Bonsai-2 on Vulkan completed a 21-leaf plan on six pens with the
  model's 262144-token context; the full 51-leaf Raft stress reached synthesis
  but its HTTP client deadline expired before a public answer. See `RERoT.md`
  §22.3 for the exact scope and artifacts.

- **TP5 replay scheduling and shared transfer recordings.** Warm epoch chains
  reuse submission templates without skipping live binding, HC recipe, or full
  command-buffer sequence validation. Compatible reductions share owned P1
  recordings while retaining private P2 recipes and GPU retirement lifetimes.
  The measured cold collective recording allocation count falls from 1860 to
  930; paired no-MTP request medians are 39.00 versus 39.91 tok/s, not the 50
  tok/s target. Canonical 280-step logits remain bitwise unchanged. The server
  launcher adds `--baseline` and non-launching `--baseline --print-config` for
  fixed single-slot no-MTP comparisons with environment and binary provenance.

- **Whole-region Vulkan decode and collective boundaries.** GDN, attention,
  routed/shared MoE, and HC regions preserve their native arithmetic and cache
  ownership while eliminating intermediate dispatches. Terminal producers can
  emit the exact F16 wire representation alongside their F32 output; repeated
  reductions without a new producer still repack current data. Sparse mask
  compaction can share attention preparation, with independent-buffer fallback.
  The verified five-card checkpoint records 669 compute + 96 collective
  dispatches per token and bitwise-identical 280-step canonical logits. HC
  SUM/normalization fusion is numerically checked but is not an independently
  proven throughput improvement. The no-MTP 50 tok/s target remains unmet;
  further 8-to-6 dispatch lowering is paused at the user's request.

- **Bounded meta reconstruction and replay validation.** Reduction subgraphs
  allocate graph/hash capacity for their own spans rather than the entire model.
  Deferral analysis indexes nodes through the existing graph identity hash and
  stops ancestor traversal at the current reduction boundary. Replay validates
  current live bindings, shapes, operation parameters, offsets, and Vulkan
  buffers without dereferencing retired captured tensor addresses; splitting
  a formerly shared source still invalidates its recorded bindings. See `TP5.md`
  for measured cold/warm costs and the remaining collective-recording bottleneck.
  The later shared-P1 implementation and its measurements are listed above.

- **CPU attention honors explicit F32 accumulation.** F16 value caches no
  longer force F16 accumulators when `GGML_PREC_F32` is requested. Both direct
  decode and split-KV paths retain F32 value sums through online-softmax
  rescaling. A constant-value regression drops from roughly 3.88e-4 error to
  1.19e-7; the default-precision path and cache storage types are unchanged.

- **Vulkan replay preserves pending uploads.** Pinned host uploads and event
  waits on the ordinary compute context are flushed asynchronously before
  recording or submitting replay buffers, rather than discarded by a context
  reset. A minimal pinned-upload regression failed before the repair. The real
  five-GPU layer model now produces bitwise-identical replay/non-replay logits
  across 11 positions and the complete 248320-token vocabulary.

- **Vulkan async output copies retain their buffers.** A queued readback of
  four logits rows could outlive the graph allocator's source VkBuffer as
  RERoT switched between six active pens and a seventh parked worker. Pinned
  host transfers now retain both VkBuffer owners until the queue fence retires
  the recording context. The Bonsai-2 seven-leaf GPU request that previously
  triggered a CPG use-after-free now completes with the correct answer and no
  new GPUVM fault. Mindmap remains opt-in; its paired wall time on that prompt
  is slower than the JSON baseline, which chose a simple single-answer route.

- **Lazy tensor payload and lifetime.** On-demand tables remain mapped after
  loader retirement, including when other weights use non-mmap loading.
  Preallocated fallback buffers are loaded instead of silently left empty.
  This fixes both a CPU PLE gather crash and zero PLE results under `--no-mmap`.
  Regression coverage includes mapped-only, eager-fallback, and mixed contexts.
  The real GPU PLE gather now matches all 2560 CPU elements bitwise; CPU mmap
  and non-mmap loading match over 11×248320 logits. Full CPU/GPU model parity
  remains a separate acceptance check.

- **Ordinary Qwen4EXP recurrence and Vulkan HC fold.** Indexed hybrid memory now
  forwards explicit RERoT capacities instead of enabling grouped recurrence when
  RERoT is off, and preserves the requested recurrent capacity. Four-stream HC
  folds now match the native 11-node multiply/reshape/reduce graph, with the
  original floating-point order. Graph optimization preserves the fold and its
  input lifetimes; Vulkan roots are at least 16-byte aligned. Unaligned views
  and externally observed intermediates retain the unfused path. Real-model
  profiling confirms 1057 fused calls per rank across the 11-position tape,
  with all 11×248320 logits bitwise unchanged. Complete 171-token counting
  reaches 5.69–5.72 tok/s after the PLE repair, not the 100 tok/s goal.

- **Qwen4EXP tensor-split GDN layout.** Native Q/K/V projections, convolution
  histories, and per-head decay parameters now use the same repeated-segment
  ownership. Column-parallel matmul and convolution preserve that layout instead
  of collapsing it into contiguous rank slices. A five-rank CPU regression
  matches 10,240 convolution outputs and 48 decay gates exactly; bounded
  five-GPU counting and arithmetic requests now produce correct text. This is
  not full-model numerical or 100 tok/s acceptance; see `TP5.md` for limits.

- **Vulkan indexed replay and GDN fusion.** Device-side gather/scatter operations
  may replay with changing indices and cache writes; the new six-round regression
  checks all cache rows exactly. Native-layout tensor inference again uses normal
  fused-GDN capability detection. Bounded, non-speculative five-GPU counting
  improved from 3.17 to 4.27 tok/s while preserving the tested answers; these are
  short samples, not sustained-throughput acceptance. Replay profile counters now
  distinguish queue API calls from submission batches correctly.

- **Vulkan TP5 R=2 correctness and fused submission.** Both reduction phases now
  use the same aligned two-bank mailbox mapping. Replay plans retain their
  buffers, validate source bindings and scratch generations, and register
  externally submitted work for synchronization. Adjacent SUM/compute/PUSH
  stages are fused without dropping required memory dependencies. Five-RX-6800
  F16/F32 numerical and dependent-replay checks pass; warm 96-stage paired
  median speedups are 1.660×/1.462× (microbenchmark, not end-to-end or tail-latency
  guarantees). See `TP5.md` for protocol, complete timing samples, and limits.

### Added

- **Owned asynchronous input snapshots; backend plugin ABI 3.** Supporting
  backends capture host bytes before returning and order destination writes
  after prior device work, so callers may immediately reuse the host storage.
  Composite backends check all destinations before capture. Backends without
  this capability retain the existing synchronized path. Out-of-tree backend
  plugins must be rebuilt for the new interface version.

- **Opt-in replicated TP5 attention/GDN.** `GGML_TP5_REPLICATE_ATTN=1`
  mirrors native attention weights and caches while retaining expert channel
  partitioning. The real five-GPU model executes 48 rather than 96 reductions;
  complete 171-token counting requests measure 5.35–5.40 tok/s, not 100 tok/s.
  Peak observed VRAM is about 13.25 GiB per card. CPU/GPU full-model numerical
  acceptance remains open. The header-only inspector supports the matching
  `--replicate-attention` mode and fixes double-counted KV layer instances.

- **Single-submission decode chain includes the model tail.** The final
  non-reducing subgraph now travels inside each rank's one batched submission
  instead of a separate async submit per rank, so the completion signal and the
  tail it must order are published together. The hot path records five queue
  API calls and 485 submission batches per decode graph; these are not driver
  submit counts. Mesh tests verify a dependent GPU tail against a CPU oracle
  and reject malformed tails before submission. Short model requests are
  correct, but no isolated throughput improvement from tail batching is proven.
  After correcting an earlier pre-change artifact mix-up, a fresh capture
  hitting the five-call path matches non-replay over 11×248320 logits bitwise.

- **TP5 replay-chain GPU timing.** `GGML_TP5_GPU_TIMING=N` captures one
  timeline chain with per-rank SUM/compute/PUSH intervals and inter-batch gaps.
  The same capture reports host queue-call durations and compute, collective,
  and marker command-buffer counts after every rank has been submitted.
  Queries are availability-only and never reused in flight. Extra command
  buffers and barriers perturb timing; use separate runs for throughput.


- **FlashPrefill V2 sparse prefill (experimental, opt-in, default off;
  implementation and compile delivered, runtime acceptance NOT RUN).**
  New `--flashprefill off|auto|required` policy plus tuning flags
  (`--flashprefill-alpha`, `--flashprefill-block-q`, `--flashprefill-block-k`,
  `--flashprefill-sink-blocks`, `--flashprefill-window-blocks`,
  `--flashprefill-dense-tail-tiles`, `--flashprefill-tail-scope`,
  `--flashprefill-min-kv`, `--flashprefill-full-attn-layers`,
  `--flashprefill-mean-correction`, `--flashprefill-exact-all`), backed by new
  GGML ops (`GGML_OP_FLASH_PREFILL_POOL/SELECT/ATTN`), CPU reference kernels,
  Vulkan native kernels, always-emitted `/metrics` series
  (`llamacpp:flashprefill_*`, zeros while OFF; GPU totals merged only after
  successful graph slices; GPU dispatch times 0 until the timestamp hook
  reports; required-mode enforcement is graph-side, metrics only counts),
  and `scripts/flashprefill-matrix.py` /
  `scripts/flashprefill-quality.py` harnesses. Only ordinary prefill and
  bounded RERoT teacher-forced injections are sparse-eligible (ordinary
  dispatch shared over supported KV shapes; raw-Q RERoT hooks Qwen3.5
  dense/MoE only, including current Ornith weights); decode, MTP
  draft/verify,
  embeddings, rerank, out-of-family RERoT, recurrent/SWA layers,
  transposed-V or multi-stream layouts, special KQ bias, and unsupported
  backends keep the existing dense path. TriAttention (`3/32`) semantics and the RERoT
  active-lane MTP pause are unchanged. See `PREFILL.md`.

### Notes

- **Acceptance not run.** The server, 4 new tests and 7 existing test
  targets all compile/link clean (`build-prefill/bin/llama-server`;
  baseline frozen separately), but no tests, benchmarks, quality gates, or
  deployment have been executed. No performance or quality claims are made;
  the Definition-of-Done checklist in `PREFILL.md` §21.3 remains fully
  unchecked. Hashes: see `build-prefill-evidence/manifest.json` and
  `binary-libraries.sha256`.
- State restores across contexts/processes/restarts are deliberately rejected
  (enabled-only 64-byte policy envelope; re-prefill on mismatch; no sidecar
  file). Qwen3.5 dense/MoE family only; other architectures get no automatic
  sparse routing.

## b10269-1.6.0

### Added

- **Windows AMD ROCm archive** `llama-turboquant-windows-x64-rocm.zip`. HIP
  backend for RDNA2 through RDNA4 and Ryzen AI 300 / Ryzen AI Max (gfx1030,
  gfx1100/1101/1102/1103, gfx1150/1151, gfx1200/1201), self-contained: the HIP
  runtime and the BLAS DLLs it links are bundled (about 100 MB), only a current
  Adrenalin driver is needed, no ROCm SDK install. Until now Windows + Radeon
  meant the Vulkan build; HIP is the faster prompt-processing path on these
  GPUs. Everything in the archive is Authenticode-signed, the AMD DLLs with
  AMD's signature where they ship one.
- **Linux ROCm archive** now also targets gfx950 (Instinct MI350/MI355X),
  gfx1150 (Ryzen AI 300) and gfx1103 (Radeon 780M/760M).
- `docs/amd/`: what ships for AMD, the ROCm vs Vulkan benchmark plan for the
  TurboQuant KV cache, and the open items. `scripts/bench-amd.sh` runs that
  matrix per backend build, `scripts/bench-amd-report.py` renders one table.

### Changed

- ROCm builds no longer pass `GGML_HIP_ROCWMMA_FATTN`; upstream removed the
  rocWMMA flash-attention path and the flag was a no-op.

### Notes

- **The Windows ROCm archive is beta.** It is built, signed and checked for
  completeness in CI, but has not been run on a Radeon yet. `llama-server
  --list-devices` must show a HIP device; if it does not, or if loading fails,
  report the GPU, driver version and the error, and use the Vulkan archive in
  the meantime.
- Atomic Chat does not select the Windows ROCm backend yet; the client change
  follows separately. Until then it is a manual download.

## b10269-1.5.1

### Fixed

- **Ling-3.0-flash (BailingMoeV3) no longer emits garbage token bursts.** The
  model is trained with clamped SwiGLU activations in its late layers, and the
  per-layer limits live in `config.json` under `expert_swiglu_limit_list` and
  `share_expert_swiglu_limit_list`. The public HF modeling code ignores those
  keys and so did this port, which caused deterministic transient logit
  collapse - output like `count += 1eville` dropped into otherwise fine
  generations. Measured at roughly -20 pass@1 on HumanEval (72.6% -> 93%+ with
  the fix); the garbage-token repro is eliminated.

### Notes

- **Re-convert your Ling-3.0-flash GGUF to get the fix.** The clamp limits are
  written by the converter into two new KVs (`{arch}.swiglu_clamp_exp` and
  `{arch}.swiglu_clamp_shexp`); a GGUF produced before this release does not
  carry them, and the runtime then defaults to no clamping. Re-download the
  quant or re-run `conversion/bailingmoe.py`.
- Both KVs are optional and default to zero, so existing GGUFs and every other
  architecture are unaffected. The graph needed no change - the SwiGLU clamp
  branches in `build_ffn` / `build_moe_ffn` already trigger on a nonzero
  per-layer limit, matching the vLLM `SwigluStepAndMul` semantics.

## b10269-1.5.0

### Added

- **NVIDIA DGX Spark (GB10) support.** New archive
  `llama-turboquant-linux-arm64-cuda-13.3`, built natively for aarch64 with
  CUDA 13.3 and sm_121 SASS. Other arm64 NVIDIA machines (GH200, GB200, Jetson
  Thor) run it too, JITing the kernels from PTX on first launch. This is the
  first Linux arm64 build the fork ships — until now arm64 meant macOS only.
- **BailingMoeV3 (Ling 3.0) architecture support**, including the KDA gate
  handling.

### Changed

- **Linux CUDA archives are roughly half the size** — 1657 → 956 MB (12.4) and
  1879 → 1028 MB (13.3) measured across both the `.zip` and `.tar.gz`. The zips
  were storing `libcublas.so` → `.so.13` → `.so.13.5.1.27` as three full copies
  because `zip` followed the symlinks.
- **CUDA 13.3 builds ship Ampere PTX (`80-virtual`).** A100/H100/B200 were
  falling back to the Turing PTX floor, which silently disabled `cp.async` and
  the Ampere MMA path — both gated on `__CUDA_ARCH__ >= 800`. Those cards get
  Ampere-class kernels now. No architecture lost support in this release.
- Windows CUDA builds got their architecture lists pinned, all runner cores, a
  ccache that can actually hold a CUDA build, and 7-Zip instead of
  `Compress-Archive`. Release turnaround drops accordingly.

### Notes

- The DGX Spark archive has **not yet been validated on real GB10 hardware** —
  it is built and arch-checked in CI (`cuobjdump` asserts sm_121 SASS is
  present), but nobody has run it on a Spark yet. Treat this one as beta and
  report back.
- The CUDA 13.3 archives now use `-compress-mode=size`. Kernel SASS is
  unchanged and inference speed is unaffected; the fatbin is decompressed once
  at module load. It needs a driver from the CUDA 12.4 era or newer.
