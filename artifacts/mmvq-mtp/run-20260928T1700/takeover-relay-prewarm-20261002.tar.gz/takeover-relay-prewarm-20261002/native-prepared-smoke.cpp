#include TP5_SOURCE_UNDER_TEST

#include <cstdio>

// CPU control-plane smoke: call the production definition qualification and
// owner-retirement methods. Programs are deliberately unsubmitted (no Vk
// devices/pools); opaque CB identities are compared, never executed.
#define REQUIRE(condition) do { if (!(condition)) { std::fprintf(stderr, "failed: %s\n", #condition); return 1; } } while (0)

int main() {
    tp5_comm comm{};
    comm.chain_plan_indices = {0, 1, 2};
    comm.chain_keys.resize(3);
    const size_t elements[] = {7, 11, 17};
    for (size_t stage = 0; stage < 3; ++stage) comm.chain_keys[stage].n_elems = elements[stage];
    uint32_t identities[4][5]{};
    std::vector<std::vector<std::vector<void *>>> cbs(4);
    for (size_t stage = 0; stage < 4; ++stage) {
        cbs[stage].resize(5);
        for (size_t rank = 0; rank < 5; ++rank) cbs[stage][rank].push_back(&identities[stage][rank]);
    }
    auto & definition = comm.prepared_linear;
    definition.n_stages = 3;
    definition.isolate_bo = false;
    definition.capture = false;
    definition.workspace_gen = comm.workspace_gen;
    definition.plans_gen = comm.plans_gen;
    definition.capacity_rows = 4;
    definition.stage_keys = comm.chain_keys;
    definition.stage_plan_indices = comm.chain_plan_indices;
    definition.stage_compute_cbs = cbs;
    for (auto & program : definition.programs) program = std::make_shared<tp5_linear_program>();
    auto admitted = [&](size_t stages = 3, bool isolate = false, bool capture = false, uint32_t rows = 4) {
        return comm.linear_prepared_for(stages, isolate, capture, rows, comm.chain_keys, cbs);
    };
    REQUIRE(admitted());
    REQUIRE(!admitted(2));
    REQUIRE(!admitted(3, true));
    REQUIRE(!admitted(3, false, true));
    REQUIRE(!admitted(3, false, false, 0));
    REQUIRE(!admitted(3, false, false, 3));
    auto alternate = std::move(definition.programs[1]);
    REQUIRE(!admitted());
    definition.programs[1] = std::move(alternate);
    comm.workspace_gen++;
    REQUIRE(!admitted());
    comm.workspace_gen--;
    comm.plans_gen++;
    REQUIRE(!admitted());
    comm.plans_gen--;
    comm.chain_keys[1].n_elems++;
    REQUIRE(!admitted());
    comm.chain_keys[1].n_elems--;
    comm.chain_plan_indices[0] = 2;
    REQUIRE(!admitted());
    comm.chain_plan_indices[0] = 0;
    cbs[2][4][0] = &identities[0][0];
    REQUIRE(!admitted());
    cbs[2][4][0] = &identities[2][4];
    REQUIRE(admitted());
    std::weak_ptr<tp5_linear_program> first = definition.programs[0];
    std::weak_ptr<tp5_linear_program> second = definition.programs[1];
    comm.invalidate_chain("definition_transition");
    REQUIRE(!admitted());
    REQUIRE(!first.expired() && !second.expired());
    comm.retired_linear_programs.clear(); // no GPU work was submitted in this smoke
    REQUIRE(first.expired() && second.expired());
    comm.cached_plans.resize(3);
    for (size_t stage = 0; stage < 3; ++stage) comm.cached_plans[stage].key = comm.chain_keys[stage];
    comm.clear_cached_plans(false, "workspace_transition");
    REQUIRE(comm.chain_plan_indices.size() == 3 && comm.cached_plans.empty());
    for (size_t stage = 0; stage < 3; ++stage) {
        comm.cached_plans.emplace_back();
        comm.cached_plans.back().key = comm.chain_keys[stage];
        comm.chain_plan_indices[stage] = stage;
    }
    REQUIRE(comm.cached_plans[comm.chain_plan_indices[0]].key.n_elems == 7);
    REQUIRE(comm.cached_plans[comm.chain_plan_indices.back()].key.n_elems == 17);
    comm.clear_cached_plans(false, "repeat_transition");
    std::puts("PASS: production prepared admission rejects mismatched definitions; both owners retire safely; plan reset/restart remains intact (CPU only, no GPU submissions)");
    return 0;
}
