#!/usr/bin/env python3
import argparse
import collections
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import re
import signal
import statistics
import subprocess
import time
import urllib.error
import urllib.request

BIN = Path('/var/tmp/tp5-takeover-build/bin/llama-server')
TARGET = '/home/kunweiz/models/Qwen3.8-Flash-Next-APEX-I-Compact/Qwen3.8-Flash-Next-APEX-I-Compact-00001-of-00006.gguf'
DRAFT = '/home/kunweiz/models/Qwen3.8-Flash-Next-MTP/mtp-Qwen3.8-Flash-Next-Q4_K_M.gguf'
ROOT = Path('/var/tmp/tp5-takeover-20261002/joint-search')
PORT = 8175
NP = 400
PROMPTS = [
    '请用八句话简要介绍健康减重原则、每周运动安排、饮食建议和睡眠误区。',
    '如何减肥',
    'Explain how a hash table handles collisions and resizing. Compare separate chaining with open addressing, including deletion and load factor. Give a concise worked example.',
]
REGION = re.compile(r'\[vulkan-region-policy\] backend=(\S+) family=(\S+) fused=1 mmvq_mask=(\d+) shared_q8_1=(\d+)')
POLICY = re.compile(r'\[vulkan-mmvq-policy\] backend=(\S+) mode=(\S+)')
SERVER = None


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


LATE_VARIANTS = ('off', 'exact', 'aggressive', 'q8first', 'pack-once', 'ap', 'l2', 'l2-ap')


def config(policy='auto', depth=1, knobs=None, sampling=True, pmin=0.0, late='off'):
    return dict(policy=policy, depth=depth, knobs=knobs or {}, sampling=sampling, pmin=pmin, late=late)


def http(path, payload=None, timeout=180):
    data = None if payload is None else json.dumps(payload, ensure_ascii=False).encode()
    req = urllib.request.Request(f'http://127.0.0.1:{PORT}{path}', data=data,
                                 headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=timeout) as response:
        return json.load(response)


def stop_server():
    global SERVER
    if SERVER is None:
        return
    process, log = SERVER
    if process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=10)
    log.close()
    SERVER = None


def interrupted(signum, frame):
    stop_server()
    raise SystemExit(128 + signum)


def trial(label, cfg, diagnostic=False, repeats=2):
    global SERVER
    directory = ROOT / label
    directory.mkdir(parents=True, exist_ok=False)
    env = dict(PATH='/usr/bin:/bin', HOME=os.environ.get('HOME', '/home/kunweiz'),
               LD_LIBRARY_PATH=str(BIN.parent), RADV_DEBUG='nobolist',
               GGML_VK_FORCE_MMVQ='1' if cfg['policy'] == 'forced' else '0',
               GGML_VK_DISABLE_MMVQ='1' if cfg['policy'] == 'disabled' else '0',
               GGML_VK_SMALL_Q8_COLUMNS='1', GGML_MTP_KV_ONLY='1',
               GGML_TP5_MTP_DRAFT_SINGLE_GPU='1', GGML_TP5_QSA_HEADMAP='1',
               GGML_TP5_GDN_HEADMAP='1', GGML_TP5_REPLICATE_ATTN='0')
    env.update(cfg['knobs'])
    late = cfg['late']
    if late != 'off':
        env['GGML_TP5_LATE_TRANSPORT'] = 'gtt-push'
        env['GGML_TP5_LATEBIND_OVERLAP'] = 'legacy'
    if late not in ('off', 'exact'):
        env['GGML_TP5_LATEBIND_ALLOW_APPROX'] = '1'
    if late in ('q8first', 'ap', 'l2-ap'):
        env['GGML_TP5_LATEBIND_Q8_ORDER'] = 'first'
    if late in ('pack-once', 'ap', 'l2-ap'):
        env['GGML_TP5_LATEBIND_PACK_ONCE'] = '1'
    if late in ('l2', 'l2-ap'):
        env['GGML_TP5_LATEBIND_L2'] = 'td'
    if diagnostic:
        env['GGML_TP5_RELAY_DEBUG'] = '1'
    cmd = [str(BIN), '-dev', 'Vulkan0,Vulkan1,Vulkan2,Vulkan3,Vulkan4',
           '--split-mode', 'tensor', '--fit', 'off', '-ngl', '999', '-c', '768',
           '-b', '32', '-ub', '32', '--no-mmap', '--no-host', '-np', '1',
           '--host', '127.0.0.1', '--port', str(PORT), '--model', TARGET,
           '--tp5', 'qwen4exp-af', '--tp5-latebind', late if late in ('off', 'exact') else 'aggressive']
    if cfg['depth']:
        cmd += ['-md', DRAFT, '--spec-type', 'draft-mtp', '--spec-draft-n-max', str(cfg['depth']),
                '--spec-draft-p-min', str(cfg['pmin']),
                '--spec-draft-backend-sampling' if cfg['sampling'] else '--no-spec-draft-backend-sampling']
    save(directory / 'manifest.json', dict(config=cfg, command=cmd, environment=env,
         diagnostic_only=diagnostic, prediction_tokens=NP, start_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())))
    # Never terminate unrelated services or globally pkill llama-server.
    try:
        http('/health', timeout=1)
    except (urllib.error.URLError, TimeoutError, OSError):
        pass
    else:
        raise RuntimeError('Benchmark port already occupied')
    log = (directory / 'server.log').open('wb')
    process = subprocess.Popen(cmd, env=env, stdout=log, stderr=subprocess.STDOUT,
                               pass_fds=(GPU_LOCK.fileno(),))
    SERVER = (process, log)
    try:
        deadline = time.monotonic() + 300
        while True:
            if process.poll() is not None:
                raise RuntimeError(f'{label}: server exited {process.returncode}')
            try:
                if http('/health', timeout=2).get('status') == 'ok':
                    break
            except (urllib.error.URLError, TimeoutError, OSError):
                pass
            if time.monotonic() >= deadline:
                raise RuntimeError(f'{label}: readiness deadline exceeded')
            time.sleep(0.5)
        mapped = {}
        for line in Path(f'/proc/{process.pid}/maps').read_text().splitlines():
            fields = line.split(maxsplit=5)
            if len(fields) == 6 and fields[5].startswith('/'):
                path = Path(fields[5])
                if '.so' in path.name and path.parent == BIN.parent and str(path) not in mapped:
                    mapped[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
        save(directory / 'mapped-libraries.json', mapped)
        rows = []
        schedule = [(True, 0)] if diagnostic else [(True, i) for i in range(len(PROMPTS))]
        schedule += [(False, i) for _ in range(1 if diagnostic else repeats) for i in range(1 if diagnostic else len(PROMPTS))]
        for number, (warmup, prompt_index) in enumerate(schedule):
            before = (directory / 'server.log').stat().st_size
            payload = dict(prompt=PROMPTS[prompt_index], n_predict=NP, temperature=0,
                           seed=42, stream=False, ignore_eos=False, cache_prompt=False)
            start = time.monotonic()
            reply = http('/completion', payload)
            wall_ms = (time.monotonic() - start) * 1000
            save(directory / f'request-{number}.json', reply)
            timings = reply.get('timings', {})
            n = timings.get('predicted_n', 0)
            ms = timings.get('predicted_ms', 0)
            if not 0 < n <= NP or not math.isfinite(ms) or ms <= 0:
                raise RuntimeError(f'{label}: invalid natural completion {n=}, {ms=}')
            if cfg['depth'] and timings.get('draft_n', 0) <= 0:
                raise RuntimeError(f'{label}: MTP requested but no drafts observed')
            data = (directory / 'server.log').read_bytes()[before:]
            row = dict(index=number, prompt=prompt_index, warmup=warmup, wall_ms=wall_ms,
                       predicted_n=n, predicted_ms=ms, ms_per_token=ms/n, tok_s=n*1000/ms,
                       draft_n=timings.get('draft_n', 0), accepted=timings.get('draft_n_accepted', 0),
                       output_sha256=hashlib.sha256(reply.get('content', '').encode()).hexdigest(),
                       fallback_count=data.count(b'CRITICAL-FALLBACK'),
                       log_begin=before, log_end=before+len(data))
            rows.append(row)
            save(directory / 'requests.json', rows)
        text = (directory / 'server.log').read_text(errors='replace')
        if re.search(r'FAILURE:|handoff failed|Compute error|sidecar timeout', text):
            raise RuntimeError(f'{label}: runtime protocol failure; see server.log')
        modes = collections.defaultdict(set)
        for backend, mode in POLICY.findall(text):
            modes[backend].add(mode)
        if set(modes) != {f'Vulkan{i}' for i in range(5)} or any(v != {cfg['policy']} for v in modes.values()):
            raise RuntimeError(f'{label}: actual backend modes disagree: {dict(modes)}')
        regions = [dict(backend=b, family=f, mask=int(m), shared_q8_1=int(q)) for b,f,m,q in REGION.findall(text)]
        if diagnostic:
            masks = {'disabled': {'gdn-projections': 0, 'qsa-projections': 0},
                     'auto': {'gdn-projections': 3, 'qsa-projections': 1},
                     'forced': {'gdn-projections': 7, 'qsa-projections': 5}}[cfg['policy']]
            for backend in modes:
                for family, expected in masks.items():
                    if not any(r['backend'] == backend and r['family'] == family and r['mask'] == expected for r in regions):
                        raise RuntimeError(f'{label}: missing actual dispatch mask {backend}/{family}/{expected}')
        measured = [r for r in rows if not r['warmup']]
        # Only the repository's canonical weightloss workload selects the winner.
        # The inherited failure prompt and English prompt are correctness/drift guards.
        score = statistics.median(r['tok_s'] for r in measured if r['prompt'] == 0)
        result = dict(label=label, config=cfg, diagnostic_only=diagnostic, modes={k:sorted(v) for k,v in modes.items()},
                      mapped_libraries=mapped,
                      actual_region_records=regions, score_tps=score, rows=rows,
                      total_fallbacks=text.count('CRITICAL-FALLBACK'), returncode=None)
        save(directory / 'result.json', result)
        print(json.dumps(dict(label=label, config=cfg, diagnostic_only=diagnostic,
             score_tps=score, measured_fallbacks=sum(r['fallback_count'] for r in measured),
             region_masks=sorted({(r['family'],r['mask']) for r in regions})), ensure_ascii=False), flush=True)
        return result
    finally:
        stop_server()


def main():
    global BIN, ROOT, GPU_LOCK
    parser = argparse.ArgumentParser()
    parser.add_argument('phase', choices=['probe', 'screen', 'confirm', 'smoke'])
    parser.add_argument('--candidate', type=Path)
    parser.add_argument('--binary', type=Path, default=BIN)
    parser.add_argument('--output', type=Path, default=ROOT)
    args = parser.parse_args()
    BIN = args.binary.resolve()
    ROOT = args.output.resolve()
    ROOT.mkdir(parents=True, exist_ok=True)
    for signum in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        signal.signal(signum, interrupted)
    GPU_LOCK = open('/var/tmp/tp5-gpu.lock', 'a+')
    fcntl.flock(GPU_LOCK, fcntl.LOCK_EX)
    health = subprocess.run(['systemctl', 'is-active', 'eagle-gpu-watchdog'], capture_output=True, text=True)
    if health.returncode or health.stdout.strip() != 'active':
        raise RuntimeError('Eagle watchdog is not active; refusing GPU experiment')
    devices = subprocess.run([str(BIN), '--list-devices'], capture_output=True, text=True,
                             env=dict(PATH='/usr/bin:/bin', HOME='/home/kunweiz', RADV_DEBUG='nobolist'), timeout=30)
    save(ROOT / 'devices.json', dict(returncode=devices.returncode, stdout=devices.stdout, stderr=devices.stderr))
    if devices.returncode or len(re.findall(r'^\s*Vulkan\d+:.*RX 6800', devices.stdout, re.M)) != 5:
        raise RuntimeError('Exactly five physical RX6800 Vulkan devices required; no experiment submitted')
    save(ROOT / 'identity.json', dict(binary=str(BIN), binary_sha256=hashlib.sha256(BIN.read_bytes()).hexdigest(),
         workload=PROMPTS, primary_prompt=0, max_prediction_tokens=NP, ignore_eos=False,
         late_variants=LATE_VARIANTS, policy=('disabled', 'auto', 'forced'),
         depth_seeds=(0, 1, 2, 3, 4, 6, 8, 10, 12, 16), inference='Hill climbing proves only the exercised neighborhood, not a global hardware optimum'))
    if args.phase == 'probe':
        for policy in ('disabled', 'auto', 'forced'):
            trial('probe-'+policy, config(policy), diagnostic=True)
    elif args.phase == 'smoke':
        for late in ('off', 'exact', 'aggressive', 'ap', 'l2'):
            trial('smoke-'+late, config('disabled', 1, late=late), repeats=5)
    elif args.phase == 'screen':
        results = []
        incumbent = config('auto', 1)
        results.append(trial('screen-anchor-start', incumbent))
        # Cross-factor seeds prevent the old search from excluding disabled/no-MTP winners.
        for late in LATE_VARIANTS:
            for policy in ('disabled', 'auto', 'forced'):
                for depth in (0, 1, 2, 3, 4):
                    if late == 'off' and policy == 'auto' and depth == 1:
                        continue
                    result = trial(f'screen-{late}-{policy}-d{depth}', config(policy, depth, late=late))
                    results.append(result)
                    save(ROOT / 'screen-progress.json', results)
        for depth in (6, 8, 10, 12, 16):
            results.append(trial(f'screen-deep-{depth}', config('auto', depth)))
        winner = max(results, key=lambda r:r['score_tps'])
        # Evaluate complete one-factor neighborhoods; no arbitrary trial-count cutoff.
        key = lambda cfg: json.dumps(cfg, sort_keys=True)
        seen = {key(r['config']): r for r in results}
        walk = []
        step = 0
        stop_reason = 'no neighbor exceeds the 2% screening threshold'
        while True:
            base = winner['config']
            neighbors = []
            for depth in (base['depth'] - 1, base['depth'] + 1):
                if 0 <= depth <= 16:
                    neighbors.append(('depth-'+str(depth), {**base, 'depth':depth}))
            neighbors.extend(('policy-'+policy, {**base, 'policy':policy})
                             for policy in ('disabled', 'auto', 'forced') if policy != base['policy'])
            neighbors.extend(('late-'+late, {**base, 'late':late}) for late in LATE_VARIANTS if late != base['late'])
            for label, knob in (('columns', 'GGML_VK_SMALL_Q8_COLUMNS'), ('kv', 'GGML_MTP_KV_ONLY')):
                if knob == 'GGML_MTP_KV_ONLY' and base['depth'] == 0:
                    continue
                knobs = dict(base['knobs'])
                if knobs.get(knob, '1') == '1':
                    knobs[knob] = '0'
                else:
                    knobs.pop(knob)
                neighbors.append((label, {**base, 'knobs':knobs}))
            knobs = dict(base['knobs'])
            if 'GGML_VK_DISABLE_GDN_CACHED_SEGMENT' in knobs:
                knobs.pop('GGML_VK_DISABLE_GDN_CACHED_SEGMENT')
            else:
                knobs['GGML_VK_DISABLE_GDN_CACHED_SEGMENT'] = '1'
            neighbors.append(('gdn-cache', {**base, 'knobs':knobs}))
            if base['depth']:
                neighbors.append(('sampling', {**base, 'sampling':not base['sampling']}))
            evaluated = []
            for label, current in neighbors:
                identity = key(current)
                if identity not in seen:
                    result = trial(f'screen-step{step}-{label}', current)
                    results.append(result)
                    seen[identity] = result
                    save(ROOT / 'screen-progress.json', results)
                evaluated.append(seen[identity])
            best = max([winner] + evaluated, key=lambda r:r['score_tps'])
            walk.append(dict(step=step, incumbent=base, incumbent_tps=winner['score_tps'],
                             neighbors=[dict(config=r['config'], score_tps=r['score_tps']) for r in evaluated],
                             complete_neighborhood=True))
            if best['score_tps'] <= winner['score_tps'] * 1.02:
                break
            winner = best
            step += 1
        save(ROOT / 'walk.json', dict(steps=walk, stop_reason=stop_reason))
        results.append(trial('screen-anchor-end', config('auto',1)))
        save(ROOT / 'screen.json', results)
        save(ROOT / 'candidate.json', winner['config'])
        print('SCREEN_COMPLETE '+json.dumps(winner['config']), flush=True)
    else:
        candidate = json.loads((args.candidate or ROOT/'candidate.json').read_text())
        reference = config('disabled', 1)
        results = []
        for block, order in enumerate((('R','C'),('C','R'),('R','C'),('C','R')), 1):
            for arm in order:
                cfg = reference if arm == 'R' else candidate
                results.append(trial(f'confirm-{block}-{arm}', cfg, repeats=3))
        save(ROOT / 'confirmation.json', results)
        by_label = {r['label']:r for r in results}
        paired = [math.log(by_label[f'confirm-{block}-C']['score_tps'] /
                           by_label[f'confirm-{block}-R']['score_tps']) for block in range(1, 5)]
        center = statistics.mean(paired)
        radius = 3.182446305284263 * statistics.stdev(paired) / math.sqrt(len(paired))
        report = dict(candidate=candidate, reference=reference, independent_blocks=4,
                      paired_tps_ratio=math.exp(center), ci95=[math.exp(center-radius), math.exp(center+radius)],
                      significant_speedup=center-radius > 0,
                      measured_fallbacks={arm:sum(row['fallback_count'] for r in results if r['label'].endswith(arm)
                                                  for row in r['rows'] if not row['warmup']) for arm in ('R','C')},
                      scope='Current binary, these fixed prompts and token count; not a global optimum proof')
        save(ROOT / 'confirmation-report.json', report)
        print('CONFIRMATION_COMPLETE '+json.dumps(report), flush=True)


if __name__ == '__main__':
    main()
