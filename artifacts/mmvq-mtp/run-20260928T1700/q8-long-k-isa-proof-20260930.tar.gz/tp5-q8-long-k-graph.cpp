#include "ggml.h"
#include "ggml-backend.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <vector>

static void check(bool v, const char * where) {
    if (!v) { std::fprintf(stderr, "FAIL %s\n", where); std::exit(1); }
}
int main(int argc, char ** argv) {
    check(argc == 6, "usage: graph K M N view output.bin");
    const int k = std::atoi(argv[1]), m = std::atoi(argv[2]), n = std::atoi(argv[3]);
    const bool view = std::atoi(argv[4]) != 0;
    check(k > 0 && k % 32 == 0 && m > 0 && n > 0, "dimensions");
    ggml_backend_load_all();
    auto * reg = ggml_backend_reg_by_name("Vulkan"); check(reg, "Vulkan registry");
    auto * gpu = ggml_backend_dev_init(ggml_backend_reg_dev_get(reg, 0), nullptr); check(gpu, "Vulkan device");
    auto * cpu_reg = ggml_backend_reg_by_name("CPU"); check(cpu_reg, "CPU registry");
    auto * cpu = ggml_backend_dev_init(ggml_backend_reg_dev_get(cpu_reg, 0), nullptr); check(cpu, "CPU device");
    auto * wc = ggml_init({1024 * 1024, nullptr, true}); check(wc, "weight context");
    auto * parent = ggml_new_tensor_2d(wc, GGML_TYPE_Q8_0, k, m + (view ? 1 : 0));
    auto * wb = ggml_backend_alloc_ctx_tensors(wc, gpu); check(wb, "weight buffer");
    std::vector<float> wf(size_t(k) * parent->ne[1]);
    for (size_t i = 0; i < wf.size(); ++i) {
        const int row = i / k, col = i % k;
        wf[i] = row % 37 == 0 ? 0.0f : std::ldexp(float(int((i * 17 + row * 53) % 509) - 254) * 0.0012f, (row + col / 32) % 9 - 4);
    }
    std::vector<unsigned char> qw(ggml_nbytes(parent));
    check(ggml_quantize_chunk(GGML_TYPE_Q8_0, wf.data(), qw.data(), 0, parent->ne[1], k, nullptr) == qw.size(), "quantization");
    ggml_backend_tensor_set(parent, qw.data(), 0, qw.size());
    auto * gc = ggml_init({1024 * 1024, nullptr, true}); check(gc, "graph context");
    auto * w = view ? ggml_view_2d(gc, parent, k, m, parent->nb[1], parent->nb[1]) : parent;
    auto * xp = ggml_new_tensor_2d(gc, GGML_TYPE_F32, k, n + (view ? 1 : 0)); ggml_set_input(xp);
    auto * x = view ? ggml_view_2d(gc, xp, k, n, xp->nb[1], xp->nb[1]) : xp;
    auto * y = ggml_mul_mat(gc, w, x); ggml_set_output(y);
    auto * g = ggml_new_graph_custom(gc, 16, false); ggml_build_forward_expand(g, y);
    ggml_backend_t backends[] = {gpu, cpu};
    auto * sched = ggml_backend_sched_new(backends, nullptr, 2, 32, false, true); check(sched, "scheduler");
    ggml_backend_sched_set_tensor_backend(sched, xp, gpu);
    check(ggml_backend_sched_alloc_graph(sched, g), "graph allocation");
    auto * f = std::fopen(argv[5], "wb"); check(f, "output file");
    for (int run = 0; run < 3; ++run) {
        std::vector<float> input(size_t(k) * xp->ne[1]);
        for (size_t i = 0; i < input.size(); ++i) {
            input[i] = std::ldexp(std::sin(float((i * 11 + run * 101) % 251) * 0.071f), int((i / 32 + run) % 7) - 3);
        }
        ggml_backend_tensor_set(xp, input.data(), 0, input.size() * sizeof(float));
        check(ggml_backend_sched_graph_compute(sched, g) == GGML_STATUS_SUCCESS, "compute");
        std::vector<float> out(size_t(m) * n);
        ggml_backend_tensor_get(y, out.data(), 0, out.size() * sizeof(float));
        for (float v : out) check(std::isfinite(v), "finite output");
        check(std::fwrite(out.data(), sizeof(float), out.size(), f) == out.size(), "output write");
    }
    check(std::fclose(f) == 0, "output close");
    std::printf("PASS Q8 K=%d M=%d N=%d view=%d runs=3\n", k, m, n, int(view));
    ggml_backend_sched_free(sched); ggml_free(gc); ggml_backend_buffer_free(wb); ggml_free(wc); ggml_backend_free(cpu); ggml_backend_free(gpu);
}
