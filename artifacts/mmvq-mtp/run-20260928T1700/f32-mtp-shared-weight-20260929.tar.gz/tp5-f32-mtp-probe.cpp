#include "ggml.h"
#include "ggml-backend.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>

static void check(bool v,const char *where){if(!v){std::fprintf(stderr,"FAIL %s\n",where);std::exit(1);}}
int main(int argc,char **argv){
    check(argc==5||argc==6,"usage: probe width rows tokens output.bin [f16]");
    const int k=std::atoi(argv[1]),m=std::atoi(argv[2]),n=std::atoi(argv[3]);
    const bool half=argc==6&&std::strcmp(argv[5],"f16")==0;
    check(argc==5||half,"activation type");
    check(k>0&&m>0&&n>=1&&n<=16,"dimensions");
    ggml_backend_load_all();
    auto *vr=ggml_backend_reg_by_name("Vulkan"),*cr=ggml_backend_reg_by_name("CPU");check(vr&&cr,"registrations");
    auto *gpu=ggml_backend_dev_init(ggml_backend_reg_dev_get(vr,0),nullptr);
    auto *cpu=ggml_backend_dev_init(ggml_backend_reg_dev_get(cr,0),nullptr);check(gpu&&cpu,"backends");
    auto *wctx=ggml_init({1024*1024,nullptr,true});
    auto *w=ggml_new_tensor_2d(wctx,GGML_TYPE_F32,k,m);
    auto *wb=ggml_backend_alloc_ctx_tensors(wctx,gpu);check(wb,"weight buffer");
    std::vector<float> wf(size_t(k)*m);
    for(size_t i=0;i<wf.size();++i)wf[i]=float(int(i%251)-125)*0.0003f;
    ggml_backend_tensor_set(w,wf.data(),0,ggml_nbytes(w));
    std::vector<float>().swap(wf);
    auto *ctx=ggml_init({1024*1024,nullptr,true});
    auto *x=ggml_new_tensor_2d(ctx,half?GGML_TYPE_F16:GGML_TYPE_F32,k,n);ggml_set_input(x);
    auto *y=ggml_mul_mat(ctx,w,x);ggml_set_output(y);
    auto *graph=ggml_new_graph_custom(ctx,16,false);ggml_build_forward_expand(graph,y);
    ggml_backend_t backends[2]{gpu,cpu};
    auto *sched=ggml_backend_sched_new(backends,nullptr,2,32,false,true);check(sched,"scheduler");
    ggml_backend_sched_set_tensor_backend(sched,x,gpu);
    check(ggml_backend_sched_alloc_graph(sched,graph),"graph allocation");
    std::vector<float> input(size_t(k)*n);
    for(size_t i=0;i<input.size();++i)input[i]=std::sin(float(i%251)*0.071f)*0.7f;
    if(half){
        std::vector<ggml_fp16_t> h(input.size());
        for(size_t i=0;i<h.size();++i)h[i]=ggml_fp32_to_fp16(input[i]);
        ggml_backend_tensor_set(x,h.data(),0,h.size()*sizeof(ggml_fp16_t));
    }else{
        ggml_backend_tensor_set(x,input.data(),0,input.size()*sizeof(float));
    }
    const char *env=std::getenv("TP5_F32_REPEATS");const int repeats=env?std::atoi(env):1;check(repeats>0,"repeats");
    for(int i=0;i<repeats;++i)check(ggml_backend_sched_graph_compute(sched,graph)==GGML_STATUS_SUCCESS,"compute");
    std::vector<float> values(size_t(m)*n);
    ggml_backend_tensor_get(y,values.data(),0,values.size()*sizeof(float));
    for(float v:values)check(std::isfinite(v),"finite output");
    auto *file=std::fopen(argv[4],"wb");check(file,"output open");
    check(std::fwrite(values.data(),sizeof(float),values.size(),file)==values.size(),"output write");
    check(std::fclose(file)==0,"output close");
    std::printf("PASS F32 k=%d m=%d n=%d input=%s\n",k,m,n,half?"f16":"f32");
    ggml_backend_sched_free(sched);ggml_free(ctx);ggml_backend_buffer_free(wb);ggml_free(wctx);
    ggml_backend_free(cpu);ggml_backend_free(gpu);
}
