#include "ggml.h"
#include "ggml-backend.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <vector>

static void check(bool v,const char *what){if(!v){std::fprintf(stderr,"FAIL %s\n",what);std::exit(1);}}
int main(int argc,char **argv){
    check(argc==5,"usage: probe width rows tokens output.bin");
    const int k=std::atoi(argv[1]),m=std::atoi(argv[2]),n=std::atoi(argv[3]);
    check(k>0&&k%32==0&&m>0&&n>=1&&n<=16,"shape");
    ggml_backend_load_all();
    auto *vr=ggml_backend_reg_by_name("Vulkan"),*cr=ggml_backend_reg_by_name("CPU");check(vr&&cr,"registrations");
    auto *gpu=ggml_backend_dev_init(ggml_backend_reg_dev_get(vr,0),nullptr);
    auto *cpu=ggml_backend_dev_init(ggml_backend_reg_dev_get(cr,0),nullptr);check(gpu&&cpu,"backends");
    auto *wctx=ggml_init({1024*1024,nullptr,true});
    auto *w=ggml_new_tensor_2d(wctx,GGML_TYPE_Q8_0,k,m);
    auto *wb=ggml_backend_alloc_ctx_tensors(wctx,gpu);check(wb,"weight allocation");
    std::vector<float> floats(size_t(k)*m);
    for(size_t i=0;i<floats.size();++i)floats[i]=std::sin(float(i%509)*0.037f)*0.035f;
    std::vector<unsigned char> packed(ggml_nbytes(w));
    check(ggml_quantize_chunk(GGML_TYPE_Q8_0,floats.data(),packed.data(),0,m,k,nullptr)==packed.size(),"weight quantize");
    ggml_backend_tensor_set(w,packed.data(),0,packed.size());
    floats.clear();packed.clear();
    auto *ctx=ggml_init({1024*1024,nullptr,true});
    auto *x=ggml_new_tensor_2d(ctx,GGML_TYPE_F32,k,n);ggml_set_input(x);
    auto *y=ggml_mul_mat(ctx,w,x);ggml_set_output(y);
    auto *graph=ggml_new_graph_custom(ctx,16,false);ggml_build_forward_expand(graph,y);
    ggml_backend_t backends[2]{gpu,cpu};
    auto *sched=ggml_backend_sched_new(backends,nullptr,2,32,false,true);check(sched,"scheduler");
    ggml_backend_sched_set_tensor_backend(sched,x,gpu);
    check(ggml_backend_sched_alloc_graph(sched,graph),"graph allocation");
    std::vector<float> input(size_t(k)*n);
    for(size_t i=0;i<input.size();++i)input[i]=std::sin(float(i%251)*0.071f)*0.7f;
    ggml_backend_tensor_set(x,input.data(),0,input.size()*sizeof(float));
    const char *env=std::getenv("TP5_Q8_REPEATS");
    const int repeats=env?std::atoi(env):1;check(repeats>0,"repeats");
    for(int i=0;i<repeats;++i)check(ggml_backend_sched_graph_compute(sched,graph)==GGML_STATUS_SUCCESS,"compute");
    std::vector<float> values(size_t(m)*n);
    ggml_backend_tensor_get(y,values.data(),0,values.size()*sizeof(float));
    for(float v:values)check(std::isfinite(v),"finite output");
    auto *file=std::fopen(argv[4],"wb");check(file,"open output");
    check(std::fwrite(values.data(),sizeof(float),values.size(),file)==values.size(),"write output");
    check(std::fclose(file)==0,"close output");
    std::printf("PASS Q8_0 k=%d m=%d n=%d\n",k,m,n);
    ggml_backend_sched_free(sched);ggml_free(ctx);ggml_backend_buffer_free(wb);ggml_free(wctx);
    ggml_backend_free(cpu);ggml_backend_free(gpu);
}
