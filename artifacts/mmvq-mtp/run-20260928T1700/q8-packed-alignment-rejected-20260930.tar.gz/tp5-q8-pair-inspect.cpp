#include <vulkan/vulkan.h>
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <vector>
static void check(VkResult r, const char *where) { if (r != VK_SUCCESS) { std::fprintf(stderr, "%s: %d\n", where, r); std::exit(1); } }
int main(int argc, char **argv) {
    if (argc != 5) return 2;
    std::ifstream source(argv[1], std::ios::binary | std::ios::ate);
    const auto bytes = source.tellg();
    if (!source || bytes <= 0 || bytes % 4) return 2;
    std::vector<uint32_t> code(size_t(bytes) / 4);
    source.seekg(0); source.read(reinterpret_cast<char *>(code.data()), bytes);
    if (!source) return 2;
    VkApplicationInfo app{}; app.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO; app.apiVersion = VK_API_VERSION_1_3;
    VkInstanceCreateInfo ic{}; ic.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO; ic.pApplicationInfo = &app;
    VkInstance instance{}; check(vkCreateInstance(&ic, nullptr, &instance), "instance");
    uint32_t count = 0; check(vkEnumeratePhysicalDevices(instance, &count, nullptr), "device count");
    std::vector<VkPhysicalDevice> devices(count); check(vkEnumeratePhysicalDevices(instance, &count, devices.data()), "devices");
    VkPhysicalDevice physical{};
    for (auto p : devices) { VkPhysicalDeviceProperties props{}; vkGetPhysicalDeviceProperties(p, &props); if (props.vendorID == 0x1002) { physical = p; break; } }
    if (!physical) return 2;
    VkPhysicalDeviceFeatures2 enable{}; enable.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2; enable.features.shaderInt16 = VK_TRUE;
    VkPhysicalDeviceVulkan11Features f11{}; f11.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_1_FEATURES; f11.storageBuffer16BitAccess = VK_TRUE;
    VkPhysicalDeviceVulkan12Features f12{}; f12.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_2_FEATURES; f12.storageBuffer8BitAccess = VK_TRUE; f12.shaderInt8 = VK_TRUE;
    VkPhysicalDeviceVulkan13Features f13{}; f13.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_3_FEATURES; f13.shaderIntegerDotProduct = VK_TRUE;
    enable.pNext = &f11; f11.pNext = &f12; f12.pNext = &f13;
    const float priority = 1.0f;
    VkDeviceQueueCreateInfo qi{}; qi.sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO; qi.queueFamilyIndex = 0; qi.queueCount = 1; qi.pQueuePriorities = &priority;
    VkDeviceCreateInfo dc{}; dc.sType = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO; dc.pNext = &enable; dc.queueCreateInfoCount = 1; dc.pQueueCreateInfos = &qi;
    VkDevice device{}; check(vkCreateDevice(physical, &dc, nullptr, &device), "device");
    VkDescriptorSetLayoutBinding bindings[5]{};
    for (uint32_t i = 0; i < 5; ++i) { bindings[i].binding = i; bindings[i].descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER; bindings[i].descriptorCount = 1; bindings[i].stageFlags = VK_SHADER_STAGE_COMPUTE_BIT; }
    VkDescriptorSetLayoutCreateInfo dl{}; dl.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO; dl.bindingCount = 5; dl.pBindings = bindings;
    VkDescriptorSetLayout dsl{}; check(vkCreateDescriptorSetLayout(device, &dl, nullptr, &dsl), "descriptor layout");
    VkPushConstantRange push{VK_SHADER_STAGE_COMPUTE_BIT, 0, 52};
    VkPipelineLayoutCreateInfo pl{}; pl.sType = VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO; pl.setLayoutCount = 1; pl.pSetLayouts = &dsl; pl.pushConstantRangeCount = 1; pl.pPushConstantRanges = &push;
    VkPipelineLayout layout{}; check(vkCreatePipelineLayout(device, &pl, nullptr, &layout), "pipeline layout");
    VkShaderModuleCreateInfo mc{}; mc.sType = VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO; mc.codeSize = code.size() * 4; mc.pCode = code.data();
    VkShaderModule module{}; check(vkCreateShaderModule(device, &mc, nullptr, &module), "shader module");
    std::array<uint32_t, 5> values{{64, uint32_t(std::strtoul(argv[2], nullptr, 10)), 2, uint32_t(std::strtoul(argv[3], nullptr, 10)), uint32_t(std::strtoul(argv[4], nullptr, 10))}};
    VkSpecializationMapEntry entries[5]{{0, 0, 4}, {1, 4, 4}, {2, 8, 4}, {3, 12, 4}, {4, 16, 4}};
    VkSpecializationInfo si{5, entries, sizeof(values), values.data()};
    VkPipelineShaderStageCreateInfo stage{}; stage.sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO; stage.stage = VK_SHADER_STAGE_COMPUTE_BIT; stage.module = module; stage.pName = "main"; stage.pSpecializationInfo = &si;
    VkComputePipelineCreateInfo pc{}; pc.sType = VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO; pc.stage = stage; pc.layout = layout;
    VkPipeline pipeline{}; check(vkCreateComputePipelines(device, VK_NULL_HANDLE, 1, &pc, nullptr, &pipeline), "pipeline");
    std::printf("PIPELINE_ONLY rows=%u fixedK=%u fixedM=%u; no dispatch/query/queue submission\n", values[1], values[3], values[4]);
    vkDestroyPipeline(device, pipeline, nullptr); vkDestroyShaderModule(device, module, nullptr); vkDestroyPipelineLayout(device, layout, nullptr); vkDestroyDescriptorSetLayout(device, dsl, nullptr); vkDestroyDevice(device, nullptr); vkDestroyInstance(instance, nullptr);
}
