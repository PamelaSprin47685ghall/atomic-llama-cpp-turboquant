import assert from 'node:assert/strict';
const u32 = x => x >>> 0;
function original(view, ib, iqs) {
    const p = ib * 34 + 2 + iqs * 8;
    const pack = o => u32((view.getInt16(o, true) & 65535) | (view.getInt16(o + 2, true) << 16));
    return [pack(p), pack(p + 4)];
}
function rawPair(view, ib, iqs, tail16) {
    const p = ib * 34 + 2 + iqs * 8;
    const w = Math.floor(p / 4) * 4;
    const lo = view.getUint32(w, true), mid = view.getUint32(w + 4, true);
    if (!(p & 2)) return [lo, mid];
    const hi = tail16 ? view.getUint16(ib * 34 + 2 + 2 * (iqs * 4 + 3), true) : view.getUint32(w + 8, true);
    return [u32((lo >>> 16) | (mid << 16)), u32((mid >>> 16) | (hi << 16))];
}
let basis = 0;
for (const ib of [0, 1]) for (let iqs = 0; iqs < 4; ++iqs) {
    const p = ib * 34 + 2 + iqs * 8;
    for (let bit = 0; bit < 96; ++bit) {
        const bytes = new Uint8Array(70);
        bytes[p - 2 + Math.floor(bit / 8)] = 1 << (bit % 8);
        const view = new DataView(bytes.buffer);
        assert.deepEqual(rawPair(view, ib, iqs, true), original(view, ib, iqs));
        ++basis;
    }
}
let seed = 0x19ef4ab3;
function nextByte() { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed >>> 24; }
let pairs = 0;
for (const prefix of [0, 1, 7, 32]) for (const count of [1, 2, 3, 10, 320]) {
    const bytes = new Uint8Array((prefix + count) * 34);
    for (let i = 0; i < bytes.length; ++i) bytes[i] = nextByte();
    const view = new DataView(bytes.buffer);
    for (let ib = prefix; ib < prefix + count; ++ib) for (let iqs = 0; iqs < 4; ++iqs) {
        assert.deepEqual(rawPair(view, ib, iqs, true), original(view, ib, iqs));
        ++pairs;
    }
}
const tail = new DataView(new ArrayBuffer(34));
for (let i = 0; i < 34; ++i) tail.setUint8(i, i ^ 0x83);
assert.throws(() => rawPair(tail, 0, 3, false), RangeError);
assert.deepEqual(rawPair(tail, 0, 3, true), original(tail, 0, 3));
console.log(JSON.stringify({basisChecks: basis, randomPairs: pairs, exact34ByteRaw32Overread: true, exact34ByteTail16Matches: true, gpuDispatches: 0, note: 'Source-level bit/address oracle; not GPU numerical or speed evidence'}));
