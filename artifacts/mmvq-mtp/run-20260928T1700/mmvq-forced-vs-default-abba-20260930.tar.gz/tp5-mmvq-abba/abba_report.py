#!/usr/bin/env python3
"""Aggregate MMVQ+MTP ABBA: per-arm ms/cycle and tok/s, paired per-block
ratios against R with t-based 95% CI."""
import collections, math, os, re, statistics as st, sys

O = sys.argv[1] if len(sys.argv) > 1 else '/var/tmp/tp5-mmvq-abba/run1'
rows = [l.rstrip('\n').split('\t') for l in open(os.path.join(O, 'summary.tsv')) if l.strip()]
per = collections.defaultdict(list)
for r in rows:
    if len(r) < 12 or r[2] in ('LOADFAIL', 'NOJSON'):
        continue
    tag = r[0]
    m = re.match(r'([A-Za-z]+)(\d+)$', tag)
    arm, blk = m.group(1), int(m.group(2))
    per[(arm, blk)].append((float(r[8]), float(r[9]), r[2], int(r[10]), int(r[11])))

arms = sorted({a for a, _ in per}, key=lambda a: ['R', 'T'].index(a) if a in ('R', 'T') else 9)
blocks = sorted({b for _, b in per})

def tcrit(n):
    return {1: 12.706, 2: 4.303, 3: 3.182, 4: 2.776, 5: 2.571, 6: 2.447, 7: 2.365}.get(n - 1, 2.0)

print(f"{'arm':4s} {'n':>3s} {'ms/cyc med':>10s} {'mean':>7s} {'min':>7s} {'max':>7s} {'tok/s med':>9s}  md5s  fallbacks/session  coherence(cjk,marks)")
for a in arms:
    vals = [x for b in blocks for x in per.get((a, b), [])]
    ms = [v[0] for v in vals]; ts = [v[1] for v in vals]
    md5s = collections.Counter(v[2] for v in vals)
    fb = []
    for b in blocks:
        lg = os.path.join(O, f'{a}{b}.log')
        if os.path.exists(lg):
            fb.append(sum(1 for l in open(lg, errors='replace') if 'CRITICAL-FALLBACK' in l))
    coh = collections.Counter((v[3], v[4]) for v in vals)
    print(f"{a:4s} {len(ms):3d} {st.median(ms):10.3f} {st.mean(ms):7.3f} {min(ms):7.3f} {max(ms):7.3f} {st.median(ts):9.2f}  "
          f"{dict(md5s)}  {fb}  {dict(coh)}")

print('\npaired per-block ratio of median ms/cycle vs R (lower = faster), t-95% CI over blocks:')
for a in arms:
    if a == 'R':
        continue
    rat = []
    for b in blocks:
        if per.get((a, b)) and per.get(('R', b)):
            rat.append(st.median(v[0] for v in per[(a, b)]) / st.median(v[0] for v in per[('R', b)]))
    if len(rat) >= 2:
        m = st.mean(rat); s = st.stdev(rat); h = tcrit(len(rat)) * s / math.sqrt(len(rat))
        print(f"  {a:3s}/R  blocks={len(rat)} mean={m:.4f}  95% CI [{m - h:.4f}, {m + h:.4f}]  per-block={[round(x, 4) for x in rat]}")
    else:
        print(f"  {a:3s}/R  insufficient blocks ({len(rat)})")

print('\nMMVQ policy and fallback check per session:')
for a in arms:
    for b in blocks:
        lg = os.path.join(O, f'{a}{b}.log')
        if not os.path.exists(lg):
            continue
        mmvq = [l.strip() for l in open(lg, errors='replace') if 'vulkan-mmvq-policy' in l]
        mmvq = mmvq[-1] if mmvq else 'NO_MMVQ_LOG'
        fb_cnt = sum(1 for l in open(lg, errors='replace') if 'CRITICAL-FALLBACK' in l)
        print(f"  {a}{b}: {mmvq}  fallbacks={fb_cnt}")
