#!/bin/bash
# MMVQ+MTP ABBA extension: blocks 5-8 appended to run1 for tighter CI.
set -u
D=/var/tmp/tp5-mmvq-abba
O=${O:-$D/run1}
mkdir -p "$O"
run() {
    local tag=$1
    case ${tag%%[0-9]*} in
        R)  $D/arm.sh "$O" "$tag" 3 ;;
        T)  $D/arm.sh "$O" "$tag" 3 GGML_VK_FORCE_MMVQ=1 ;;
    esac
}
for b in 5 6 7 8; do
    if [ $((b % 2)) = 1 ]; then order="R T"; else order="T R"; fi
    for arm in $order; do run "${arm}${b}" > /dev/null 2>&1; done
    echo "block $b done $(date +%H:%M:%S)"
done
echo ABBA2_DONE
