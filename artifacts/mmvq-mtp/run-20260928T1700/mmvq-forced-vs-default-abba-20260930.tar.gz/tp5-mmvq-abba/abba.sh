#!/bin/bash
# MMVQ+MTP ABBA: 4 blocks, alternating direction.
# R = default auto MMVQ (reference)
# T = forced MMVQ (GGML_VK_FORCE_MMVQ=1)
# Blocks: R T | T R | R T | T R  (ABBA palindrome across each pair)
set -u
D=/var/tmp/tp5-mmvq-abba
O=${O:-$D/run1}
mkdir -p "$O"
run() {
    local tag=$1
    case ${tag%%[0-9]*} in
        R)  $D/arm.sh "$O" "$tag" 3 ;;
        T)  $D/arm.sh "$O" "$tag" 3 GGML_VK_FORCE_MMVQ=1 ;;
    esac
}
for b in 1 2 3 4; do
    if [ $((b % 2)) = 1 ]; then order="R T"; else order="T R"; fi
    for arm in $order; do run "${arm}${b}" > /dev/null 2>&1; done
    echo "block $b done $(date +%H:%M:%S)"
done
echo ABBA_DONE
