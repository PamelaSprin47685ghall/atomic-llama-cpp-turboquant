#!/bin/bash
# MMVQ+MTP ABBA harness. One call = one arm = one server process + N requests.
#   arm.sh OUTDIR TAG NREQ [ENV=VAL ...]
# All arms use --tp5-latebind off to isolate MMVQ+MTP from LateBind.
set -u
OUT="$1"; TAG="$2"; NREQ="$3"; shift 3
mkdir -p "$OUT"
BIN="${BIN:-/var/tmp/tp5-final-build/bin/llama-server}"
TARGET_MODEL="/home/kunweiz/models/Qwen3.8-Flash-Next-APEX-I-Compact/Qwen3.8-Flash-Next-APEX-I-Compact-00001-of-00006.gguf"
MTP_MODEL="/home/kunweiz/models/Qwen3.8-Flash-Next-MTP/mtp-Qwen3.8-Flash-Next-Q4_K_M.gguf"
PORT="${PORT:-8161}"; NP="${NP:-171}"
PROMPT="请用八句话简要介绍健康减重原则、每周运动安排、饮食建议和睡眠误区。"
REQ=$(jq -n --arg p "$PROMPT" --argjson n "$NP" '{prompt:$p, n_predict:$n, temperature:0, seed:42, stream:false}')

exec 9>/var/tmp/tp5-gpu.lock
flock 9
pkill -9 -x llama-server 2>/dev/null; sleep 3

env -i PATH=/usr/bin:/bin HOME="$HOME" RADV_DEBUG=nobolist "$@" \
    "$BIN" -dev Vulkan0,Vulkan1,Vulkan2,Vulkan3,Vulkan4 --split-mode tensor --fit off \
    -ngl 999 -c 768 -b 32 -ub 32 --no-mmap --no-host -np 1 \
    --host 127.0.0.1 --port "$PORT" --model "$TARGET_MODEL" \
    --tp5 qwen4exp-af -md "$MTP_MODEL" --spec-type draft-mtp \
    --spec-draft-n-max 1 --spec-draft-p-min 0 \
    --tp5-latebind off > "$OUT/$TAG.log" 2>&1 &
PID=$!
ok=0
for i in $(seq 1 300); do
    if curl -s --max-time 2 "http://127.0.0.1:$PORT/health" 2>/dev/null | grep -q '"ok"'; then ok=1; break; fi
    kill -0 $PID 2>/dev/null || break
    sleep 1
done
if [ "$ok" != 1 ]; then
    echo "### $TAG: server did not become healthy"; tail -5 "$OUT/$TAG.log" | cut -c1-200
    printf '%s\t-\tLOADFAIL\n' "$TAG" >> "$OUT/summary.tsv"
    kill -9 $PID 2>/dev/null; exit 1
fi
LEDGER=$(grep -oE '\[tp5-linear-definition\] rank=0 [^"]*' "$OUT/$TAG.log" | tail -1 | \
         grep -oE 'mode=[^ ]+|late=[0-9]+|rho=[0-9]+|l2=[0-9]+|dispatches=[0-9]+|barriers=[0-9]+' | tr '\n' ' ')
MMVQ_LOG=$(grep -oE '\[vulkan-mmvq-policy\] backend=[^ ]+ mode=[^ ]+' "$OUT/$TAG.log" | tail -1)
for r in $(seq 0 "$NREQ"); do
    curl -s --max-time 900 -X POST "http://127.0.0.1:$PORT/completion" \
        -H 'Content-Type: application/json' -d "$REQ" > "$OUT/${TAG}_r$r.json"
    [ "$r" = 0 ] && continue
    python3 - "$OUT/${TAG}_r$r.json" "$TAG" "$r" "$LEDGER" >> "$OUT/summary.tsv" <<'PY'
import json, sys, hashlib
f, tag, r, ledger = sys.argv[1:5]
try:
    j = json.load(open(f))
except Exception:
    print(f"{tag}\t{r}\tNOJSON"); sys.exit(0)
t = j.get('timings', {}); c = j.get('content', '')
n = t.get('predicted_n', 0); acc = t.get('draft_n_accepted', 0); dn = t.get('draft_n', 0)
ms = t.get('predicted_ms', 0.0); cyc = max(1, n - acc)
cjk = sum(1 for ch in c if '\u4e00' <= ch <= '\u9fff'); marks = sum(1 for ch in c if ch in '。，！？；：、')
print(f"{tag}\t{r}\t{hashlib.md5(c.encode()).hexdigest()[:12]}\t{n}\t{dn}\t{acc}\t{cyc}\t{ms:.1f}\t{ms/cyc:.3f}\t"
      f"{t.get('predicted_per_second',0):.2f}\t{cjk}\t{marks}\t{ledger}")
PY
done
kill -9 $PID 2>/dev/null; wait $PID 2>/dev/null
grep -P "^$TAG\t" "$OUT/summary.tsv" | awk -F'\t' '{printf "  %s r%s md5=%s n=%s cyc=%s ms/cyc=%s tok/s=%s cjk=%s marks=%s\n",$1,$2,$3,$4,$7,$9,$10,$11,$12}'
echo "  ledger: $LEDGER"
echo "  mmvq: $MMVQ_LOG"
