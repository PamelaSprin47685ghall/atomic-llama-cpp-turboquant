#include <vulkan/vulkan.h>
#include <cstdio>
#include <cstdlib>
#include <vector>

static void check(VkResult rc,const char *where){if(rc!=VK_SUCCESS){std::fprintf(stderr,"%s failed: %d\n",where,rc);std::exit(1);}}
int main(){
    VkApplicationInfo app{};app.sType=VK_STRUCTURE_TYPE_APPLICATION_INFO;app.pApplicationName="tp5-counter-enumeration";app.apiVersion=VK_API_VERSION_1_3;
    VkInstanceCreateInfo info{};info.sType=VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;info.pApplicationInfo=&app;
    VkInstance instance{};check(vkCreateInstance(&info,nullptr,&instance),"vkCreateInstance");
    auto enumerate=reinterpret_cast<PFN_vkEnumeratePhysicalDeviceQueueFamilyPerformanceQueryCountersKHR>(vkGetInstanceProcAddr(instance,"vkEnumeratePhysicalDeviceQueueFamilyPerformanceQueryCountersKHR"));
    auto getPasses=reinterpret_cast<PFN_vkGetPhysicalDeviceQueueFamilyPerformanceQueryPassesKHR>(vkGetInstanceProcAddr(instance,"vkGetPhysicalDeviceQueueFamilyPerformanceQueryPassesKHR"));
    if(!enumerate||!getPasses){std::puts("Vulkan performance query enumeration unavailable");vkDestroyInstance(instance,nullptr);return 2;}
    uint32_t n=0;check(vkEnumeratePhysicalDevices(instance,&n,nullptr),"physical device count");
    std::vector<VkPhysicalDevice> devs(n);check(vkEnumeratePhysicalDevices(instance,&n,devs.data()),"physical devices");
    for(uint32_t i=0;i<n;++i){
        VkPhysicalDeviceProperties props{};vkGetPhysicalDeviceProperties(devs[i],&props);
        if(props.vendorID!=0x1002)continue;
        VkPhysicalDevicePerformanceQueryFeaturesKHR features{};features.sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PERFORMANCE_QUERY_FEATURES_KHR;
        VkPhysicalDeviceFeatures2 features2{};features2.sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2;features2.pNext=&features;
        vkGetPhysicalDeviceFeatures2(devs[i],&features2);
        std::printf("device=%u enabled_query_pools=%u multiple_pools=%u\n",i,features.performanceCounterQueryPools,features.performanceCounterMultipleQueryPools);
        uint32_t nf=0;vkGetPhysicalDeviceQueueFamilyProperties(devs[i],&nf,nullptr);
        std::vector<VkQueueFamilyProperties> families(nf);vkGetPhysicalDeviceQueueFamilyProperties(devs[i],&nf,families.data());
        for(uint32_t q=0;q<nf;++q){
            if(!(families[q].queueFlags&VK_QUEUE_COMPUTE_BIT))continue;
            uint32_t nc=0;VkResult r=enumerate(devs[i],q,&nc,nullptr,nullptr);
            std::printf("device=%u name=%s family=%u queues=%u flags=%u rc=%d counter_count=%u\n",i,props.deviceName,q,families[q].queueCount,families[q].queueFlags,r,nc);
            if(r!=VK_SUCCESS||!nc)continue;
            std::vector<VkPerformanceCounterKHR> counters(nc);
            std::vector<VkPerformanceCounterDescriptionKHR> desc(nc);
            for(auto &c:counters)c.sType=VK_STRUCTURE_TYPE_PERFORMANCE_COUNTER_KHR;
            for(auto &d:desc)d.sType=VK_STRUCTURE_TYPE_PERFORMANCE_COUNTER_DESCRIPTION_KHR;
            check(enumerate(devs[i],q,&nc,counters.data(),desc.data()),"counter details");
            for(uint32_t c=0;c<nc;++c)std::printf("  %u scope=%d unit=%d storage=%d flags=%u name=%s description=%s\n",c,counters[c].scope,counters[c].unit,counters[c].storage,desc[c].flags,desc[c].name,desc[c].description);
            for(const std::vector<uint32_t> ids: {std::vector<uint32_t>{12},std::vector<uint32_t>{1,5,12,15,16},std::vector<uint32_t>{0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16}}){
                VkQueryPoolPerformanceCreateInfoKHR pc{};pc.sType=VK_STRUCTURE_TYPE_QUERY_POOL_PERFORMANCE_CREATE_INFO_KHR;pc.queueFamilyIndex=q;pc.counterIndexCount=ids.size();pc.pCounterIndices=ids.data();
                uint32_t passes=0;getPasses(devs[i],&pc,&passes);
                std::printf("  counter_group=%zu passes=%u\n",ids.size(),passes);
            }
        }
    }
    vkDestroyInstance(instance,nullptr);
}
