#include <vulkan/vulkan.h>
#include <array>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <vector>

static void ok(VkResult r, const char *where) { if(r != VK_SUCCESS) { std::fprintf(stderr,"%s: %d\n",where,r);std::exit(1); } }
static void require(bool v,const char *where){if(!v){std::fprintf(stderr,"%s\n",where);std::exit(1);}}
struct Buf { VkBuffer b{}; VkDeviceMemory mem{}; VkDeviceSize sz{}; };
int main(int argc,char **argv){
    const auto start=std::chrono::steady_clock::now();
    auto elapsed=[&](){return std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();};
    require(argc==6,"usage: q6-rows-perf shader.spv width rows tokens rows-per-group");
    const uint32_t k=std::strtoul(argv[2],nullptr,10),m=std::strtoul(argv[3],nullptr,10),n=std::strtoul(argv[4],nullptr,10),rowTile=std::strtoul(argv[5],nullptr,10);
    require(k>0&&k%256==0&&m>0&&(n==1||n==2)&&(rowTile==1||rowTile==2)&&m%rowTile==0,"model dimensions");
    std::ifstream source(argv[1],std::ios::binary|std::ios::ate);require(source.good(),"SPIR-V path");
    const auto len=source.tellg();require(len>0&&len%4==0,"SPIR-V length");
    std::vector<uint32_t> shader(size_t(len)/4);source.seekg(0);source.read(reinterpret_cast<char*>(shader.data()),len);require(source.good(),"SPIR-V read");
    VkApplicationInfo app{};app.sType=VK_STRUCTURE_TYPE_APPLICATION_INFO;app.apiVersion=VK_API_VERSION_1_3;app.pApplicationName="tp5-vk-q6-perf";
    VkInstanceCreateInfo ci{};ci.sType=VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;ci.pApplicationInfo=&app;
    VkInstance instance{};ok(vkCreateInstance(&ci,nullptr,&instance),"instance");
    uint32_t cnt=0;ok(vkEnumeratePhysicalDevices(instance,&cnt,nullptr),"devices count");
    std::vector<VkPhysicalDevice> devices(cnt);ok(vkEnumeratePhysicalDevices(instance,&cnt,devices.data()),"devices");
    VkPhysicalDevice physical{};for(auto p:devices){VkPhysicalDeviceProperties props{};vkGetPhysicalDeviceProperties(p,&props);if(props.vendorID==0x1002){physical=p;break;}}require(physical,"no RX 6800");
    VkPhysicalDeviceVulkan11Features f11{};f11.sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_1_FEATURES;
    VkPhysicalDeviceVulkan12Features f12{};f12.sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_2_FEATURES;
    VkPhysicalDeviceVulkan13Features f13{};f13.sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_3_FEATURES;
    VkPhysicalDevicePerformanceQueryFeaturesKHR fp{};fp.sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PERFORMANCE_QUERY_FEATURES_KHR;
    VkPhysicalDeviceFeatures2 f2{};f2.sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2;f2.pNext=&f11;f11.pNext=&f12;f12.pNext=&f13;f13.pNext=&fp;
    vkGetPhysicalDeviceFeatures2(physical,&f2);
    require(f2.features.shaderInt16&&f11.storageBuffer16BitAccess&&f12.storageBuffer8BitAccess&&f12.shaderInt8&&f13.shaderIntegerDotProduct&&fp.performanceCounterQueryPools,"device shader/profiler features");
    VkPhysicalDeviceFeatures2 enable{};enable.sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2;enable.features.shaderInt16=VK_TRUE;
    VkPhysicalDeviceVulkan11Features e11{};e11.sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_1_FEATURES;e11.storageBuffer16BitAccess=VK_TRUE;
    VkPhysicalDeviceVulkan12Features e12{};e12.sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_2_FEATURES;e12.storageBuffer8BitAccess=VK_TRUE;e12.shaderInt8=VK_TRUE;
    VkPhysicalDeviceVulkan13Features e13{};e13.sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_3_FEATURES;e13.shaderIntegerDotProduct=VK_TRUE;
    VkPhysicalDevicePerformanceQueryFeaturesKHR ep{};ep.sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PERFORMANCE_QUERY_FEATURES_KHR;ep.performanceCounterQueryPools=VK_TRUE;
    enable.pNext=&e11;e11.pNext=&e12;e12.pNext=&e13;e13.pNext=&ep;
    const float priority=1;VkDeviceQueueCreateInfo qi{};qi.sType=VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO;qi.queueFamilyIndex=0;qi.queueCount=1;qi.pQueuePriorities=&priority;
    const char *extension=VK_KHR_PERFORMANCE_QUERY_EXTENSION_NAME;VkDeviceCreateInfo dc{};dc.sType=VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO;dc.pNext=&enable;dc.queueCreateInfoCount=1;dc.pQueueCreateInfos=&qi;dc.enabledExtensionCount=1;dc.ppEnabledExtensionNames=&extension;
    VkDevice device{};ok(vkCreateDevice(physical,&dc,nullptr,&device),"device");VkQueue queue{};vkGetDeviceQueue(device,0,0,&queue);
    VkPhysicalDeviceMemoryProperties memprops{};vkGetPhysicalDeviceMemoryProperties(physical,&memprops);
    auto create=[&](VkDeviceSize size,VkBufferUsageFlags usage,VkMemoryPropertyFlags flags)->Buf{
        Buf out{};out.sz=size;VkBufferCreateInfo bc{};bc.sType=VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO;bc.size=size;bc.usage=usage;bc.sharingMode=VK_SHARING_MODE_EXCLUSIVE;
        ok(vkCreateBuffer(device,&bc,nullptr,&out.b),"buffer");VkMemoryRequirements req{};vkGetBufferMemoryRequirements(device,out.b,&req);
        uint32_t mt=UINT32_MAX;for(uint32_t i=0;i<memprops.memoryTypeCount;++i)if((req.memoryTypeBits&(1u<<i))&&((memprops.memoryTypes[i].propertyFlags&flags)==flags)){
            if(mt==UINT32_MAX||((flags&VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT)&&!(memprops.memoryTypes[i].propertyFlags&VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT)))mt=i;
        }
        require(mt!=UINT32_MAX,"memory type");VkMemoryAllocateInfo ac{};ac.sType=VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;ac.allocationSize=req.size;ac.memoryTypeIndex=mt;
        ok(vkAllocateMemory(device,&ac,nullptr,&out.mem),"memory");ok(vkBindBufferMemory(device,out.b,out.mem,0),"bind memory");return out;
    };
    auto clear=[&](Buf &v){vkDestroyBuffer(device,v.b,nullptr);vkFreeMemory(device,v.mem,nullptr);};
    const VkDeviceSize weightBytes=VkDeviceSize(k)*m/256*210,activationBytes=VkDeviceSize(k)*n/128*144,outputBytes=VkDeviceSize(m)*n*sizeof(float);
    Buf weights=create(weightBytes,VK_BUFFER_USAGE_STORAGE_BUFFER_BIT|VK_BUFFER_USAGE_TRANSFER_DST_BIT,VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    Buf activ=create(activationBytes,VK_BUFFER_USAGE_STORAGE_BUFFER_BIT|VK_BUFFER_USAGE_TRANSFER_DST_BIT,VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    Buf output=create(outputBytes,VK_BUFFER_USAGE_STORAGE_BUFFER_BIT|VK_BUFFER_USAGE_TRANSFER_DST_BIT|VK_BUFFER_USAGE_TRANSFER_SRC_BIT,VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    Buf stagingA=create(weightBytes,VK_BUFFER_USAGE_TRANSFER_SRC_BIT,VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT|VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    Buf stagingB=create(activationBytes,VK_BUFFER_USAGE_TRANSFER_SRC_BIT,VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT|VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    Buf readback=create(outputBytes,VK_BUFFER_USAGE_TRANSFER_DST_BIT,VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT|VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    void *mapped{};ok(vkMapMemory(device,stagingA.mem,0,weightBytes,0,&mapped),"map weights");
    auto *wb=static_cast<uint8_t*>(mapped);for(VkDeviceSize off=0;off<weightBytes;off+=210){
        std::memset(wb+off,0x11,128);std::memset(wb+off+128,0x55,64);std::memset(wb+off+192,1,16);
        wb[off+208]=0;wb[off+209]=0x3c;
    }vkUnmapMemory(device,stagingA.mem);
    ok(vkMapMemory(device,stagingB.mem,0,activationBytes,0,&mapped),"map activation");
    auto *ab=static_cast<uint8_t*>(mapped);for(VkDeviceSize off=0;off<activationBytes;off+=144){for(unsigned j=0;j<4;++j){ab[off+4*j]=0;ab[off+4*j+1]=0x3c;ab[off+4*j+2]=0;ab[off+4*j+3]=0x50;}std::memset(ab+off+16,1,128);}vkUnmapMemory(device,stagingB.mem);
    VkDescriptorSetLayoutBinding binds[5]{};for(uint32_t j=0;j<5;++j){binds[j].binding=j;binds[j].descriptorType=VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;binds[j].descriptorCount=1;binds[j].stageFlags=VK_SHADER_STAGE_COMPUTE_BIT;}
    VkDescriptorSetLayoutCreateInfo dl{};dl.sType=VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO;dl.bindingCount=5;dl.pBindings=binds;VkDescriptorSetLayout dsl{};ok(vkCreateDescriptorSetLayout(device,&dl,nullptr,&dsl),"descriptor layout");
    VkDescriptorPoolSize ps{VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,5};VkDescriptorPoolCreateInfo poolc{};poolc.sType=VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO;poolc.poolSizeCount=1;poolc.pPoolSizes=&ps;poolc.maxSets=1;
    VkDescriptorPool pool{};ok(vkCreateDescriptorPool(device,&poolc,nullptr,&pool),"descriptor pool");VkDescriptorSetAllocateInfo ai{};ai.sType=VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO;ai.descriptorPool=pool;ai.descriptorSetCount=1;ai.pSetLayouts=&dsl;
    VkDescriptorSet set{};ok(vkAllocateDescriptorSets(device,&ai,&set),"descriptor set");
    VkDescriptorBufferInfo bufs[5]{{weights.b,0,weightBytes},{activ.b,0,activationBytes},{output.b,0,outputBytes},{output.b,0,outputBytes},{output.b,0,outputBytes}};
    VkWriteDescriptorSet writes[5]{};for(uint32_t j=0;j<5;++j){writes[j].sType=VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;writes[j].dstSet=set;writes[j].dstBinding=j;writes[j].descriptorType=VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;writes[j].descriptorCount=1;writes[j].pBufferInfo=&bufs[j];}vkUpdateDescriptorSets(device,5,writes,0,nullptr);
    VkShaderModuleCreateInfo sm{};sm.sType=VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO;sm.codeSize=shader.size()*4;sm.pCode=shader.data();VkShaderModule module{};ok(vkCreateShaderModule(device,&sm,nullptr,&module),"shader module");
    struct PC{uint32_t ncols,stride_a,stride_b,stride_d,batch_stride_a,batch_stride_b,batch_stride_d,fusion_flags,base_work_group_y,ne02,ne12,broadcast2,broadcast3;};
    const PC pc{k,k,k,m,k*m,k,m,0,0,1,1,1,1};static_assert(sizeof(PC)==52);
    VkPushConstantRange range{VK_SHADER_STAGE_COMPUTE_BIT,0,sizeof(PC)};VkPipelineLayoutCreateInfo pl{};pl.sType=VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO;pl.setLayoutCount=1;pl.pSetLayouts=&dsl;pl.pushConstantRangeCount=1;pl.pPushConstantRanges=&range;
    VkPipelineLayout layout{};ok(vkCreatePipelineLayout(device,&pl,nullptr,&layout),"pipeline layout");
    std::array<uint32_t,3> spec{{32,rowTile,n}};VkSpecializationMapEntry entries[3]{{0,0,4},{1,4,4},{2,8,4}};
    VkSpecializationInfo si{3,entries,12,spec.data()};VkPipelineShaderStageCreateInfo stage{};stage.sType=VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;stage.stage=VK_SHADER_STAGE_COMPUTE_BIT;stage.module=module;stage.pName="main";stage.pSpecializationInfo=&si;
    VkComputePipelineCreateInfo cp{};cp.sType=VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO;cp.stage=stage;cp.layout=layout;VkPipeline pipeline{};ok(vkCreateComputePipelines(device,VK_NULL_HANDLE,1,&cp,nullptr,&pipeline),"compute pipeline");std::printf("stage pipeline %.3f s\n",elapsed());std::fflush(stdout);
    const uint32_t indices[]{1,5,12,15,16};VkQueryPoolPerformanceCreateInfoKHR pcq{};pcq.sType=VK_STRUCTURE_TYPE_QUERY_POOL_PERFORMANCE_CREATE_INFO_KHR;pcq.queueFamilyIndex=0;pcq.counterIndexCount=5;pcq.pCounterIndices=indices;
    auto passCount=reinterpret_cast<PFN_vkGetPhysicalDeviceQueueFamilyPerformanceQueryPassesKHR>(vkGetInstanceProcAddr(instance,"vkGetPhysicalDeviceQueueFamilyPerformanceQueryPassesKHR"));require(passCount,"pass query");uint32_t passes=0;passCount(physical,&pcq,&passes);require(passes>0&&passes<=8,"pass count");
    VkQueryPoolCreateInfo qc{};qc.sType=VK_STRUCTURE_TYPE_QUERY_POOL_CREATE_INFO;qc.pNext=&pcq;qc.queryType=VK_QUERY_TYPE_PERFORMANCE_QUERY_KHR;qc.queryCount=1;
    VkQueryPool queries{};ok(vkCreateQueryPool(device,&qc,nullptr,&queries),"performance query pool");
    auto acquire=reinterpret_cast<PFN_vkAcquireProfilingLockKHR>(vkGetDeviceProcAddr(device,"vkAcquireProfilingLockKHR"));auto release=reinterpret_cast<PFN_vkReleaseProfilingLockKHR>(vkGetDeviceProcAddr(device,"vkReleaseProfilingLockKHR"));require(acquire&&release,"profiling lock entrypoints");
    VkAcquireProfilingLockInfoKHR li{};li.sType=VK_STRUCTURE_TYPE_ACQUIRE_PROFILING_LOCK_INFO_KHR;li.timeout=3000000000ULL;ok(acquire(device,&li),"profiling lock");std::printf("stage lock %.3f s\n",elapsed());std::fflush(stdout);
    VkCommandPoolCreateInfo pci{};pci.sType=VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO;pci.queueFamilyIndex=0;pci.flags=VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;VkCommandPool commands{};ok(vkCreateCommandPool(device,&pci,nullptr,&commands),"command pool");
    VkCommandBufferAllocateInfo cba{};cba.sType=VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;cba.commandPool=commands;cba.level=VK_COMMAND_BUFFER_LEVEL_PRIMARY;cba.commandBufferCount=1;VkCommandBuffer cb{};ok(vkAllocateCommandBuffers(device,&cba,&cb),"command buffer");
    VkCommandBuffer reset{};ok(vkAllocateCommandBuffers(device,&cba,&reset),"reset buffer");
    VkCommandBufferBeginInfo resetBegin{};resetBegin.sType=VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;resetBegin.flags=VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    ok(vkBeginCommandBuffer(reset,&resetBegin),"begin reset");vkCmdResetQueryPool(reset,queries,0,1);ok(vkEndCommandBuffer(reset),"end reset");
    VkSubmitInfo resetSubmit{};resetSubmit.sType=VK_STRUCTURE_TYPE_SUBMIT_INFO;resetSubmit.commandBufferCount=1;resetSubmit.pCommandBuffers=&reset;
    ok(vkQueueSubmit(queue,1,&resetSubmit,VK_NULL_HANDLE),"submit reset");ok(vkQueueWaitIdle(queue),"wait reset");
    VkCommandBufferBeginInfo begin{};begin.sType=VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;begin.flags=VK_COMMAND_BUFFER_USAGE_SIMULTANEOUS_USE_BIT;ok(vkBeginCommandBuffer(cb,&begin),"begin");
    const bool empty=std::getenv("TP5_EMPTY_QUERY")!=nullptr;
    VkBufferCopy copyA{0,0,weightBytes},copyB{0,0,activationBytes},copyOut{0,0,outputBytes};
    VkCommandBuffer prep{};ok(vkAllocateCommandBuffers(device,&cba,&prep),"prep buffer");ok(vkBeginCommandBuffer(prep,&resetBegin),"begin prep");
    vkCmdCopyBuffer(prep,stagingA.b,weights.b,1,&copyA);vkCmdCopyBuffer(prep,stagingB.b,activ.b,1,&copyB);vkCmdFillBuffer(prep,output.b,0,outputBytes,0);
    VkBufferMemoryBarrier prior[2]{};for(int j=0;j<2;++j){prior[j].sType=VK_STRUCTURE_TYPE_BUFFER_MEMORY_BARRIER;prior[j].srcAccessMask=VK_ACCESS_TRANSFER_WRITE_BIT;prior[j].dstAccessMask=VK_ACCESS_SHADER_READ_BIT;prior[j].srcQueueFamilyIndex=VK_QUEUE_FAMILY_IGNORED;prior[j].dstQueueFamilyIndex=VK_QUEUE_FAMILY_IGNORED;prior[j].buffer=j?activ.b:weights.b;prior[j].size=j?activationBytes:weightBytes;}
    vkCmdPipelineBarrier(prep,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,0,0,nullptr,2,prior,0,nullptr);
    ok(vkEndCommandBuffer(prep),"end prep");VkSubmitInfo prepSubmit{};prepSubmit.sType=VK_STRUCTURE_TYPE_SUBMIT_INFO;prepSubmit.commandBufferCount=1;prepSubmit.pCommandBuffers=&prep;
    ok(vkQueueSubmit(queue,1,&prepSubmit,VK_NULL_HANDLE),"submit prep");ok(vkQueueWaitIdle(queue),"wait prep");
    const bool warm=std::getenv("TP5_WARMUP")!=nullptr;
    if(warm&&!empty){VkCommandBuffer warmCB{};ok(vkAllocateCommandBuffers(device,&cba,&warmCB),"warmup buffer");ok(vkBeginCommandBuffer(warmCB,&resetBegin),"begin warmup");
        vkCmdBindPipeline(warmCB,VK_PIPELINE_BIND_POINT_COMPUTE,pipeline);vkCmdBindDescriptorSets(warmCB,VK_PIPELINE_BIND_POINT_COMPUTE,layout,0,1,&set,0,nullptr);
        vkCmdPushConstants(warmCB,layout,VK_SHADER_STAGE_COMPUTE_BIT,0,sizeof(pc),&pc);vkCmdDispatch(warmCB,m/rowTile,1,1);ok(vkEndCommandBuffer(warmCB),"end warmup");
        VkSubmitInfo warmSubmit{};warmSubmit.sType=VK_STRUCTURE_TYPE_SUBMIT_INFO;warmSubmit.commandBufferCount=1;warmSubmit.pCommandBuffers=&warmCB;
        ok(vkQueueSubmit(queue,1,&warmSubmit,VK_NULL_HANDLE),"submit warmup");ok(vkQueueWaitIdle(queue),"wait warmup");}
    vkCmdBindPipeline(cb,VK_PIPELINE_BIND_POINT_COMPUTE,pipeline);vkCmdBindDescriptorSets(cb,VK_PIPELINE_BIND_POINT_COMPUTE,layout,0,1,&set,0,nullptr);vkCmdPushConstants(cb,layout,VK_SHADER_STAGE_COMPUTE_BIT,0,sizeof(pc),&pc);
    vkCmdBeginQuery(cb,queries,0,0);if(!empty)vkCmdDispatch(cb,m/rowTile,1,1);vkCmdEndQuery(cb,queries,0);
    ok(vkEndCommandBuffer(cb),"end");
    for(uint32_t i=0;i<passes;++i){VkPerformanceQuerySubmitInfoKHR ps{};ps.sType=VK_STRUCTURE_TYPE_PERFORMANCE_QUERY_SUBMIT_INFO_KHR;ps.counterPassIndex=i;
        VkSubmitInfo si2{};si2.sType=VK_STRUCTURE_TYPE_SUBMIT_INFO;si2.pNext=&ps;si2.commandBufferCount=1;si2.pCommandBuffers=&cb;ok(vkQueueSubmit(queue,1,&si2,VK_NULL_HANDLE),"submit");ok(vkQueueWaitIdle(queue),"wait");std::printf("stage pass%u %.3f s\n",i,elapsed());std::fflush(stdout);}
    VkCommandBuffer readCB{};ok(vkAllocateCommandBuffers(device,&cba,&readCB),"readback buffer");ok(vkBeginCommandBuffer(readCB,&resetBegin),"begin readback");
    VkBufferMemoryBarrier after{};after.sType=VK_STRUCTURE_TYPE_BUFFER_MEMORY_BARRIER;after.srcAccessMask=empty?VK_ACCESS_TRANSFER_WRITE_BIT:VK_ACCESS_SHADER_WRITE_BIT;after.dstAccessMask=VK_ACCESS_TRANSFER_READ_BIT;after.srcQueueFamilyIndex=VK_QUEUE_FAMILY_IGNORED;after.dstQueueFamilyIndex=VK_QUEUE_FAMILY_IGNORED;after.buffer=output.b;after.size=outputBytes;
    vkCmdPipelineBarrier(readCB,empty?VK_PIPELINE_STAGE_TRANSFER_BIT:VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,0,0,nullptr,1,&after,0,nullptr);vkCmdCopyBuffer(readCB,output.b,readback.b,1,&copyOut);
    ok(vkEndCommandBuffer(readCB),"end readback");VkSubmitInfo readSubmit{};readSubmit.sType=VK_STRUCTURE_TYPE_SUBMIT_INFO;readSubmit.commandBufferCount=1;readSubmit.pCommandBuffers=&readCB;
    ok(vkQueueSubmit(queue,1,&readSubmit,VK_NULL_HANDLE),"submit readback");ok(vkQueueWaitIdle(queue),"wait readback");
    release(device);
    std::array<VkPerformanceCounterResultKHR,5> results{};ok(vkGetQueryPoolResults(device,queries,0,1,sizeof(results),results.data(),sizeof(results),VK_QUERY_RESULT_WAIT_BIT),"counter results");std::printf("stage results %.3f s\n",elapsed());std::fflush(stdout);
    const char*names[]{"waves","VMEM loads","VRAM read bytes","L1 hit ratio","L2 hit ratio"};
    for(unsigned i=0;i<5;++i)std::printf("counter %s %.3f\n",names[i],results[i].float64);
    ok(vkMapMemory(device,readback.mem,0,outputBytes,0,&mapped),"readback");auto *vals=static_cast<float*>(mapped);
    const float expected=empty?0.0f:-15.0f*float(k);
    for(uint32_t i=0;i<m*n;++i)if(vals[i]!=expected){std::fprintf(stderr,"incorrect %u/%u got %.8g want %.8g\n",i,m*n,vals[i],expected);std::exit(1);}
    std::printf("PASS width=%u rows=%u tokens=%u rowTile=%u output=%g passes=%u empty=%u warm=%u\n",k,m,n,rowTile,vals[0],passes,empty,warm);vkUnmapMemory(device,readback.mem);
    vkDestroyCommandPool(device,commands,nullptr);vkDestroyQueryPool(device,queries,nullptr);vkDestroyPipeline(device,pipeline,nullptr);vkDestroyPipelineLayout(device,layout,nullptr);vkDestroyShaderModule(device,module,nullptr);
    vkDestroyDescriptorPool(device,pool,nullptr);vkDestroyDescriptorSetLayout(device,dsl,nullptr);
    clear(weights);clear(activ);clear(output);clear(stagingA);clear(stagingB);clear(readback);
    vkDestroyDevice(device,nullptr);vkDestroyInstance(instance,nullptr);
}
