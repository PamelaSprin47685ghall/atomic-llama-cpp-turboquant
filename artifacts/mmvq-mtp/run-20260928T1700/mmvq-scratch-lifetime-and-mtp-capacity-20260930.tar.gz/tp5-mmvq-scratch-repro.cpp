#include "ggml.h"
#include "ggml-backend.h"
#include "ggml-cpu.h"
#include "ggml-vulkan.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <vector>
static void check(bool v, const char *where) { if (!v) { std::fprintf(stderr, "FAIL %s\n", where); std::exit(2); } }
int main(int argc, char **argv) {
    const bool attention = argc == 2 && std::strcmp(argv[1], "fa") == 0;
    if (argc > 2 || (argc == 2 && !attention)) return 2;
    constexpr int k = 320, m = 128, softmax_width = k * m;
    constexpr int kv_length = 8192;
    auto * gpu = ggml_backend_vk_init(0); check(gpu, "GPU");
    auto * cpu = ggml_backend_cpu_init(); check(cpu, "CPU");
    auto * wc = ggml_init({1024 * 1024, nullptr, true}); check(wc, "weight context");
    auto * w = ggml_new_tensor_2d(wc, GGML_TYPE_Q8_0, k, m);
    auto * keys = attention ? ggml_new_tensor_4d(wc, GGML_TYPE_F16, m, kv_length, 1, 1) : nullptr;
    auto * values = attention ? ggml_new_tensor_4d(wc, GGML_TYPE_F16, m, kv_length, 1, 1) : nullptr;
    auto * mask = attention ? ggml_new_tensor_2d(wc, GGML_TYPE_F16, kv_length, k) : nullptr;
    auto * wb = ggml_backend_alloc_ctx_tensors(wc, gpu); check(wb, "weight buffer");
    ggml_backend_buffer_set_usage(wb, GGML_BACKEND_BUFFER_USAGE_WEIGHTS);
    std::vector<float> weights(k * m);
    for (int row = 0; row < m; ++row) for (int col = 0; col < k; ++col) {
        const int q = col % 32 == 0 ? 127 : ((row * 17 + col * 31) % 253) - 126;
        weights[row * k + col] = std::ldexp(float(q), -5 - row % 3);
    }
    std::vector<unsigned char> packed(ggml_nbytes(w));
    check(ggml_quantize_chunk(w->type, weights.data(), packed.data(), 0, m, k, nullptr) == packed.size(), "quantization");
    ggml_backend_tensor_set(w, packed.data(), 0, packed.size());
    if (attention) {
        std::vector<ggml_fp16_t> key_data(ggml_nelements(keys), ggml_fp32_to_fp16(0.0f));
        std::vector<ggml_fp16_t> value_data(ggml_nelements(values));
        std::vector<ggml_fp16_t> mask_data(ggml_nelements(mask), ggml_fp32_to_fp16(0.0f));
        for (size_t i = 0; i < value_data.size(); ++i) value_data[i] = ggml_fp32_to_fp16(float(int(i % m) % 31 - 15) / 256.0f);
        ggml_backend_tensor_set(keys, key_data.data(), 0, key_data.size() * sizeof(ggml_fp16_t));
        ggml_backend_tensor_set(values, value_data.data(), 0, value_data.size() * sizeof(ggml_fp16_t));
        ggml_backend_tensor_set(mask, mask_data.data(), 0, mask_data.size() * sizeof(ggml_fp16_t));
    }
    auto * gc = ggml_init({1024 * 1024, nullptr, true}); check(gc, "graph context");
    auto * x = ggml_new_tensor_1d(gc, GGML_TYPE_F32, k); ggml_set_input(x);
    auto * first = ggml_mul_mat(gc, w, x); ggml_set_output(first);
    auto * repeated = ggml_repeat(gc, first, ggml_new_tensor_1d(gc, GGML_TYPE_F32, softmax_width));
    auto * probabilities = attention ?
        ggml_flash_attn_ext(gc, ggml_reshape_4d(gc, repeated, m, k, 1, 1), keys, values, mask,
                            1.0f / std::sqrt(float(m)), 0.0f, 0.0f) : ggml_soft_max(gc, repeated);
    if (attention) ggml_flash_attn_ext_set_prec(probabilities, GGML_PREC_F32);
    ggml_set_output(probabilities);
    auto * produced_weights = ggml_cast(gc, ggml_reshape_2d(gc, probabilities, k, m), GGML_TYPE_Q8_0);
    ggml_set_output(produced_weights);
    auto * last = ggml_mul_mat(gc, produced_weights, x); ggml_set_output(last);
    check(ggml_backend_supports_op(gpu, first) && ggml_backend_supports_op(gpu, repeated) &&
          ggml_backend_supports_op(gpu, probabilities) && ggml_backend_supports_op(gpu, produced_weights) &&
          ggml_backend_supports_op(gpu, last), "GPU supports all operations");
    auto * g = ggml_new_graph_custom(gc, 32, false);
    ggml_build_forward_expand(g, first);
    ggml_build_forward_expand(g, probabilities);
    ggml_build_forward_expand(g, last);
    ggml_backend_t backends[] = {gpu, cpu};
    auto * sched = ggml_backend_sched_new(backends, nullptr, 2, 64, false, true); check(sched, "scheduler");
    ggml_backend_sched_set_tensor_backend(sched, x, gpu);
    for (auto * node : {first, repeated, probabilities, produced_weights, last}) ggml_backend_sched_set_tensor_backend(sched, node, gpu);
    check(ggml_backend_sched_alloc_graph(sched, g), "allocation");
    for (auto * node : {first, repeated, probabilities, produced_weights, last}) {
        auto * assigned = ggml_backend_sched_get_tensor_backend(sched, node);
        std::printf("ASSIGNED op=%s backend=%s\n", ggml_op_name(node->op), assigned ? ggml_backend_name(assigned) : "null");
        check(assigned == gpu, "one GPU graph, no CPU scratch fallback");
    }
    using stats_fn = void (*)(ggml_backend_t, uint64_t *, uint64_t *, uint64_t *, uint64_t *);
    const auto stats = reinterpret_cast<stats_fn>(ggml_backend_reg_get_proc_address(ggml_backend_vk_reg(), "ggml_backend_vk_get_replay_stats"));
    check(stats, "stats API");
    uint64_t hits0 = 0, misses0 = 0; stats(gpu, &hits0, &misses0, nullptr, nullptr);
    bool valid = true;
    for (int run = 0; run < 3; ++run) {
        std::vector<float> input(k), expected(m), expected_last(m), before(m), after(m), probs(softmax_width);
        for (int col = 0; col < k; ++col) {
            const int q = col % 32 == 0 ? 127 : ((col * 13 + run * 19) % 253) - 126;
            input[col] = std::ldexp(float(q), -4 - run);
        }
        for (int row = 0; row < m; ++row) {
            double sum = 0;
            for (int col = 0; col < k; ++col) sum += double(weights[row * k + col]) * input[col];
            expected[row] = float(sum);
        }
        ggml_backend_tensor_set(x, input.data(), 0, input.size() * sizeof(float));
        check(ggml_backend_sched_graph_compute(sched, g) == GGML_STATUS_SUCCESS, "compute");
        ggml_backend_tensor_get(first, before.data(), 0, before.size() * sizeof(float));
        ggml_backend_tensor_get(last, after.data(), 0, after.size() * sizeof(float));
        ggml_backend_tensor_get(probabilities, probs.data(), 0, probs.size() * sizeof(float));
        std::vector<unsigned char> actual_weights(ggml_nbytes(produced_weights));
        ggml_backend_tensor_get(produced_weights, actual_weights.data(), 0, actual_weights.size());
        std::vector<float> dequantized_weights(k * m);
        ggml_get_type_traits(produced_weights->type)->to_float(actual_weights.data(), dequantized_weights.data(), k * m);
        for (int row = 0; row < m; ++row) {
            double sum = 0;
            for (int col = 0; col < k; ++col) sum += double(dequantized_weights[row * k + col]) * input[col];
            expected_last[row] = float(sum);
        }
        double prob_sum = 0; for (float p : probs) { check(std::isfinite(p) && (attention || p >= 0), "finite intermediate"); prob_sum += p; }
        if (attention) {
            for (size_t i = 0; i < probs.size(); ++i) check(std::abs(probs[i] - float(int(i % m) % 31 - 15) / 256.0f) < 1e-5f, "independent constant-value attention oracle");
        } else check(std::abs(prob_sum - 1.0) < 1e-4, "normalized softmax");
        size_t failures = 0; float max_error = 0;
        for (int row = 0; row < m; ++row) {
            check(std::isfinite(before[row]) && std::abs(before[row] - expected[row]) <= 1e-5f, "first independent CPU oracle");
            if (!std::isfinite(after[row]) || std::abs(after[row] - expected_last[row]) > 1e-5f) {
                if (failures == 0) std::printf("MISMATCH run=%d row=%d expected=%.9g first=%.9g after=%.9g\n", run, row, expected_last[row], before[row], after[row]);
                ++failures;
            }
            if (std::isfinite(after[row])) max_error = std::max(max_error, std::abs(after[row] - expected_last[row]));
        }
        std::printf("run=%d first_cpu_rows=%d last_mismatch_rows=%zu max_last_error=%.9g normalized_softmax=%.12g\n", run, m, failures, max_error, prob_sum);
        valid = valid && failures == 0;
    }
    uint64_t hits = 0, misses = 0; stats(gpu, &hits, &misses, nullptr, nullptr);
    std::printf("%s MMVQ/%s/same-input-MMVQ replay_hits=%llu replay_misses=%llu\n", valid ? "PASS" : "FAIL", attention ? "FA-mask" : "large-softmax", (unsigned long long)(hits - hits0), (unsigned long long)(misses - misses0));
    ggml_backend_sched_free(sched); ggml_free(gc); ggml_backend_buffer_free(wb); ggml_free(wc); ggml_backend_free(cpu); ggml_backend_free(gpu);
    return valid ? 0 : 1;
}
