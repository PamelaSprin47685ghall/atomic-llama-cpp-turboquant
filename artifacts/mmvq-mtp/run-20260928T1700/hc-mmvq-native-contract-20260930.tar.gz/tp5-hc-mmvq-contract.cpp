#include "ggml.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <vector>
int main(int argc, char **argv) {
    if (argc > 2) return 2;
    const int prefix = argc == 2 ? std::atoi(argv[1]) : 0;
    if (prefix < 0) return 2;
    constexpr int k = 10240;
    std::vector<float> x(k), quantized(k);
    std::array<double, 4> exact{}, approximate{}, bound{};
    for (int i = 0; i < k; ++i) x[i] = std::sin(float((i + prefix) * 7)) * 3.0f;
    x[0] = 0.0f;
    for (int block = 0; block < k / 32; ++block) {
        float amax = 0.0f;
        for (int j = 0; j < 32; ++j) amax = std::max(amax, std::abs(x[block * 32 + j]));
        const float d = amax / 127.0f;
        const float inverse = d == 0.0f ? 0.0f : 1.0f / d;
        const float stored = ggml_fp16_to_fp32(ggml_fp32_to_fp16(d));
        for (int j = 0; j < 32; ++j) {
            const int col = block * 32 + j;
            const float qx = std::round(x[col] * inverse);
            quantized[col] = stored * qx;
            for (int row = 0; row < 4; ++row) {
                const float dw = std::ldexp(1.0f, -12 - ((block + row) % 4));
                const int qw = j == 0 ? 127 : ((col * 31 + row * 17) % 253) - 126;
                const float weight = qw * dw;
                exact[row] += double(weight) * x[col];
                approximate[row] += double(weight) * quantized[col];
                bound[row] += std::abs(double(weight)) * (double(d) * 0.5 + 127.0 * std::abs(double(stored) - d) + 4.0 * std::ldexp(double(amax), -23));
            }
        }
    }
    bool distinguishes = false;
    for (int row = 0; row < 4; ++row) {
        const double native = 1000.0 + 5.0 / (1.0 + std::exp(-exact[row] * 0.25));
        const double mmvq = 1000.0 + 5.0 / (1.0 + std::exp(-approximate[row] * 0.25));
        const double diff = std::abs(native - mmvq);
        const double raw_diff = std::abs(exact[row] - approximate[row]);
        if (raw_diff > bound[row]) return 1;
        distinguishes = distinguishes || diff > 0.000100;
        std::printf("prefix=%d row=%d exact_inject=%.12f quantized_inject=%.12f raw_abs_diff=%.12f error_bound=%.12f native_scatter=%.12f mmvq_scatter=%.12f scatter_abs_diff=%.12f\n", prefix, row, exact[row], approximate[row], raw_diff, bound[row], native, mmvq, diff);
    }
    if (!distinguishes) return 1;
    std::puts("PASS independent double-precision source-contract oracle: Q8_1 requantization exceeds native-scatter tolerance; no GPU dispatch or timing");
}
