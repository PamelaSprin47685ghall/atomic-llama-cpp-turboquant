#include "ggml.h"
#include "ggml-backend.h"
#include "ggml-cpu.h"
#include "ggml-vulkan.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
static void check(bool v, const char *where) {
    if (!v) { std::fprintf(stderr, "FAIL %s\n", where); std::exit(1); }
}
using replay_stats = void (*)(ggml_backend_t, uint64_t *, uint64_t *, uint64_t *, uint64_t *);
int main(int argc, char **argv) {
    check(argc == 8, "usage: graph K M N layout view reference.bin output.bin");
    const int k = std::atoi(argv[1]), m = std::atoi(argv[2]), n = std::atoi(argv[3]);
    const int layout = std::atoi(argv[4]);
    const bool view = std::atoi(argv[5]) != 0;
    check(k > 0 && k % 32 == 0 && m > 0 && n == 2 && layout >= 0 && layout <= 2, "dimensions");
    auto *gpu = ggml_backend_vk_init(0); check(gpu, "Vulkan device");
    auto *cpu = ggml_backend_cpu_init(); check(cpu, "CPU device");
    const auto stats = reinterpret_cast<replay_stats>(ggml_backend_reg_get_proc_address(ggml_backend_vk_reg(), "ggml_backend_vk_get_replay_stats"));
    check(stats, "replay stats API");
    auto *wc = ggml_init({1024 * 1024, nullptr, true}); check(wc, "weight context");
    auto *parent = ggml_new_tensor_2d(wc, GGML_TYPE_Q8_0, k, m + (view ? 1 : 0));
    auto *wb = ggml_backend_alloc_ctx_tensors(wc, gpu); check(wb, "weight buffer");
    std::vector<float> wf(size_t(k) * parent->ne[1]);
    for (size_t i = 0; i < wf.size(); ++i) {
        const int row = i / k, col = i % k;
        wf[i] = row % 37 == 0 ? 0.0f : std::ldexp(float(int((i * 17 + row * 53) % 509) - 254) * 0.0012f, (row + col / 32) % 9 - 4);
    }
    std::vector<unsigned char> qw(ggml_nbytes(parent));
    check(ggml_quantize_chunk(GGML_TYPE_Q8_0, wf.data(), qw.data(), 0, parent->ne[1], k, nullptr) == qw.size(), "quantization");
    ggml_backend_tensor_set(parent, qw.data(), 0, qw.size());
    auto *gc = ggml_init({1024 * 1024, nullptr, true}); check(gc, "graph context");
    auto *w = view ? ggml_view_2d(gc, parent, k, m, parent->nb[1], parent->nb[1]) : parent;
    auto *xp = ggml_new_tensor_2d(gc, GGML_TYPE_F32, k, n + (view ? 1 : 0)); ggml_set_input(xp);
    ggml_tensor *x;
    if (layout == 0) {
        x = view ? ggml_view_2d(gc, xp, k, n, xp->nb[1], xp->nb[1]) : xp;
    } else {
        const int64_t ne2 = layout == 1 ? n : 1;
        const int64_t ne3 = layout == 2 ? n : 1;
        x = ggml_view_4d(gc, xp, k, 1, ne2, ne3, size_t(k) * sizeof(float), size_t(k) * sizeof(float), size_t(k) * ne2 * sizeof(float), view ? xp->nb[1] : 0);
    }
    auto *y = ggml_mul_mat(gc, w, x); ggml_set_output(y);
    check(ggml_backend_supports_op(gpu, y), "Vulkan supports requested layout");
    auto *g = ggml_new_graph_custom(gc, 16, false); ggml_build_forward_expand(g, y);
    ggml_backend_t backends[] = {gpu, cpu};
    auto *sched = ggml_backend_sched_new(backends, nullptr, 2, 32, false, true); check(sched, "scheduler");
    ggml_backend_sched_set_tensor_backend(sched, xp, gpu);
    check(ggml_backend_sched_alloc_graph(sched, g), "graph allocation");
    auto *reference = std::fopen(argv[6], "rb"); check(reference, "reference file");
    auto *output = std::fopen(argv[7], "wb"); check(output, "output file");
    uint64_t hits0 = 0, misses0 = 0; stats(gpu, &hits0, &misses0, nullptr, nullptr);
    for (int run = 0; run < 3; ++run) {
        std::vector<float> input(size_t(k) * xp->ne[1]);
        for (size_t i = 0; i < input.size(); ++i) input[i] = std::ldexp(std::sin(float((i * 11 + run * 101) % 251) * 0.071f), int((i / 32 + run) % 7) - 3);
        ggml_backend_tensor_set(xp, input.data(), 0, input.size() * sizeof(float));
        check(ggml_backend_sched_graph_compute(sched, g) == GGML_STATUS_SUCCESS, "compute");
        std::vector<float> out(size_t(m) * n), expected(out.size());
        ggml_backend_tensor_get(y, out.data(), 0, out.size() * sizeof(float));
        check(std::fread(expected.data(), sizeof(float), expected.size(), reference) == expected.size(), "reference read");
        for (float v : out) check(std::isfinite(v), "finite output");
        check(std::memcmp(out.data(), expected.data(), out.size() * sizeof(float)) == 0, "bitwise reference equality");
        check(std::fwrite(out.data(), sizeof(float), out.size(), output) == out.size(), "output write");
    }
    check(std::fgetc(reference) == EOF, "exact reference length");
    check(std::fclose(reference) == 0 && std::fclose(output) == 0, "file close");
    uint64_t hits = 0, misses = 0; stats(gpu, &hits, &misses, nullptr, nullptr);
    check(hits - hits0 >= 2, "two actual command replay hits");
    std::printf("PASS Q8 K=%d M=%d N=%d layout=%d view=%d runs=3 bytes=%zu replay_hits=%llu replay_misses=%llu\n", k, m, n, layout, int(view), size_t(m) * n * sizeof(float) * 3, (unsigned long long)(hits - hits0), (unsigned long long)(misses - misses0));
    ggml_backend_sched_free(sched); ggml_free(gc); ggml_backend_buffer_free(wb); ggml_free(wc); ggml_backend_free(cpu); ggml_backend_free(gpu);
}
