#include "ggml.h"
#include "ggml-backend.h"
#include "ggml-cpu.h"
#include "ggml-vulkan.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
static void require(bool ok, const char * message) {
    if (!ok) { std::fprintf(stderr, "FAIL %s\n", message); std::exit(2); }
}
int main() {
    constexpr int k = 320;
    auto * gpu = ggml_backend_vk_init(0);
    auto * cpu = ggml_backend_cpu_init();
    require(gpu && cpu, "backends");
    auto * wc = ggml_init({1024 * 1024, nullptr, true});
    require(wc, "weight context");
    auto * weight = ggml_new_tensor_2d(wc, GGML_TYPE_Q8_0, k, 1);
    auto * wb = ggml_backend_alloc_ctx_tensors(wc, gpu);
    require(wb, "weights allocation");
    ggml_backend_buffer_set_usage(wb, GGML_BACKEND_BUFFER_USAGE_WEIGHTS);
    require(ggml_type_size(GGML_TYPE_Q8_0) == 34, "Q8_0 block contract");
    std::vector<unsigned char> packed(ggml_nbytes(weight), 0);
    const ggml_fp16_t one = ggml_fp32_to_fp16(1.0f);
    for (int b = 0; b < k / 32; ++b) std::memcpy(packed.data() + 34 * b, &one, sizeof(one));
    packed[2] = 1; // Exact first-coordinate projection, without a rounded 1/127 scale.
    ggml_backend_tensor_set(weight, packed.data(), 0, packed.size());
    auto * ctx = ggml_init({1024 * 1024, nullptr, true});
    require(ctx, "graph context");
    auto * input = ggml_new_tensor_1d(ctx, GGML_TYPE_F32, k);
    ggml_set_input(input);
    auto * first = ggml_mul_mat(ctx, weight, input);
    ggml_set_output(first);
    auto * factors = ggml_repeat(ctx, first, input);
    auto * mutated = ggml_mul_inplace(ctx, input, factors);
    ggml_set_output(mutated);
    auto * produced_weight = ggml_cast(ctx, ggml_reshape_2d(ctx, mutated, k, 1), GGML_TYPE_Q8_0);
    ggml_set_output(produced_weight);
    // The produced weight forces the final matmul after the original storage has changed.
    auto * last = ggml_mul_mat(ctx, produced_weight, input);
    ggml_set_output(last);
    auto * transparent_after = ggml_view_1d(ctx, mutated, k, 0);
    require(mutated->view_src == input && transparent_after->view_src == input, "storage roots flattened");
    require(transparent_after->src[0] == mutated && mutated->op == GGML_OP_MUL, "producer boundary retained");
    auto * graph = ggml_new_graph_custom(ctx, 32, false);
    ggml_build_forward_expand(graph, first);
    ggml_build_forward_expand(graph, last);
    ggml_backend_t backends[] = {gpu, cpu};
    auto * sched = ggml_backend_sched_new(backends, nullptr, 2, 64, false, true);
    require(sched, "scheduler");
    ggml_backend_sched_set_tensor_backend(sched, input, gpu);
    for (auto * node : {first, factors, mutated, produced_weight, last}) {
        require(ggml_backend_supports_op(gpu, node), "GPU support");
        ggml_backend_sched_set_tensor_backend(sched, node, gpu);
    }
    require(ggml_backend_sched_alloc_graph(sched, graph), "graph allocation");
    for (auto * node : {first, factors, mutated, produced_weight, last}) {
        require(ggml_backend_sched_get_tensor_backend(sched, node) == gpu, "no CPU fallback");
    }
    using stats_fn = void (*)(ggml_backend_t, uint64_t *, uint64_t *, uint64_t *, uint64_t *);
    auto stats = reinterpret_cast<stats_fn>(ggml_backend_reg_get_proc_address(ggml_backend_vk_reg(), "ggml_backend_vk_get_replay_stats"));
    require(stats, "replay API");
    uint64_t hits0 = 0, misses0 = 0;
    stats(gpu, &hits0, &misses0, nullptr, nullptr);
    bool valid = true;
    for (int round = 0; round < 3; ++round) {
        std::vector<float> values(k), actual_input(k), actual_weights(k);
        for (int col = 0; col < k; ++col) values[col] = col % 32 == 31 ? 127.0f : float((col + round) % 7 - 3);
        values[0] = float(2 + round);
        const double factor = values[0];
        double expected = 0;
        for (float v : values) expected += factor * factor * v * v;
        ggml_backend_tensor_set(input, values.data(), 0, values.size() * sizeof(float));
        require(ggml_backend_sched_graph_compute(sched, graph) == GGML_STATUS_SUCCESS, "compute");
        float actual_first = 0, actual_last = 0;
        ggml_backend_tensor_get(first, &actual_first, 0, sizeof(float));
        ggml_backend_tensor_get(last, &actual_last, 0, sizeof(float));
        ggml_backend_tensor_get(mutated, actual_input.data(), 0, actual_input.size() * sizeof(float));
        std::vector<unsigned char> produced_bytes(ggml_nbytes(produced_weight));
        ggml_backend_tensor_get(produced_weight, produced_bytes.data(), 0, produced_bytes.size());
        ggml_get_type_traits(produced_weight->type)->to_float(produced_bytes.data(), actual_weights.data(), k);
        require(actual_first == factor, "first exact CPU oracle");
        for (int col = 0; col < k; ++col) {
            require(actual_input[col] == factor * values[col], "in-place mutation exact oracle");
            require(actual_weights[col] == factor * values[col], "produced weight exact oracle");
        }
        const bool equal = std::isfinite(actual_last) && double(actual_last) == expected;
        std::printf("round=%d factor=%.0f expected=%.0f actual=%.0f equal=%d\n", round, factor, expected, actual_last, equal);
        valid = valid && equal;
    }
    uint64_t hits1 = 0, misses1 = 0;
    stats(gpu, &hits1, &misses1, nullptr, nullptr);
    require(hits1 >= hits0 + 2, "two real replay hits");
    std::printf("%s input-mutation CPU oracle, replay_hits=%llu replay_misses=%llu\n", valid ? "PASS" : "FAIL", (unsigned long long)(hits1 - hits0), (unsigned long long)(misses1 - misses0));
    ggml_backend_sched_free(sched);
    ggml_free(ctx);
    ggml_backend_buffer_free(wb);
    ggml_free(wc);
    ggml_backend_free(cpu);
    ggml_backend_free(gpu);
    return valid ? 0 : 1;
}
