import json

REQUEST = 128
results = []
for k, m, tiles in ((320, 10240, (2, 4, 8, 16, 32, 64)), (10240, 320, (1, 2, 4))):
    row_bytes = k // 32 * 34
    tensor_bytes = row_bytes * m
    cases = []
    for rows in tiles:
        assert m % rows == 0
        groups = m // rows
        summaries = []
        for offset in range(REQUEST):
            unique_lines = (offset + tensor_bytes + REQUEST - 1) // REQUEST
            group_lines = 0
            starts = []
            ends = []
            for group in range(groups):
                start = offset + group * rows * row_bytes
                end = start + rows * row_bytes
                first = start // REQUEST
                last = (end - 1) // REQUEST
                group_lines += last - first + 1
                starts.append(first)
                ends.append(last)
            # Adjacent byte spans intersect at most one aligned request.
            overlap = sum(a == b for a, b in zip(ends[:-1], starts[1:]))
            assert group_lines - overlap == unique_lines
            assert group_lines >= unique_lines
            if offset == 0 and rows * row_bytes % REQUEST == 0:
                assert group_lines == unique_lines
            summaries.append({
                "offset_mod_128": offset,
                "unique_source_lines": unique_lines,
                "summed_per_group_lines": group_lines,
                "boundary_overlap_lines": overlap,
                "summed_per_group_covered_bytes": group_lines * REQUEST,
            })
        cases.append({
            "rows": rows,
            "groups": groups,
            "offsets_verified": REQUEST,
            "aligned": summaries[0],
            "offset_32": summaries[32],
            "best_boundary_overlap_lines": min(s["boundary_overlap_lines"] for s in summaries),
            "worst_boundary_overlap_lines": max(s["boundary_overlap_lines"] for s in summaries),
        })
    results.append({"K": k, "M": m, "row_bytes": row_bytes, "tensor_source_bytes": tensor_bytes, "tiles": cases})
print(json.dumps({
    "request_bytes": REQUEST,
    "scope": "Address-cover geometry, not observed hardware requests, cache misses, VRAM traffic or throughput",
    "assumptions": "Existing contiguous Q8_0 layout; arbitrary offset modulo 128; ideal intra-group reuse only for interpretation of summed spans",
    "proof": results,
    "gpu_dispatches": 0,
    "performance_queries": 0,
}, indent=2))
