#include "ggml-vulkan-tp5-relay-tiles.h"

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <vector>

// Cancellation detects any tree/rank reorder; odd extents detect overlapping
// tiles, dropped tails and writes outside active rows. Reusing the dispatcher
// with changed sources detects stale generation or premature completion.
int main() {
    constexpr size_t capacity = 10243;
    for (size_t tiles : {2u, 4u}) {
        vk_tp5_relay_tiles pool(tiles);
        std::array<std::vector<float>, 5> src, dst;
        std::array<const void *, 5> ranks;
        std::array<float *, 5> outputs;
        std::array<size_t, 5> prefix{};
        for (size_t r = 0; r < 5; ++r) {
            src[r].resize(capacity + 32);
            dst[r].resize(capacity + 32);
            ranks[r] = src[r].data() + 1; // deliberately unaligned inputs
        }
        for (size_t offset : {0u, 1u, 8u}) {
            for (size_t r = 0; r < 5; ++r) {
                const uintptr_t aligned = (reinterpret_cast<uintptr_t>(dst[r].data()) + 31u) & ~uintptr_t(31u);
                outputs[r] = reinterpret_cast<float *>(aligned) + offset;
                prefix[r] = size_t(outputs[r] - dst[r].data());
            }
            for (size_t n : {1u, 7u, 8u, 15u, 16u, 17u, 31u, 63u, 64u, 65u, 2560u, 5120u, 10243u}) {
                for (unsigned epoch = 0; epoch < 8; ++epoch) {
                    for (auto & d : dst) std::fill(d.begin(), d.end(), -12345.0f);
                    for (size_t i = 0; i < n; ++i) {
                        const float values[] = {1.0e20f, -1.0e20f, float(i % 97) + float(epoch),
                                                -float(i % 13), 0.25f};
                        for (size_t r = 0; r < 5; ++r) src[r][i + 1] = values[r];
                    }
                    assert(pool.run(ranks.data(), outputs.data(), n,
                                    std::chrono::steady_clock::now() + std::chrono::seconds(2)));
                    for (size_t i = 0; i < n; ++i) {
                        float expected = src[0][i + 1];
                        for (size_t r = 1; r < 5; ++r) expected += src[r][i + 1];
                        for (size_t r = 0; r < 5; ++r)
                            assert(std::memcmp(&outputs[r][i], &expected, sizeof(float)) == 0);
                    }
                    for (size_t r = 0; r < 5; ++r) {
                        const auto & d = dst[r];
                        for (size_t i = 0; i < prefix[r]; ++i) assert(d[i] == -12345.0f);
                        for (size_t i = prefix[r] + n; i < d.size(); ++i) assert(d[i] == -12345.0f);
                    }
                }
            }
        }
        for (auto & d : dst) std::fill(d.begin(), d.end(), -12345.0f);
        assert(!pool.run(ranks.data(), outputs.data(), capacity,
                         std::chrono::steady_clock::now() - std::chrono::seconds(1)));
        assert(!pool.run(ranks.data(), outputs.data(), capacity,
                         std::chrono::steady_clock::now() + std::chrono::seconds(2)));
        for (const auto & d : dst) for (float value : d) assert(value == -12345.0f);
    }
    std::puts("relay tiles: rank-ordered cancellation, active tails, guards, changed epochs, deadline poison passed");
}
