#pragma once

#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <stdexcept>
#include <thread>
#if defined(__x86_64__) || defined(_M_X64) || defined(__i386__)
#include <immintrin.h>
#endif

#if defined(__GNUC__) && (defined(__x86_64__) || defined(__i386__))
__attribute__((target("avx2")))
static size_t tp5_star_sum_broadcast_f32_avx2(const void * const * ranks, float * const * dsts,
                                              size_t begin, size_t end) {
    size_t i = begin;
    const bool aligned = std::all_of(dsts, dsts + 5, [i](const float * p) {
        return (reinterpret_cast<uintptr_t>(p + i) & 31u) == 0;
    });
    if (!aligned) return i;
    for (; i + 16 <= end; i += 16) {
        __m256 sum0 = _mm256_loadu_ps((const float *) ranks[0] + i);
        __m256 sum1 = _mm256_loadu_ps((const float *) ranks[0] + i + 8);
        for (size_t r = 1; r < 5; ++r) {
            sum0 = _mm256_add_ps(sum0, _mm256_loadu_ps((const float *) ranks[r] + i));
            sum1 = _mm256_add_ps(sum1, _mm256_loadu_ps((const float *) ranks[r] + i + 8));
        }
        for (size_t r = 0; r < 5; ++r) {
            _mm256_stream_ps(dsts[r] + i, sum0);
            _mm256_stream_ps(dsts[r] + i + 8, sum1);
        }
    }
    for (; i + 8 <= end; i += 8) {
        __m256 sum = _mm256_loadu_ps((const float *) ranks[0] + i);
        for (size_t r = 1; r < 5; ++r) {
            sum = _mm256_add_ps(sum, _mm256_loadu_ps((const float *) ranks[r] + i));
        }
        for (size_t r = 0; r < 5; ++r) {
            _mm256_stream_ps(dsts[r] + i, sum);
        }
    }
    return i;
}
#endif

static void tp5_accumulate_broadcast_star_f32(const void * const * rank_ptrs, float * const * dsts,
                                               size_t n_elems, size_t begin = 0) {
    size_t i = begin;
#if defined(__GNUC__) && (defined(__x86_64__) || defined(__i386__))
    if (__builtin_cpu_supports("avx2")) {
        i = tp5_star_sum_broadcast_f32_avx2(rank_ptrs, dsts, i, n_elems);
    }
#endif
    for (; i < n_elems; ++i) {
        float sum = ((const float *) rank_ptrs[0])[i];
        for (size_t r = 1; r < 5; ++r) sum += ((const float *) rank_ptrs[r])[i];
        for (size_t r = 0; r < 5; ++r) dsts[r][i] = sum;
    }
#if defined(__x86_64__) || defined(_M_X64) || defined(__i386__)
    // Every writer orders its own WC stores before reporting completion.
    _mm_sfence();
#endif
}

// Serialized communicator-owned dispatcher. Each element is summed in the
// reference rank order; only disjoint, cache-line-aligned coordinate tiles run
// concurrently. The caller alone owns headers, epochs and bank retirement.
class vk_tp5_relay_tiles {
public:
    explicit vk_tp5_relay_tiles(size_t tiles) : count(tiles) {
        if (count != 2 && count != 4) throw std::invalid_argument("relay tiles must be 2 or 4");
        try {
            for (size_t i = 1; i < count; ++i) workers[i - 1] = std::thread([this, i] { work(i); });
        } catch (...) {
            stop_and_join();
            throw;
        }
    }
    ~vk_tp5_relay_tiles() { stop_and_join(); }
    vk_tp5_relay_tiles(const vk_tp5_relay_tiles &) = delete;
    vk_tp5_relay_tiles & operator=(const vk_tp5_relay_tiles &) = delete;

    bool run(const void * const * inputs, float * const * outputs, size_t elements,
             std::chrono::steady_clock::time_point deadline) {
        if (stop.load(std::memory_order_relaxed)) return false;
        if (std::chrono::steady_clock::now() >= deadline) {
            stop_and_join();
            return false;
        }
        std::copy_n(inputs, 5, ranks.begin());
        std::copy_n(outputs, 5, dsts.begin());
        n_elems = elements;
        const uint64_t next = generation.load(std::memory_order_relaxed) + 1;
        generation.store(next, std::memory_order_release);
        tile(0);
        bool expired = std::chrono::steady_clock::now() >= deadline;
        for (size_t i = 1; i < count; ++i) {
            for (size_t spin = 0; done[i].value.load(std::memory_order_acquire) != next; ++spin) {
                if ((spin & 1023u) == 0 && std::chrono::steady_clock::now() >= deadline) expired = true;
                pause();
            }
        }
        // Even on timeout, retire all writes before stack/bank reuse. A poisoned
        // dispatcher refuses later work; no partially written generation is published.
        if (expired) stop_and_join();
        return !expired;
    }

private:
    struct alignas(64) completion { std::atomic<uint64_t> value{0}; };
    const size_t count;
    std::array<std::thread, 3> workers;
    std::array<completion, 4> done;
    std::array<const void *, 5> ranks{};
    std::array<float *, 5> dsts{};
    size_t n_elems = 0;
    alignas(64) std::atomic<uint64_t> generation{0};
    alignas(64) std::atomic<bool> stop{false};

    static void pause() {
#if defined(__x86_64__) || defined(_M_X64) || defined(__i386__)
        _mm_pause();
#else
        std::this_thread::yield();
#endif
    }
    void tile(size_t i) {
        const size_t lines = (n_elems + 15) / 16;
        const size_t begin = std::min(n_elems, (lines * i / count) * 16);
        const size_t end = std::min(n_elems, (lines * (i + 1) / count) * 16);
        tp5_accumulate_broadcast_star_f32(ranks.data(), dsts.data(), end, begin);
    }
    void work(size_t i) {
        uint64_t observed = 0;
        while (!stop.load(std::memory_order_acquire)) {
            const uint64_t current = generation.load(std::memory_order_acquire);
            if (current == observed) { pause(); continue; }
            tile(i);
            observed = current;
            done[i].value.store(current, std::memory_order_release);
        }
    }
    void stop_and_join() {
        stop.store(true, std::memory_order_release);
        for (auto & worker : workers) if (worker.joinable()) worker.join();
    }
};
